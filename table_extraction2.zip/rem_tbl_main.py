"""
main.py — MD&A Table Removal Pipeline
======================================

Steps:
1. Load the parquet file from the workspace directory.
2. Take the first 50 rows (head(50)) to keep the data manageable.
3. For each row, run TableExtractor on ``mda_text``:
   - Detected tables are replaced with ``[table extracted]``.
   - The cleaned text is stored in a new column ``remTbl_mda_txt``.
4. Save the modified DataFrame (with ``remTbl_mda_txt`` added) as a new
   parquet file: ``sample30naics3_yr_data_remTbl.parquet``.

Usage:
    python main.py
"""

from __future__ import annotations

import os
import sys
import pandas as pd

# ---------------------------------------------------------------------------
# Make sure table_extraction is importable from the same directory
# ---------------------------------------------------------------------------
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

from table_extraction import TableExtractor  # noqa: E402

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
INPUT_PARQUET  = os.path.join(SCRIPT_DIR, "sample30naics3_yr_data.parquet")
OUTPUT_PARQUET = os.path.join(SCRIPT_DIR, "sample30naics3_yr_data_remTbl.parquet")
N_ROWS = 50   # use only the first N rows


def build_document_id(row: pd.Series) -> str:
    """Construct a unique document ID from available identifiers."""
    cik  = str(row.get("cik",  ""))
    year = str(row.get("year", ""))
    acc  = str(row.get("accession", ""))
    return acc if acc else f"{cik}_{year}"


def main() -> None:
    # ------------------------------------------------------------------
    # 1. Load & truncate
    # ------------------------------------------------------------------
    print(f"[main] Loading parquet: {INPUT_PARQUET}")
    df = pd.read_parquet(INPUT_PARQUET)
    print(f"[main] Full dataset shape: {df.shape}")

    df = df.head(N_ROWS).copy()
    print(f"[main] Working with head({N_ROWS}): {df.shape}")

    # ------------------------------------------------------------------
    # 2. Extract tables row-by-row
    # ------------------------------------------------------------------
    extractor = TableExtractor(min_formatted_rows=3)

    cleaned_texts = []
    total_tables  = 0

    for idx, row in df.iterrows():
        raw_text = row.get("mda_text", "") or ""

        doc_id = build_document_id(row)
        cik    = str(row.get("cik",    ""))
        ein    = str(row.get("ein",    ""))
        sic    = str(row.get("sic",    ""))
        naics3 = str(row.get("naics3", ""))
        year   = str(row.get("year",   ""))

        cleaned, tables = extractor.extract(
            text        = raw_text,
            document_id = doc_id,
            cik         = cik,
            ein         = ein,
            sic         = sic,
            naics3      = naics3,
            year        = year,
            metadata    = {},
        )

        cleaned_texts.append(cleaned)
        total_tables += len(tables)

    print(f"[main] Total tables extracted across {N_ROWS} rows: {total_tables}")

    # ------------------------------------------------------------------
    # 3. Add remTbl_mda_txt column
    # ------------------------------------------------------------------
    df["remTbl_mda_txt"] = cleaned_texts

    print(f"[main] Added column 'remTbl_mda_txt'. Final columns: {list(df.columns)}")

    # ------------------------------------------------------------------
    # 4. Save new parquet
    # ------------------------------------------------------------------
    df.to_parquet(OUTPUT_PARQUET, index=False)
    print(f"[main] Saved: {OUTPUT_PARQUET}")
    print("[main] Done.")


if __name__ == "__main__":
    main()
