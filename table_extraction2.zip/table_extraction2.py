"""
Step 2 — Table extraction (no SQLite)
======================================

Responsibilities:

1. ``TableExtractor`` — detect HTML and whitespace-aligned tables inside
   ``mda_text``, remove them, replace each occurrence with ``[table extracted]``,
   and return the *cleaned* text along with a list of ``ExtractedTable`` records.

SQLite storage has been removed. Tables are returned in-memory only.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


@dataclass
class ExtractedTable:
    """One table extracted from an MD&A document."""
    table_id: str
    source_document_id: str
    table_html: str
    table_data: List[List[str]]
    table_title: str
    cik: str
    ein: str = ""
    sic: str = ""
    naics3: str = ""
    year: str = ""
    table_index: int = 0          # ordinal within the filing (0-based)
    metadata: Dict = field(default_factory=dict)


# ----------------------------------------------------------------------
# Extraction
# ----------------------------------------------------------------------
_HTML_TABLE_RE = re.compile(r"<table[^>]*>.*?</table>", re.IGNORECASE | re.DOTALL)
_ROW_RE = re.compile(r"<tr[^>]*>(.*?)</tr>", re.IGNORECASE | re.DOTALL)
_CELL_RE = re.compile(r"<t[dh][^>]*>(.*?)</t[dh]>", re.IGNORECASE | re.DOTALL)
_TAG_RE = re.compile(r"<[^>]+>")
_ENTITY_RE = re.compile(r"&[a-z]+;|&#\d+;", re.IGNORECASE)


class TableExtractor:
    """Detect + remove tables from SEC filing MD&A text.

    Each table span is replaced with ``[table extracted]`` in the cleaned text.
    No data is written to SQLite or any persistent store.
    """

    def __init__(self, min_formatted_rows: int = 3):
        """
        Args:
            min_formatted_rows: Whitespace-aligned blocks need at least this
                many lines before we treat them as a table (avoids stripping
                ordinary indented prose).
        """
        self.min_formatted_rows = min_formatted_rows
        self.all_tables: List[ExtractedTable] = []

    # -- HTML --------------------------------------------------------
    def _detect_html_tables(self, text: str) -> List[Tuple[int, int, str]]:
        return [(m.start(), m.end(), m.group()) for m in _HTML_TABLE_RE.finditer(text)]

    def _parse_html_table(self, html: str) -> List[List[str]]:
        rows: List[List[str]] = []
        for row_match in _ROW_RE.finditer(html):
            cells = []
            for cell_match in _CELL_RE.finditer(row_match.group(1)):
                text = cell_match.group(1)
                text = _TAG_RE.sub("", text)
                text = _ENTITY_RE.sub(" ", text)
                cells.append(text.strip())
            if cells:
                rows.append(cells)
        return rows

    # -- whitespace-aligned -----------------------------------------
    def _detect_formatted_tables(self, text: str) -> List[Tuple[int, int, str]]:
        """Find blocks of consecutive lines that look like aligned columns."""
        tables = []
        lines = text.split("\n")
        block_start_line = None
        block_lines: List[str] = []

        # We need to know each line's character offset in the original text.
        line_offsets: List[int] = []
        offset = 0
        for line in lines:
            line_offsets.append(offset)
            offset += len(line) + 1   # +1 for the newline we split on

        def flush(end_line_idx: int) -> None:
            if block_start_line is None or len(block_lines) < self.min_formatted_rows:
                return
            start_pos = line_offsets[block_start_line]
            end_line = end_line_idx - 1
            end_pos = line_offsets[end_line] + len(lines[end_line])
            tables.append((start_pos, end_pos, "\n".join(block_lines)))

        for i, line in enumerate(lines):
            if re.search(r"\s{2,}|\t", line) and line.strip():
                if block_start_line is None:
                    block_start_line = i
                block_lines.append(line)
            else:
                flush(i)
                block_start_line = None
                block_lines = []
        flush(len(lines))
        return tables

    def _parse_formatted_table(self, table_text: str) -> List[List[str]]:
        rows = []
        for line in table_text.split("\n"):
            if line.strip():
                cells = re.split(r"\s{2,}|\t+", line.strip())
                if cells:
                    rows.append(cells)
        return rows

    # -- orchestrator ------------------------------------------------
    def extract(
        self,
        text: str,
        document_id: str,
        cik: str,
        ein: str,
        sic: str,
        naics3: str,
        year: str,
        metadata: Dict,
    ) -> Tuple[str, List[ExtractedTable]]:
        """Return ``(cleaned_text, [ExtractedTable])`` for one filing.

        Each detected table is replaced with ``[table extracted]`` in the
        cleaned text. No SQLite or file I/O is performed.
        """
        if not text:
            return text, []

        html_spans = self._detect_html_tables(text)
        formatted_spans_raw = self._detect_formatted_tables(text)

        # Drop formatted spans that overlap an HTML span (already covered).
        formatted_spans = []
        for s, e, body in formatted_spans_raw:
            overlap = any(
                s < he and e > hs for hs, he, _ in html_spans
            )
            if not overlap:
                formatted_spans.append((s, e, body))

        extracted: List[ExtractedTable] = []
        running_idx = 0

        for s, e, html in html_spans:
            rows = self._parse_html_table(html)
            title_match = re.search(r"([^\n]*?)\s*<table", html[:300], re.IGNORECASE)
            title = title_match.group(1).strip() if title_match else f"Table {running_idx + 1}"
            extracted.append(ExtractedTable(
                table_id=f"{document_id}_html_{running_idx}",
                source_document_id=document_id,
                table_html=html,
                table_data=rows,
                table_title=title or f"Table {running_idx + 1}",
                cik=cik, ein=ein, sic=sic, naics3=naics3, year=year,
                table_index=running_idx,
                metadata=dict(metadata),
            ))
            running_idx += 1

        for s, e, body in formatted_spans:
            rows = self._parse_formatted_table(body)
            if len(rows) < self.min_formatted_rows:
                continue
            line_before = text[:s].split("\n")
            title = line_before[-1].strip() if line_before else f"Table {running_idx + 1}"
            extracted.append(ExtractedTable(
                table_id=f"{document_id}_fmt_{running_idx}",
                source_document_id=document_id,
                table_html=body,
                table_data=rows,
                table_title=title or f"Table {running_idx + 1}",
                cik=cik, ein=ein, sic=sic, naics3=naics3, year=year,
                table_index=running_idx,
                metadata=dict(metadata),
            ))
            running_idx += 1

        # Replace all table spans with [table extracted] (back-to-front so offsets stay valid).
        all_spans = sorted(
            [(s, e) for s, e, _ in html_spans] + [(s, e) for s, e, _ in formatted_spans],
            reverse=True,
        )
        cleaned = text
        for s, e in all_spans:
            cleaned = cleaned[:s] + " [table extracted] " + cleaned[e:]

        # Tidy up the cleaned text (collapse runs of blank lines).
        cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)

        self.all_tables.extend(extracted)
        return cleaned, extracted


if __name__ == "__main__":
    # Tiny self-test
    sample = """
    Item 7.  MD&A

    Overview

    Revenue increased.

    <table><tr><th>Year</th><th>Revenue</th></tr><tr><td>2024</td><td>100</td></tr></table>

    Liquidity

    Cash flow was strong.
    """
    extractor = TableExtractor()
    cleaned, tabs = extractor.extract(
        sample, "DOC1", "0000001", "12-34", "9999", "311", "2024", {},
    )
    print("Cleaned text:\n", cleaned)
    print("Tables extracted:", len(tabs))
    print("Table title:", tabs[0].table_title if tabs else "none")
