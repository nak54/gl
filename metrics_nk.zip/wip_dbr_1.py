#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#hamming dist distance between records
import pandas as pd

d_dir='/home/d1ttb/nkpywork/synth_data/eda_misc_metrics/'
max_cardinality_catcol=78 #used to identify numeric vs cat col
r_d=pd.read_csv(d_dir+'rd_1718.csv')
s_d=pd.read_csv(d_dir+'sd_1718.csv')
nunique_cols=r_d.nunique(dropna=True)
cat_cols = nunique_cols[nunique_cols <= max_cardinality_catcol].index.tolist()
all_cols = r_d.columns
num_cols = [c for c in all_cols if c not in cat_cols]
print(len(cat_cols))
print(len(num_cols))


# In[2]:


import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.neighbors import NearestNeighbors


# In[ ]:


def fix_num_cols(real_df, synth_df):
    global num_cols
    global cat_cols
    real_dfn=real_df.loc[:,num_cols]
    synth_dfn=synth_df.loc[:,num_cols]
    real_dfc=synth_df.loc[:,cat_cols]
    synth_dfc=synth_df.loc[:,cat_cols]
    real_dfn = real_dfn.apply(pd.to_numeric, errors="coerce").to_numpy(dtype=np.float64)
    real_dfn=pd.DataFrame(real_dfn)
    synth_dfn = synth_dfn.apply(pd.to_numeric, errors="coerce").to_numpy(dtype=np.float64)
    synth_dfn=pd.DataFrame(synth_dfn)

    real_df_n=pd.concat([ real_dfc,  real_dfn], axis=1, ignore_index=True)
    synth_df_n=pd.concat([ synth_dfc,  synth_dfn], axis=1, ignore_index=True)
    real_df_n.columns =cat_cols+num_cols
    synth_df_n.columns =cat_cols+num_cols

    return real_df_n, synth_df_n

def _make_preprocessor(df: pd.DataFrame):
    '''
    if cat_cols is None:
        cat_cols = [c for c in df.columns if df[c].dtype == "object" or str(df[c].dtype).startswith("category")]
    if num_cols is None:
        num_cols = [c for c in df.columns if c not in cat_cols] 
    '''
    global cat_cols
    global num_cols
    pre = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(with_mean=True, with_std=True), num_cols),
            ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=True), cat_cols),
        ],
        remainder="drop",
        sparse_threshold=0.3,
    )
    return pre, cat_cols, num_cols

def distance_to_closest_record(real_df: pd.DataFrame, synth_df: pd.DataFrame, 
                               metric="mahalanobis", n_jobs=None):
    """
    Returns:
      dcr_sr: distances from each synthetic row to nearest real row
      dcr_rs: distances from each real row to nearest synthetic row
    """
    pre, cat_cols, num_cols = _make_preprocessor(real_df)
    pipe = Pipeline([("pre", pre)])

    real_df, synth_df = fix_num_cols(real_df,synth_df)



    Xr = pipe.fit_transform(real_df)
    Xs = pipe.transform(synth_df)
    Vr = np.cov(Xr, rowvar=False)      # covariance of X
    VIr = np.linalg.pinv(Vr)  # or np.linalg.inv(V) if well-conditioned
    Vs = np.cov(Xs, rowvar=False)      # covariance of X
    VIs = np.linalg.pinv(Vs)  # or np.linalg.inv(V) if well-conditioned

    nn_r = NearestNeighbors(n_neighbors=1, metric=metric, metric_params={"VI": VIr}, n_jobs=n_jobs).fit(Xr)
    dcr_sr, _ = nn_r.kneighbors(Xs, n_neighbors=1, return_distance=True)
    dcr_sr = dcr_sr.ravel()

    nn_s = NearestNeighbors(n_neighbors=1, metric=metric, metric_params={"VI": VIs}, n_jobs=n_jobs).fit(Xs)
    dcr_rs, _ = nn_s.kneighbors(Xr, n_neighbors=1, return_distance=True)
    dcr_rs = dcr_rs.ravel()

    return dcr_sr, dcr_rs

def distance_to_closest_record2(real_df: pd.DataFrame, synth_df: pd.DataFrame, 
                               metric="mahalanobis", n_jobs=None):
    """
    Returns:
      dcr_sr: distances from each synthetic row to nearest real row
      dcr_rs: distances from each real row to nearest synthetic row
    """
    pre, cat_cols, num_cols = _make_preprocessor(real_df)
    pipe = Pipeline([("pre", pre)])

    real_df, synth_df = fix_num_cols(real_df,synth_df)



    Xr = pipe.fit_transform(real_df)
    Xs = pipe.transform(synth_df)
    #shared inv cov to make distances comparable
    Xrs=np.vstack([Xr, Xs])
    '''
    Vr = np.cov(Xr, rowvar=False)      # covariance of X
    VIr = np.linalg.pinv(Vr)  # or np.linalg.inv(V) if well-conditioned
    Vs = np.cov(Xs, rowvar=False)      # covariance of X
    VIs = np.linalg.pinv(Vs)  # or np.linalg.inv(V) if well-conditioned
    '''
    Vrs = np.cov(Xrs, rowvar=False)      # covariance of X
    VIrs = np.linalg.pinv(Vrs)  # or np.linalg.inv(V) if well-conditioned

    nn_r = NearestNeighbors(n_neighbors=1, metric=metric, metric_params={"VI": VIrs}, n_jobs=n_jobs).fit(Xr)
    dcr_sr, _ = nn_r.kneighbors(Xs, n_neighbors=1, return_distance=True)
    dcr_sr = dcr_sr.ravel()

    nn_s = NearestNeighbors(n_neighbors=1, metric=metric, metric_params={"VI": VIrs}, n_jobs=n_jobs).fit(Xs)
    dcr_rs, _ = nn_s.kneighbors(Xr, n_neighbors=1, return_distance=True)
    dcr_rs = dcr_rs.ravel()

    return dcr_sr, dcr_rs


def summarize_dcr(d: np.ndarray):
    return {
        "n": int(len(d)),
        "min": round(float(np.min(d)),ndigits=2),
        "p01": round(float(np.quantile(d, 0.01)),ndigits=2),
        "p05": round(float(np.quantile(d, 0.05)),ndigits=2),
        "median": round(float(np.median(d)),ndigits=2),
        "mean": round(float(np.mean(d)),ndigits=2),
        "p95": round(float(np.quantile(d, 0.95)),ndigits=2),
        "p99": round(float(np.quantile(d, 0.99)),ndigits=2),
        "max": round(float(np.max(d)),ndigits=2),
    }


# In[4]:


dcr_sr1, dcr_rs1 = distance_to_closest_record(r_d, s_d)
dcr_sr2, dcr_rs2 = distance_to_closest_record2(r_d, s_d)
print("Synth->Real:", summarize_dcr(dcr_sr1))
print("Real->Synth:", summarize_dcr(dcr_rs1))
print('stacked cov for comparing')
print("Synth->Real:", summarize_dcr(dcr_sr2))
print("Real->Synth:", summarize_dcr(dcr_rs2))


# In[5]:


#np.savez('dist_c_r.npz',dcr_sr=dcr_sr, dcr_rs=dcr_rs)


# In[6]:


get_ipython().run_line_magic('who', '')


# In[ ]:


#dcr_rs=dcr_sr
assert "dcr_sr1" in globals() and "dcr_rs1" in globals()
assert "dcr_sr2" in globals() and "dcr_rs2" in globals()

np.savez("dist_bet_r_260416.npz", dcr_sr1=dcr_sr1, dcr_rs1=dcr_rs1, dcr_sr2=dcr_sr2, dcr_rs2=dcr_rs2)
#del dcr_rs, dcr_sr
#z = np.load("dist_c_r.npz", allow_pickle=True)
#print("saved:", z.files)


# In[8]:


import numpy as np
import matplotlib.pyplot as plt

# dcr_sr: distances from each synthetic point to nearest real point
# dcr_rs: distances from each real point to nearest synthetic point

# Optional: choose a common x-limit to make plots comparable (robust to outliers)
hi = np.percentile(np.concatenate([dcr_sr2, dcr_rs2]), 99)
#hi = np.percentile(np.concatenate([dcr_sr]), 99)

fig, axes = plt.subplots(1, 3, figsize=(15, 4))

# 1) Overlaid histogram
bins = 50
axes[0].hist(dcr_sr2, bins=bins, alpha=0.5, label="dcr_sr (S→R)", range=(0, hi), density=True)
axes[0].hist(dcr_rs2, bins=bins, alpha=0.5, label="dcr_rs (R→S)", range=(0, hi), density=True)
axes[0].set_title("Histogram (density)")
axes[0].set_xlabel("NN distance")
axes[0].set_ylabel("Density")
axes[0].legend()

# 2) ECDF (often clearer than hist)
def ecdf(x):
    x = np.sort(x)
    y = np.arange(1, len(x) + 1) / len(x)
    return x, y

x1, y1 = ecdf(dcr_sr2)
x2, y2 = ecdf(dcr_rs2)
axes[1].plot(x1, y1, label="dcr_sr (S→R)")
axes[1].plot(x2, y2, label="dcr_rs (R→S)")
axes[1].set_xlim(0, hi)
axes[1].set_title("ECDF")
axes[1].set_xlabel("NN distance")
axes[1].set_ylabel("Fraction ≤ x")
axes[1].legend()

# 3) Boxplot / summary comparison
axes[2].boxplot([dcr_sr2, dcr_rs2], labels=["S→R", "R→S"], showfliers=False)
axes[2].set_title("Boxplot (no fliers)")
axes[2].set_ylabel("NN distance")

plt.tight_layout()
plt.show()


# In[9]:


import numpy as np
import matplotlib.pyplot as plt

hi = np.percentile(np.concatenate([dcr_sr2, dcr_rs2]), 99)
plt.figure(figsize=(7,4))
plt.hist(dcr_sr2, bins=60, alpha=0.45, label="dcr_sr (S→R)", range=(0, hi), density=True)
plt.hist(dcr_rs2, bins=60, alpha=0.45, label="dcr_rs (R→S)", range=(0, hi), density=True)

plt.axvline(np.median(dcr_sr2), color="C0", linestyle="--", linewidth=2, label="median S→R")
plt.axvline(np.median(dcr_rs2), color="C1", linestyle="--", linewidth=2, label="median R→S")

plt.xlabel("NN distance")
plt.ylabel("Density")
plt.title("NN distance distributions + medians")
plt.legend()
plt.tight_layout()
plt.show()

