#!/usr/bin/env python
# coding: utf-8

# In[2]:


import gower
import pandas as pd
import numpy as np

data = pd.DataFrame({
    'age': [20, 30, 40, 50],      # range = 30 (50-20)
    'salary': [30000, 50000, 70000, 90000]  # range = 60000
})

# Gower distance between first two records:
# age contribution: |20 - 30| / 30 = 0.333
# salary contribution: |30000 - 50000| / 60000 = 0.333
# average: (0.333 + 0.333) / 2 = 0.333
data_float = data.astype("float64")
dist = gower.gower_matrix(data_float)
print(f"Distance [0,1]: {dist[0,1]}")  # Should be ~0.333


# In[3]:


from sklearn.pipeline import Pipeline
from sklearn.neighbors import NearestNeighbors

d_dir='/home/d1ttb/nkpywork/synth_data/eda_misc_metrics/'
max_cardinality_catcol=78 #used to identify numeric vs cat col
r_d=pd.read_csv(d_dir+'rd_1718.csv')
s_d=pd.read_csv(d_dir+'sd_1718.csv')
nunique_cols=r_d.nunique(dropna=True)
cat_cols = nunique_cols[nunique_cols <= max_cardinality_catcol].index.tolist()
all_cols = r_d.columns
num_cols = [c for c in all_cols if c not in cat_cols]
print(len(cat_cols))
print(len(num_cols))


# In[4]:


from sklearn.preprocessing import  OrdinalEncoder

def encode_cats_same_space(r_d, s_d, cat_cols):
    ord_enc = OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1)

    tmp1 = r_d[cat_cols].copy()
    tmp2 = s_d[cat_cols].copy()

    # align dtypes + fill missing consistently
    tmp1 = tmp1.astype("string").fillna("unfilled")
    tmp2 = tmp2.astype("string").fillna("unfilled")

    # fit on union so codes mean the same thing in both
    combined = pd.concat([tmp1, tmp2], axis=0, ignore_index=True)

    ord_enc.fit(combined)

    n_tmp1 = ord_enc.transform(tmp1).astype(np.int64)
    n_tmp2 = ord_enc.transform(tmp2).astype(np.int64)

    return n_tmp1, n_tmp2, ord_enc

def summarize_dcr(d: np.ndarray):
    return {
        "n": int(len(d)),
        "min": round(float(np.min(d)),ndigits=2),
        "p01": round(float(np.quantile(d, 0.01)),ndigits=2),
        "p05": round(float(np.quantile(d, 0.05)),ndigits=2),
        "median": round(float(np.median(d)),ndigits=2),
        "mean": round(float(np.mean(d)),ndigits=2),
        "p95": round(float(np.quantile(d, 0.95)),ndigits=2),
        "p99": round(float(np.quantile(d, 0.99)),ndigits=2),
        "max": round(float(np.max(d)),ndigits=2),
    }


# In[ ]:


r_d_cn,s_d_cn,ord_enc=encode_cats_same_space(r_d,s_d,cat_cols)





# In[17]:


tmp11=pd.DataFrame(r_d_cn,columns=cat_cols)
tmp11=tmp11.astype("category")
tmp22=pd.DataFrame(r_d_cn,columns=cat_cols)
tmp22=tmp22.astype("category")


# In[21]:


ccols = tmp11.select_dtypes(include=["category"]).columns.tolist()
print(ccols)


# In[22]:


r_d2 = pd.concat([tmp11,r_d[num_cols].copy()], ignore_index=True, axis=1)
s_d2 = pd.concat([tmp22,s_d[num_cols].copy()], ignore_index=True, axis=1)


# In[23]:


r_d2.columns=cat_cols+num_cols
s_d2.columns=cat_cols+num_cols
r_d2.dtypes


# In[27]:


from sklearn.pipeline import Pipeline
#data already pre proc to cat and num
pipe = Pipeline([
    ("pre", "passthrough")
])
Xr = pipe.fit_transform(r_d2).astype(np.float64, copy=False)
Xs = pipe.transform(s_d2).astype(np.float64, copy=False)

dist_sr = gower.gower_matrix(Xs, Xr)
dcr_sr = dist_sr.min(axis=1)


# In[25]:


print("Synth->Real:", summarize_dcr(dcr_sr))


# In[29]:


import matplotlib.pyplot as plt
# Histogram
plt.figure(figsize=(10, 6))
plt.hist(dcr_sr, bins=50, alpha=0.7, edgecolor='black')
plt.axvline(dcr_sr.mean(), color='red', linestyle='--', 
            label=f'Mean: {dcr_sr.mean():.3f}')
plt.axvline(np.median(dcr_sr), color='green', linestyle='--', 
            label=f'Median: {np.median(dcr_sr):.3f}')
plt.xlabel("Gower Distance to Nearest Real Record")
plt.ylabel("Count")
plt.title("Distance Distribution: Synthetic → Real")
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()


# In[32]:


# Check for exact duplicates
duplicates = s_d2.merge(r_d2, how='inner', indicator=False)
print(f"Exact duplicates: {len(duplicates)} / {len(s_d2)}")



# In[33]:


# Or check min distances

print(f"Records with distance=0: {(dcr_sr == 0).sum()}")
print(f"Min distances stats:\n{pd.Series(dcr_sr).describe()}")

