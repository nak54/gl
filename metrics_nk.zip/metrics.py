#IMPORTING PACKAGES
import numpy as np
import pandas as pd
from scipy.linalg import pinv
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.neighbors import NearestNeighbors
import gower

#LOADING REAL & SYNTHETIC DATA
d_dir = '/projects/syntax/SynTax/data/'
df_real = pd.read_csv(d_dir+'rd_1718.csv')
df_synth = pd.read_csv(d_dir+'sd_1718.csv')

#SUBFUNCTION1-IDENTIFY NUMERICAL VS CATEGORICAL COLUMNS USING CARDINAL THTESHHOLD
def get_col_types_by_cardinality(df, max_cardinality_catcol=78):
    nunique_cols = df.nunique(dropna=True)
    cat_cols = nunique_cols[
        nunique_cols <= max_cardinality_catcol
    ].index.tolist()
    num_cols = [
        col for col in df.columns
        if col not in cat_cols
    ]
    return num_cols, cat_cols

#SUBFUNCTION2-CLEAN CATEGORICAL COLUMNS FOR DISTANCE METRICS
def clean_for_metrics(df_real, df_synth, max_cardinality_catcol=78):
    df_real = df_real.copy()
    df_synth = df_synth.copy()

    numeric_cols, categorical_cols = get_col_types_by_cardinality(
        df_real,
        max_cardinality_catcol=max_cardinality_catcol
    )

    for col in categorical_cols:
        df_real[col] = df_real[col].fillna("unfilled").astype(str)
        df_synth[col] = df_synth[col].fillna("unfilled").astype(str)
    return df_real, df_synth

#SUBFUNCTION3-DETERMINE ADAPTIVE HISTOGRAM BIN COUNT
def doanes_bins(x):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = x.size
    if n < 3:
        return 1
    mu = x.mean()
    s = x.std(ddof=1)
    if s == 0:
        return 1
    m3 = np.mean((x - mu) ** 3)
    g1 = m3 / (s ** 3)

    sigma_g1 = np.sqrt(
        6 * (n - 2) / ((n + 1) * (n + 3))
    )
    k = 1 + np.log2(n) + np.log2(
        1 + np.abs(g1) / (sigma_g1 + 1e-30)
    )
    return int(np.ceil(k))

#SUBFUNCTION4-COMPUTE 1D HELLINGER DISTANCE FOR NUMERICAL COLUMNS
def hellinger_hist_1d_doane(real, synth, eps=1e-12, edges=None):
    real = np.asarray(real, dtype=float)
    synth = np.asarray(synth, dtype=float)
    real = real[np.isfinite(real)]
    synth = synth[np.isfinite(synth)]
    if edges is None:
        if real.size and synth.size:
            data = np.concatenate([real, synth])
        elif real.size:
            data = real
        elif synth.size:
            data = synth
        else:
            return np.nan, None
        bins = doanes_bins(data)
        _, edges = np.histogram(data, bins=bins)
    hr, _ = np.histogram(real, bins=edges)
    hs, _ = np.histogram(synth, bins=edges)
    pr = hr.astype(float) + eps
    ps = hs.astype(float) + eps
    pr = pr / pr.sum()
    ps = ps / ps.sum()
    h = (1 / np.sqrt(2)) * np.linalg.norm(
        np.sqrt(pr) - np.sqrt(ps)
    )
    return float(h), edges

#SUBFUNCTION5-COMPUTE HELLINGER DISTANCE FOR CATEGORICAL COLUMNS
def hellinger_cat(real, synth, eps=1e-12):
    real = pd.Series(real).astype(str).fillna("unfilled").to_numpy()
    synth = pd.Series(synth).astype(str).fillna("unfilled").to_numpy()
    categories = np.unique(
        np.concatenate([real, synth]).astype(str)
    )
    pr = np.array([(real == c).sum() for c in categories], dtype=float) + eps
    ps = np.array([(synth == c).sum() for c in categories], dtype=float) + eps
    pr = pr / pr.sum()
    ps = ps / ps.sum()
    h = (1 / np.sqrt(2)) * np.linalg.norm(np.sqrt(pr) - np.sqrt(ps))
    return float(h), categories


#SUBFUNCTION6-CALCULATE COLUMN-WISE HELLINGER DISTANCES
def hellinger_calculation(df_real, df_synth, max_cardinality_catcol=78):
    nunique_cols = df_real.nunique(dropna=True)
    categorical_cols = nunique_cols[
        nunique_cols <= max_cardinality_catcol
    ].index.tolist()
    numeric_cols = [
        col for col in df_real.columns
        if col not in categorical_cols
    ]
    scores = {}
    for col in numeric_cols:
        h, edges = hellinger_hist_1d_doane(
            pd.to_numeric(df_real[col], errors="coerce").to_numpy(),
            pd.to_numeric(df_synth[col], errors="coerce").to_numpy()
        )
        scores[col] = round(float(h), 3)
    for col in categorical_cols:
        h, categories = hellinger_cat(
            df_real[col].astype("string").fillna("unfilled").to_numpy(),
            df_synth[col].astype("string").fillna("unfilled").to_numpy()
        )
        scores[col] = round(float(h), 3)
    scores_sorted = dict(
        sorted(
            scores.items(),
            key=lambda item: item[1],
            reverse=True
        )
    )
    valid_scores = [
        v for v in scores_sorted.values()
        if not pd.isna(v)
    ]
    average_score = (
        round(float(np.mean(valid_scores)), 3)
        if valid_scores
        else np.nan
    )
    return {
        "column_scores": scores_sorted,
        "average_score": average_score
    }


#SUBFUNCTION7-SUMMARIZE NEAREST-RECORD DISTANCE DISTRIBUTIONS
def summarize_distances(distances):
    return {
        "n": int(len(distances)),
        "min": round(float(np.min(distances)), 4),
        "p01": round(float(np.quantile(distances, 0.01)), 4),
        "p05": round(float(np.quantile(distances, 0.05)), 4),
        "median": round(float(np.median(distances)), 4),
        "mean": round(float(np.mean(distances)), 4),
        "p95": round(float(np.quantile(distances, 0.95)), 4),
        "p99": round(float(np.quantile(distances, 0.99)), 4),
        "max": round(float(np.max(distances)), 4)
    }


#SUBFUNCTION8-CALCULATE NEAREST-RECORD MAHALABONIS DISTANCE
def mahalanobis_nearest_record_calculation(df_real, df_synth):
    numeric_cols, categorical_cols = get_col_types_by_cardinality(df_real)
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), numeric_cols),
            ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), categorical_cols)
        ],
        remainder="drop"
    )
    pipeline = Pipeline([
        ("preprocessor", preprocessor)
    ])
    X_real = pipeline.fit_transform(df_real)
    X_synth = pipeline.transform(df_synth)
    X_real = np.asarray(X_real, dtype=float)
    X_synth = np.asarray(X_synth, dtype=float)
    X_stacked = np.vstack([X_real, X_synth])
    covariance_matrix = np.cov(X_stacked, rowvar=False)
    inverse_covariance = pinv(np.atleast_2d(covariance_matrix))
    nn_real = NearestNeighbors(
        n_neighbors=1,
        metric="mahalanobis",
        metric_params={"VI": inverse_covariance}
    )
    nn_real.fit(X_real)
    synth_to_real_distances, _ = nn_real.kneighbors(
        X_synth,
        n_neighbors=1,
        return_distance=True
    )
    nn_synth = NearestNeighbors(
        n_neighbors=1,
        metric="mahalanobis",
        metric_params={"VI": inverse_covariance}
    )
    nn_synth.fit(X_synth)

    real_to_synth_distances, _ = nn_synth.kneighbors(
        X_real,
        n_neighbors=1,
        return_distance=True
    )
    synth_to_real_distances = synth_to_real_distances.ravel()
    real_to_synth_distances = real_to_synth_distances.ravel()
    return {
        "Synthetic_to_Real": summarize_distances(synth_to_real_distances),
        "Real_to_Synthetic": summarize_distances(real_to_synth_distances)
    }


#SUBFUNCTION9-CALCULATE NEAREST-RECORD GOWER DISTANCE
def gower_nearest_record_calculation(df_real, df_synth):
    dist_matrix = gower.gower_matrix(
        df_synth,
        df_real
    )
    synth_to_real = dist_matrix.min(axis=1)

    dist_matrix_reverse = gower.gower_matrix(
        df_real,
        df_synth
    )
    real_to_synth = dist_matrix_reverse.min(axis=1)
    return {
        "Synthetic_to_Real": summarize_distances(synth_to_real),
        "Real_to_Synthetic": summarize_distances(real_to_synth)
    }


#MAIN FUNCTION, CALCULATES ALL METRICS RETURN RESULTS IN DICTIONARY FORMAT
def calculate_all_metrics(df_real, df_synth, sample_size=102053):
    df_real, df_synth = clean_for_metrics(df_real, df_synth)
    df_real_sample = df_real.sample(
        n=min(sample_size, len(df_real)),
        random_state=42
    )
    df_synth_sample = df_synth.sample(
        n=min(sample_size, len(df_synth)),
        random_state=42
    )
    output = {}
    print("Calculating Hellinger...")
    output["Hellinger"] = hellinger_calculation(df_real, df_synth)
    print("Calculating Mahalanobis nearest-record distances...")
    output["Mahalanobis"] = mahalanobis_nearest_record_calculation(
        df_real_sample,
        df_synth_sample
    )
    print("Calculating Gower nearest-record distances...")
    output["Gower"] = gower_nearest_record_calculation(
        df_real_sample,
        df_synth_sample
    )
    print("Done.")
    return output


#DISPLAYING OUTPUT
results = calculate_all_metrics(df_real, df_synth, sample_size = 100)
import pprint
pprint.pprint(results,sort_dicts=False, width=120)