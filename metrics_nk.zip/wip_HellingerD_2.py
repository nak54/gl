#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np

d_dir='/home/d1ttb/nkpywork/synth_data/eda_misc_metrics/'
max_cardinality_catcol=78 #used to identify numeric vs cat col
r_d=pd.read_csv(d_dir+'rd_1718.csv')
s_d=pd.read_csv(d_dir+'sd_1718.csv')
nunique_cols=r_d.nunique(dropna=True)
cat_cols = nunique_cols[nunique_cols <= max_cardinality_catcol].index.tolist()
all_cols = r_d.columns
num_cols = [c for c in all_cols if c not in cat_cols]
print(len(cat_cols))
print(len(num_cols))



# In[2]:


import numpy as np
import matplotlib.pyplot as plt

def _doanes_bins(x):
    """
    Doane's rule: bins = 1 + log2(n) + log2(1 + |g1|/sigma_g1)
    where g1 is sample skewness, sigma_g1 = sqrt(6(n-2)/((n+1)(n+3))).
    """
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = x.size
    if n < 3:
        return 1

    mu = x.mean()
    s = x.std(ddof=1)
    if s == 0:
        return 1

    # Fisher-Pearson standardized moment (sample skewness)
    m3 = np.mean((x - mu) ** 3)
    g1 = m3 / (s ** 3)

    sigma_g1 = np.sqrt(6 * (n - 2) / ((n + 1) * (n + 3)))
    k = 1 + np.log2(n) + np.log2(1 + np.abs(g1) / (sigma_g1 + 1e-30))

    return int(np.ceil(k))

def plot_hist_1d_doane(real, synth, eps=1e-12, edges=None, *, density=True, title=None):
    """
    Plot overlaid histograms for real vs synthetic using Doane bins (from combined data)
    unless `edges` are provided.

    Returns: (edges, hr, hs)
    """
    real = np.asarray(real, dtype=float)
    synth = np.asarray(synth, dtype=float)

    real = real[np.isfinite(real)]
    synth = synth[np.isfinite(synth)]

    if edges is None:
        data = np.concatenate([real, synth]) if (real.size and synth.size) else (real if real.size else synth)
        if data.size == 0:
            return None, None, None

        bins = _doanes_bins(data)
        _, edges = np.histogram(data, bins=bins)

    hr, _ = np.histogram(real, bins=edges)
    hs, _ = np.histogram(synth, bins=edges)

    widths = np.diff(edges)
    centers = (edges[:-1] + edges[1:]) / 2

    if density:
        # Convert counts to probability density-like values (prob mass / bin width)
        pr = hr.astype(float) + eps
        ps = hs.astype(float) + eps
        pr /= pr.sum()
        ps /= ps.sum()
        y_r = pr / widths
        y_s = ps / widths
        ylabel = "probability density (approx)"
    else:
        y_r = hr
        y_s = hs
        ylabel = "count"

    plt.figure(figsize=(9, 4))
    plt.bar(centers, y_r, width=widths, alpha=0.5, label="real", edgecolor="black", align="center")
    plt.bar(centers, y_s, width=widths, alpha=0.5, label="synthetic", edgecolor="black", align="center")

    plt.xlabel("value")
    plt.ylabel(ylabel)
    plt.title(title or "Real vs Synthetic histogram (Doane bins)")
    plt.legend()
    plt.tight_layout()
    plt.show()

    return edges, hr, hs


# In[3]:


r=r_d['net_income_amt'].to_numpy()
s=s_d['net_income_amt'].to_numpy()
plot_hist_1d_doane(r,s)


# In[4]:


r=r_d['exemption_amt'].to_numpy()
s=s_d['exemption_amt'].to_numpy()
plot_hist_1d_doane(r,s)


# In[ ]:


r=r_d['exemption_amt'].to_numpy()
s=s_d['exemption_amt'].to_numpy()
plot_hist_1d_doane(r,s)


# In[3]:


def hellinger_hist_1d_doane(real,synth , eps=1e-12, edges=None):
    """
    1D Hellinger distance using a histogram with Doane's rule bin count
    (good default for skewed distributions).

    - If `edges` is provided, those edges are used.
    - Otherwise, bin count is chosen via Doane on the *combined* samples,
      and edges are computed from the combined data to keep bins consistent.
    """
    real = np.asarray(real, dtype=float)
    synth = np.asarray(synth, dtype=float)

    real = real[np.isfinite(real)]
    synth = synth[np.isfinite(synth)]

    if edges is None:
        data = np.concatenate([real, synth]) if (real.size and synth.size) else (real if real.size else synth)
        if data.size == 0:
            return np.nan, None

        bins = _doanes_bins(data)
        _, edges = np.histogram(data, bins=bins)

    hr, _ = np.histogram(real, bins=edges)
    hs, _ = np.histogram(synth, bins=edges)

    pr = hr.astype(float) + eps
    ps = hs.astype(float) + eps
    pr /= pr.sum()
    ps /= ps.sum()

    h = (1 / np.sqrt(2)) * np.linalg.norm(np.sqrt(pr) - np.sqrt(ps))
    return h, edges

scores={}
for c in num_cols:
        print(c)
        r = r_d[c].to_numpy()
        s = s_d[c].to_numpy()
        scores[c] = hellinger_hist_1d_doane(r, s)


# In[4]:


scores_sorted = dict(sorted(scores.items(), key=lambda kv: kv[1][0], reverse=True))
#scores_sorted


# In[5]:


scores_only = {k: round(float(v[0]),ndigits=3) for k, v in scores_sorted.items()}
scores_only


# In[30]:


import numpy as np
import matplotlib.pyplot as plt


def hellinger_cat(real, synth, eps=1e-12):
    """
    Hellinger distance for categorical columns.
    Each unique category acts as a bin.
    """
    real = np.asarray(real)
    synth = np.asarray(synth)

    categories = np.union1d(real, synth)

    pr = np.array([(real == c).sum() for c in categories], dtype=float) + eps
    ps = np.array([(synth == c).sum() for c in categories], dtype=float) + eps
    pr /= pr.sum()
    ps /= ps.sum()

    h = (1 / np.sqrt(2)) * np.linalg.norm(np.sqrt(pr) - np.sqrt(ps))
    return h, categories


def plot_hist_cat(real, synth, eps=1e-12, *, density=True, title=None):
    """
    Overlaid bar charts for real vs synthetic categorical distributions.
    """
    real = np.asarray(real)
    synth = np.asarray(synth)

    categories = np.union1d(real, synth)
    x = np.arange(len(categories))
    width = 0.35

    hr = np.array([(real == c).sum() for c in categories], dtype=float)
    hs = np.array([(synth == c).sum() for c in categories], dtype=float)

    if density:
        pr = (hr + eps); ps = (hs + eps)
        pr /= pr.sum(); ps /= ps.sum()
        y_r, y_s = pr, ps
        ylabel = "probability"
    else:
        y_r, y_s = hr, hs
        ylabel = "count"

    plt.figure(figsize=(9, 4))
    plt.bar(x - width / 2, y_r, width, alpha=0.5, label="real", edgecolor="black")
    plt.bar(x + width / 2, y_s, width, alpha=0.5, label="synthetic", edgecolor="black")
    plt.xticks(x, categories, rotation=45, ha="right")
    plt.xlabel("category")
    plt.ylabel(ylabel)
    plt.title(title or "Real vs Synthetic (categorical)")
    plt.legend()
    plt.tight_layout()
    plt.show()

    return categories, hr.astype(int), hs.astype(int)




# In[ ]:


scores_sorted_c = dict(sorted(scores2.items(), key=lambda kv: kv[1][0], reverse=True))
scores_sorted_c


# In[28]:


from sklearn.preprocessing import  OrdinalEncoder

def encode_cats_same_space(r_d, s_d, cat_cols):
    ord_enc = OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1)

    tmp1 = r_d[cat_cols].copy()
    tmp2 = s_d[cat_cols].copy()

    # align dtypes + fill missing consistently
    tmp1 = tmp1.astype("string").fillna("unfilled")
    tmp2 = tmp2.astype("string").fillna("unfilled")

    # fit on union so codes mean the same thing in both
    combined = pd.concat([tmp1, tmp2], axis=0, ignore_index=True)

    ord_enc.fit(combined)

    n_tmp1 = ord_enc.transform(tmp1).astype(np.int64)
    n_tmp2 = ord_enc.transform(tmp2).astype(np.int64)

    return n_tmp1, n_tmp2, ord_enc   


# In[37]:


tmp1 = r_d[cat_cols].copy()
tmp2 = s_d[cat_cols].copy()

    # align dtypes + fill missing consistently
tmp1 = tmp1.astype("string").fillna("unfilled")
tmp2 = tmp2.astype("string").fillna("unfilled")


# In[29]:


r_d_cn,s_d_cn,ord_enc=encode_cats_same_space(r_d,s_d,cat_cols)


# In[38]:


# --- Usage ---
scores2 = {}
for c in range(13):
    print(cat_cols[c])
    r = r_d_cn[c]
    s = s_d_cn[c]
    scores2[c] = hellinger_cat(r, s)


# In[39]:


for c in range(13):
    print(cat_cols[c],scores2[c])
    r = r_d_cn[c]
    s = s_d_cn[c]
    plot_hist_cat(r, s)

