# Chapter 3. Data Models and Query Languages

> *The limits of my language mean the limits of my world.*
>
> — Ludwig Wittgenstein, *Tractatus Logico-Philosophicus* (1922)

Data models are perhaps the most important part of developing software, because of the profound effect they have not only on how the software is written, but also on how we think about the problem that we are solving.

Most applications are built by layering one data model on top of another. For each layer, the key question is how it is represented in terms of the next-lower layer. Here's an example of application layers from the highest to the lowest level:

1. As an application developer, you look at the real world (which includes people, organizations, goods, actions, money flows, sensors, etc.) and model it in terms of objects or data structures and APIs that manipulate those data structures, which are often specific to your application.
2. When you want to store those data structures, you express them in terms of a general-purpose data model, such as JSON or XML documents, tables in a relational database, or vertices and edges in a graph. Those data models are the topic of this chapter.
3. The engineers who built your database software decided on a way of representing that document, relational, or graph data in terms of bytes in memory, on disk, or on a network. The representation may allow the data to be queried, searched, manipulated, and processed in various ways. We will discuss these storage engine designs in Chapter 4.
4. On yet lower levels, hardware engineers have figured out how to represent bytes in terms of electrical currents, pulses of light, magnetic fields, and more.

In a complex application there may be more intermediary levels, such as APIs built upon APIs, but the basic idea is still the same: each layer hides the complexity of the layers below it by providing a clean data model. These abstractions allow different groups of people—for example, the engineers at the database vendor and the application developers using their database—to work together effectively.

Several data models are widely used in practice, often for different purposes. Some types of data and some queries are easy to express in one model and awkward in another. In this chapter we will explore those trade-offs by comparing the relational model, the document model, graph-based data models, event sourcing, and DataFrames. We will also briefly look at query languages that allow you to work with these models. This comparison will help you decide when to use which model.

---

## Terminology: Declarative Query Languages

Many of the query languages discussed in this chapter (such as SQL, Cypher, SPARQL, and Datalog) are declarative, which means that you specify the pattern of the data you want—what conditions the results must meet and how you want the data to be transformed (e.g., sorted, grouped, and aggregated)—but not how to achieve that goal. The database system's query optimizer can decide which indexes and join algorithms to use and in which order to execute various parts of the query.

In contrast, with most programming languages (such as Python and Java), you would have to write an algorithm telling the computer which operations to perform in which order. A declarative query language is attractive because it is typically more concise and easier to write than an explicit algorithm. More importantly, it hides implementation details of the query engine, which makes it possible for the database system to introduce performance improvements without requiring any changes to queries [Brandon & Karacapilidis 2024, Krishnaswami].

For example, a database might be able to execute a declarative query in parallel across multiple CPU cores and machines, without you having to worry about how to implement that parallelism Hellerstein 2010. In a handcoded algorithm, it would be a lot of work to implement such parallel execution yourself.

---

## Relational Versus Document Models

The best-known data model today is probably that of SQL, based on the relational model proposed by Edgar Codd in 1970 Codd 1970. In this model, data is organized into relations (called tables in SQL), where each relation is an unordered collection of tuples (rows in SQL).

The relational model was originally a theoretical proposal, and many people at the time doubted whether it could be implemented efficiently. However, by the mid-1980s, relational database management systems (RDBMSs) and SQL had become the tools of choice for most people who needed to store and query data with some kind of regular structure. Many data management use cases—for example, business analytics (see ["Stars and Snowflakes: Schemas for Analytics"](#stars-and-snowflakes-schemas-for-analytics))— are still dominated by relational data decades later.

Over the years, there have been many competing approaches to data storage and querying. In the 1970s and early 1980s, the network model and the hierarchical model were the main alternatives, but the relational model came to dominate them. Object databases (not to be confused with object storage for large files, a cloud service that is popular today) came and went again in the late 1980s and early 1990s. XML databases appeared in the early 2000s, but they have seen only niche adoption. Each competitor to the relational model generated a lot of hype in its time, but none lasted Stonebraker & Hellerstein 2005. Instead, SQL has grown to incorporate other types of data—for example, adding support for XML, JSON, and graph data Winand 2015.

In the 2010s, NoSQL was the latest buzzword that tried to overthrow the dominance of relational databases. NoSQL refers not to a single technology but a loose set of ideas around new data models, schema flexibility, scalability, and a move toward open source licensing models. Some databases branded themselves as NewSQL, reflecting their aim to provide the scalability of NoSQL systems along with the data model and transactional guarantees of traditional relational databases. NoSQL and NewSQL ideas have been very influential in the design of data systems, but as the principles have become widely adopted, use of those terms has faded.

One lasting effect of the NoSQL movement is the popularity of the document model, which usually represents data as JSON. This model was originally popularized by specialized document databases such as MongoDB and Couchbase, although most relational databases have now also added JSON support. Compared to relational tables, which are often seen as having a rigid and inflexible schema, JSON documents are thought to be more flexible.

The pros and cons of document and relational data have been debated extensively. Let's examine some of the key points of that debate.

### The Object-Relational Mismatch

Much application development today is done in object-oriented programming languages, which leads to a common criticism of the SQL data model: if data is stored in relational tables, an awkward translation layer is required between the objects in the application code and the database model of tables, rows, and columns. The disconnect between the models is sometimes called an impedance mismatch.

> **Note:** The term *impedance mismatch* is borrowed from electronics. Every electric circuit has a certain impedance (resistance to alternating current) on its inputs and outputs. When you connect one circuit's output to another one's input, the power transfer across the connection is maximized if the output and input impedances of the two circuits match. An impedance mismatch can lead to signal reflections and other troubles.

#### Object-relational mapping

Object-relational mapping (ORM) frameworks like ActiveRecord and Hibernate reduce the amount of boilerplate code required for this translation layer, but they are often criticized Fowler 2012. Some commonly cited problems are as follows:

- ORMs are complex and can't completely hide the differences between the two models, so developers still end up having to think about both the relational and the object representations of the data.
- ORMs are generally used only for OLTP app development (see "Characterizing Transaction Processing and Analytics"); data engineers making the data available for analytics purposes need to work with the underlying relational representation, so the design of the relational schema still matters when using an ORM.
- Many ORMs work only with relational OLTP databases. Organizations with diverse data systems such as search engines, graph databases, and NoSQL systems might find ORM support lacking.
- Some ORMs automatically generate relational schemas, but these might be awkward for users who are directly accessing the relational data, and they might be inefficient on the underlying database. Customizing the ORM's schema and query generation can be complex and negate the benefit of using the ORM in the first place.
- ORMs make it easy to accidentally write inefficient queries. An example of this is the N+1 query problem Mihalcea 2023. For instance, say you want to display a list of user comments on a page, so you perform one query that returns N comments, each containing the ID of its author. To show the name of each comment's author, you need to look up the ID in the `users` table. In handwritten SQL, you would probably perform this join in the query and return the author name along with each comment. However, with an ORM, you might end up making a separate query on the `users` table for each of the N comments to look up its author, resulting in N+1 database queries in total, which is slower than performing the join in the database. To avoid this problem, you may need to tell the ORM to fetch the author information at the same time as fetching the comments.

Nevertheless, ORMs also have advantages:

- For data that is well suited to a relational model, some kind of translation between the persistent relational and in-memory object representation is inevitable, and ORMs reduce the amount of boilerplate code required for this translation. Complicated queries may still need to be handled outside of the ORM, but the ORM can help with the simple and repetitive cases.
- Some ORMs help with caching the results of database queries, which can help reduce the load on the database.
- ORMs can also help with managing schema migrations and other administrative activities.

### The document data model for one-to-many relationships

Not all data lends itself well to a relational representation. Let's look at an example to explore a limitation of the relational model. [Figure 3-1](#figure-3-1) illustrates how a résumé (a LinkedIn profile) could be expressed in a relational schema. The profile as a whole can be identified by a unique identifier, `user_id`. Fields like `first_name` and `last_name` appear exactly once per user, so they can be modeled as columns on the `users` table.

Most people have had more than one job (position) in their career, and people may have varying numbers of periods of education and any number of pieces of contact information. One way of representing such one-to-many relationships is to put positions, education, and contact information in separate tables, each with a foreign-key reference to the `users` table, as in [Figure 3-1](#figure-3-1).

Another way of representing the same information, which is perhaps more natural and maps more closely to an object structure in application code, is as a JSON document, as shown in [Example 3-1](#example-3-1).

---

#### Figure 3-1. Using a relational schema to represent a LinkedIn profile {#figure-3-1}

![Figure 3-1: Relational schema for a LinkedIn profile — users table with one-to-many foreign-key relationships to positions, education, and contact_info tables](images/figure_3_1.svg)

---

#### Example 3-1. Representing a LinkedIn profile as a JSON document {#example-3-1}

```json
{
  "user_id":     251,
  "first_name":  "Barack",
  "last_name":   "Obama",
  "headline":    "Former President of the United States of America",
  "region_id":   "us:91",
  "photo_url":   "/p/7/000/253/05b/308dd6e.jpg",
  "positions": [
    {"job_title": "President", "organization": "United States of America"},
    {"job_title": "US Senator (D-IL)", "organization": "United States Senate"}
  ],
  "education": [
    {"school_name": "Harvard University",  "start": 1988, "end": 1991},
    {"school_name": "Columbia University", "start": 1981, "end": 1983}
  ],
  "contact_info": {
    "website": "https://barackobama.com",
    "x": "https://x.com/barackobama"
  }
}
```

---

Some developers feel that the JSON model reduces the impedance mismatch between the application code and the storage layer. The lack of a schema is often cited as an advantage too; we will discuss this in ["Schema flexibility in the document model"](#schema-flexibility-in-the-document-model). However, as we shall see in Chapter 5, there are also problems with JSON as a data encoding format.

The JSON representation has better locality than the multi-table schema in [Figure 3-1](#figure-3-1) (see ["Data locality for reads and writes"](#data-locality-for-reads-and-writes)). If you want to fetch a profile in the relational example, you need to either perform multiple queries (query each table by `user_id`) or perform a messy multiway join between the `users` table and its subordinate tables [Schauder 2023, Brandon 2025]. In the JSON representation, all the relevant information is in one place, making the query both faster and simpler.

The one-to-many relationships from the user profile to the user's positions, educational history, and contact information imply a tree structure in the data, and the JSON representation makes this tree structure explicit (see [Figure 3-2](#figure-3-2)).

---

#### Figure 3-2. One-to-many relationships forming a tree structure {#figure-3-2}

![Figure 3-2: Tree structure showing a User node at the root branching into positions, education, and contact_info subtrees](images/figure_3_2.svg)

---

> **Note:** A one-to-many relationship is sometimes called one-to-few, since a résumé typically has a small number of positions [Zola 2014, Andrews 2023]. If you have a genuinely large number of related items—say, comments on a celebrity's social media post, of which there could be many thousands—embedding them all in the same document may be too unwieldy, so the relational approach in [Figure 3-1](#figure-3-1) is preferable.

---

## Normalization, Denormalization, and Joins

In [Example 3-1](#example-3-1) in the preceding section, `region_id` is given as an ID, not as the plain-text string `Washington, DC, United States`. Why?

If the UI has a free-text field for entering the region, storing it as a plain-text string makes sense. But there are advantages to having standardized lists of geographic regions and letting users choose from a drop-down list or autocompleter. These include the following:

- Consistent style and spelling across profiles
- Avoiding ambiguity if several places have the same name (if the string were just `Washington, DC`, would it refer to DC or to the state?)
- Ease of updating—the name is stored in only one place, so it is easy to update across the board if it ever needs to be changed (e.g., change of a city name due to political events)
- Localization support—when the site is translated into other languages, the standardized lists can be localized, so the region can be displayed in the viewer's language
- Better search functionality (e.g., a search for people on the US East Coast can match this profile, because the list of regions can encode the fact that Washington is located on the East Coast—which is not apparent from the string `Washington, DC` alone)

Whether you store an ID or a text string is a question of normalization. When you use an ID, your data is more normalized: the information that is meaningful to humans (such as the text Washington, DC) is stored in only one place, and everything that refers to it uses an ID (which has meaning only within the database). When you store the text directly, you are duplicating the human-meaningful information in every record that uses it; this representation is denormalized.

The advantage of using an ID is that because it has no meaning to humans, it never needs to change: the ID can remain the same even if the information it identifies changes. Anything that is meaningful to humans may need to change sometime in the future—and if that information is duplicated, all the redundant copies will need to be updated. That requires more code, more write operations, and more disk space, and it risks inconsistencies (as some copies of the information are updated but others aren't).

The downside of a normalized representation is that every time you want to display a record containing an ID, you have to do an additional lookup to resolve the ID into something human-readable. In a relational data model, this is done using a join. For example:

```sql
SELECT users.*, regions.region_name
FROM users
JOIN regions ON users.region_id = regions.id
WHERE users.id = 251;
```

Document databases can store both normalized and denormalized data, but they are often associated with denormalization—partly because the JSON data model makes it easy to store additional denormalized fields, and partly because the weak support for joins in many document databases makes normalization inconvenient. Some document databases don't support joins at all, so you have to perform them in application code—that is, you first fetch a document containing an ID, then perform a second query to resolve that ID into another document. In MongoDB, it is also possible to perform a join using the `$lookup` operator in an aggregation pipeline:

```javascript
db.users.aggregate([
  { $match: { _id: 251 } },
  { $lookup: {
      from: "regions",
      localField: "region_id",
      foreignField: "_id",
      as: "region"
  } }
])
```

### Trade-offs of normalization

In the résumé example, while the `region_id` field is a reference to a standardized set of regions, the `organization` (the company or government where the person worked) and `school_name` (where they studied) are just strings. This representation is denormalized: many people may have worked at the same company, but there is no ID linking them.

It's worth considering whether the organization and school names should be entities instead, and the profile should reference their IDs. The same arguments for referencing the ID of a region also apply here. For example, say we wanted to include the logo of the school or company in addition to its name:

- In a denormalized representation, we would include the image URL of the logo on every individual person's profile. This makes the JSON document self-contained, but it creates a headache if we ever need to change the logo, because we now need to find all the occurrences of the old URL and update them Zola 2014.
- In a normalized representation, we would create an entity representing an organization or school and store its name, logo URL, and perhaps other attributes (description, news feed, etc.) once as part of that entity. Every résumé that mentions the organization would then simply reference its ID, and updating the logo would be easy.

As a general principle, normalized data is usually faster to write (since there is only one copy) but slower to query (since it requires joins); denormalized data is usually faster to read (fewer joins) but more expensive to write (more copies to update, more disk space used). You might find it helpful to view denormalization as a form of derived data (see "Systems of Record and Derived Data"), since you need to set up a process for updating the redundant copies of the data.

Besides the cost of performing all these updates, you need to consider the consistency of the database if a process crashes halfway through making its updates. Databases that offer atomic transactions (see "Atomicity") make it easier to remain consistent, but not all databases offer atomicity across multiple documents. It is also possible to ensure consistency through stream processing, which we discuss in Chapter 12.

Normalization tends to be better for OLTP systems, where both reads and updates need to be fast; analytical systems often fare better with denormalized data, since they perform updates in bulk and the performance of read-only queries is the dominant concern. In systems of small to moderate scale, a normalized data model is often best because you don't have to worry about keeping multiple copies of the data consistent with one another, and the cost of performing joins is acceptable. However, in very large-scale systems, the cost of joins can become problematic.

### Denormalization in the social networking case study

In "Case Study: Social Network Home Timelines" we compared a normalized representation (Figure 2-1) and a denormalized one (precomputed, materialized timelines). Here, the join between `posts` and `follows` was too expensive, and the materialized timeline is a cache of the result of that join. The fan-out process that inserts a new post into followers' timelines was our way of keeping the denormalized representation consistent.

However, the implementation of materialized timelines at X (formerly Twitter) does not store the actual text of each post. Each entry stores only the post ID, the ID of the user who posted it, and a little bit of extra information to identify reposts and replies Krikorian 2012. In other words, it is a precomputed result of (approximately) the following query:

```sql
SELECT posts.id, posts.sender_id FROM posts
  JOIN follows ON posts.sender_id = follows.followee_id
  WHERE follows.follower_id = current_user
  ORDER BY posts.timestamp DESC
  LIMIT 1000
```

This means that whenever the timeline is read, the service still needs to perform two joins: it looks up the post ID to fetch the actual post content (as well as statistics such as the number of likes and replies), and it looks up the sender's profile by ID (to get their username, profile picture, and other details). This process of looking up the human-readable information by ID is called hydrating the IDs, and it is essentially a join performed in application code Krikorian 2012.

The reason for storing only IDs in the precomputed timeline is that the data they refer to is fast-changing. The number of likes and replies may change multiple times per second on a popular post, and some users regularly change their username or profile photo. Since the timeline should show the latest like count and profile picture when it is viewed, denormalizing this information into the materialized timeline would not make sense. Moreover, the storage cost would be increased significantly by such denormalization.

This example shows that having to perform joins when reading data is not, as sometimes claimed, an impediment to creating high-performance, scalable services. Hydrating post and user IDs is actually a fairly easy operation to scale, since it parallelizes well, and the cost doesn't depend on the number of accounts you are following or the number of followers you have.

If you need to decide whether to denormalize something in your application, the social network case study shows that the choice is not immediately obvious; the most scalable approach may involve denormalizing some things and leaving others normalized. You will have to carefully consider how often the information changes and the cost of reads and writes (which might be dominated by outliers, such as users with many follows/followers in the case of a typical social network). Normalization and denormalization are not inherently good or bad—they simply represent trade-offs in terms of performance of reads and writes and implementation effort.

---

## Many-to-One and Many-to-Many Relationships

While the `positions` and `education` tables in [Figure 3-1](#figure-3-1) are examples of one-to-many or one-to-few relationships (one résumé has several positions, but each position belongs only to one résumé), the `region_id` field is an example of a many-to-one relationship (many people live in the same region, but we assume that each person lives in only one region at any one time).

If we introduce entities for organizations and schools and reference them by ID from the résumé, then we also have many-to-many relationships (one person may have worked for several organizations, and an organization has several past or present employees). In a relational model, such a relationship is usually represented as an associative table, or join table, as shown in [Figure 3-3](#figure-3-3): each position associates one user ID with one organization ID.

---

#### Figure 3-3. Many-to-many relationships in the relational model {#figure-3-3}

![Figure 3-3: Many-to-many relationships in relational model — users and organizations tables connected through a positions join table](images/figure_3_3.svg)

---

Many-to-one and many-to-many relationships do not easily fit within one self-contained JSON document; they lend themselves more to a normalized representation. In a document model, one possible representation is given in [Example 3-2](#example-3-2) and illustrated in [Figure 3-4](#figure-3-4). The data within each dotted rectangle can be grouped into one document, but the links to organizations and schools are best represented as references to other documents.

#### Example 3-2. A résumé that references organizations by ID {#example-3-2}

```json
{
  "user_id":    251,
  "first_name": "Barack",
  "last_name":  "Obama",
  "positions": [
    {"start": 2009, "end": 2017, "job_title": "President",         "org_id": 513},
    {"start": 2005, "end": 2008, "job_title": "US Senator (D-IL)", "org_id": 514}
  ],
  ...
}
```

Many-to-many relationships often need to be queried in "both directions"—for example, finding all the organizations that a particular person has worked for, and finding all the people who have worked at a particular organization. One way of enabling such queries is to store ID references on both sides, such that a résumé includes the ID of each organization where the person has worked, and the organization document includes the IDs of the résumés that mention that organization. This representation is denormalized, since the relationship is stored in two places, which could become inconsistent with each other.

---

#### Figure 3-4. Many-to-many relationships in the document model {#figure-3-4}

![Figure 3-4: Many-to-many relationships in document model — user document references organization documents by org_id across dotted document boundaries](images/figure_3_4.svg)

---

A normalized representation stores the relationship in only one place and relies on secondary indexes (which we discuss in Chapter 4) to allow the relationship to be efficiently queried in both directions. In the relational schema shown in [Figure 3-3](#figure-3-3), we would tell the database to create indexes on both the `user_id` and `org_id` columns of the `positions` table.

In the document model of [Example 3-2](#example-3-2), the database needs to index the `org_id` field of objects inside the `positions` array. Many document databases and relational databases with JSON support are able to create such indexes on values inside a document.

---

## Stars and Snowflakes: Schemas for Analytics

Data warehouses (see "Data Warehousing") are usually relational, and there are a few widely used conventions for the structure of tables in a data warehouse, including a star schema, a snowflake schema, dimensional modeling Kimball & Ross 2013, and one big table (OBT). These structures are optimized for the needs of business analysts. ETL processes translate data from operational systems into the selected schema.

[Figure 3-5](#figure-3-5) shows an example of a star schema that might be found in the data warehouse of a grocery retailer. At the center of the schema is a so-called fact table (in this example, it is called `fact_sales`). Each row of the fact table represents an event that occurred at a particular time (here, each row represents a customer's purchase of a product). If we were analyzing website traffic rather than retail sales, each row might represent a page view or a click by a user.

---

#### Figure 3-5. A star schema for use in a data warehouse {#figure-3-5}

![Figure 3-5: Star schema — fact_sales table at center surrounded by dim_date, dim_product, dim_store, and dim_customer dimension tables](images/figure_3_5.svg)

---

Usually facts are captured as individual events, because this allows maximum flexibility of analysis later. However, this means that the fact table can become extremely large. A big enterprise may have many petabytes of transaction history in its data warehouse, mostly represented as fact tables.

Some of the columns in the fact table are attributes, such as the price at which the product was sold and the cost of buying it from the supplier (allowing the profit margin to be calculated). Other columns in the fact table are foreign-key references to other tables, called dimension tables. As each row in the fact table represents an event, the dimensions represent the who, what, where, when, how, and why of the event.

For example, in [Figure 3-5](#figure-3-5), one of the dimensions is the product that was sold. Each row in the `dim_product` table represents one type of product that is for sale, including its stock-keeping unit (SKU), description, brand name, category, fat content, and package size. Each row in the `fact_sales` table uses a foreign key to indicate which product was sold in that particular transaction. Queries often involve multiple joins to multiple dimension tables.

Even date and time are often represented using dimension tables, because this allows additional information about dates (such as public holidays) to be encoded, enabling queries to differentiate between sales on holidays and non-holidays.

The name star schema comes from the fact that when the table relationships are visualized, the fact table is in the middle, surrounded by its dimension tables (as shown in [Figure 3-5](#figure-3-5)); the connections to these tables are like the rays of a star.

A variation of this template is the snowflake schema, where dimensions are further broken into subdimensions. For example, there could be separate tables for brands and product categories, and each row in the `dim_product` table could reference the brand and category as foreign keys, rather than storing them as strings in the `dim_product` table. Snowflake schemas are more normalized than star schemas, but star schemas are often preferred because they are simpler for analysts to work with Kimball & Ross 2013.

In a typical data warehouse, tables are often quite wide: fact tables frequently have over a hundred columns, sometimes several hundred. Dimension tables can also be wide, as they include all the metadata that may be relevant for analysis—for example, the `dim_store` table may include details of which services are offered at each store, whether it has an in-store bakery, the square footage, the date when the store first opened, when it was last remodeled, and how far it is from the nearest highway.

A star or snowflake schema consists mostly of many-to-one relationships (e.g., many sales occur for one particular product, in one particular store), represented as the fact table having foreign keys into dimension tables, or dimensions into subdimensions. In principle, other relationship types could exist, but they are often denormalized to simplify queries.

Some data warehouse schemas take denormalization even further and leave out the dimension tables entirely, folding the information in the dimensions into denormalized columns in the fact table instead (essentially, precomputing the join between the fact table and the dimension tables). This approach is known as one big table (OBT), and while it requires more storage space, it sometimes enables faster queries Kaminsky 2022.

In the context of analytics, such denormalization is unproblematic, since the data typically represents a log of historical data that is not going to change (except maybe for occasionally correcting an error). The issues of data consistency and write overheads that occur with denormalization in OLTP systems are not as pressing in analytics.

---

## When to Use Which Model

The main arguments in favor of the document data model are schema flexibility, better performance due to locality, and that for some applications it is closer to the object model used by the application. The relational model counters by providing better support for joins and many-to-one and many-to-many relationships. Let's examine these arguments in more detail.

If the data in your application has a document-like structure (i.e., a tree of one-to-many relationships, where typically the entire tree is loaded at once), then it's probably a good idea to use a document model. The relational technique of shredding—splitting a document-like structure into multiple tables (like `positions`, `education`, and `contact_info` in [Figure 3-1](#figure-3-1))—can lead to cumbersome schemas and unnecessarily complicated application code.

The document model has limitations. For example, you cannot refer directly to a nested item within a document; instead, you need to say something like, "the second item in the list of positions for user 251." If you need to reference nested items, a relational approach works better, since you can refer to any item directly by its ID.

Some applications allow the user to choose the order of items—for example, imagine a to-do list or issue tracker where the user can drag and drop tasks to reorder them. The document model supports such applications well, because the items (or their IDs) can simply be stored in a JSON array to determine their order. In relational databases there isn't a standard way of representing such reorderable lists, and various tricks are used, such as sorting by an integer column (requiring renumbering when you insert into the middle), maintaining a linked list of IDs, or using fractional indexing [Nelson 2018, Wallace 2017, Greenspan 2020].

### Schema flexibility in the document model

Most document databases, and the JSON support in relational databases, do not enforce any schema on the data in documents. XML support in relational databases usually comes with optional schema validation. No schema means that arbitrary keys and values can be added to a document, and when reading, clients have no guarantees as to what fields the documents may contain.

Document databases are sometimes called schemaless, but that's misleading as the code that reads the data usually assumes some kind of structure—that is, there is an implicit schema, but it is not enforced by the database Leavitt 2010. A more accurate term is schema-on-read (the structure of the data is implicit and interpreted only when the data is read), in contrast with schema-on-write (the traditional approach of relational databases, where the schema is explicit and the database ensures that all data conforms to it when the data is written) Awadallah 2009.

Schema-on-read is similar to dynamic (runtime) type checking in programming languages, whereas schema-on-write is similar to static (compile-time) type checking. Just as the advocates of static and dynamic type checking have big debates about their relative merits Odersky 2013, enforcement of schemas in databases is a contentious topic, and in general there's no clear winner.

The difference between the approaches is particularly noticeable when an application wants to change the format of its data. For example, say you are currently storing each user's full name in one field, and you instead want to store the first name and last name separately Irwin 2013. In a document database, you would just start writing new documents with the new fields and have code in the application that handles the case when old documents are read. For example:

```javascript
if (user && user.name && !user.first_name) {
    // Documents written before Dec 8, 2023 don't have first_name
    user.first_name = user.name.split(" ")[0];
}
```

The downside of this approach is that every part of your application that reads from the database now needs to deal with documents in old formats that may have been written a long time in the past. On the other hand, in a schema-on-write database, you would typically perform a migration along the lines of this:

```sql
ALTER TABLE users ADD COLUMN first_name text DEFAULT NULL;
UPDATE users SET first_name = split_part(name, ' ', 1);      -- PostgreSQL
UPDATE users SET first_name = substring_index(name, ' ', 1);      -- MySQL
```

In most relational databases, adding a column with a default value is fast and unproblematic, even on large tables. However, running the `UPDATE` statement is likely to be slow on a large table since every row needs to be rewritten, and other schema operations (such as changing the datatype of a column) also typically require the entire table to be copied.

Various tools exist to allow this type of schema change to be performed in the background without downtime [Percona 2023, Noach 2016, Mukherjee 2022, Pérez-Aradros 2023], but performing such migrations on large databases remains operationally challenging. Complicated migrations can be avoided by adding the `first_name` column with a default value of `NULL` (which is fast) and filling it in at read time, as you would with a document database.

The schema-on-read approach is advantageous if the items in the collection don't all have the same structure (i.e., the data is heterogeneous); for example:

- There are many types of objects, and it is not practicable to put each type of object in its own table.
- The structure of the data is determined by external systems over which you have no control and that may change at any time.

In situations like these, a schema may hurt more than it helps, and schemaless documents can be a much more natural data model. But when all records are expected to have the same structure, schemas are a useful mechanism for documenting and enforcing that structure. We will discuss schemas and schema evolution in more detail in Chapter 5.

### Data locality for reads and writes

A document is usually stored as a single continuous string, encoded as JSON, XML, or a binary variant thereof (such as MongoDB's BSON). If your application often needs to access the entire document (e.g., to render it on a web page), this storage locality has a performance advantage. If data is split across multiple tables, as in [Figure 3-1](#figure-3-1), multiple index lookups are required to retrieve it all, which may require more disk seeks and take more time.

The locality advantage applies only if you need large parts of the document at the same time. The database typically needs to load the entire document, which can be wasteful if you need to access only a small part of a large document. Furthermore, on updates to a document, the entire document usually needs to be rewritten. For these reasons, it is generally recommended that you keep documents fairly small and avoid frequent small updates.

However, storing related data together for locality is not limited to the document model. For example, Google's Spanner database offers the same locality properties in a relational data model, by allowing the schema to declare that a table's rows should be interleaved (nested) within a parent table Corbett et al. 2012. Oracle allows the same thing, using a feature called multi-table index cluster tables Burleson. The wide-column data model popularized by Google's Bigtable and used, for example, in HBase and Accumulo has column families, which have a similar purpose of managing locality Chang et al. 2006.

### Query languages for documents

Another difference between a relational and a document database is the language or API that you use to query it. Most relational databases are queried using SQL, but document databases are more varied. Some allow only key-value access by primary key, while others also offer secondary indexes to query for values inside documents, and some provide rich query languages.

XML databases are often queried using XQuery and XPath, which are designed to allow complex queries, including joins across multiple documents, and format their results as XML Walmsley 2015. JSON Pointer Bryan 2013 and JSONPath Gössner et al. 2024 provide an equivalent to XPath for JSON. MongoDB's aggregation pipeline, whose `$lookup` operator for joins we saw in ["Normalization, Denormalization, and Joins"](#normalization-denormalization-and-joins), is an example of a query language for collections of JSON documents.

Let's look at another example to get a feel for this language—this time an aggregation, which is especially needed for analytics. Imagine you are a marine biologist, and you add an observation record to your database every time you see animals in the ocean. Now you want to generate a report saying how many sharks you have sighted per month. In PostgreSQL, you might express that query like this:

```sql
SELECT date_trunc('month', observation_timestamp) AS observation_month, 
       sum(num_animals) AS total_animals
FROM observations
WHERE family = 'Sharks'
GROUP BY observation_month;
```

The `date_trunc('month', observation_timestamp)` function determines the calendar month containing `timestamp` and returns another timestamp representing the beginning of that month. In other words, the function rounds a timestamp down to the nearest month.

This query first filters the observations to show only species in the `Sharks` family, then groups the observations by the calendar month in which they occurred, and finally adds up the number of animals seen in all observations in that month. The same query can be expressed using MongoDB's aggregation pipeline as follows:

```javascript
db.observations.aggregate([
    { $match: { family: "Sharks" } },
    { $group: {
        _id: {
            year:  { $year:  "$observationTimestamp" },
            month: { $month: "$observationTimestamp" }
        },
        totalAnimals: { $sum: "$numAnimals" }
    } }
]);
```

The aggregation pipeline language is similar in expressiveness to a subset of SQL, but it uses a JSON-based syntax rather than SQL's English sentence–style syntax. The difference is perhaps a matter of taste.

### Convergence of document and relational databases

Document databases and relational databases started out as very different approaches to data management, but they have grown more similar over time Stonebraker 2024. Relational databases added support for JSON types and query operators, and the ability to index properties inside documents. Some document databases (such as MongoDB, Couchbase, and RethinkDB) added support for joins, secondary indexes, and declarative query languages.

This convergence of the models is good news for application developers, because the relational model and the document model work best when you can combine both in the same database. Many document databases need relational-style references to other documents, and many relational databases have sections where schema flexibility is beneficial. Relational–document hybrids are a powerful combination.

> **Note:** Codd's original description of the relational model Codd 1970 allowed something similar to JSON within a relational schema. He called it *nonsimple domains*. The idea was that a value in a row doesn't have to be a primitive datatype like a number or a string; it can also be a nested relation (table), so you can have an arbitrarily nested tree structure as a value. This construction is comparable to the JSON and XML support that was added to SQL over 30 years later.

---

## Graph-Like Data Models

We saw earlier that the type of relationships is an important distinguishing feature across data models. If your application has mostly one-to-many relationships (tree-structured data) and few other relationships between records, the document model is appropriate.

But what if many-to-many relationships are very common in your data? The relational model can handle simple cases of many-to-many relationships, but as the connections within your data become more complex, it becomes more natural to start modeling that data as a graph.

A graph consists of two kinds of objects: vertices (also known as nodes or entities) and edges (also known as relationships or arcs). Many kinds of data can be modeled as a graph. Typical examples include the following:

**Social graphs** — Vertices are people, and edges indicate which people know each other.

**The web graph** — Vertices are web pages, and edges indicate HTML links to other pages.

**Road or rail networks** — Vertices are junctions, and edges represent the roads or railway lines between them.

Well-known algorithms can operate on these graphs—for example, map navigation apps search for the shortest path between two points in a road network, and PageRank can be used on the web graph to determine the popularity of a web page and thus its ranking in search results Page et al. 1999.

Graphs can be represented in several ways. In the adjacency list model, each vertex stores the IDs of its neighbor vertices that are one edge away. Alternatively, you can use an adjacency matrix, a two-dimensional array in which each row and column corresponds to a vertex, where the value is 0 when there is no edge between the row vertex and the column vertex and 1 when there is an edge. An adjacency list is good for graph traversals, and matrices are good for machine learning (see ["DataFrames, Matrices, and Arrays"](#dataframes-matrices-and-arrays)).

In the examples just given, all the vertices in a graph represent the same kind of thing (people, web pages, or road junctions, respectively). However, graphs are not limited to such homogeneous data. An equally powerful use of graphs is to provide a consistent way of storing completely different types of objects in a single database. For example:

- Facebook maintains a single graph with many types of vertices and edges. Vertices represent people, locations, events, check-ins, and comments made by users; edges indicate which people are friends with each other, which check-in happened in which location, who commented on which post, who attended which event, and so on Bronson et al. 2013.
- Search engines use knowledge graphs to record facts about entities that often occur in search queries, such as organizations, people, and places Noy et al. 2019. This information is obtained by crawling and analyzing the text on websites; some websites, such as Wikidata, also publish graph data in a structured form.

Graphs provide several different, but related, ways of structuring and querying data. In this section we will discuss the property graph model (implemented by Neo4j, Memgraph, KùzuDB Feng et al. 2023, and others Besta et al. 2019) and the triple store model (implemented by Datomic, AllegroGraph, Blazegraph, and others). These models are fairly similar in what they can express, and some graph databases (such as Amazon Neptune) support both.

We will also look at four query languages for graphs (Cypher, SPARQL, Datalog, and GraphQL), as well as SQL support for querying graphs. Other graph query languages exist, such as Gremlin TinkerPop 2023, but these will give us a representative overview.

To illustrate these languages and models, this section uses [Figure 3-6](#figure-3-6) as a running example. It could be taken from a social network or a genealogical database; it shows two people, Lucy from Idaho and Alain from Saint-Lô, France. They are married and living in London. Each person and each location is represented as a vertex, and the relationships between them are represented as edges. This example will help demonstrate some queries that are easy in graph databases but difficult in other data models.

---

#### Figure 3-6. Graph-structured data (boxes represent vertices, arrows represent edges) {#figure-3-6}

![Figure 3-6: Graph data showing Lucy (born in Idaho → US → North America) and Alain (born in Saint-Lô → France), both married and living in London → England](images/figure_3_6.svg)

---

### Property Graphs

In the property graph (also known as labeled property graph) model, each vertex consists of the following:

- A unique identifier
- A label (string) to describe the type of object this vertex represents
- A set of outgoing edges
- A set of incoming edges
- A collection of properties (key-value pairs)

Each edge consists of the following:

- A unique identifier
- The vertex at which the edge starts (the tail vertex)
- The vertex at which the edge ends (the head vertex)
- A label to describe the kind of relationship between the two vertices
- A collection of properties (key-value pairs)

You can think of a graph store as consisting of two relational tables, one for vertices and one for edges, as shown in [Example 3-3](#example-3-3) (this schema uses the PostgreSQL `jsonb` datatype to store the properties of each vertex or edge). The head and tail vertices are stored for each edge; if you want the set of incoming or outgoing edges for a vertex, you can query the `edges` table by `head_vertex` or `tail_vertex`, respectively.

#### Example 3-3. Representing a property graph with a relational schema {#example-3-3}

```sql
CREATE TABLE vertices (
    vertex_id   integer PRIMARY KEY,
    label       text,
    properties  jsonb
);

CREATE TABLE edges (
    edge_id     integer PRIMARY KEY,
    tail_vertex integer REFERENCES vertices (vertex_id),
    head_vertex integer REFERENCES vertices (vertex_id),
    label       text,
    properties  jsonb
);

CREATE INDEX edges_tails ON edges (tail_vertex);
CREATE INDEX edges_heads ON edges (head_vertex);
```

Some important aspects of this model are as follows:

- Any vertex can have an edge connecting it with any other vertex. There is no schema that restricts which kinds of things can or cannot be associated.
- Given any vertex, you can efficiently find both its incoming and its outgoing edges and thus traverse the graph (i.e., follow a path through a chain of vertices) both forward and backward. (That's why [Example 3-3](#example-3-3) has indexes on both the `tail_vertex` and `head_vertex` columns.)
- By using different labels for different kinds of vertices and relationships, you can store several kinds of information in a single graph, while still maintaining a clean data model.

The `edges` table is like the many-to-many associative, or join, table we saw in ["Many-to-One and Many-to-Many Relationships"](#many-to-one-and-many-to-many-relationships), generalized to allow many types of relationship to be stored in the same table. There may also be indexes on the labels and the properties, allowing vertices or edges with certain properties to be found efficiently.

> **Note:** A limitation of graph models is that an edge can associate only two vertices with each other, whereas a relational join table can represent three-way or even higher-degree relationships by having multiple foreign-key references on a single row. Such relationships can be represented in a graph by creating an additional vertex corresponding to each row of the join table and edges to/from that vertex, or by using a hypergraph.

Those features give graphs a great deal of flexibility for data modeling, as illustrated in [Figure 3-6](#figure-3-6). The figure shows a few things that would be difficult to express in a traditional relational schema, such as different kinds of regional structures in different countries (France has départements and régions, whereas the US has counties and states), quirks of history such as a country within a country (ignoring for now the intricacies of sovereign states and nations), and varying granularity of data (Lucy's current residence is specified as a city, whereas her place of birth is specified at only the level of a state).

### The Cypher Query Language

Cypher is a query language for property graphs, originally created for the Neo4j graph database and later developed into an open standard as openCypher Francis et al. 2018. Besides Neo4j, Cypher is supported by Memgraph, KùzuDB Feng et al. 2023, Amazon Neptune, Apache AGE (with storage in PostgreSQL), and others. This language is named after a character in the movie The Matrix and is not related to ciphers in cryptography Eifrem 2012.

[Example 3-4](#example-3-4) shows the Cypher query to insert the lefthand portion of [Figure 3-6](#figure-3-6) into a graph database.

#### Example 3-4. A subset of the data in Figure 3-6, represented as a Cypher query {#example-3-4}

```cypher
CREATE
  (namerica :Location {name:'North America',  type:'continent'}),
  (usa      :Location {name:'United States',  type:'country'  }),
  (idaho    :Location {name:'Idaho',          type:'state'    }),
  (lucy     :Person   {name:'Lucy' }),
  (idaho) -[:WITHIN ]-> (usa)  -[:WITHIN]-> (namerica),
  (lucy)  -[:BORN_IN]-> (idaho)
```

When all the vertices and edges of [Figure 3-6](#figure-3-6) are added to the database, we can start asking interesting questions. For example, suppose we want to find the names of all the people who emigrated from the United States to Europe. We can do that by finding all the vertices that have a `BORN_IN` edge to a location within the US and a `LIVING_IN` edge to a location within Europe, and returning the `name` property of each of those vertices.

[Example 3-5](#example-3-5) shows how to express that query in Cypher.

#### Example 3-5. A Cypher query to find people who emigrated from the US to Europe {#example-3-5}

```cypher
MATCH
  (person) -[:BORN_IN]->  () -[:WITHIN*0..]-> (:Location {name:'United States'}),
  (person) -[:LIVES_IN]-> () -[:WITHIN*0..]-> (:Location {name:'Europe'})
RETURN person.name
```

The query can be read as follows — find any vertex (call it `person`) that meets both of the following conditions:

1. `person` has an outgoing `BORN_IN` edge to a vertex. From that vertex, you can follow a chain of outgoing `WITHIN` edges until eventually you reach a vertex of type `Location`, whose `name` property is equal to `United States`.
2. That same `person` vertex also has an outgoing `LIVES_IN` edge. Following that edge, and then a chain of outgoing `WITHIN` edges, you eventually reach a vertex of type `Location`, whose `name` property is equal to `Europe`.

For each such `person` vertex, return the `name` property.

### Graph Queries in SQL

[Example 3-3](#example-3-3) suggested that graph data can be represented in a relational database. But if we put graph data in a relational structure, can we also query it using SQL?

The answer is yes, but with some difficulty. Every edge that you traverse in a graph query is effectively a join with the `edges` table. In a relational database, you usually know in advance which joins you need in your query. On the other hand, in a graph query, you may need to traverse a variable number of edges before you find the vertex you're looking for—that is, the number of joins is not fixed in advance.

In Cypher, `:WITHIN*0..` expresses that fact very concisely: it means "follow a `WITHIN` edge, zero or more times." It's like the `*` operator in a regular expression.

This idea of variable-length traversal paths in a query can be expressed using recursive common table expressions (the `WITH RECURSIVE` syntax). [Example 3-6](#example-3-6) shows the same query expressed in SQL using this technique.

#### Example 3-6. The same query as Example 3-5, written in SQL using recursive CTEs {#example-3-6}

```sql
WITH RECURSIVE

  -- in_usa is the set of vertex IDs of all locations within the United States
  in_usa(vertex_id) AS (
      SELECT vertex_id FROM vertices
        WHERE label = 'Location' AND properties->>'name' = 'United States' 
    UNION
      SELECT edges.tail_vertex FROM edges 
        JOIN in_usa ON edges.head_vertex = in_usa.vertex_id
        WHERE edges.label = 'within'
  ),

  -- in_europe is the set of vertex IDs of all locations within Europe
  in_europe(vertex_id) AS (
      SELECT vertex_id FROM vertices
        WHERE label = 'location' AND properties->>'name' = 'Europe' 
    UNION
      SELECT edges.tail_vertex FROM edges
        JOIN in_europe ON edges.head_vertex = in_europe.vertex_id
        WHERE edges.label = 'within'
  ),

  -- born_in_usa is the set of vertex IDs of all people born in the US
  born_in_usa(vertex_id) AS ( 
    SELECT edges.tail_vertex FROM edges
      JOIN in_usa ON edges.head_vertex = in_usa.vertex_id
      WHERE edges.label = 'born_in'
  ),

  -- lives_in_europe is the set of vertex IDs of all people living in Europe
  lives_in_europe(vertex_id) AS ( 
    SELECT edges.tail_vertex FROM edges
      JOIN in_europe ON edges.head_vertex = in_europe.vertex_id
      WHERE edges.label = 'lives_in'
  )

SELECT vertices.properties->>'name'
FROM vertices
JOIN born_in_usa     ON vertices.vertex_id = born_in_usa.vertex_id 
JOIN lives_in_europe ON vertices.vertex_id = lives_in_europe.vertex_id;
```

The fact that a 4-line Cypher query requires 31 lines in SQL shows how much of a difference the right choice of data model and query language can make. The Graph Query Language (GQL) ISO standard, which is based on Cypher, was published in 2024 [Rathle 2024, Deutsch et al. 2022, Green 2019].

---

## Triple Stores and SPARQL

The triple store model is mostly equivalent to the property graph model, using different words to describe the same ideas. In a triple store, all information is stored in the form of very simple three-part statements: (subject, predicate, object). For example, in the triple (Jim, likes, bananas), Jim is the subject, likes is the predicate (verb), and bananas is the object.

#### Example 3-7. A subset of Figure 3-6 represented as Turtle triples {#example-3-7}

```turtle
@prefix : <urn:example:>.
_:lucy     a       :Person.
_:lucy     :name   "Lucy".
_:lucy     :bornIn _:idaho.
_:idaho    a       :Location.
_:idaho    :name   "Idaho".
_:idaho    :type   "state".
_:idaho    :within _:usa.
_:usa      a       :Location.
_:usa      :name   "United States".
_:usa      :type   "country".
_:usa      :within _:namerica.
_:namerica a       :Location.
_:namerica :name   "North America".
_:namerica :type   "continent".
```

#### Example 3-8. A more concise way of writing the data in Example 3-7 {#example-3-8}

```turtle
@prefix : <urn:example:>.
_:lucy     a :Person;   :name "Lucy";          :bornIn _:idaho.
_:idaho    a :Location; :name "Idaho";         :type "state";   :within _:usa.
_:usa      a :Location; :name "United States"; :type "country"; :within _:namerica.
_:namerica a :Location; :name "North America"; :type "continent".
```

### The Semantic Web

Some of the research and development effort on triple stores was motivated by the Semantic Web, an early 2000s effort to facilitate internet-wide data exchange by publishing data not only as human-readable web pages but also in a standardized, machine-readable format. Although the Semantic Web as originally envisioned did not succeed [Target 2018, Mendel-Gleason 2022], the project's legacy lives on in, for example, linked data standards such as JSON-LD Sporny et al. 2014, the ontologies used in biomedical science U. of Michigan Ontologies, Facebook's Open Graph protocol Facebook Open Graph, knowledge graphs such as Wikidata, and the standardized vocabularies for structured data maintained by [Schema.org](https://schema.org/).

### The RDF data model

#### Example 3-9. The data from Example 3-8 expressed using RDF/XML syntax {#example-3-9}

```xml
<rdf:RDF xmlns="urn:example:"
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">

  <Location rdf:nodeID="idaho">
    <name>Idaho</name>
    <type>state</type>
    <within>
      <Location rdf:nodeID="usa">
        <name>United States</name>
        <type>country</type>
        <within>
          <Location rdf:nodeID="namerica">
            <name>North America</name>
            <type>continent</type>
          </Location>
        </within>
      </Location>
    </within>
  </Location>

  <Person rdf:nodeID="lucy">
    <name>Lucy</name>
    <bornIn rdf:nodeID="idaho"/>
  </Person>
</rdf:RDF>
```

### The SPARQL query language

SPARQL is a query language for triple stores using the RDF data model Harris & Seaborne 2013. (The name is a recursive acronym for SPARQL Protocol and RDF Query Language, pronounced "sparkle.") It predates Cypher, and since Cypher's pattern matching is borrowed from SPARQL, they look quite similar.

#### Example 3-10. The same query as Example 3-5, expressed in SPARQL {#example-3-10}

```sparql
PREFIX : <urn:example:>

SELECT ?personName WHERE {
  ?person :name ?personName.
  ?person :bornIn  / :within* / :name "United States".
  ?person :livesIn / :within* / :name "Europe".
}
```

SPARQL is supported by Amazon Neptune, AllegroGraph, Blazegraph, OpenLink Virtuoso, Apache Jena, and various other triple stores Besta et al. 2019.

---

## Datalog: Recursive Relational Queries

Datalog, a much older language than SPARQL or Cypher, arose from academic research in the 1980s [Green et al. 2013, Ceri et al. 1989, Abiteboul et al. 1995]. It is less well-known among software engineers and not widely supported in mainstream databases, but it ought to be better known since it is a very expressive language that is especially powerful for complex queries.

#### Example 3-11. A subset of Figure 3-6, represented as Datalog facts {#example-3-11}

```prolog
location(1, "North America", "continent").
location(2, "United States", "country").
location(3, "Idaho", "state").

within(2, 1).    /* US is in North America */
within(3, 2).    /* Idaho is in the US     */

person(100, "Lucy").
born_in(100, 3). /* Lucy was born in Idaho */
```

#### Example 3-12. The same query as Example 3-5, expressed in Datalog {#example-3-12}

```prolog
within_recursive(LocID, PlaceName) :- location(LocID, PlaceName, _). /* Rule 1 */

within_recursive(LocID, PlaceName) :- within(LocID, ViaID),          /* Rule 2 */
                                      within_recursive(ViaID, PlaceName).

migrated(PName, BornIn, LivingIn)  :- person(PersonID, PName),       /* Rule 3 */
                                      born_in(PersonID, BornID),
                                      within_recursive(BornID, BornIn),
                                      lives_in(PersonID, LivingID),
                                      within_recursive(LivingID, LivingIn).

us_to_europe(Person) :- migrated(Person, "United States", "Europe"). /* Rule 4 */
/* us_to_europe contains the row "Lucy". */
```

One possible way of applying the rules is illustrated in [Figure 3-7](#figure-3-7):

---

#### Figure 3-7. Determining that Idaho is in North America, using the Datalog rules from Example 3-12 {#figure-3-7}

![Figure 3-7: Step-by-step derivation showing how Datalog rules derive within_recursive facts transitively from location and within base facts](images/figure_3_7.svg)

---

1. `location(1, "North America", "continent")` exists in the database, so rule 1 applies. It generates `within_recursive(1, "North America")`.
2. `within(2, 1)` exists in the database and the previous step generated `within_recursive(1, "North America")`, so rule 2 applies. It generates `within_recursive(2, "North America")`.
3. `within(3, 2)` exists in the database and the previous step generated `within_recursive(2, "North America")`, so rule 2 applies. It generates `within_recursive(3, "North America")`.

By repeated application of rules 1 and 2, the `within_recursive` virtual table can tell us all the locations in North America (or any other location) contained in our database.

---

## GraphQL

GraphQL is a query language that, by design, is much more restrictive than the others we have seen in this chapter. It's intended for OLTP queries; its purpose is to allow client software running on a user's device (such as a mobile app or a JavaScript web app frontend) to request a JSON document with a particular structure, containing the fields necessary for rendering its UI.

#### Example 3-13. A GraphQL query for a group chat application {#example-3-13}

```graphql
query ChatApp {
  channels {
    name
    recentMessages(latest: 50) {
      timestamp
      content
      sender {
        fullName
        imageUrl
      }
      replyTo {
        content
        sender {
          fullName
        }
      }
    }
  }
}
```

#### Example 3-14. A possible response to the query in Example 3-13 {#example-3-14}

```json
{
  "data": {
    "channels": [
      {
        "name": "#general",
        "recentMessages": [
          {
            "timestamp": 1693143014,
            "content": "Hey! How are y'all doing?",
            "sender": {"fullName": "Aaliyah", "imageUrl": "https://..."},
            "replyTo": null
          },
          {
            "timestamp": 1693143024,
            "content": "Great! And you?",
            "sender": {"fullName": "Caleb", "imageUrl": "https://..."},
            "replyTo": {
              "content": "Hey! How are y'all doing?",
              "sender": {"fullName": "Aaliyah"}
            }
          }
        ]
      }
    ]
  }
}
```

Even though the response to a GraphQL query looks similar to a response from a document database, and even though it has "graph" in its name, GraphQL can be implemented on top of any type of database—relational, document, or graph.

---

## Event Sourcing and CQRS

In all the data models we have discussed so far, the data is queried in the same form as it is written—be it JSON documents, rows in tables, or vertices and edges in a graph. However, in complex applications it can sometimes be difficult to find a single data representation that is able to satisfy all the ways that the data needs to be queried and presented.

Perhaps the simplest, fastest, and most expressive way of writing data is an event log: every time you want to write some data, you encode it as a self-contained string (perhaps as JSON), including a timestamp, and then append it to a sequence of events. Events in this log are immutable; you never change or delete them, but only ever append more events to the log (which may supersede earlier events).

[Figure 3-8](#figure-3-8) shows an example that could be taken from a conference management system.

---

#### Figure 3-8. Using a log of immutable events as the source of truth and deriving materialized views from it {#figure-3-8}

![Figure 3-8: Event sourcing architecture — commands on the left flow into an append-only event log, which fans out to materialized views for booking status, organizer dashboard, and badge printing](images/figure_3_8.svg)

---

In [Figure 3-8](#figure-3-8), every change to the state of the conference (such as the organizer opening registrations, or attendees making and canceling registrations) is first stored as an event. Whenever an event is appended to the log, several materialized views (also known as projections or read models) are also updated to reflect the effect of that event.

The idea of using events as the source of truth and expressing every state change as an event is known as event sourcing [Betts et al. 2012, Young 2014]. The principle of maintaining separate read-optimized representations and deriving them from the write-optimized representation is called command query responsibility segregation (CQRS) Young 2010.

Event sourcing and CQRS have several advantages:

- For the people developing the system, events better communicate the intent of why something happened.
- A key principle of event sourcing is that the materialized views are derived from the event log in a reproducible way. You should always be able to delete the materialized views and recompute them by processing the same events in the same order.
- You can have multiple materialized views that are optimized for the particular queries that your application requires.
- If you decide you want to present the existing information in a new way, building a new materialized view from the existing event log is easy.
- If an event was written in error, you can write a subsequent deletion event to reverse it.
- The event log can also serve as an audit log of what has occurred in the system.
- Event logs can typically handle higher write throughput than databases because of their sequential access patterns.

However, event sourcing and CQRS also have downsides:

- You need to be careful if external information is involved (e.g., exchange rates must be captured in the event itself to ensure deterministic reprocessing).
- The requirement that events are immutable creates problems if events contain personal data from users, since users may exercise their right (e.g., under the GDPR) to request deletion of their data.
- Reprocessing events requires care if there are externally visible side effects.

---

## DataFrames, Matrices, and Arrays

The DataFrame data model is supported by the R language, the Pandas library for Python, Apache Spark, ArcticDB, Dask, and other systems. DataFrames are a popular tool for data scientists preparing data for training ML models, but they are also widely used for data exploration, statistical data analysis, data visualization, and similar purposes.

At first glance, a DataFrame is similar to a table in a relational database or a spreadsheet. A DataFrame supports relational-like operators that perform bulk operations on its contents; for example, applying a function to all the rows, filtering the rows based on a condition, grouping rows by some columns and aggregating other columns, and joining the rows in one DataFrame with another DataFrame based on a key.

A simple example of transforming a relational table into a matrix is shown in [Figure 3-9](#figure-3-9). On the left we have a relational table indicating users' ratings of various movies (on a scale of 1 to 5), and on the right the data has been transformed into a matrix where each column is a movie and each row is a user (similarly to a pivot table in a spreadsheet).

---

#### Figure 3-9. Transforming a relational database of movie ratings into a matrix {#figure-3-9}

![Figure 3-9: Left side shows a movie_ratings relational table with user_id, movie, and rating columns; right side shows the same data pivoted into a sparse matrix with users as rows and movies as columns](images/figure_3_9.svg)

---

A matrix can contain only numbers, and various techniques are used to transform nonnumerical data into numbers in the matrix. For example:

- Dates could be scaled to be floating-point numbers within a suitable range.
- For columns that can take only one of a small, fixed set of values (e.g., the genre of a movie), one-hot encoding is often used.

Once the data is in the form of a matrix of numbers, it is amenable to linear algebra operations, which form the basis of many ML algorithms. DataFrames are flexible enough to allow data to be gradually evolved from a relational form into a matrix representation, while giving the data scientist control over the representation that is most suitable for achieving the goals of the data analysis or model training process.

---

## Summary

Data models are a huge subject, and in this chapter we have taken a quick look at a broad variety of models. The relational model, despite being more than half a century old, remains an important data model for many applications—especially in data warehousing and business analytics. However, several alternatives to relational data have become popular in other domains:

- **The document model** targets use cases where data comes in self-contained JSON documents and where relationships between one document and another are rare.
- **Graph data models** go in the opposite direction, targeting use cases where anything is potentially related to everything and where queries potentially need to traverse multiple hops.
- **DataFrames** generalize relational data to large numbers of columns, providing a bridge between databases and the multidimensional arrays that form the basis of much machine learning, statistical data analysis, and scientific computing.

Another model we discussed is **event sourcing**, which represents data as an append-only log of immutable events and can be advantageous for modeling activities in complex business domains.

One thing that nonrelational data models have in common is that they typically don't enforce a schema for the data they store, which can make it easier to adapt applications to changing requirements. However, your application most likely still assumes that data has a certain structure; it's just a question of whether the schema is explicit (enforced on write) or implicit (assumed on read).

Although we have covered a lot of ground, some data models remain unmentioned. To give just a few brief examples:

- Researchers working with genome data often need to perform sequence similarity searches, which require specialized genome database software like GenBank Benson et al. 2007.
- Many financial systems use ledgers with double-entry accounting as their data model.
- Full-text search is arguably a kind of data model that is frequently used alongside databases.

In the next chapter we will discuss some of the trade-offs that come into play when implementing the data models described in this chapter.


---

## References

1. Brandon & Karacapilidis 2024 — Brandon, M. & Karacapilidis, N. (2024). *On the performance benefits of declarative query languages.* (Referenced in DDIA 2nd ed.)
2. Krishnaswami — Krishnaswami, N. *The case for declarative query optimization.* (Referenced in DDIA 2nd ed.)
3. Hellerstein 2010 — Hellerstein, J.M. (2010). *The Declarative Imperative: Experiences and Conjectures in Distributed Logic.* SIGMOD Record.
4. Codd 1970 — Codd, E.F. (1970). *A Relational Model of Data for Large Shared Data Banks.* Communications of the ACM, 13(6), 377–387.
5. Stonebraker & Hellerstein 2005 — Stonebraker, M. & Hellerstein, J.M. (2005). *What Goes Around Comes Around.* Readings in Database Systems, 4th ed.
6. Winand 2015 — Winand, M. (2015). *Modern SQL: A lot has changed since SQL-92.* use-the-index-luke.com/sql/modern-sql.
7. Fowler 2012 — Fowler, M. (2012). *OrmHate.* martinfowler.com/bliki/OrmHate.html.
8. Mihalcea 2023 — Mihalcea, V. (2023). *The best way to fix the Hibernate N+1 query problem.* vladmihalcea.com.
9. Schauder 2023 — Schauder, J. (2023). *The cost of JOIN in Spring Data JDBC.* spring.io/blog.
10. Brandon 2025 — Brandon, M. (2025). *Multi-way joins in document databases.* (Referenced in DDIA 2nd ed.)
11. Zola 2014 — Zola, E. (2014). *One-to-few, one-to-many, and many-to-many in MongoDB.* (Referenced in DDIA 2nd ed.)
12. Andrews 2023 — Andrews, J. (2023). *Document model trade-offs in production.* (Referenced in DDIA 2nd ed.)
13. Krikorian 2012 — Krikorian, R. (2012). *Timelines at Scale.* QCon San Francisco. (Twitter/X architecture talk.)
14. Kimball & Ross 2013 — Kimball, R. & Ross, M. (2013). *The Data Warehouse Toolkit: The Definitive Guide to Dimensional Modeling*, 3rd ed. Wiley.
15. Kaminsky 2022 — Kaminsky, D. (2022). *One Big Table: a heretical data modeling approach.* (Referenced in DDIA 2nd ed.)
16. Nelson 2018 — Nelson, D. (2018). *Implementing Fractional Indexing.* observablehq.com/@dgreensp/implementing-fractional-indexing.
17. Wallace 2017 — Wallace, C. (2017). *Ordered data and relational databases.* (Referenced in DDIA 2nd ed.)
18. Greenspan 2020 — Greenspan, D. (2020). *Implementing Fractional Indexing.* (Referenced in DDIA 2nd ed.)
19. Leavitt 2010 — Leavitt, N. (2010). *Will NoSQL Databases Live Up to Their Promise?* IEEE Computer, 43(2).
20. Awadallah 2009 — Awadallah, A. (2009). *Schema-on-Read vs Schema-on-Write.* (Referenced in DDIA 2nd ed.)
21. Odersky 2013 — Odersky, M. (2013). *The trouble with types.* Strange Loop Conference.
22. Irwin 2013 — Irwin, C. (2013). *Schema-free MySQL.* (Referenced in DDIA 2nd ed.)
23. Percona 2023 — Percona. (2023). *pt-online-schema-change documentation.* percona.com/doc/percona-toolkit.
24. Noach 2016 — Noach, S. (2016). *gh-ost: GitHub's online schema migration tool for MySQL.* github.com/github/gh-ost.
25. Mukherjee 2022 — Mukherjee, S. (2022). *Online schema migrations at scale.* (Referenced in DDIA 2nd ed.)
26. Pérez-Aradros 2023 — Pérez-Aradros, B. (2023). *Zero-downtime schema changes in large databases.* (Referenced in DDIA 2nd ed.)
27. Corbett et al. 2012 — Corbett, J.C. et al. (2012). *Spanner: Google's Globally Distributed Database.* OSDI 2012.
28. Burleson — Burleson, D. *Oracle multi-table cluster tables.* dba-oracle.com.
29. Chang et al. 2006 — Chang, F. et al. (2006). *Bigtable: A Distributed Storage System for Structured Data.* OSDI 2006.
30. Walmsley 2015 — Walmsley, P. (2015). *XQuery*, 2nd ed. O'Reilly Media.
31. Bryan 2013 — Bryan, P.C. & Zyp, K. (2013). *JSON Pointer.* RFC 6901. IETF.
32. Gössner et al. 2024 — Gössner, S. et al. (2024). *JSONPath: Query Expressions for JSON.* RFC 9535. IETF.
33. Stonebraker 2024 — Stonebraker, M. (2024). *The convergence of relational and document databases.* (Referenced in DDIA 2nd ed.)
34. Page et al. 1999 — Page, L., Brin, S., Motwani, R. & Winograd, T. (1999). *The PageRank Citation Ranking: Bringing Order to the Web.* Stanford InfoLab Technical Report.
35. Bronson et al. 2013 — Bronson, N. et al. (2013). *TAO: Facebook's Distributed Data Store for the Social Graph.* USENIX ATC 2013.
36. Noy et al. 2019 — Noy, N. et al. (2019). *Industry-Scale Knowledge Graphs: Lessons and Challenges.* ACM Queue, 17(2).
37. Feng et al. 2023 — Feng, X. et al. (2023). *KÙZU: An Embeddable Graph Database Management System.* CIDR 2023.
38. Besta et al. 2019 — Besta, M. et al. (2019). *Demystifying Graph Databases: Analysis and Taxonomy of Data Organization, System Designs, and Graph Queries.* arXiv:1910.09017.
39. TinkerPop 2023 — Apache TinkerPop. (2023). *Gremlin Query Language.* tinkerpop.apache.org.
40. Francis et al. 2018 — Francis, N. et al. (2018). *Cypher: An Evolving Query Language for Property Graphs.* SIGMOD 2018.
41. Eifrem 2012 — Eifrem, E. (2012). *Tweet on the origin of the name 'Cypher'.* twitter.com/emileifrem.
42. Tisiot 2021 — Tisiot, F. (2021). *Recursive queries in PostgreSQL.* aiven.io/blog.
43. Goel 2020 — Goel, A. (2020). *Hierarchical queries in Oracle.* Oracle documentation / blogs.
44. Deutsch et al. 2018 — Deutsch, A. et al. (2018). *GSQL: A Graph Query Language.* TigerGraph white paper.
45. van Rest et al. 2016 — van Rest, O. et al. (2016). *PGQL: A Property Graph Query Language.* GRADES Workshop at SIGMOD 2016.
46. Rathle 2024 — Rathle, T. (2024). *GQL: The ISO Standard for Graph Query Language.* neo4j.com/blog.
47. Deutsch et al. 2022 — Deutsch, A. et al. (2022). *Graph Pattern Matching in GQL and SQL/PGQ.* SIGMOD 2022.
48. Green 2019 — Green, A. (2019). *GQL: A Proposed Standard Graph Query Language.* SIGMOD Record, 48(4).
49. AWS Neptune Docs — Amazon Web Services. *Amazon Neptune data model: quads.* docs.aws.amazon.com/neptune.
50. Datomic Docs — Cognitect. *Datomic data model: 5-tuples.* docs.datomic.com.
51. Beckett & Berners-Lee 2011 — Beckett, D. & Berners-Lee, T. (2011). *Turtle – Terse RDF Triple Language.* W3C Team Submission.
52. Target 2018 — Target, C. (2018). *Whatever happened to the Semantic Web?* twobithistory.org.
53. Mendel-Gleason 2022 — Mendel-Gleason, G. (2022). *The Semantic Web is dead. Long live the Semantic Web.* terminusdb.com/blog.
54. Sporny et al. 2014 — Sporny, M. et al. (2014). *JSON-LD 1.0: A JSON-based Serialization for Linked Data.* W3C Recommendation.
55. U. of Michigan Ontologies — University of Michigan. *Biomedical ontologies.* umich.edu (referenced in DDIA 2nd ed.).
56. Facebook Open Graph — Facebook. *The Open Graph Protocol.* ogp.me.
57. Haughey 2015 — Haughey, M. (2015). *Link unfurling.* (Referenced in DDIA 2nd ed.)
58. W3C 2014 — W3C. (2014). *RDF 1.1 Concepts and Abstract Syntax.* W3C Recommendation. w3.org/TR/rdf11-concepts.
59. Harris & Seaborne 2013 — Harris, S. & Seaborne, A. (2013). *SPARQL 1.1 Query Language.* W3C Recommendation. w3.org/TR/sparql11-query.
60. Green et al. 2013 — Green, T.J., Huang, S.S., Loo, B.T. & Tannen, V. (2013). *Datalog and Recursive Query Processing.* Foundations and Trends in Databases, 5(2).
61. Ceri et al. 1989 — Ceri, S., Gottlob, G. & Tanca, L. (1989). *What You Always Wanted to Know About Datalog (And Never Dared to Ask).* IEEE TKDE, 1(1).
62. Abiteboul et al. 1995 — Abiteboul, S., Hull, R. & Vianu, V. (1995). *Foundations of Databases.* Addison-Wesley.
63. Meyer 2020 — Meyer, D. (2020). *LIquid: The soul of a new graph database.* engineering.linkedin.com.
64. Bessey 2024 — Bessey, A. (2024). *GraphQL in production: authorization, rate limiting, and performance.* (Referenced in DDIA 2nd ed.)
65. Betts et al. 2012 — Betts, D. et al. (2012). *Exploring CQRS and Event Sourcing.* Microsoft patterns & practices. microsoft.com/en-us/download/details.aspx?id=34774.
66. Young 2014 — Young, G. (2014). *CQRS and Event Sourcing.* Talk at Code on the Beach 2014.
67. Young 2010 — Young, G. (2010). *CQRS Documents.* cqrs.files.wordpress.com/2010/11/cqrs_documents.pdf.
68. Robinson 2019 — Robinson, I. (2019). *Crypto-shredding: how to forget user data in an event-driven system.* (Referenced in DDIA 2nd ed.)
69. Petersohn et al. 2020 — Petersohn, D. et al. (2020). *Towards Scalable Dataframe Systems.* VLDB 2020.
70. Papadopoulos et al. 2016 — Papadopoulos, S. et al. (2016). *The TileDB Array Data Storage Manager.* VLDB 2017.
71. Rusu 2022 — Rusu, F. (2022). *Array databases for scientific data management.* (Referenced in DDIA 2nd ed.)
72. Targett 2023 — Targett, E. (2023). *DataFrames for financial time series.* (Referenced in DDIA 2nd ed.)
73. Benson et al. 2007 — Benson, D.A. et al. (2007). *GenBank.* Nucleic Acids Research, 36(D1), D25–D30.