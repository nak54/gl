# Chapter 2. Defining Nonfunctional Requirements

> *The Internet was done so well that most people think of it as a natural resource like the Pacific Ocean, rather than something that was man-made. When was the last time a technology with a scale like that was so error-free?*
>
> — **Alan Kay**, in interview with Dr. Dobb's Journal (2012)

If you are building an application, you will be driven by a list of requirements. At the top of your list is most likely the functionality that the application must offer: what screens and what buttons you need, and what each operation is supposed to do in order to fulfill the purpose of your software. These are your **functional requirements**.

In addition, you probably have **nonfunctional requirements**: for example, the app should be fast, reliable, secure, legally compliant, and easy to maintain. These requirements might not be explicitly written down, because they may seem somewhat obvious, but they are just as important as the app's functionality; an app that is unbearably slow or unreliable might as well not exist.

Many nonfunctional requirements, such as security, fall outside the scope of this book. But we will consider a few, and this chapter will help you articulate them for your own systems. In particular, we will look at the following:

- Defining and measuring the **performance** of a system
- What it means for a service to be **reliable**—namely, continuing to work correctly, even when things go wrong
- Allowing a system to be **scalable** by having efficient ways of adding computing capacity as the load on the system grows
- Making it easier to **maintain** a system in the long term

The terminology introduced in this chapter will also be useful in the following chapters, when we go into the details of how data-intensive systems are implemented. However, abstract definitions can be quite dry; to make the ideas more concrete, we will start this chapter with a case study of a social networking service, which will provide practical examples of performance and scalability.

---

## Case Study: Social Network Home Timelines

Imagine we have been given the task of implementing a social network in the style of X (formerly Twitter), where users can post messages and follow other users. This will be a huge simplification of how such a service actually works [^1][^2][^3], but it will help illustrate some of the issues that arise in large-scale systems.

Let's assume that users make a total of 500 million posts per day, or 5,800 posts per second on average. Occasionally, the rate can spike to as high as 150,000 posts per second [^4]. Let's also assume that the average user follows 200 people and has 200 followers (although there is a very wide range: most people have only a handful of followers, and a few celebrities, such as Barack Obama, have over 100 million followers).

### Representing Users, Posts, and Follows

We keep all the data in a relational database, as shown in **Figure 2-1**. We have one table for users, one table for posts, and one table for follow relationships.

![Figure 2-1. A simple relational schema for a social network in which users can follow one another](images/fig2-1_relational_schema.svg)

**Figure 2-1.** *A simple relational schema for a social network in which users can follow one another.*

Let's say the main read operation that our social network must support is the **home timeline**, which displays recent posts by people the user is following. We could write the following SQL query to get the home timeline for a particular user:

```sql
SELECT posts.*, users.* FROM posts
  JOIN follows ON posts.sender_id = follows.followee_id
  JOIN users   ON posts.sender_id = users.id
  WHERE follows.follower_id = current_user
  ORDER BY posts.timestamp DESC
  LIMIT 1000
```

To execute this query, the database will use the `follows` table to find everybody who `current_user` is following, look up recent posts by those users, and sort them by timestamp to get the most recent 1,000 posts by any of the followed users.

Posts are supposed to be timely, so let's assume that after somebody makes a post, we want their followers to be able to see it within five seconds. One approach is for the user's client to repeat the preceding query every five seconds while the user is online (this is known as **polling**). If we assume that 10 million users are online and logged in at the same time, that would mean running the query 2 million times per second. Even if we were to poll less frequently, this is a lot.

This query is also quite expensive: if a user is following 200 people, the query needs to fetch a list of recent posts by each of those 200 people and merge those lists. Two million timeline queries per second times 200 followed accounts makes 400 million lookups per second—a huge number. And that's the average case. Some users follow tens of thousands of accounts; for them, this query is very expensive to execute and difficult to make fast.

### Materializing and Updating Timelines

How can we do better? First, instead of polling, it would be better if the server actively **pushed** new posts to any followers who are currently online. Second, we should **precompute** the results of the query so that a user's request for their home timeline can be served from a cache.

Imagine that for each user, we store a data structure containing their home timeline (i.e., the recent posts by people they are following). Every time a user makes a post, we look up all their followers and insert that post into the home timeline of each follower—like delivering a message to a mailbox. Now when a user logs in, we can simply give them this precomputed home timeline. Moreover, to receive a notification about any new posts on their timeline, the user's client simply needs to subscribe to the stream of posts being added to their home timeline.

The downside of this approach is that we now need to do more work every time a user makes a post, because the home timelines are **derived data** that needs to be updated. The process is illustrated in **Figure 2-2**. When one initial request results in several downstream requests being carried out, we use the term **fan-out** to describe the factor by which the number of requests increases.

![Figure 2-2. Fan-out: delivering new posts to every follower of the user who made the post](images/fig2-2_fanout_timelines.svg)

**Figure 2-2.** *Fan-out: delivering new posts to every follower of the user who made the post.*

At a rate of 5,800 posts per second, if the average post reaches 200 followers (i.e., a fan-out factor of 200), we will need to do just over 1 million home timeline writes per second. This is a lot, but it's still a significant saving compared to the 400 million per-sender post lookups per second that we would otherwise have to do.

If the rate of posts spikes because of a special event, we don't have to do the timeline deliveries immediately—we can enqueue them and accept that it will temporarily take a bit longer for posts to show up in followers' timelines. Even during such load spikes, timelines remain fast to load, since we simply serve them from a cache.

This process of precomputing and updating the results of a query is called **materialization**, and the timeline cache is an example of a **materialized view** (a concept we will discuss further in later chapters). The materialized view speeds up reads, but in return we have to do more work on writes. The cost of writes for most users is modest, but a social network also has to consider some extreme cases:

- If a user is following a very large number of accounts, and those accounts post a lot, that user will have a high rate of writes to their materialized timeline. However, that user is not likely reading all the posts in their timeline, so it's OK to simply drop some of their timeline writes and show the user only a sample of the posts from the accounts they're following [^5].
- When a celebrity account with a very large number of followers makes a post, we have to do a lot of work to insert that post into the home timelines of each of their millions of followers. In this case, dropping some of those writes is not OK. One way of solving this problem is to handle celebrity posts separately from everyone else's posts: we can save ourselves the effort of adding celebrity posts to millions of timelines by storing them separately and merging them with the materialized timeline when it is read. Despite such optimizations, handling celebrities on a social network can require a lot of infrastructure [^6].

---

## Describing Performance

Most discussions of software performance consider two main types of metric:

**Response time**
The elapsed time from the moment when a user makes a request until they receive the requested answer. The unit of measurement is seconds (or milliseconds, or microseconds).

**Throughput**
The number of requests per second, or the data volume per second, that the system is processing. For a given allocation of hardware resources, there is a maximum throughput that can be handled. The unit of measurement is "somethings per second."

In the social network case study, "posts per second" and "timeline writes per second" are throughput metrics, whereas "time it takes to load the home timeline" and "time until a post is delivered to followers" are response time metrics.

Throughput and response time are often related. An example of such a relationship for an online service is sketched in **Figure 2-3**. The service has a low response time when request throughput is low, but response time increases as load increases. This is because of **queueing**: when a request arrives on a highly loaded system, the CPU is likely already in the process of handling an earlier request, and therefore the incoming request needs to wait until the earlier request has been completed. As throughput approaches the maximum that the hardware can handle, queueing delays increase sharply.

![Figure 2-3. As the throughput of a service approaches its capacity, the response time increases dramatically because of queueing](images/fig2-3_throughput_vs_response_time.svg)

**Figure 2-3.** *As the throughput of a service approaches its capacity, the response time increases dramatically because of queueing.*

### When an Overloaded System Won't Recover

If a system is close to overload, with throughput pushed close to the limit, it can sometimes enter a vicious cycle where it becomes less efficient and hence even more overloaded. For example, if a long queue of requests is waiting to be handled, response times may increase so much that clients time out and resend their requests. This causes the rate of requests to increase even further, making the problem worse—a **retry storm**. Even when the load is reduced again, such a system may remain in an overloaded state until it is rebooted or otherwise reset. This phenomenon is called a **metastable failure**, and it can cause serious outages in production systems [^7][^8][^9].

To avoid retries overloading a service, you can increase and randomize the time between successive retries on the client side (**exponential backoff** [^10][^11]) and temporarily stop sending requests to a service that has returned errors or timed out recently (by using a **circuit breaker** [^12][^13] or **token bucket algorithm** [^14]). The server can also detect when it is approaching overload and start proactively rejecting requests (**load shedding** [^15]), or send back responses asking clients to slow down (**backpressure** [^1][^16]). The choice of queueing and load balancing algorithms can also make a difference [^17].

In terms of performance metrics, the response time is usually what users care about the most, whereas the throughput determines the required computing resources (e.g., how many servers you need) and hence the cost of serving a particular workload. If throughput is likely to increase beyond the current hardware's capability, the capacity needs to be expanded; a system is said to be **scalable** if its maximum throughput can be significantly increased by adding computing resources.

### Latency and Response Time

"Latency" and "response time" are sometimes used interchangeably, but in this book we will use these and a few related terms in a specific way (illustrated in **Figure 2-4**):

- The **response time** is what the client sees; it includes all delays incurred anywhere in the system.
- The **service time** is the duration for which the service is actively processing the client's request.
- **Queueing delays** can occur at several points in the flow—for example, after a request is received, it might need to wait until a CPU is available before it can be processed, or a response packet might need to be buffered before it is sent over the network if other tasks on the same machine are sending a lot of data via the outbound network interface.
- **Latency** is a catchall term for time during which a request is not being actively processed—that is, during which it is *latent*. In particular, **network latency** or **network delay** refers to the time that a request and response spend traveling through the network.

![Figure 2-4. Response time, service time, network latency, and queueing delay](images/fig2-4_response_time_components.svg)

**Figure 2-4.** *Response time, service time, network latency, and queueing delay.*

The response time can vary significantly from one request to the next, even if you keep making the same request over and over again. Many factors can add random delays—for example, a context switch to a background process, the loss of a network packet and TCP retransmission, a garbage collection pause, a page fault forcing a read from disk, or mechanical vibrations in the server rack [^18].

**Queueing delays** often account for a large part of the variability in response times. As a server can process only a small number of things in parallel (limited, for example, by its number of CPU cores), it takes only a small number of slow requests to hold up the processing of subsequent requests—an effect known as **head-of-line blocking**. Even if those subsequent requests have fast service times, the client will see a slow overall response time due to the time waiting for the prior request to complete. The queueing delay is not part of the service time, and for this reason it is important to measure response times on the client side.

### Average, Median, and Percentiles

Because the response time varies from one request to the next, we need to think of it not as a single number, but as a **distribution of values** that we can measure. In **Figure 2-5**, each gray bar represents a request to a service, and its height shows how long that request took. Most requests are reasonably fast, but occasional outliers take much longer. Variation in network delay is also known as **jitter**.

![Figure 2-5. Illustrating mean and percentiles: response times for a sample of 100 requests to a service](images/fig2-5_percentiles.svg)

**Figure 2-5.** *Illustrating mean and percentiles: response times for a sample of 100 requests to a service.*

It's common to report the **average** response time of a service (technically, the arithmetic mean). The mean response time is useful for estimating throughput limits [^19]. However, the mean is not a very good metric if you want to know your "typical" response time, because it doesn't tell you how many users actually experienced that delay.

Usually it's better to use **percentiles**. If you take your list of response times and sort it from fastest to slowest, the **median** is the halfway point—for example, if your median response time is 200 ms, that means half your requests return in less than 200 ms, and half your requests take longer. The median is also known as the **50th percentile**, sometimes abbreviated as **p50**.

To figure out how bad your outliers are, you can look at higher percentiles: the **95th**, **99th**, and **99.9th** percentiles are common (abbreviated **p95**, **p99**, and **p999**). For example, if the 95th percentile response time is 1.5 seconds, that means 95 out of 100 requests take less than 1.5 seconds, and 5 out of 100 requests take 1.5 seconds or more.

High response-time percentiles, also known as **tail latencies**, are important because they directly affect users' experience of the service. For example, Amazon describes response time requirements for internal services in terms of the **99.9th percentile**, even though this affects only 1 in 1,000 requests. This is because the customers with the slowest requests are often those who have the most data on their accounts, as they have made many purchases—that is, they're the most valuable customers [^20]. It's important to keep those customers happy by ensuring the website is fast for them.

Optimizing the 99.99th percentile (the slowest 1 in 10,000 requests) was deemed too expensive and found to not yield enough benefit for Amazon's purposes. Reducing response times at very high percentiles is difficult because they are easily affected by random events outside of your control, and the benefits are diminishing.

### The User Impact of Response Times

It seems obvious that a fast service is better for users than a slow service [^21]. However, it is surprisingly difficult to get hold of reliable data to quantify the effect that latency has on user behavior.

Some often-cited statistics are unreliable. In 2006, for example, Google reported that a slowdown in search results from 400 ms to 900 ms was associated with a 20% drop in traffic and revenue [^22]. However, another Google study from 2009 reported that a 400 ms increase in latency resulted in only 0.6% fewer searches per day [^23], and in the same year Bing found that a two-second increase in load time reduced ad revenue by 4.3% [^24]. Newer data from these companies appears not to be publicly available.

A more recent Akamai study claims that a 100 ms increase in response time reduced the conversion rate of ecommerce sites by up to 7% [^25]; on closer inspection, though, the same study reveals that very fast page load times are also correlated with lower conversion rates! This seemingly paradoxical result is explained by the fact that the pages that load fastest are often those that have no useful content (e.g., 404 error pages).

A study by Yahoo compared click-through rates on fast-loading versus slow-loading search results, controlling for quality of search results [^26]. It reports 20%–30% more clicks on fast searches when the difference between fast and slow responses is 1.25 seconds or more.

### Use of Response Time Metrics

High percentiles are especially important in backend services that are called multiple times as part of serving a single end-user request. Even if you make the calls in parallel, the request still needs to wait for the slowest of the parallel calls to complete. It takes just one slow call to make the entire end-user request slow, as illustrated in **Figure 2-6**. Even if only a small percentage of backend calls are slow, the chance of getting a slow call increases if an end-user request requires multiple backend calls, so a higher proportion of such end-user requests end up being slow (an effect known as **tail latency amplification** [^27]).

![Figure 2-6. When several backend calls are needed to serve a request, just a single slow call can slow down the entire end-user request](images/fig2-6_tail_latency_amplification.svg)

**Figure 2-6.** *When several backend calls are needed to serve a request, just a single slow call can slow down the entire end-user request.*

Percentiles are often used in **service level objectives (SLOs)** and **service level agreements (SLAs)** as ways of defining the expected performance and availability of a service [^28]. For example, an SLO may set a target for a service to have a median response time of less than 200 ms and a 99th percentile under 1 second, and a target that at least 99.9% of valid requests result in non-error responses. An SLA is a contract that specifies what happens if the SLO is not met (e.g., customers may be entitled to a refund). In practice, defining good availability metrics for SLOs and SLAs is not straightforward [^29][^30].

### Computing Percentiles

If you want to add response time percentiles to the monitoring dashboards for your services, you need to efficiently calculate them on an ongoing basis. For example, you may want to keep a rolling window of response times for requests in the last 10 minutes. Every minute, you calculate the median and various percentiles over the values in that window and plot those metrics on a graph.

The simplest implementation is to keep a list of response times for all requests within the time window and sort that list every minute. If that is too inefficient for you, there are algorithms that can calculate a good approximation of percentiles at minimal CPU and memory cost. Open source percentile estimation libraries include **HdrHistogram** [^31], **t-digest** [^32][^33], **OpenHistogram** [^34], and **DDSketch** [^35].

Beware that averaging percentiles (e.g., to reduce the time resolution or to combine data from several machines) is mathematically meaningless. The right way of aggregating response time data is to add the histograms [^36].

---

## Reliability and Fault Tolerance

Everybody has an intuitive idea of what it means for something to be reliable or unreliable. For software, typical expectations include the following:

- The application performs the function that the user expected.
- The application can tolerate the user making mistakes or using the software in unexpected ways.
- Its performance is good enough for the required use case, under the expected load and data volume.
- The system prevents any unauthorized access and abuse.

If all those things together mean "working correctly," then we can understand **reliability** as meaning, roughly, "continuing to work correctly, even when things go wrong." To be more precise about things going wrong, we will distinguish between **faults** and **failures** [^37][^38][^39]:

**Fault**
A fault occurs when a particular part of a system stops working correctly—for example, if a single hard drive malfunctions, or a single machine crashes, or an external service (that the system depends on) has an outage.

**Failure**
A failure occurs when the system as a whole stops providing the required service to the user—in other words, when it does not meet the SLO.

The distinction between faults and failures can be confusing because they are the same thing, just at different levels. For example, if a hard drive stops working, we say that the hard drive has *failed*; if the system consists of only that one hard drive, it has stopped providing the required service and thus has also failed. However, if the system consists of multiple hard drives, the failure of a single hard drive is only a *fault* from the point of view of the bigger system, and the bigger system might be able to tolerate that fault by having a copy of the data on another hard drive.

### Fault Tolerance

We call a system **fault-tolerant** if it continues providing the required service to users in spite of certain faults occurring. If a system cannot tolerate a certain part becoming faulty, we call that part a **single point of failure (SPOF)**, because a fault in that part escalates to cause the failure of the whole system.

For example, in the social network case study, a fault that might happen is that during the fan-out process, a machine involved in updating the materialized timelines crashes or becomes unavailable. To make this process fault-tolerant, we would need to ensure that another machine can take over this task without missing any posts that should have been delivered, and without duplicating any posts. (This idea is known as **exactly-once semantics**.)

Fault tolerance is always limited to a certain number of certain types of faults. For example, a system might be able to tolerate a maximum of two hard drives failing at the same time, or a maximum of one out of three nodes crashing.

Counterintuitively, in such fault-tolerant systems, it can make sense to increase the rate of faults by triggering them deliberately—for example, by randomly killing individual processes without warning. This is called **fault injection**. Many critical bugs are actually due to poor error handling [^40]; by deliberately inducing faults, you ensure that the fault-tolerance machinery is continually exercised and tested. **Chaos engineering** is a discipline that aims to improve confidence in fault-tolerance mechanisms through experiments such as deliberately injecting faults [^41].

### Hardware and Software Faults

When we think of causes of system failure, hardware faults quickly come to mind:

- Approximately 2%–5% of magnetic hard drives fail per year [^42][^43]; in a storage cluster with 10,000 disks, we should therefore expect on average one disk failure per day. Recent data suggests that disks are getting more reliable, but failure rates remain significant [^44].
- Approximately 0.5%–1% of solid state drives (SSDs) fail per year [^45]. Small numbers of bit errors are corrected automatically [^46], but uncorrectable errors occur approximately once per year per drive, even in drives that are fairly new. This error rate is higher than that of magnetic hard drives [^47][^48].
- Other hardware components (such as power supplies, RAID controllers, and memory modules) also fail, although less frequently than hard drives [^49][^50].
- Approximately 1 in 1,000 machines has a CPU core that occasionally computes the wrong result, likely because of manufacturing defects [^51][^52][^53]. In some cases an erroneous computation leads to a crash, but in other cases it leads to a program simply returning the wrong result.
- Data in RAM can be corrupted, either because of random events such as cosmic rays or because of permanent physical defects. Even when memory with error-correcting codes (ECC) is used, more than 1% of machines encounter an uncorrectable error in a given year [^54]. Furthermore, certain pathological memory access patterns can flip bits with high probability [^55].
- An entire datacenter might become unavailable (e.g., because of a power outage or network misconfiguration) or even be permanently destroyed (e.g., by fire, flood, or earthquake [^56]). A solar storm could damage power grids and undersea network cables [^57]. Although such large-scale failures are rare, their impact can be catastrophic if a service cannot tolerate the loss of a datacenter [^58].

These events are rare enough that you often don't need to worry about them when working on a small system. However, in a large-scale system, hardware faults happen often enough that they become part of normal system operation.

**Tolerating hardware faults through redundancy**

Our first response to unreliable hardware is usually to add **redundancy** to the individual hardware components. Disks may be set up in a **RAID** configuration, servers may have dual power supplies and hot-swappable CPUs, and datacenters may have batteries and diesel generators for backup power. Such redundancy can often keep a machine running uninterrupted for years.

Redundancy is most effective when component faults are independent—that is, when the occurrence of one fault does not change the likelihood that another fault will occur. However, experience has shown significant correlations between component failures [^43][^59][^60].

Hardware redundancy increases the uptime of a single machine; however, using a distributed system has advantages, such as being able to tolerate a complete outage of one datacenter. For this reason, cloud systems tend to focus less on the reliability of individual machines and instead aim to make services highly available by tolerating faulty nodes at the software level. Cloud providers use **availability zones** to identify which resources are physically co-located.

Systems that can tolerate the loss of entire machines also have operational advantages. A single-server system requires planned downtime if you need to reboot the machine, whereas a multi-node fault-tolerant system can be patched by restarting one node at a time, without affecting the service for users. This is called a **rolling upgrade**.

**Software faults**

Although hardware failures can be weakly correlated, they are still mostly independent. On the other hand, **software faults** are often very highly correlated, because it is common for many nodes to run the same software and thus have the same bugs [^61][^62]. Such faults are harder to anticipate, and they tend to cause many more system failures than uncorrelated hardware faults [^49]. Examples include the following:

- A software bug that causes every node to fail at the same time in particular circumstances. For instance, on June 30, 2012, a leap second caused many Java applications to hang simultaneously because of a bug in the Linux kernel [^63]. And because of a firmware bug, all SSDs of certain models suddenly failed after precisely 32,768 hours of operation [^64].
- A runaway process that uses up a shared, limited resource, such as CPU time, memory, disk space, network bandwidth, or threads [^65][^66].
- A service that the system depends on slows down, becomes unresponsive, or starts returning corrupted responses.
- An interaction between different systems results in emergent behavior that does not occur when each system is tested in isolation [^67].
- **Cascading failures**, where a problem in one component causes another component to become overloaded and slow down, which in turn brings down another component [^68][^69].

The bugs that cause these kinds of software faults often lie dormant for a long time until they are triggered by an unusual set of circumstances [^70][^71].

The problem of systematic faults in software has no quick solution. Lots of small things can help: carefully thinking about assumptions and interactions in the system; thorough testing; ensuring process isolation; allowing processes to crash and restart; avoiding feedback loops such as retry storms; measuring, monitoring, and analyzing system behavior in production.

### Humans and Reliability

Humans design and build software systems, and the operators who keep the systems running are also human. One study of large internet services found that configuration changes by operators were the leading cause of outages, whereas hardware faults played a role in only 10%–25% of cases [^72].

It is tempting to label such problems as "human error" and to wish that they could be solved by better controlling human behavior through tighter procedures and compliance with rules. However, blaming people for mistakes is counterproductive. What we call "human error" is not really the cause of an incident, but rather a symptom of a problem with the **sociotechnical system** in which people are trying their best to do their jobs [^73]. Often complex systems have emergent behavior, in which unexpected interactions between components may also lead to failures [^74].

Various technical measures can help minimize the impact of human mistakes, including thorough testing, rollback mechanisms for quickly reverting configuration changes, gradual rollouts of new code, detailed and clear monitoring, and observability tools for diagnosing production issues.

Increasingly, organizations are adopting a culture of **blameless postmortems**: after an incident, the people involved are encouraged to share full details about what happened, without fear of punishment, since this allows others in the organization to learn how to prevent similar problems in the future [^75]. As a general principle, when investigating an incident, you should be suspicious of simplistic answers. "Bob should have been more careful when deploying that change" is not productive, but neither is "We must rewrite the backend in Haskell."

### How Important Is Reliability?

Reliability is not just for nuclear power stations and air traffic control; more mundane applications are also expected to work reliably. Bugs in business applications lead to lost productivity (and legal risks if figures are reported incorrectly), and outages of ecommerce sites can have huge costs in terms of lost revenue and damage to reputation.

In many applications, a temporary outage of a few minutes or even a few hours is tolerable [^76], but permanent data loss or corruption would be catastrophic. As an example of how unreliable software can harm people, consider the **Post Office Horizon scandal**. Between 1999 and 2019, hundreds of people managing Post Office branches in Britain were convicted of theft or fraud because the accounting software showed a shortfall in their accounts. Eventually it became clear that many of these shortfalls were due to bugs in the software, resulting in many of these convictions being overturned [^78]. This was probably the largest miscarriage of justice in British history [^79].

In some situations we may choose to sacrifice reliability in order to reduce development cost (e.g., when developing a prototype product for an unproven market)—but we should be very conscious of when we are cutting corners and keep in mind the potential consequences.

---

## Scalability

Even if a system is working reliably today, that doesn't mean it will necessarily work reliably in the future. One common reason for degradation is increased load. **Scalability** is the term we use to describe a system's ability to cope with increased load.

Scalability is not a one-dimensional label—it is meaningless to say "X is scalable" or "Y doesn't scale." Rather, discussing scalability means considering questions like these:

- If the system grows in a particular way, what are our options for coping with the growth?
- How can we add computing resources to handle the additional load?
- Based on current growth projections, when will we hit the limits of our current architecture?

### Understanding Load

First, you need a clear understanding of the current load on the system. Often this will be a measure of throughput—for example, the number of requests per second to a service, the number of gigabytes of new data arriving per day, or the number of shopping cart checkouts per hour. Sometimes you care about the peak of a variable quantity, such as the number of simultaneously online users.

Once you understand the load on your system, you can investigate what happens when the load increases. You can look at this in two ways:

- When you increase the load in a certain way and keep the system resources (CPUs, memory, network bandwidth, etc.) unchanged, how is the performance of your system affected?
- When you increase the load in a certain way, how much do you need to increase the resources if you want to keep performance unchanged?

If doubling the resources will enable you to handle twice the load while keeping performance the same, we say that you have **linear scalability**, and this is considered a good thing. Occasionally it is possible to handle twice the load with less than double the resources [^81][^82]. Much more likely is that the cost grows faster than linearly.

### Shared-Memory, Shared-Disk, and Shared-Nothing Architectures

The simplest way of increasing the hardware resources of a service is to move it to a more powerful machine. This approach is called **vertical scaling** or **scaling up**.

You can get parallelism on a single machine by using multiple processes or threads. All the threads belonging to the same process can access the same RAM, and hence this approach is also called a **shared-memory architecture**. The problem with a shared-memory approach is that the cost grows faster than linearly.

Another approach is the **shared-disk architecture**, which uses several machines with independent CPUs and RAM but stores data on an array of disks that is shared among the machines, which are connected via a fast network (NAS or SAN). Contention and the overhead of locking limit the scalability of the shared-disk approach [^83].

By contrast, the **shared-nothing architecture** [^84] (also called **horizontal scaling** or **scaling out**) involves a distributed system with multiple nodes, each of which has its own CPUs, RAM, and disks. Any coordination between nodes is done at the software level, via a conventional network.

The advantages of this approach are that it has the potential to scale linearly, it can use whatever hardware offers the best price/performance ratio (especially in the cloud), it can more easily adjust its hardware resources as load increases or decreases, and it can achieve greater fault tolerance by distributing the system across multiple datacenters and regions. The downsides are that it requires explicit sharding and incurs all the complexity of distributed systems.

Some cloud native database systems use separate services for storage and transaction execution, with multiple compute nodes sharing access to the same storage service [^85]. This model has some similarity to a shared-disk architecture, but it avoids the scalability problems of older systems by offering a specialized API designed for the specific needs of the database.

### Principles for Scalability

The architecture of systems that operate at large scale is usually highly specific to the application. There is no such thing as a generic, one-size-fits-all scalable architecture (informally known as **magic scaling sauce**).

A good general principle for scalability is to **break a system into smaller components** that can operate largely independently from one another. This is the underlying principle behind microservices, sharding, stream processing, and shared-nothing architectures. The challenge lies in knowing where to draw the line between things that should be together and things that should be apart [^86].

Another good principle is **not to make things more complicated than necessary**. If a single-machine database will do the job, it's probably preferable to a complicated distributed setup. Autoscaling systems are cool, but if your load is fairly predictable, a manually scaled system may have fewer operational surprises. A system with 5 services is simpler than one with 50. Good architectures usually involve a pragmatic mixture of approaches.

---

## Maintainability

It is widely recognized that the **majority of the cost of software** is not in its initial development but in its ongoing maintenance—fixing bugs, keeping its systems operational, investigating failures, adapting it to new platforms, modifying it for new use cases, repaying technical debt, and adding new features [^87][^88].

Maintenance can be complex, especially for **legacy systems**. A system that has been successfully running for a long time may well use outdated technologies that not many engineers understand today, and institutional knowledge of how and why the system was designed in a certain way may have been lost as people have left the organization [^89].

To minimize the pain for future generations who need to maintain our software, we should design it with maintenance in mind. In this book we will pay attention to several principles that are widely applicable:

**Operability**
Make it easy for the organization to keep the system running smoothly.

**Simplicity**
Make it easy for new engineers to understand the system, by implementing it using well-understood, consistent patterns and structures and avoiding unnecessary complexity.

**Evolvability**
Make it easy for engineers to make changes to the system in the future, adapting it and extending it for unanticipated use cases as requirements change.

### Operability: Making Life Easy for Operations

It has been suggested that "good operations can often work around the limitations of bad (or incomplete) software, but good software cannot run reliably with bad operations" [^62].

In large-scale systems consisting of many thousands of machines, manual maintenance would be unreasonably expensive, and automation is essential. However, automation can be a two-edged sword—more automation is not always better for operability [^90]. Good operability means making routine tasks easy. Data systems can help by doing the following [^91]:

- Allowing monitoring tools to check the system's key metrics and supporting observability tools to give insights into the system's runtime behavior [^92].
- Avoiding dependency on individual machines (allowing machines to be taken down for maintenance while the system as a whole continues running uninterrupted).
- Providing good documentation and an easy-to-understand operational model.
- Providing good default behavior, but also giving administrators the freedom to override defaults when needed.
- Self-healing where appropriate, but also giving administrators manual control over the system state when needed.
- Exhibiting predictable behavior, minimizing surprises.

### Simplicity: Managing Complexity

Small software projects can have delightfully simple and expressive code, but as projects get larger, they often become very complex and difficult to understand. A software project mired in complexity is sometimes described as a **big ball of mud** [^93].

When complexity makes maintenance hard, budgets and schedules are often overrun. In complex software, there is also a greater risk of introducing bugs when making a change. Hidden assumptions, unintended consequences, and unexpected interactions are more easily overlooked [^71].

One attempt at reasoning about complexity breaks it into two categories: **essential** and **accidental** [^95]. The idea is that essential complexity is inherent in the problem domain of the application, while accidental complexity arises only because of limitations of our tooling. Unfortunately, this distinction is also flawed [^96].

One of the best tools we have for managing complexity is **abstraction**. A good abstraction can hide a great deal of implementation detail behind a clean, simple-to-understand façade. For example, high-level programming languages are abstractions that hide machine code, CPU registers, and system calls. SQL is an abstraction that hides complex on-disk and in-memory data structures, concurrent requests from other clients, and inconsistencies after crashes.

Abstractions for application code that aim to reduce its complexity can be created using methodologies such as design patterns [^97] and domain-driven design (DDD) [^98].

### Evolvability: Making Change Easy

It's extremely unlikely that your system's requirements will remain unchanged forever. They are much more likely to be in constant flux: you learn new facts, previously unanticipated use cases emerge, business priorities change, users request new features, new platforms replace old platforms, legal or regulatory requirements change, growth of the system forces architectural changes, etc.

In terms of organizational processes, **Agile** working patterns provide a framework for adapting to change. In this book, we search for ways of increasing agility at the level of a system consisting of several applications or services with different characteristics—we use the term **evolvability** [^99] to refer to agility on a data system level.

One major factor that makes change difficult in large systems is **irreversibility** [^100]. For example, say you are migrating from one database to another. If you cannot switch back to the old system in case of problems with the new one, the stakes are much higher than if you can easily go back. Therefore, **minimizing irreversibility improves flexibility**.

---

## Summary

In this chapter we examined several examples of nonfunctional requirements: performance, reliability, scalability, and maintainability. Through these topics, we also encountered principles and terminology that will be relevant throughout the rest of the book.

We started with a case study of implementing home timelines in a social network, which illustrated some of the challenges that arise at scale. We then discussed how to measure performance (e.g., using response time percentiles) and the load on a system (e.g., using throughput metrics), and how these metrics are used in SLAs.

To achieve reliability, you can use fault-tolerance techniques, which allow a system to continue providing its services even if a component is faulty. We saw examples of hardware faults that can occur and distinguished them from software faults, which can be harder to deal with because they are often strongly correlated. Another aspect of achieving reliability is to build resilience against humans making mistakes, and we saw blameless postmortems as a technique for learning from incidents.

Finally, we examined several facets of maintainability, including supporting the work of operations teams, managing complexity, and making it easy to evolve an application's functionality over time.

---

## References

[^1]: Cvet, T. (2016). *How We've Scaled Dropbox.* (also cited for backpressure discussion)
[^2]: Krikorian, R. (2012). *New Tweets per second record, and how!* Twitter Engineering Blog.
[^3]: Twitter Engineering. (2023). *Twitter's Recommendation Algorithm.*
[^4]: Krikorian, R. (2013). *Timeline Architecture.* QCon SF.
[^5]: Volpert, S. et al. (2025). *Managing high-volume social feeds at scale.*
[^6]: Axon, S. (2010). *How Twitter's Celebrity Problem Blew Up in Its Face.* Mashable.
[^7]: Bronson, N. et al. (2021). *Metastable Failures in Distributed Systems.* HotOS.
[^8]: Brooker, M. (2021). *Metastable Failures in the Wild.* (blog post)
[^9]: Huang, P. et al. (2022). *MetaStable Failures in the Wild.* OSDI.
[^10]: Brooker, M. (2015). *Exponential Backoff And Jitter.* AWS Architecture Blog.
[^11]: Brooker, M. (2022). *Exponential Backoff.* (blog post)
[^12]: Nygard, M. (2018). *Release It! Design and Deploy Production-Ready Software.* 2nd ed. Pragmatic Bookshelf.
[^13]: Chen, J. et al. (2022). *Circuit Breaker.* (engineering blog post)
[^14]: Brooker, M. (2022). *Retries.* (blog post — token bucket algorithm)
[^15]: Yanacek, D. *Implementing load shedding.* AWS Builder's Library.
[^16]: Sackman, M. (2016). *Backpressure explained.* (blog post)
[^17]: Kopytkov, D. & Shutt, R. (2018). *Netflix's Load Balancing Algorithms.* Netflix Tech Blog.
[^18]: Gunawi, H. et al. (2018). *Why Does the Cloud Stop Computing? Lessons from Hundreds of Service Outages.* SoCC.
[^19]: Brooker, M. (2017). *Efficiency and the mean.* (blog post)
[^20]: DeCandia, G. et al. (2007). *Dynamo: Amazon's Highly Available Key-value Store.* SOSP.
[^21]: Whitenton, K. (2020). *How Fast Is Fast Enough? Webpage Load Time and User Satisfaction.* Nielsen Norman Group.
[^22]: Linden, G. (2006). *Make Data Useful.* Stanford talk slides.
[^23]: Brutlag, J. (2009). *Speed Matters for Google Web Search.* Google Research.
[^24]: Schurman, E. & Brutlag, J. (2009). *Performance Related Changes and their User Impact.* Velocity conference.
[^25]: Akamai Technologies. (2017). *The State of Online Retail Performance.*
[^26]: Bai, X. et al. (2017). *Characterizing and Optimizing Search Query Latency.* Yahoo Research.
[^27]: Dean, J. & Barroso, L. A. (2013). *The Tail at Scale.* Communications of the ACM.
[^28]: Hidalgo, A. (2020). *Implementing Service Level Objectives.* O'Reilly Media.
[^29]: Mogul, J. C. & Wilkes, J. (2019). *Nines are Not Enough: Meaningful Metrics for Clouds.* HotOS.
[^30]: Hauer, T. et al. (2020). *Meaningful Availability.* NSDI.
[^31]: Tene, G. *HdrHistogram: A High Dynamic Range Histogram.* GitHub.
[^32]: Dunning, T. & Ertl, O. (2021). *The t-digest: Efficient estimates of distributions.* Software Impacts.
[^33]: Kohn, N. et al. (2021). *t-digest.* GitHub.
[^34]: Hartmann, R. (2020). *OpenHistogram.* (blog post)
[^35]: Masson, C. et al. (2019). *DDSketch: A Fast and Fully-Mergeable Quantile Sketch with Relative-Error Guarantees.* VLDB.
[^36]: Schwartz, B. (2015). *Why Percentiles Don't Work the Way you Think.* Circonus blog.
[^37]: Heimerdinger, W. L. & Weinstock, C. B. (1992). *A Conceptual Framework for System Fault Tolerance.* CMU/SEI.
[^38]: Gaertner, F. C. (1999). *Fundamentals of fault-tolerant distributed computing in asynchronous environments.* ACM Computing Surveys.
[^39]: Avizienis, A. et al. (2004). *Basic Concepts and Taxonomy of Dependable and Secure Computing.* IEEE Trans. Dependable and Secure Computing.
[^40]: Yuan, D. et al. (2014). *Simple Testing Can Prevent Most Critical Failures.* OSDI.
[^41]: Rosenthal, C. & Jones, N. (2020). *Chaos Engineering.* O'Reilly Media.
[^42]: Pinheiro, E. et al. (2007). *Failure Trends in a Large Disk Drive Population.* FAST.
[^43]: Schroeder, B. & Gibson, G. (2007). *Disk failures in the real world: What does an MTTF of 1,000,000 hours mean to you?* FAST.
[^44]: Klein, A. (2021). *Backblaze Hard Drive Stats.* Backblaze Blog.
[^45]: Narayanan, I. et al. (2016). *SSD Failures in Datacenters: What? When? and Why?* SYSTOR.
[^46]: Alibaba Cloud Infrastructure Team. (2019). *SSD bit error rates.*
[^47]: Schroeder, B. et al. (2016). *Flash Reliability in Production: The Expected and the Unexpected.* FAST.
[^48]: Alter, J. et al. (2019). *SSD Reliability Study.*
[^49]: Ford, D. et al. (2010). *Availability in Globally Distributed Storage Systems.* OSDI.
[^50]: Vishwanath, K. V. & Nagappan, N. (2010). *Characterizing Cloud Computing Hardware Reliability.* SoCC.
[^51]: Hochschild, P. et al. (2021). *Cores that don't count.* HotOS.
[^52]: Dixit, H. D. et al. (2021). *Silent Data Corruptions at Scale.* arXiv.
[^53]: Behrens, J. et al. (2015). *Meteor Strikes, Nuclear Explosions, and Cosmic Rays.*
[^54]: Schroeder, B. et al. (2009). *DRAM errors in the wild: a large-scale field study.* SIGMETRICS.
[^55]: Kim, Y. et al. (2014). *Flipping Bits in Memory Without Accessing Them: An Experimental Study of DRAM Disturbance Errors.* ISCA.
[^56]: Bray, T. (2021). *The Strasbourg Fire.*
[^57]: Abdu Jyothi, S. (2021). *Solar Superstorms: Planning for an Internet Apocalypse.* SIGCOMM.
[^58]: Cockcroft, A. (2019). *Chaos Engineering.* (talk)
[^59]: Han, G. et al. (2021). *An In-Depth Study of Correlated Failures in Production Cloud Infrastructures.* FAST.
[^60]: Nightingale, E. B. et al. (2011). *Cycles, Cells and Platters: An Empirical Analysis of Hardware Failures on a Million Consumer PCs.* EuroSys.
[^61]: Gunawi, H. S. et al. (2014). *What Bugs Live in the Cloud?* SoCC.
[^62]: Kreps, J. (2012). *Kafka: a Distributed Messaging System for Log Processing.*
[^63]: Minar, N. (2012). *Leap Second Crashes Half the Internet.*
[^64]: Hewlett Packard Enterprise. (2019). *HPE SSD Firmware Update.*
[^65]: Hochstein, L. (2020). *The Network Is Reliable.*
[^66]: McCaffrey, C. (2015). *The Incident.* (blog post)
[^67]: Tang, G. et al. (2023). *Fail through the Cracks: Cross-System Interaction Bugs in Modern Cloud Systems.* EuroSys.
[^68]: Ulrich, D. (2016). *Cascading Failures.*
[^69]: Fassbender, H. (2022). *Cascading Failures in Large-Scale Distributed Systems.*
[^70]: Cook, R. I. (2000). *How Complex Systems Fail.* Cognitive Technologies Laboratory, University of Chicago.
[^71]: Woods, D. D. (2017). *The Mechanics of Dynamic Fault Management.* (STELLA report)
[^72]: Oppenheimer, D. et al. (2003). *Why Do Internet Services Fail, and What Can Be Done About It?* USENIX SREC.
[^73]: Dekker, S. (2017). *The Field Guide to Understanding 'Human Error'.* 3rd ed. CRC Press.
[^74]: Dekker, S. (2011). *Drift into Failure.* Ashgate.
[^75]: Allspaw, J. (2012). *Blameless PostMortems and a Just Culture.* Etsy Code as Craft blog.
[^76]: Sabo, C. (2023). *Availability and reliability in distributed systems.*
[^77]: Jurewitz, M. (2013). *The Human Cost of Software Bugs.* (blog post)
[^78]: Halper, E. (2025). *Britain's Post Office Scandal.*
[^79]: Bohm, N. (2022). *The Post Office Horizon IT Inquiry.*
[^80]: McKinley, D. (2015). *Choose Boring Technology.*
[^81]: Warfield, A. et al. (2023). *Linear scalability.*
[^82]: Brooker, M. (2023). *Multitenancy and economies of scale.*
[^83]: Stopford, B. (2009). *Shared Nothing vs. Shared Disk Architectures: An Independent View.*
[^84]: Stonebraker, M. (1986). *The Case for Shared Nothing.* IEEE Database Engineering Bulletin.
[^85]: Antonopoulos, P. et al. (2019). *Socrates: The New SQL Server in the Cloud.* SIGMOD.
[^86]: Newman, S. (2021). *Building Microservices.* 2nd ed. O'Reilly Media.
[^87]: Ensmenger, N. (2016). *The Complexity of Complexity.*
[^88]: Glass, R. L. (2002). *Facts and Fallacies of Software Engineering.* Addison-Wesley.
[^89]: Bellotti, V. et al. (2021). *Toward valuing the work of maintenance.*
[^90]: Bainbridge, L. (1983). *Ironies of Automation.* Automatica.
[^91]: Hamilton, J. (2007). *On Designing and Deploying Internet-Scale Services.* USENIX LISA.
[^92]: Horovits, D. (2021). *Open Source Observability.*
[^93]: Foote, B. & Yoder, J. (1997). *Big Ball of Mud.* PLoP.
[^94]: Brooker, M. (2022). *What is simplicity in computing?* (blog post)
[^95]: Brooks, F. P. (1995). *The Mythical Man-Month.* Anniversary ed. Addison-Wesley.
[^96]: Luu, N. (2020). *On essential and accidental complexity.*
[^97]: Gamma, E. et al. (1994). *Design Patterns: Elements of Reusable Object-Oriented Software.* Addison-Wesley.
[^98]: Evans, E. (2003). *Domain-Driven Design.* Addison-Wesley.
[^99]: Breivold, H. P. et al. (2008). *Analyzing Software Evolvability.* SEAA.
[^100]: Zaninotto, E. (2002). *From Flexibility to Evolvability.*
