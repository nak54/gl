# SEC MD&A RAG Pipeline – Complete Documentation

## 📋 Overview

This is a **production-grade Retrieval-Augmented Generation (RAG) system** for SEC MD&A (Management's Discussion & Analysis) filings. It combines semantic vector search with structured SQL queries, enabling dual-modality retrieval over financial documents.

**Key achievement**: Evolution of prior Azure/CDW cognitive toolkit work into a modern, self-hosted, cost-efficient pipeline with enhanced domain-specific intelligence.

---

## 📚 Documentation Guide

### Start Here (This File)
- **Purpose**: Navigation hub for all documentation
- **Audience**: Everyone
- **Time to read**: 10 minutes

### 1. [SEC_MDA_Pipeline_Analysis.md](SEC_MDA_Pipeline_Analysis.md) – Deep Dive
- **Purpose**: Comprehensive architectural analysis
- **Audience**: Architects, technical leads, anyone building similar systems
- **Sections**:
  - Executive summary + data flow diagram
  - 5-stage pipeline breakdown (data ingest → table extraction → chunking → embeddings → vector store)
  - Design patterns (lazy loading, graceful degradation, metadata carriage)
  - Performance benchmarks + extension points
- **Time to read**: 45 minutes
- **Key takeaway**: Understand how every piece fits together

### 2. [Quick_Reference_Guide.md](Quick_Reference_Guide.md) – Cheat Sheet
- **Purpose**: Fast lookup guide for concepts, configs, commands
- **Audience**: Developers using the pipeline, DevOps, QA
- **Sections**:
  - One-line summary of each stage
  - Data class schemas
  - Key configuration parameters
  - Debugging tips
  - SQL query examples
- **Time to read**: 20 minutes (scan; return as reference)
- **Key takeaway**: Quick answers without reading full docs

### 3. [Code_Examples_and_Patterns.md](Code_Examples_and_Patterns.md) – Recipes
- **Purpose**: Copy-paste examples and production patterns
- **Audience**: Developers implementing or extending the pipeline
- **Sections**:
  - 25+ working code examples
  - Basic usage → advanced configuration → custom extensions
  - Performance tuning
  - Production patterns (error handling, context managers, monitoring)
- **Time to read**: 1 hour (scan; copy what you need)
- **Key takeaway**: "How do I do X?" → find the code

### 4. [Extension_of_Prior_Work.md](Extension_of_Prior_Work.md) – Continuity Narrative
- **Purpose**: Position this as evolution of Azure/CDW work, not rewrite
- **Audience**: Teams that built the prior system
- **Sections**:
  - What's carried forward (patterns, data model, philosophy)
  - What's new (Qdrant, sentence-transformers, domain-specific chunking)
  - Feature parity + innovations table
  - Migration path from Azure/CDW
  - Cost/latency/quality comparisons
- **Time to read**: 30 minutes
- **Key takeaway**: "This isn't starting over; it's an upgrade"

---

## 🎯 Quick Navigation by Role

### Data Engineer / ML Engineer
1. Start: [Quick_Reference_Guide.md](Quick_Reference_Guide.md) – data classes + SQL schemas
2. Deep dive: [SEC_MDA_Pipeline_Analysis.md](SEC_MDA_Pipeline_Analysis.md) – stages 1–5
3. Implement: [Code_Examples_and_Patterns.md](Code_Examples_and_Patterns.md) – examples 1–5

### Software Architect
1. Start: [SEC_MDA_Pipeline_Analysis.md](SEC_MDA_Pipeline_Analysis.md) – entire document
2. Patterns: [Code_Examples_and_Patterns.md](Code_Examples_and_Patterns.md) – production patterns
3. Context: [Extension_of_Prior_Work.md](Extension_of_Prior_Work.md) – design decisions

### Developer (Building Features)
1. Quick ref: [Quick_Reference_Guide.md](Quick_Reference_Guide.md) – module responsibilities + configs
2. Recipes: [Code_Examples_and_Patterns.md](Code_Examples_and_Patterns.md) – specific use cases
3. Debugging: [Quick_Reference_Guide.md](Quick_Reference_Guide.md) – debugging tips section

### DevOps / SRE
1. Quick ref: [Quick_Reference_Guide.md](Quick_Reference_Guide.md) – performance benchmarks
2. Patterns: [Code_Examples_and_Patterns.md](Code_Examples_and_Patterns.md) – context managers, monitoring
3. Continuity: [Extension_of_Prior_Work.md](Extension_of_Prior_Work.md) – deployment strategies

### Project Manager / Leader
1. Overview: This file – read "What is this?" section below
2. Continuity: [Extension_of_Prior_Work.md](Extension_of_Prior_Work.md) – section "Recommended Adoption Path"
3. Metrics: [SEC_MDA_Pipeline_Analysis.md](SEC_MDA_Pipeline_Analysis.md) – "Performance Benchmarks" section

---

## 🏗️ What Is This?

### The Problem
SEC filings (Form 10-K, 20-F, etc.) contain:
- **MD&A (Item 7)**: 20,000–100,000 word narrative explanations
- **Tables**: Financial data, metrics, historical comparisons
- **Metadata**: Company identifiers, industry codes, filing dates

Traditional approaches: Full-text search (keyword-based), manual review, or SQL queries on fixed schemas.

**Limitation**: Can't answer semantic questions like "What are the main liquidity risks for beverage manufacturers in 2024?"

### The Solution
This RAG pipeline enables:
1. **Semantic search** over narrative prose (vectors + Qdrant)
2. **Structured queries** over financial tables (SQL + SQLite)
3. **Filtered retrieval** by company, year, industry, section
4. **Metadata preservation** for upstream joins (traceability)

### The Data Flow
```
SEC Filings (Parquet)
    ↓
Step 1: Data Ingest → SECDocument
    ↓
Step 2: Table Extraction → ExtractedTable + cleaned text
    ├→ SQLite (filings_tables, tables_long)
    ↓
Step 3: Text Chunking → TextChunk (28 MD&A subsections)
    ↓
Step 4: Embedding → EmbeddedChunk (384-dim vectors)
    ↓
Step 5: Vector Store → Qdrant collection
    ├→ Semantic search
    └→ + metadata filters (year, naics3, company, etc.)
```

---

## 🔑 Key Concepts (5-Minute Intro)

### 1. Metadata Carriage
Every document flows through 5 stages. At each stage, metadata (company, year, CIK, NAICS, section name) is preserved and enriched. Final SearchResult includes all metadata for upstream joins.

**Why**: Enables questions like "Which food manufacturers (NAICS 311) mentioned supply chain risks in 2024?"

### 2. Dual-Store Architecture
- **Qdrant** (vector DB): For semantic search over prose
- **SQLite** (relational DB): For SQL queries over structured tables

**Why**: Different data shapes need different backends. Vectors excel at fuzzy matching; SQL excels at exact filters.

### 3. MD&A Structure Recognition
Pipeline recognizes 28 standard SEC Item 7 subsections:
- Overview, Results of Operations, Liquidity, Risk Factors, Critical Accounting Policies, etc.

Every chunk tagged with `section_name`. Enables section-filtered retrieval.

**Why**: SEC filings have predictable structure. Recognizing it improves chunk quality.

### 4. Overlapping Chunks with Boundary Snapping
Chunks overlap by 15% (configurable), but breaks happen at sentence/line boundaries (not mid-word).

**Why**: Semantic continuity (overlap) + readability (no mid-sentence cuts).

### 5. Graceful Degradation
Missing dependencies don't crash the pipeline:
- No sentence-transformers? Use deterministic random vectors (continues, degrades quality)
- No Qdrant? Use in-memory brute-force search (continues, slower)
- No GPU? Fall back to CPU (continues, slower)

**Why**: Development velocity. Build/test anywhere, optimize in production.

---

## 🚀 Getting Started

### 1. Installation (5 minutes)
```bash
pip install pandas sentence-transformers qdrant-client
# Optional: torch (for GPU support)
```

### 2. Prepare Data (Parquet file)
```python
# Required columns:
# accession, year, mda_text, cik, name, sic, ein, 
# address, naics3, naics17Title, is_ambiguous_naics3

# Load your parquet:
import pandas as pd
df = pd.read_parquet("mda_merged_sic_naics_24_25.parquet")
```

### 3. Run Pipeline (15 minutes for 100 docs)
```python
from mda_pipeline.pipeline import RAGPipeline

pipe = RAGPipeline(parquet_path="mda_merged_sic_naics_24_25.parquet")
stats = pipe.build()
print(f"Built in {stats['elapsed_seconds']:.1f}s")

result = pipe.query("What are the main liquidity risks?", top_k=5)
for hit in result.results:
    print(f"{hit.score:.4f} | {hit.section_name}")
    print(f"  {hit.text[:150]}...")
```

### 4. Explore Results
See [Code_Examples_and_Patterns.md](Code_Examples_and_Patterns.md) for 25+ examples.

---

## 📊 Architecture at a Glance

```
┌─────────────────────────────────────────────────────────────────┐
│                      RAGPipeline (orchestrator)                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  Step 1: SecDataIngest      Step 2: TableExtractor              │
│  ├─ Load parquet            ├─ HTML table detection             │
│  ├─ Validate columns        ├─ Whitespace-aligned detection    │
│  └─ Coerce types            └─ Extract tables + cleaned text    │
│      │                           │                               │
│      └─→ SECDocument[]           ├─→ ExtractedTable[]           │
│                                  │       │                       │
│                                  └─→ SQLiteTableStore            │
│                                      (filings_tables,            │
│                                       tables_long)               │
│                                                                   │
│  Step 3: TextChunker                 Step 4: EmbeddingGenerator │
│  ├─ Detect 28 MD&A sections          ├─ sentence-transformers  │
│  ├─ Overlap: 15%                     ├─ 384-dim vectors        │
│  └─ Boundary snap (no mid-sentence)  └─ GPU/CPU auto-detect    │
│      │                                   │                       │
│      └─→ TextChunk[]                     └─→ EmbeddedChunk[]    │
│                                                  │                │
│                                          Step 5: QdrantStore    │
│                                          ├─ Vector upsert      │
│                                          ├─ COSINE distance    │
│                                          └─ Filtered search    │
│                                              (by metadata)      │
│                                                  │                │
│                                            Qdrant collection    │
│                                                                   │
├─────────────────────────────────────────────────────────────────┤
│  Query Path:                                                     │
│    query_text → encode → vector_search (Qdrant)                │
│              → SearchResult[] (with metadata)                   │
│                                                                   │
│  Alternate Path:                                                │
│    query_tables(cik, year, naics3) → SQL (SQLite)             │
│                                    → Table[]                    │
└─────────────────────────────────────────────────────────────────┘
```

---

## 💾 Data Models

### Input: Parquet Row
```python
{
  "accession": "0000789019-24-000042",
  "year": "2024",
  "cik": "0000789019",
  "name": "EXAMPLE CORP",
  "sic": "3721",
  "ein": "12-3456789",
  "address": "123 Main St",
  "naics3": "311",
  "naics17Title": "Beverage Manufacturing",
  "is_ambiguous_naics3": False,
  "mda_text": "Item 7. Management's Discussion and Analysis...",
}
```

### Output: SearchResult (from query)
```python
SearchResult(
  chunk_id="0000789019-24-000042_chunk_12",
  text="Liquidity is strong with $5B in cash...",
  score=0.8234,  # cosine similarity [0, 1]
  section_name="Liquidity and Capital Resources",
  metadata={
    "company": "EXAMPLE CORP",
    "year": "2024",
    "cik": "0000789019",
    "naics3": "311",
    "chunk_index": 12,
    "total_chunks": 45,
    "start_char": 4521,
    "end_char": 5801,
  }
)
```

---

## 📈 Performance Summary

| Metric | Value | Notes |
|--------|-------|-------|
| **Build Time (1,000 docs)** | ~3 min | GPU (Tesla P100); CPU ~10x slower |
| **Query Latency** | 100–500 ms | top-k=5; in-memory Qdrant |
| **Throughput (embedding)** | 500 chunks/sec | batch_size=64, GPU |
| **Index Size (1,000 docs)** | ~200 MB | Qdrant + SQLite |
| **Cost (for dev/test)** | $0 | Open-source; local infrastructure |
| **Memory (full pipeline)** | ~4 GB | With embeddings in RAM |

---

## 🔄 Continuity with Prior Work

### From Azure/CDW to This
| Aspect | Prior | This | Benefit |
|--------|-------|------|---------|
| **Embedding Model** | Azure Cognitive Services | sentence-transformers | Open-source, fine-tunable |
| **Vector Store** | Azure Search Index | Qdrant | Purpose-built, better ANN |
| **Table Storage** | CDW star schema | SQLite | Portable, schema-flexible |
| **Chunking** | Generic | 28 MD&A patterns | Domain-specific |
| **Cost** | $50–100 (100 docs) | ~$0 | Cost savings |
| **Infrastructure** | Azure-dependent | Self-hosted | Control + portability |

**Same philosophy**: Metadata carriage, dual-store, batch processing, graceful degradation.

**Key innovation**: Domain-specific (SEC) structure recognition + open-source cost reduction.

See [Extension_of_Prior_Work.md](Extension_of_Prior_Work.md) for detailed migration path.

---

## 📖 Learning Path

### Day 1: Understand the Basics
- Read: This file + [Quick_Reference_Guide.md](Quick_Reference_Guide.md)
- Time: 30 minutes
- Goal: Grasp the 5-stage pipeline, data models, and key concepts

### Day 2: Deep Dive into Architecture
- Read: [SEC_MDA_Pipeline_Analysis.md](SEC_MDA_Pipeline_Analysis.md)
- Time: 45 minutes
- Goal: Understand design patterns, algorithms, performance

### Day 3: Hands-On Implementation
- Read: [Code_Examples_and_Patterns.md](Code_Examples_and_Patterns.md) (Examples 1–10)
- Run: Smoke test on 10 filings (`ingest_limit=10`)
- Time: 60 minutes
- Goal: Get the system running, understand the flow

### Day 4: Production Patterns
- Read: [Code_Examples_and_Patterns.md](Code_Examples_and_Patterns.md) (Examples 11–25)
- Run: Full pipeline on 1,000 filings
- Time: 120 minutes
- Goal: Learn production practices, performance tuning, debugging

### Day 5: Integration & Customization
- Read: [Extension_of_Prior_Work.md](Extension_of_Prior_Work.md) (if coming from Azure/CDW)
- Implement: Custom chunking or embedding model
- Time: 120 minutes
- Goal: Adapt to your specific use case

---

## 🛠️ Common Tasks

### "I want to..."

#### ...build the index
→ See [Code_Examples_and_Patterns.md](Code_Examples_and_Patterns.md) Example 1

#### ...query with filters
→ See [Code_Examples_and_Patterns.md](Code_Examples_and_Patterns.md) Example 8

#### ...run on GPU
→ See [Quick_Reference_Guide.md](Quick_Reference_Guide.md) "Configuration Parameters"

#### ...tune chunk sizes
→ See [Code_Examples_and_Patterns.md](Code_Examples_and_Patterns.md) Example 4

#### ...debug chunk quality
→ See [Code_Examples_and_Patterns.md](Code_Examples_and_Patterns.md) Example 13

#### ...use a different embedding model
→ See [Code_Examples_and_Patterns.md](Code_Examples_and_Patterns.md) Example 17

#### ...rerank search results
→ See [Code_Examples_and_Patterns.md](Code_Examples_and_Patterns.md) Example 18

#### ...monitor in production
→ See [Code_Examples_and_Patterns.md](Code_Examples_and_Patterns.md) Example 25

#### ...migrate from Azure/CDW
→ See [Extension_of_Prior_Work.md](Extension_of_Prior_Work.md) sections "Migration Path" and "Recommended Adoption Path"

---

## 🎓 Conceptual Depth

### Why These Design Choices?

#### Q: Why percentage-based overlap instead of fixed?
**A**: Document length varies (20k–100k words). Percentage-based adapts to each document's characteristics. 15% overlap is recommended for SEC filings (preserves continuity without excessive redundancy).

#### Q: Why 28 MD&A patterns instead of generic chunking?
**A**: SEC Item 7 follows predictable structure. Recognizing sections enables section-aware retrieval and better semantic chunks. Generic chunking ignores domain knowledge.

#### Q: Why Qdrant instead of Azure Search Index?
**A**: Qdrant is purpose-built for vectors; Azure Search is generalist. Cost (free vs. $$$), scalability (horizontal vs. vertical), and control (open-source vs. cloud API).

#### Q: Why SQLite instead of CDW?
**A**: Portable, zero licensing, ACID guarantees, good enough for 100k tables. CDW excels at OLAP analytics; SQLite is sufficient for RAG retrieval.

#### Q: Why graceful fallbacks?
**A**: Development velocity. Test locally without GPU, embed without sentence-transformers, query without Qdrant. Degrade quality, not functionality.

---

## 🔐 Production Considerations

### Security
- **Data**: All processing local/self-hosted (no cloud exposure)
- **Credentials**: API keys (Qdrant, if remote) stored in env variables
- **Access**: Query results include metadata; filter at presentation layer if needed

### Scalability
- **Vertical**: Single machine with GPU handles 100k docs easily
- **Horizontal**: Qdrant supports clustering; SQLite can move to shared storage
- **Monitoring**: Add metrics at each stage (timing, error rates, vector quality)

### Reliability
- **Idempotency**: Re-running doesn't duplicate data (stable UUIDs + INSERT OR REPLACE)
- **Fallbacks**: Missing dependencies → graceful degradation
- **Validation**: Schema checks, vector quality checks, SQL constraints

### Cost
- **Dev/Test**: $0 (open-source, local)
- **Production**: Qdrant hosting (~$0–500/mo depending on scale) + compute
- **Compared to Azure**: 10–100x cheaper for equivalent workload

---

## 📞 Support & Debugging

### Common Issues

#### "Chunks have empty section_name"
→ See [Quick_Reference_Guide.md](Quick_Reference_Guide.md) "Debugging Tips"

#### "Qdrant file locked"
→ Call `pipeline.close()` (or use context manager)

#### "Slow queries"
→ Check `vector_store.stats()` for point count; partition if >1M

#### "Dimension mismatch"
→ Ensure embedding model matches vector store initialization

---

## 🔗 Document Relationship Map

```
START HERE
    ↓
    ├─→ Quick_Reference_Guide.md
    │   ├─→ Data models (need details?)
    │   │   └─→ SEC_MDA_Pipeline_Analysis.md (Stage X)
    │   ├─→ Configuration parameters
    │   │   └─→ Code_Examples_and_Patterns.md (Example N)
    │   └─→ Debugging tips
    │       └─→ Code_Examples_and_Patterns.md (Example 12–15)
    │
    ├─→ Code_Examples_and_Patterns.md
    │   ├─→ "How do I...?" examples
    │   └─→ Production patterns
    │       └─→ SEC_MDA_Pipeline_Analysis.md (Design Patterns section)
    │
    ├─→ SEC_MDA_Pipeline_Analysis.md
    │   ├─→ Deep architectural understanding
    │   ├─→ Extension points
    │   └─→ Performance metrics
    │
    └─→ Extension_of_Prior_Work.md
        ├─→ If coming from Azure/CDW
        └─→ Migration path + cost comparison
```

---

## 📝 Glossary

| Term | Definition |
|------|-----------|
| **MD&A** | Management's Discussion & Analysis (Item 7 of 10-K filing) |
| **SECDocument** | Parsed SEC filing (company info + mda_text) |
| **TextChunk** | Overlapping segment of MD&A text (~2048 chars) |
| **EmbeddedChunk** | TextChunk + 384-dim vector |
| **SearchResult** | Query output (chunk_id, text, score, metadata) |
| **Qdrant** | Vector database (semantic search backend) |
| **SQLite** | Relational database (structured table storage) |
| **COSINE** | Distance metric (how similar two vectors are) |
| **Idempotent** | Can be run multiple times without side effects |
| **Graceful Degradation** | Feature degrades (slower, lower quality) rather than fails |

---

## 📚 Additional Resources

### External References
- **Qdrant Docs**: https://qdrant.tech/documentation/
- **sentence-transformers**: https://www.sbert.net/
- **SEC EDGAR Database**: https://www.sec.gov/edgar/
- **Pandas Documentation**: https://pandas.pydata.org/docs/

### Related Work
- Vector databases: Pinecone, Weaviate, Chroma, Milvus
- Embedding models: OpenAI, Cohere, in-house fine-tuned
- RAG frameworks: LangChain, LlamaIndex, Haystack

---

## 🎯 Summary

| Document | Purpose | Audience | Time | When to Read |
|----------|---------|----------|------|--------------|
| **This File** | Navigation + overview | Everyone | 10 min | First |
| **Quick_Reference_Guide.md** | Fast lookup | Developers, DevOps | 20 min | Day 1 |
| **SEC_MDA_Pipeline_Analysis.md** | Deep architecture | Architects, engineers | 45 min | Day 2 |
| **Code_Examples_and_Patterns.md** | Hands-on recipes | Developers | 1+ hrs | Days 3–5 |
| **Extension_of_Prior_Work.md** | Continuity narrative | Teams from Azure/CDW | 30 min | If applicable |

---

## 🚀 Next Steps

1. **Choose your entry point** (above navigation guide)
2. **Skim the Quick Reference** (10 minutes)
3. **Run a smoke test** (10 filings, ~2 minutes)
4. **Read deeper docs** as needed
5. **Implement** (see Code Examples)
6. **Customize** (swap models, tune configs)
7. **Deploy** (production patterns)

**You're ready to go. Pick a document and dive in!**

---

*Last updated: 2024*  
*Framework: 5-stage pipeline (ingest → tables → chunks → embeddings → store)*  
*Technology: Qdrant + SQLite + sentence-transformers*  
*License: [Specify your license]*
