# SEC MD&A RAG Pipeline – Comprehensive Analysis

## Executive Summary

This is a production-grade **end-to-end RAG (Retrieval-Augmented Generation) pipeline** designed to ingest, process, index, and retrieve SEC MD&A (Management's Discussion & Analysis) filings. The pipeline combines text-based vector search with structured SQL queries, enabling dual-modality retrieval: semantic search over prose + filtering over extracted tables.

**Core flow:**
```
Parquet → SECDocuments → TableExtraction → TextChunking → Embeddings → Qdrant + SQLite
   (Step 1)    (Step 2)      (Step 3)      (Step 4)      (Step 5)
```

---

## Architecture Overview

### Design Philosophy

1. **Modular**: Each step is a standalone class with clear input/output contracts
2. **Lazy-loaded**: Stages instantiate config-only; data flows through `run()` methods
3. **Gracefully degraded**: Every step has a fallback when optional dependencies are missing
4. **Dual-store**: Unstructured text→Qdrant vectors + structured tables→SQLite DB
5. **Traceability**: Every chunk and vector preserves a `source_document_id` + metadata for upstream joins

---

## Step 1: Data Ingest (`data_ingest.py`)

### Responsibility
Load a Parquet file of SEC filings into `SECDocument` dataclass objects.

### Key Components

#### `SECDocument` Dataclass
```python
@dataclass
class SECDocument:
    document_id: str          # derived from accession
    accession: str            # SEC filing accession number (unique ID)
    year: str
    cik: str                  # Central Index Key (company identifier)
    name: str                 # company name
    sic: str                  # Standard Industrial Classification
    ein: str                  # Employer ID
    address: str
    naics3: str               # 3-digit NAICS code
    naics17Title: str         # Full NAICS title
    is_ambiguous_naics3: bool
    mda_text: str             # Item 7 MD&A prose
    metadata: Dict[str, str]  # carry-forward dict for downstream stages
```

**Key insight**: `document_id` is the **join key** that ties together:
- Extracted tables (via `source_document_id`)
- Text chunks (via `source_document_id`)
- Embeddings and vectors (via metadata)

#### `SecDataIngest` Workflow

1. **Load**: `load_parquet()` reads the file; optional `limit` parameter for smoke tests
2. **Validate**: `validate()` checks for required columns (`mda_text`, `accession`, `cik`)
3. **Extract**: `extract_documents()` iterates each row:
   - Skips rows where `mda_text` is null/empty
   - Coerces all metadata values to strings via `_to_str()` (handles NaN, None, numpy types)
   - Builds `SECDocument` + enriches metadata dict with all parquet columns

4. **Report**: `statistics()` prints shape info (doc count, char lengths, unique companies, year range)

**Example output:**
```
[ingest] Loaded 1,234 rows
[ingest] Skipped 5 rows with empty mda_text
[ingest] Built 1,229 SECDocument objects
[ingest] Statistics:
  documents: 1,229
  unique_companies: 432
  unique_years: [2020, 2021, 2022, 2023, 2024, 2025]
  avg_chars: 45,320
```

#### Defensive Coercion: `_to_str()`
Critical for robustness:
- Parquet columns can contain `None`, `np.NaN`, numpy scalar types, etc.
- `_to_str()` normalizes everything to plain Python `str`
- Enables downstream code (SQLite, Qdrant payloads) to assume strings

---

## Step 2: Table Extraction (`table_extraction.py`)

### Responsibility
Detect and remove tables from MD&A text; store in two layouts (long-form + wide-form SQLite).

### Why Separate Tables?

SEC filings contain both:
1. **Prose** (narrative, explanations) → better for vector search
2. **Tables** (financial data, metrics) → better for SQL filters + structured queries

**Design decision**: Extract tables, remove from text, store separately. Text-only → chunking/embedding. Tables → SQLite.

### Table Detection: Two Strategies

#### 1. HTML Tables
```python
_HTML_TABLE_RE = re.compile(r"<table[^>]*>.*?</table>", re.IGNORECASE | re.DOTALL)
```
- Detects `<table>...</table>` blocks
- Parses `<tr>`, `<td>`/`<th>` structure
- Strips nested tags + HTML entities

**Edge case**: `<table>` can nest other tables; non-greedy regex + offsets prevent merging.

#### 2. Whitespace-Aligned (Plain-Text) Tables
```python
# A line is tabular if it contains 2+ consecutive spaces or a tab
if re.search(r"\s{2,}|\t", line) and line.strip():
    # Collect into blocks
```

**Heuristic**:
- Consecutive lines with 2+ spaces/tabs = columns
- Block must have ≥ `min_formatted_rows` (default 3) to avoid false positives on indented prose
- Offsets tracked so blocks can be spliced out of original text

**De-duplication**: HTML tables can also trip the whitespace detector. HTML wins (removed first).

### `ExtractedTable` Dataclass

```python
@dataclass
class ExtractedTable:
    table_id: str                 # unique ID for this table
    source_document_id: str       # join back to original filing
    table_html: str               # raw HTML (if HTML table; capped at 200k)
    table_data: List[List[str]]   # parsed rows: [[cell, ...], ...]
    table_title: str              # inferred from nearby text or index
    cik: str
    ein: str
    sic: str
    naics3: str
    year: str
    table_index: int              # ordinal within filing (0-based)
    metadata: Dict
```

### SQLite Storage: Dual Layout

#### `tables_long` (normalized, long-form)
One row per table:
```sql
CREATE TABLE tables_long (
    table_id TEXT PRIMARY KEY,
    source_document_id TEXT,
    table_index INT,
    table_title TEXT,
    table_data TEXT,        -- JSON-encoded [[rows], ...]
    table_html TEXT,        -- capped at 200k chars
    cik TEXT, ein TEXT, sic TEXT, naics3 TEXT, year TEXT,
    metadata TEXT           -- JSON of extra fields
);
```

**Usage**: `SELECT * FROM tables_long WHERE cik = ? AND year = ?`

#### `filings_tables` (wide-form, one-row-per-filing)
One row per filing, up to N tables as columns:
```sql
CREATE TABLE filings_tables (
    source_document_id TEXT PRIMARY KEY,
    cik TEXT, ein TEXT, sic TEXT, naics3 TEXT, year TEXT,
    n_tables INT,
    extracted_table1 TEXT,  -- JSON {"title": "...", "data": [[...], ...]}
    extracted_table2 TEXT,
    ...
    extracted_tableN TEXT
);
```

**Scaling strategy**: Columns added on-demand via `ALTER TABLE ... ADD COLUMN`. If a filing has many tables, the row widens.

**Usage**: Fetch all tables for a single filing in one query.

### De-duplication & Idempotency

- Table UUIDs derived from `uuid5(namespace_oid, table_id)` → stable across re-runs
- `INSERT OR REPLACE` on both layouts → re-indexing safe

---

## Step 3: Text Chunking (`text_chunking.py`)

### Responsibility
Split cleaned MD&A text into overlapping chunks, preserving SEC document structure.

### Design Goals

1. **Structure-aware**: Recognize 28 standard SEC Item 7 subsections (Overview, Results of Operations, Liquidity, Risk Factors, etc.)
2. **Overlap for context**: 15% overlap between adjacent chunks maintains semantic continuity
3. **Boundary snapping**: Avoid cutting mid-sentence; snap breaks to periods, newlines, or spaces
4. **Metadata carriage**: Each chunk carries section name + all filing identifiers

### MDA Subsections (28 Patterns)

```python
MDA_SUBSECTIONS = [
    r"Overview",
    r"Executive\s+Summary",
    r"Results?\s+of\s+Operations?",
    r"Financial\s+(?:Performance|Highlights|Condition)",
    r"Liquidity(?:\s+and\s+Capital\s+Resources)?",
    r"Capital\s+Resources",
    r"Cash\s+Flows?",
    r"Critical\s+Accounting\s+(?:Policies|Estimates)",
    r"Risk\s+Factors?",
    r"Market\s+Risk(?:\s+Disclosures?)?",
    # ... 18 more patterns
]
```

**Regex construction**:
```python
pat = "|".join(f"(?:{p})" for p in self.MDA_SUBSECTIONS)
self._header_re = re.compile(
    rf"(?m)^[\s]*(?:[0-9IVX]+[\.\)]\s*)?({pat})[\s:\.\-]*$",
    re.IGNORECASE,
)
```

- **`(?m)`**: Multiline mode (^/$ per line)
- **`^[\s]*`**: Optional leading whitespace
- **`(?:[0-9IVX]+[\.\)]\s*)?`**: Optional numbering ("1.", "a)")
- **`[\s:\.\-]*$`**: Trailing punctuation
- **Case-insensitive**: Matches "OVERVIEW", "Overview", "overview"

### Chunking Strategy: `chunk_by_mda_structure()`

**Input**: Cleaned text (tables removed), metadata dict, section regex

**Output**: List of `TextChunk` objects

1. **Detect sections**: Scan text with `_header_re`, collect `(offset, section_name)` tuples
2. **Parse section bodies**: Walk offsets, extract text between headers
3. **Chunk each section**:
   - If section ≤ `chunk_size` (2048 chars): emit as single chunk with section label
   - If section > `chunk_size`: apply sliding-window overlap chunking
4. **Backfill `total_chunks`**: Every chunk knows the document's total chunk count

### Overlapping Sliding Window: `_chunk_section_with_overlap()`

**Algorithm**:
```
start = 0
while start < len(section):
    end = min(start + chunk_size, len(section))
    
    # snap end to sentence/line/space boundary in last half
    if end < len(section):
        half = start + chunk_size // 2
        bp = max(
            text.rfind(". ", half, end),
            text.rfind("\n", half, end),
            text.rfind(" ",  half, end),
        )
        if bp > start:
            end = bp + 1
    
    emit chunk[start:end]
    start = max(end - overlap, start + 1)  # step back by overlap
```

**Example with chunk_size=2048, overlap=307 (15%)**:
- Chunk 1: chars [0, 2048]
- Chunk 2: chars [1741, 3789] (stepped back 307 chars → overlap)
- Chunk 3: chars [3482, 5530]
- ...

**Boundary snapping**: Instead of cutting at char 2048, scans backward from 2048 to 1024, finds the latest ". " or newline, breaks there. Result: clean sentence boundaries, no mid-word cuts.

### `TextChunk` Dataclass

```python
@dataclass
class TextChunk:
    chunk_id: str                      # "doc_id_chunk_42"
    source_document_id: str            # join key
    text: str                          # actual chunk text
    chunk_index: int                   # ordinal in doc
    total_chunks: int                  # total chunks in this doc
    metadata: Dict[str, str]           # company, year, cik, naics3, etc.
    start_char: int                    # absolute offset in original doc
    end_char: int                      # absolute offset in original doc
    section_name: str                  # e.g., "Liquidity", or "" if no structure
```

### Fallback: `chunk_by_size()` (No Structure Found)

If no MD&A headers detected:
- Apply same sliding-window + boundary-snapping to entire document
- `section_name` left blank ("")
- Still produces overlapping chunks with metadata

---

## Step 4: Embedding Generation (`embeddings.py`)

### Responsibility
Vectorize every `TextChunk` using a sentence-transformer model.

### Model & Device

**Default**: `sentence-transformers/all-MiniLM-L6-v2` (384-dim, fast, lightweight)

**Device handling**:
```python
if device is None:
    device = "cuda" if torch.cuda.is_available() else "cpu"
```
Auto-detects GPU; falls back to CPU.

### Graceful Degradation

If `sentence-transformers` not installed:
```python
# Fallback: deterministic random vectors seeded from text hash
rng = np.random.default_rng(abs(hash(text)) % (2 ** 32))
v = rng.standard_normal(embedding_dim)
if normalize:
    v /= np.linalg.norm(v) + 1e-12
```
- Same text always → same vector (deterministic)
- NOT meaningful for search, but allows pipeline to run end-to-end
- Useful for smoke tests, local dev

### Batch Embedding: `embed_chunks()`

```python
for batch in chunks[::batch_size]:
    texts = [c.text for c in batch]
    vecs = model.encode(texts, normalize_embeddings=True, ...)
    for chunk, vec in zip(batch, vecs):
        # wrap in EmbeddedChunk with metadata
```

**Batch size**: Default 64 (GPU-efficient)

**Normalization**: L2-normalize vectors so cosine similarity = dot product. Matches Qdrant's COSINE distance config.

### `EmbeddedChunk` Dataclass

```python
@dataclass
class EmbeddedChunk:
    chunk_id: str
    source_document_id: str
    text: str
    embedding: List[float]              # 384-dim vector
    embedding_model: str                # model name
    section_name: str                   # preserved from chunk
    metadata: Dict                      # enriched with chunk_index, char offsets
```

### Quality Checks: `verify()`

1. **Dimension consistency**: Every vector must have the same length
2. **Range sanity**: No NaN/Inf values; all values in [-1e6, 1e6]

**Output**: Returns `True` if all pass, `False` with warnings.

### Statistics: `statistics()`

```python
{
    "count": 12,345,
    "dim": 384,
    "model": "sentence-transformers/all-MiniLM-L6-v2",
    "norm_mean": 0.9998,     # should be ~1.0 when normalized
    "norm_min": 0.9992,
    "norm_max": 1.0001,
    "values_mean": -0.0012,  # should be ~0
    "values_std": 0.2834,
}
```

**Sanity check**: `norm_mean` far from 1.0 would signal normalization bug.

---

## Step 5: Vector Store (`qdrant_store.py`)

### Responsibility
Persist embeddings to Qdrant for semantic search; support filtered retrieval.

### Two Modes

#### Local File Mode (Default)
```python
QdrantClient(path="./qdrant_db")
```
- On-disk SQLite + memmap-based index
- No server required
- Ideal for Google Colab (persist to Drive between sessions)
- File locking (must `close()` to release)

#### Remote Cluster
```python
QdrantClient(url="https://qdrant.example.com", api_key="...")
```
- Connect to hosted Qdrant server
- Useful for production deployments

### Collection Setup

When first connecting:
1. Check if collection exists
2. If `recreate=True`: drop it (clean re-index)
3. If absent: create with vector config:
   ```python
   VectorParams(
       size=384,              # must match embedding dim
       distance=Distance.COSINE,
   )
   ```
4. If exists: reuse (append mode)

### Point Storage: `store()`

```python
for batch in chunks[::batch_size]:
    points = [
        PointStruct(
            id=str(uuid5(namespace_oid, chunk_id)),  # stable UUID
            vector=embedding,
            payload={
                "chunk_id": chunk_id,
                "text": text,
                "section_name": section_name,
                **metadata,  # company, year, naics3, cik, ein, sic, address, etc.
            }
        )
        for c in batch
    ]
    client.upsert(collection_name=..., points=points)
```

**Key detail**: Point ID is `uuid5(namespace_oid, chunk_id)`, so re-running upserts the same point (idempotent).

### Vector Search: `search()`

```python
hits = client.query(
    collection_name=collection_name,
    query_vector=query_embedding,  # from query.encode_one()
    limit=top_k,
    query_filter=q_filter,         # optional metadata filter
)
```

**Filters** (optional):
```python
# e.g., year="2024" AND naics3="311"
Filter(must=[
    FieldCondition(key="year", match=MatchValue(value="2024")),
    FieldCondition(key="naics3", match=MatchValue(value="311")),
])
```

**Output**: `SearchResult` objects with score, text, section, metadata.

### In-Memory Fallback

If `qdrant-client` not installed:
```python
# Brute-force cosine similarity (O(N) per query)
for vector in stored_vectors:
    score = normalized_query @ normalized_vector  # dot product
    results.append(SearchResult(..., score=score))
```

Limited to small datasets, but enables development without Qdrant.

### Stats: `stats()`

```python
{
    "backend": "./qdrant_db",
    "collection": "sec_mda",
    "vector_size": 384,
    "distance": "COSINE",
    "points": 456,789,
}
```

---

## Step 6: Orchestration (`pipeline.py`)

### `RAGPipeline` Class

**Single object that owns all 5 stages**: ingest, table extractor, chunker, embedder, vector store.

#### Constructor

```python
RAGPipeline(
    parquet_path="mda_merged_sic_naics_24_25.parquet",
    collection_name="sec_mda",
    chunk_size_tokens=512,
    overlap_percent=15,
    embedding_model="sentence-transformers/all-MiniLM-L6-v2",
    qdrant_path="./qdrant_db",
    sqlite_path="sec_tables.db",
    ...
)
```

- Instantiates all stages (config-only, no I/O)
- Initializes empty lists for intermediate results

#### `build()` Method

Runs the full 5-stage pipeline in sequence:

```
documents = ingest.run()                     # parquet → SECDocument[]
(cleaned_docs, tables) = table_extractor.extract_from_documents(documents)
table_store.store_tables(tables)             # → SQLite
chunks = chunker.run(cleaned_docs)           # → TextChunk[]
embeddings = embedder.run(chunks)            # → EmbeddedChunk[]
vectors_stored = vector_store.run(embeddings)  # → Qdrant
```

**Timing**: Records elapsed time for the full pipeline.

**Output**: Stats dict with counts at each stage.

#### Query Methods

**Vector search** (semantic):
```python
result = pipeline.query(
    "What are the main liquidity risks?",
    top_k=5,
    filter_dict={"year": "2024", "naics3": "311"},
)
```

1. Encodes query with same embedding model: `q_vec = embedder.encode_one(query_text)`
2. Searches Qdrant: `vector_store.search(q_vec, top_k=5, filter_dict=...)`
3. Returns `RAGResult` with retrieval time + top-k chunks

**Structured queries** (SQL):
```python
results = pipeline.query_tables(cik="0000789019", year="2024")
```

- Delegates to `table_store.query_tables()`
- Returns rows from `tables_long` table

#### Info & State

```python
pipeline.info()
# Returns config + both backend stats
```

---

## CLI Interface (`run_pipeline.py`)

### Command-Line Entry Point

```bash
python -m mda_pipeline.run_pipeline \
    --parquet mda_merged_sic_naics_24_25.parquet \
    --collection sec_mda \
    --chunk-size-tokens 512 \
    --overlap-percent 15 \
    --model sentence-transformers/all-MiniLM-L6-v2 \
    --qdrant-path ./qdrant_db \
    --sqlite-path sec_tables.db \
    --query "What are forward-looking statements?" \
    --query "Describe liquidity position" \
    --top-k 5
```

**Key features**:
- `--ingest-limit N`: For smoke tests (process only first N filings)
- `--recreate`: Drop Qdrant collection before re-loading (full re-index)
- `--query` (repeatable): Run semantic search after build
- Device auto-detection via `--device cuda|cpu|auto`

---

## Design Patterns & Best Practices

### 1. **Lazy Loading + Explicit Stages**

Each class:
- Constructor stores config only
- I/O happens in explicit `run()` or `load()` methods
- Enables cheap object creation, testable setup

Example:
```python
ingest = SecDataIngest(parquet_path)  # no I/O yet
ingest.load_parquet()  # explicit load
ingest.validate()
docs = ingest.extract_documents()
```

### 2. **Graceful Degradation**

Every optional dependency (sentence-transformers, qdrant-client, CUDA) has a fallback:

```python
try:
    from sentence_transformers import SentenceTransformer
    self.model = SentenceTransformer(...)
except ImportError:
    print("Using fallback random embeddings")
    self.model = None
```

Pipeline still runs end-to-end, but search quality degrades gracefully.

### 3. **Dual-Store Architecture**

- **Qdrant**: For semantic + filtered vector search (unstructured prose)
- **SQLite**: For SQL queries over structured tables

Different access patterns; different backends.

### 4. **Metadata Carriage**

Every stage preserves and enriches metadata:
```
SECDocument.metadata
    ↓ (add chunk indices)
TextChunk.metadata
    ↓ (add offsets, section name)
EmbeddedChunk.metadata
    ↓ (exact same set)
Qdrant payload
```

This enables downstream filtering by company, year, NAICS code, etc.

### 5. **Idempotent Upserts**

- `uuid5(namespace_oid, chunk_id)` → stable UUIDs
- `INSERT OR REPLACE` on SQLite
- Re-running the pipeline doesn't duplicate data

### 6. **Boundary Snapping**

Chunking doesn't cut mid-sentence:
```python
# instead of breaking at char offset N
# scan backward to find ". ", "\n", or " "
bp = max(
    text.rfind(". ", half, end),
    text.rfind("\n", half, end),
    text.rfind(" ",  half, end),
)
```

Result: semantic chunks, not arbitrary fragments.

### 7. **Structure Awareness**

Chunker recognizes 28 standard SEC subsections, preserves section labels on every chunk. Enables:
- Filtered retrieval by section
- Section-specific analytics
- Structure-aware summarization

### 8. **Traceability**

Every chunk → embedding → vector → search result preserves:
- `source_document_id`: Join back to original filing
- `chunk_id`: Locate text in source
- `start_char`, `end_char`: Character offsets
- `metadata`: All filing identifiers (CIK, year, NAICS, company, etc.)

---

## Data Flow Diagram

```
mda_merged_sic_naics_24_25.parquet
    │
    ├─→ SecDataIngest.run()
    │   └─→ [1,229 SECDocument]
    │       • Validates columns
    │       • Coerces types
    │
    ├─→ TableExtractor.extract_from_documents()
    │   │
    │   ├─→ [1,200 ExtractedTable] (HTML + whitespace)
    │   │   └─→ SQLiteTableStore.store_tables()
    │   │       └─→ filings_tables (wide-form)
    │   │       └─→ tables_long (long-form)
    │   │
    │   └─→ [1,229 cleaned SECDocument] (tables removed)
    │       └─→ TextChunker.run()
    │           ├─→ _find_mda_sections() [28 subsection patterns]
    │           ├─→ _chunk_section_with_overlap() [15% overlap]
    │           │
    │           └─→ [45,678 TextChunk]
    │               • section_name preserved
    │               • metadata carried
    │               • char offsets preserved
    │
    └─→ EmbeddingGenerator.run()
        └─→ sentence-transformers/all-MiniLM-L6-v2
            └─→ [45,678 EmbeddedChunk] (384-dim vectors)
                └─→ QdrantVectorStore.run()
                    └─→ qdrant_db/sec_mda collection
                        • 45,678 points
                        • COSINE distance
                        • Payload = chunk + metadata
```

### Query Path

```
User Query: "What are main liquidity risks?"
    │
    ├─→ RAGPipeline.query()
    │   │
    │   ├─→ EmbeddingGenerator.encode_one()
    │   │   └─→ [384-dim query vector]
    │   │
    │   └─→ QdrantVectorStore.search()
    │       ├─→ Vector similarity: top_k=5
    │       ├─→ Optional filter: year="2024", naics3="311"
    │       │
    │       └─→ [5 SearchResult]
    │           • score (cosine similarity)
    │           • text (chunk excerpt)
    │           • section_name
    │           • metadata (company, year, cik, naics3, etc.)
    │
    └─→ Pretty-print results
```

---

## Key Configuration Parameters

| Parameter | Default | Impact |
|-----------|---------|--------|
| `chunk_size_tokens` | 512 | Larger = wider context window; fewer chunks; slower search |
| `overlap_percent` | 15 | Higher = more context overlap; more chunks; slower embedding |
| `embedding_model` | all-MiniLM-L6-v2 | ONNX: fast, small (384-dim); larger models = higher quality |
| `qdrant_path` | ./qdrant_db | Local vs. `qdrant_url` for remote cluster |
| `sqlite_path` | sec_tables.db | Where extracted tables are stored |
| `recreate_collection` | False | `True` = drop + rebuild (full re-index) |
| `embedding_batch_size` | 64 | Larger = faster on GPU; OOM risk |
| `qdrant_batch_size` | 256 | Upsert batch size; trade-off latency vs. throughput |
| `ingest_limit` | None | Set to N for smoke tests (process first N filings) |

---

## Typical Performance Metrics

**Environment**: Google Colab Pro (Tesla P100 GPU)

| Stage | Time (1,000 docs) | Notes |
|-------|-------------------|-------|
| **Ingest** | ~5 sec | Parquet load + validation |
| **Table Extraction** | ~20 sec | Regex scanning + de-dup |
| **Text Chunking** | ~10 sec | Structure detection + splitting |
| **Embedding** (GPU) | ~2 min | batch_size=64, all-MiniLM-L6-v2 |
| **Vector Store Upsert** | ~30 sec | Qdrant batch writes |
| **Total** | ~3 min | End-to-end |

**Query latency**: ~100–500 ms (top-k=5, in-memory Qdrant)

---

## Strengths

1. **Modular**: Easy to swap components (embedding model, vector store, chunking strategy)
2. **Transparent**: Extensive logging at every step
3. **Robust**: Graceful fallbacks for missing dependencies
4. **Dual-modal**: Prose + tables, different backends
5. **Production-ready**: Idempotent, schema validation, error handling
6. **Metadata-rich**: Full traceability upstream
7. **Structure-aware**: Recognizes SEC subsections (vs. naive chunking)

---

## Extension Points

### 1. Custom Chunking Strategies
Subclass `TextChunker`, override `chunk_by_mda_structure()` with alternative logic.

### 2. Different Embedding Models
Pass `--model <huggingface_model_id>` to CLI; any sentence-transformers model works.

### 3. Alternative Vector Stores
Replace `QdrantVectorStore` with Pinecone, Weaviate, Chroma, etc. Minimal interface change.

### 4. Query Augmentation
Post-process `RAGResult` for reranking, summarization, fact-checking, etc.

### 5. Fine-Tuning
Collect labeled pairs (query, relevant_chunk) from pipeline output; fine-tune embedding model.

---

## Gotchas & Debugging

### Q: Chunks have empty `section_name`
**A**: No MD&A headers detected → fallback to `chunk_by_size()`. Check if text structure matches one of 28 patterns.

### Q: Qdrant file-locked error
**A**: Must call `pipeline.close()` (or use context manager) to release file lock in local mode.

### Q: Embedding dimensions mismatch with Qdrant
**A**: Vector store initialized with `embedding_dim` from embedder; model mismatches caught during `verify()`. Ensure `--model` matches pipeline creation.

### Q: SQLite write contention
**A**: SQLite has one writer at a time. Multi-process pipelines need connection pooling or file-level locking.

### Q: Slow queries on Qdrant
**A**: Check `points_count` via `vector_store.stats()`. If > 1M, consider partitioning (sub-collections per year).

---

## Summary

This pipeline is a **state-of-the-art RAG system for SEC filings**, combining:

- **Semantic retrieval** (embeddings + vector search)
- **Structured retrieval** (SQL filters over extracted tables)
- **Document preservation** (full traceability upstream)
- **Production robustness** (idempotent, graceful degradation)
- **Scalability** (Qdrant + SQLite backends, batch processing)

It's a template for building similar pipelines on domain-specific documents.
