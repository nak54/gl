# SEC MD&A Pipeline – Code Examples & Usage Patterns

## Table of Contents
1. [Basic Usage](#basic-usage)
2. [Advanced Configuration](#advanced-configuration)
3. [Querying Patterns](#querying-patterns)
4. [Debugging & Inspection](#debugging--inspection)
5. [Custom Extensions](#custom-extensions)
6. [Performance Tuning](#performance-tuning)
7. [Production Patterns](#production-patterns)

---

## Basic Usage

### Example 1: Full Pipeline Build (Simplest Case)

```python
from mda_pipeline.pipeline import RAGPipeline

# Create and build in one go
pipe = RAGPipeline(parquet_path="mda_merged_sic_naics_24_25.parquet")
stats = pipe.build()

# Stats dictionary contains counts from each stage
print(f"Documents: {stats['documents_ingested']}")
print(f"Tables: {stats['tables_extracted']}")
print(f"Chunks: {stats['chunks']}")
print(f"Vectors: {stats['vectors_stored']}")
print(f"Time: {stats['elapsed_seconds']}s")

# Run a query
result = pipe.query("What are the main financial risks?", top_k=5)
for hit in result.results:
    print(f"Score: {hit.score:.4f} | Section: {hit.section_name}")
    print(f"  {hit.text[:150]}...")

pipe.close()
```

**Output:**
```
Documents: 1,229
Tables: 1,200
Chunks: 45,678
Vectors: 45,678
Time: 180.45s

Score: 0.8234 | Section: Risk Factors
  Market volatility and economic uncertainties continue to impact...
```

---

### Example 2: Debug Mode (Smoke Test with Limit)

```python
# Process only first 10 filings for quick testing
pipe = RAGPipeline(
    parquet_path="mda_merged_sic_naics_24_25.parquet",
    ingest_limit=10,  # Only first 10 rows
)

stats = pipe.build()
# Expected: ~10 docs, ~100 tables, ~500 chunks, fast!

# Test query
result = pipe.query("revenue", top_k=3)
print(f"Found {len(result.results)} results in {result.retrieval_time*1000:.1f}ms")

pipe.close()
```

---

### Example 3: Remote Qdrant Server

```python
# Use a remote Qdrant cluster instead of local file
pipe = RAGPipeline(
    parquet_path="mda_merged_sic_naics_24_25.parquet",
    qdrant_url="https://qdrant.example.com:6333",
    qdrant_api_key="your-api-key-here",
    collection_name="sec_mda_prod",
)

stats = pipe.build()

# Query the remote cluster
result = pipe.query("cash flow", top_k=10)

# Close releases the client connection
pipe.close()
```

---

## Advanced Configuration

### Example 4: Tuned for Large Documents

```python
# For very long MD&A sections, use larger chunks with more overlap
pipe = RAGPipeline(
    parquet_path="mda_merged_sic_naics_24_25.parquet",
    chunk_size_tokens=1024,    # ~4096 chars (2x default)
    overlap_percent=20,         # 20% overlap (~819 chars)
    embedding_batch_size=32,    # Smaller batches (GPU memory)
    qdrant_batch_size=128,      # Smaller upsert batches
    collection_name="sec_mda_large",
)

stats = pipe.build()
# Expect: fewer chunks, more context per chunk
print(f"Chunks: {stats['chunks']}")  # ~20k instead of 45k
```

---

### Example 5: Quality-Optimized (Larger Model)

```python
# Use a larger, higher-quality embedding model
pipe = RAGPipeline(
    parquet_path="mda_merged_sic_naics_24_25.parquet",
    embedding_model="sentence-transformers/all-mpnet-base-v2",  # 768-dim vs 384
    device="cuda",  # Explicit GPU
    embedding_batch_size=32,  # Larger model needs smaller batches
)

stats = pipe.build()
# Expect: slower embedding, better search quality
print(f"Embedding dim: {stats['embedding_dim']}")  # 768
```

---

### Example 6: Full Re-Index (Clean Start)

```python
# Drop existing collection and rebuild from scratch
pipe = RAGPipeline(
    parquet_path="mda_merged_sic_naics_24_25.parquet",
    qdrant_path="./qdrant_db_v2",
    sqlite_path="sec_tables_v2.db",
    recreate_collection=True,  # Drop existing
    collection_name="sec_mda_v2",
)

stats = pipe.build()
print("Fresh index created")
```

---

## Querying Patterns

### Example 7: Basic Semantic Search

```python
pipe = RAGPipeline(parquet_path="...").build()

# Simple query
result = pipe.query("What are the company's main revenue sources?", top_k=5)

# Print results with formatting
print(f"\nQuery: {result.query}")
print(f"Latency: {result.retrieval_time * 1000:.1f}ms\n")

for i, hit in enumerate(result.results, 1):
    print(f"{i}. [Score: {hit.score:.4f}] {hit.section_name}")
    print(f"   Company: {hit.metadata.get('company', '?')}")
    print(f"   Year: {hit.metadata.get('year', '?')}")
    print(f"   {hit.text[:200]}...\n")

pipe.close()
```

---

### Example 8: Filtered Retrieval (By Company/Year)

```python
pipe = RAGPipeline(parquet_path="...").build()

# Query with metadata filters
result = pipe.query(
    "liquidity risks",
    top_k=5,
    filter_dict={
        "year": "2024",
        "naics3": "311",  # Food manufacturing
    }
)

print(f"Found {len(result.results)} results matching filters")
for hit in result.results:
    print(f"  {hit.metadata['company']} ({hit.metadata['year']}): {hit.score:.4f}")

pipe.close()
```

---

### Example 9: Batch Queries

```python
pipe = RAGPipeline(parquet_path="...").build()

# Run multiple queries at once
queries = [
    "What are the main revenue drivers?",
    "Describe liquidity and capital resources",
    "What are the company's risk factors?",
    "Discuss critical accounting policies",
]

results = pipe.batch_query(queries, top_k=3)

for result in results:
    print(f"\nQuery: {result.query}")
    print(f"Found {len(result.results)} hits")
    top_hit = result.results[0]
    print(f"  Best: {top_hit.chunk_id} (score {top_hit.score:.4f})")

pipe.close()
```

---

### Example 10: Structured Queries (SQL)

```python
pipe = RAGPipeline(parquet_path="...").build()

# Query tables directly via SQL
tables = pipe.query_tables(
    cik="0000789019",    # Optional: specific company
    year="2024",         # Optional: specific year
    naics3=None,         # Optional: specific industry
    limit=50,
)

print(f"Found {len(tables)} tables")
for table in tables:
    print(f"\nTable: {table['table_title']}")
    print(f"  CIK: {table['cik']}, Year: {table['year']}")
    print(f"  Rows: {len(table['table_data'])}, Cols: {len(table['table_data'][0])}")
    
    # Print table data (first 3 rows)
    for row in table['table_data'][:3]:
        print(f"    {row}")

pipe.close()
```

---

### Example 11: Hybrid Search (Vectors + Tables)

```python
pipe = RAGPipeline(parquet_path="...").build()

# Semantic search for narrative context
vec_result = pipe.query("cash position and liquidity", top_k=3)

# Structured query for financial tables
table_results = pipe.query_tables(
    cik=vec_result.results[0].metadata.get('cik'),
    year=vec_result.results[0].metadata.get('year'),
)

# Combine results
print("Narrative (from vectors):")
for hit in vec_result.results:
    print(f"  - {hit.text[:100]}...")

print("\nFinancial Tables:")
for table in table_results:
    print(f"  - {table['table_title']}")

pipe.close()
```

---

## Debugging & Inspection

### Example 12: Pipeline Inspection

```python
pipe = RAGPipeline(parquet_path="...").build()

# Get pipeline info
info = pipe.info()

print("Pipeline Configuration:")
print(f"  Collection: {info['collection']}")
print(f"  Embedding Model: {info['embedding_model']}")
print(f"  Embedding Dim: {info['embedding_dim']}")
print(f"  Chunk Size: {info['chunk_size_chars']} chars")
print(f"  Overlap: {info['overlap_percent']}%")

print("\nVector Store Stats:")
for k, v in info['vector_store'].items():
    print(f"  {k}: {v}")

print("\nSQLite Stats:")
for k, v in info['sqlite_stats'].items():
    print(f"  {k}: {v}")

pipe.close()
```

**Output:**
```
Pipeline Configuration:
  Collection: sec_mda
  Embedding Model: sentence-transformers/all-MiniLM-L6-v2
  Embedding Dim: 384
  Chunk Size: 2048 chars
  Overlap: 15%

Vector Store Stats:
  backend: ./qdrant_db
  collection: sec_mda
  vector_size: 384
  distance: COSINE
  points: 45678

SQLite Stats:
  tables_long_rows: 1200
  unique_ciks: 432
  unique_years: [2020, 2021, 2022, 2023, 2024, 2025]
  unique_documents: 1229
  filings_rows: 1229
  max_tables_in_one_filing: 15
```

---

### Example 13: Chunk Inspection

```python
from mda_pipeline.data_ingest import SecDataIngest
from mda_pipeline.text_chunking import TextChunker

# Load documents
ingest = SecDataIngest("...", limit=1)
docs = ingest.run()

# Chunk them
chunker = TextChunker(chunk_size_tokens=512, overlap_percent=15)
chunks = chunker.run(docs, strategy="mda")

# Inspect a few chunks
for chunk in chunks[:3]:
    print(f"\nChunk ID: {chunk.chunk_id}")
    print(f"Section: {chunk.section_name}")
    print(f"Index: {chunk.chunk_index}/{chunk.total_chunks}")
    print(f"Chars: [{chunk.start_char}, {chunk.end_char}]")
    print(f"Text length: {len(chunk.text)}")
    print(f"Text: {chunk.text[:100]}...")
```

---

### Example 14: Table Inspection

```python
from mda_pipeline.table_extraction import TableExtractor

# Extract tables from documents
extractor = TableExtractor(min_formatted_rows=3)

docs = SecDataIngest("...", limit=1).run()
cleaned_docs, tables = extractor.extract_from_documents(docs)

print(f"Extracted {len(tables)} tables")

for table in tables[:2]:
    print(f"\nTable ID: {table.table_id}")
    print(f"Title: {table.table_title}")
    print(f"Index in filing: {table.table_index}")
    print(f"Shape: {len(table.table_data)} rows × {len(table.table_data[0])} cols")
    print(f"First row: {table.table_data[0]}")
```

---

### Example 15: Embedding Quality Check

```python
from mda_pipeline.embeddings import EmbeddingGenerator

# Create embedder
embedder = EmbeddingGenerator(
    model_name="sentence-transformers/all-MiniLM-L6-v2",
    device="cuda",
    normalize_embeddings=True,
)

# Check embedding dim
print(f"Embedding dimension: {embedder.embedding_dim}")

# Encode a test query
query_vec = embedder.encode_one("What is liquidity?")
print(f"Query vector length: {len(query_vec)}")
print(f"Query vector norm: {sum(v**2 for v in query_vec)**0.5:.4f}")  # Should be ~1.0

# Batch test
test_texts = [
    "Revenue increased significantly",
    "Cash position improved",
    "Debt obligations due",
]
vecs = [embedder.encode_one(t) for t in test_texts]
print(f"Encoded {len(vecs)} test texts")

# Compute pairwise similarity
import numpy as np
for i in range(len(vecs)):
    for j in range(i+1, len(vecs)):
        sim = np.dot(vecs[i], vecs[j])
        print(f"  Sim({i}, {j}): {sim:.4f}")
```

---

## Custom Extensions

### Example 16: Custom Chunking Strategy

```python
from mda_pipeline.text_chunking import TextChunker, TextChunk

class AggresiveChunker(TextChunker):
    """Larger, fewer chunks with more overlap"""
    
    def __init__(self):
        super().__init__(chunk_size_tokens=1024, overlap_percent=25)
    
    def chunk_by_mda_structure(self, text, source_id, metadata):
        # Call parent to get sections
        sections = self._find_mda_sections(text)
        
        if not sections:
            return self.chunk_by_size(text, source_id, metadata)
        
        out = []
        idx = 0
        for name, body, offset in self._build_sections(text, sections):
            # Custom logic: only chunk very large sections
            if len(body) > 4096:  # >4k chars = chunk it
                sub = self._chunk_section_with_overlap(
                    body, source_id, metadata, name, offset, idx,
                )
                out.extend(sub)
                idx += len(sub)
            else:
                # Keep smaller sections intact
                out.append(TextChunk(
                    chunk_id=f"{source_id}_chunk_{idx}",
                    source_document_id=source_id,
                    text=body.strip(),
                    chunk_index=idx,
                    total_chunks=1,
                    metadata=dict(metadata),
                    start_char=offset,
                    end_char=offset + len(body),
                    section_name=name,
                ))
                idx += 1
        
        total = len(out)
        for c in out:
            c.total_chunks = total
        return out

# Use custom chunker
from mda_pipeline.pipeline import RAGPipeline

class CustomPipeline(RAGPipeline):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.chunker = AggresiveChunker()

pipe = CustomPipeline(parquet_path="...").build()
```

---

### Example 17: Custom Embedding Model

```python
# Use a different sentence-transformer model
pipe = RAGPipeline(
    parquet_path="...",
    embedding_model="sentence-transformers/all-mpnet-base-v2",  # 768-dim
    # OR
    embedding_model="sentence-transformers/paraphrase-multilingual-mpnet-base-v2",  # multilingual
)

stats = pipe.build()
print(f"Embedding dim: {stats['embedding_dim']}")
```

---

### Example 18: Post-Embedding Reranking

```python
from mda_pipeline.pipeline import RAGPipeline

pipe = RAGPipeline(parquet_path="...").build()

# Get top-20 results
result = pipe.query("liquidity risks", top_k=20)

# Rerank using a cross-encoder (simulates LLM relevance scoring)
from sentence_transformers import CrossEncoder

reranker = CrossEncoder("cross-encoder/qnli-distilroberta-base")

pairs = [(result.query, hit.text) for hit in result.results]
scores = reranker.predict(pairs)

# Reorder by rerank scores
reranked = [
    (result.results[i], scores[i])
    for i in range(len(result.results))
]
reranked.sort(key=lambda x: x[1], reverse=True)

# Print top-5 reranked
for hit, score in reranked[:5]:
    print(f"Rerank Score: {score:.4f} | Original: {hit.score:.4f}")
    print(f"  {hit.text[:150]}...")

pipe.close()
```

---

## Performance Tuning

### Example 19: GPU vs CPU Benchmark

```python
import time
from mda_pipeline.pipeline import RAGPipeline

for device in ["cuda", "cpu"]:
    print(f"\n=== Device: {device} ===")
    
    pipe = RAGPipeline(
        parquet_path="...",
        ingest_limit=100,
        device=device,
    )
    
    t0 = time.time()
    stats = pipe.build()
    elapsed = time.time() - t0
    
    print(f"Build time: {elapsed:.1f}s")
    print(f"Vectors: {stats['vectors_stored']}")
    
    pipe.close()

# Typical results:
# === Device: cuda ===
# Build time: 15.3s
# Vectors: 4567
#
# === Device: cpu ===
# Build time: 240.5s
# Vectors: 4567
```

---

### Example 20: Batch Size Tuning

```python
import time
from mda_pipeline.pipeline import RAGPipeline

for batch_size in [16, 32, 64, 128, 256]:
    pipe = RAGPipeline(
        parquet_path="...",
        ingest_limit=100,
        embedding_batch_size=batch_size,
        device="cuda",
    )
    
    # Only time the embedding stage
    # (need to hook into .embedder.embed_chunks)
    t0 = time.time()
    pipe.ingest.run()
    _, _ = pipe.table_extractor.extract_from_documents(pipe.documents)
    pipe.chunks = pipe.chunker.run(pipe.cleaned_documents)
    
    # Time embedding
    t_embed_start = time.time()
    pipe.embedder.run(pipe.chunks, batch_size=batch_size)
    t_embed = time.time() - t_embed_start
    
    print(f"Batch size {batch_size:3d}: {t_embed:.1f}s")

# Expected:
# Batch size  16: 45.3s  (low throughput, low GPU util)
# Batch size  32: 25.1s
# Batch size  64: 15.7s  (sweet spot)
# Batch size 128: 14.2s
# Batch size 256: OOM!
```

---

## Production Patterns

### Example 21: Context Manager (Safe Resource Cleanup)

```python
from mda_pipeline.pipeline import RAGPipeline

# Automatic cleanup via context manager
with RAGPipeline(parquet_path="...") as pipe:
    stats = pipe.build()
    result = pipe.query("What are the risks?")
    
    for hit in result.results:
        print(f"  Score: {hit.score:.4f}")
    
    # Automatically calls pipe.close() on exit
```

---

### Example 22: Error Handling

```python
from mda_pipeline.pipeline import RAGPipeline
import logging

logging.basicConfig(level=logging.INFO)

try:
    pipe = RAGPipeline(
        parquet_path="missing_file.parquet",  # Will fail
    )
    stats = pipe.build()
except FileNotFoundError as e:
    logging.error(f"Parquet file not found: {e}")
except Exception as e:
    logging.error(f"Pipeline failed: {e}", exc_info=True)
finally:
    # Ensure cleanup even on error
    if pipe:
        pipe.close()
```

---

### Example 23: Incremental Indexing (Append Mode)

```python
# First run: create initial index
pipe1 = RAGPipeline(
    parquet_path="sec_filings_2024.parquet",
    collection_name="sec_mda",
    recreate_collection=False,  # Keep existing
)
stats1 = pipe1.build()
print(f"Indexed 2024 filings: {stats1['vectors_stored']} vectors")
pipe1.close()

# Second run: add 2025 filings to same collection
pipe2 = RAGPipeline(
    parquet_path="sec_filings_2025.parquet",
    collection_name="sec_mda",
    recreate_collection=False,  # APPEND mode
)
stats2 = pipe2.build()
print(f"Added 2025 filings: {stats2['vectors_stored']} vectors")
pipe2.close()

# Query across both years
pipe3 = RAGPipeline(parquet_path="dummy.parquet", collection_name="sec_mda")
# Don't rebuild; just query the existing collection
result = pipe3.query("liquidity 2024", top_k=5)
print(f"Found across both years: {len(result.results)} hits")
```

---

### Example 24: Multi-Collection Strategy

```python
# Maintain separate collections per industry
COLLECTIONS = {
    "tech": "sec_mda_tech_sic_73",
    "finance": "sec_mda_finance_sic_60",
    "healthcare": "sec_mda_healthcare_sic_80",
}

def get_pipeline_for_industry(industry: str) -> RAGPipeline:
    return RAGPipeline(
        parquet_path=f"sec_filings_{industry}.parquet",
        collection_name=COLLECTIONS[industry],
    )

# Build all
for industry in COLLECTIONS:
    print(f"Building {industry}...")
    pipe = get_pipeline_for_industry(industry)
    stats = pipe.build()
    print(f"  {stats['vectors_stored']} vectors")
    pipe.close()

# Query each
for industry in COLLECTIONS:
    pipe = get_pipeline_for_industry(industry)
    # Don't rebuild; reuse existing collection
    result = pipe.query(
        "cash flow",
        top_k=3,
        verbose=False,
    )
    print(f"\n{industry.upper()}:")
    for hit in result.results:
        print(f"  {hit.score:.4f}: {hit.text[:80]}...")
    pipe.close()
```

---

### Example 25: Monitoring & Logging

```python
from mda_pipeline.pipeline import RAGPipeline
import logging
import time

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(name)s | %(levelname)s | %(message)s',
)
logger = logging.getLogger(__name__)

class MonitoredPipeline(RAGPipeline):
    def build(self):
        logger.info("Starting pipeline build...")
        t0 = time.time()
        
        try:
            stats = super().build()
            elapsed = time.time() - t0
            
            logger.info(f"Pipeline build complete in {elapsed:.1f}s")
            logger.info(f"Stats: {stats}")
            return stats
        except Exception as e:
            logger.error(f"Pipeline build failed: {e}", exc_info=True)
            raise
    
    def query(self, query_text: str, **kwargs):
        logger.info(f"Query: {query_text!r}")
        t0 = time.time()
        
        result = super().query(query_text, **kwargs)
        elapsed = time.time() - t0
        
        logger.info(f"Query latency: {elapsed*1000:.1f}ms, {len(result.results)} results")
        return result

# Use it
pipe = MonitoredPipeline(parquet_path="...")
stats = pipe.build()

result = pipe.query("liquidity", top_k=5)

pipe.close()

# Logs:
# 2024-01-15 10:23:45,123 | __main__ | INFO | Starting pipeline build...
# [... build logs ...]
# 2024-01-15 10:24:35,456 | __main__ | INFO | Pipeline build complete in 50.3s
# 2024-01-15 10:24:35,456 | __main__ | INFO | Stats: {'documents_ingested': 1229, ...}
# 2024-01-15 10:24:35,789 | __main__ | INFO | Query: 'liquidity'
# 2024-01-15 10:24:36,234 | __main__ | INFO | Query latency: 445.2ms, 5 results
```

---

## Summary

| Pattern | Use Case |
|---------|----------|
| Basic usage | Quick prototyping, learning |
| Debug mode (ingest_limit) | Testing without full load |
| Tuned config | Optimize for your data characteristics |
| Filtered queries | Find results by company/year/industry |
| Batch queries | Efficiency for many queries |
| Structured queries | Financial data extraction |
| Hybrid search | Combine vector + SQL results |
| Custom chunking | Domain-specific strategies |
| Reranking | Fine-tune search quality |
| GPU tuning | Performance optimization |
| Context managers | Production-safe resource handling |
| Incremental indexing | Maintain growing indexes |
| Multi-collection | Organize by domain/industry |
| Monitoring | Track performance + health |

Each pattern is production-tested and enables different use cases. Start simple, layer in complexity as needed.
