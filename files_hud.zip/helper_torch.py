import numpy as np
import torch


def create_dataset(data, lookback=60, train_split=0.8):
    """
    Create time-series dataset for LSTM/RNN models (PyTorch).
    
    Args:
        data: 1D numpy array or tensor (e.g., stock prices)
        lookback: Number of previous steps to use (default: 60)
        train_split: Proportion for training (default: 0.8)
    
    Returns:
        x_train, y_train: Training sequences and targets as torch tensors
        x_test, y_test: Test sequences and targets as torch tensors
    
    Example:
        df = pd.read_csv('tsla.csv')
        df = df['Open'].values
        df = df.reshape(-1, 1)
        x_train, y_train, x_test, y_test = helper.create_dataset(df)
    """
    
    # Convert to numpy if tensor
    if isinstance(data, torch.Tensor):
        data = data.numpy()
    
    # Flatten if 2D
    data = data.flatten() if data.ndim > 1 else data
    
    X, y = [], []
    
    for i in range(len(data) - lookback):
        X.append(data[i:i + lookback])
        y.append(data[i + lookback])
    
    X = np.array(X)
    y = np.array(y)
    
    # Split train/test
    split_idx = int(len(X) * train_split)
    x_train = X[:split_idx]
    y_train = y[:split_idx]
    x_test = X[split_idx:]
    y_test = y[split_idx:]
    
    # Convert to torch tensors
    x_train = torch.FloatTensor(x_train)
    y_train = torch.FloatTensor(y_train)
    x_test = torch.FloatTensor(x_test)
    y_test = torch.FloatTensor(y_test)
    
    return x_train, y_train, x_test, y_test


def get_device():
    """Get device (GPU if available, else CPU)."""
    return torch.device('cuda' if torch.cuda.is_available() else 'cpu')
