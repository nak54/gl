import helper_torch as helper
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import MinMaxScaler

# Device setup
device = helper.get_device()
print(f"Using device: {device}")

# Load data
df = pd.read_csv('tsla.csv')
df = df['Open'].values
df = df.reshape(-1, 1)

# Setup datasets
dataset_train = np.array(df[:int(df.shape[0]*0.8)])
dataset_test = np.array(df[int(df.shape[0]*0.8):])

# Scale the values
scaler = MinMaxScaler(feature_range=(0, 1))
dataset_train = scaler.fit_transform(dataset_train)
dataset_test = scaler.transform(dataset_test)

# Use the 'create_dataset' function here on the datasets to create train/test datasets
x_train, y_train, x_test, y_test = helper.create_dataset(dataset_train)
# x_test, y_test = helper.create_dataset(dataset_test)

# Reshape for LSTM: (batch_size, sequence_length, input_size)
x_train = x_train.unsqueeze(-1).to(device)  # (N, 60, 1)
y_train = y_train.unsqueeze(-1).to(device)  # (N, 1)
x_test = x_test.unsqueeze(-1).to(device)
y_test = y_test.unsqueeze(-1).to(device)


# Define LSTM model
class LSTMModel(nn.Module):
    def __init__(self, input_size=1, hidden_size=50, num_layers=2, dropout=0.2):
        super(LSTMModel, self).__init__()
        self.lstm1 = nn.LSTM(input_size, hidden_size, batch_first=True)
        self.dropout1 = nn.Dropout(dropout)
        self.lstm2 = nn.LSTM(hidden_size, hidden_size, batch_first=True)
        self.dropout2 = nn.Dropout(dropout)
        self.dense = nn.Linear(hidden_size, 1)
    
    def forward(self, x):
        # x shape: (batch_size, seq_len, input_size)
        lstm_out1, _ = self.lstm1(x)
        lstm_out1 = self.dropout1(lstm_out1)
        lstm_out2, _ = self.lstm2(lstm_out1)
        lstm_out2 = self.dropout2(lstm_out2)
        # Take last output
        last_output = lstm_out2[:, -1, :]
        output = self.dense(last_output)
        return output


# Initialize model
model = LSTMModel(input_size=1, hidden_size=50, num_layers=2, dropout=0.2)
model.to(device)

# Compile (setup optimizer and loss)
optimizer = optim.Adam(model.parameters(), lr=0.001)
criterion = nn.MSELoss()

# Train the model
epochs = 100
batch_size = 32

print("Training model...")
for epoch in range(epochs):
    # Training loop
    total_loss = 0
    num_batches = 0
    
    for i in range(0, len(x_train), batch_size):
        batch_x = x_train[i:i+batch_size]
        batch_y = y_train[i:i+batch_size]
        
        # Forward pass
        predictions = model(batch_x)
        loss = criterion(predictions, batch_y)
        
        # Backward pass
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        total_loss += loss.item()
        num_batches += 1
    
    avg_loss = total_loss / num_batches
    if (epoch + 1) % 10 == 0:
        print(f"Epoch {epoch+1}/{epochs}, Loss: {avg_loss:.6f}")

# Make predictions on test set
model.eval()
with torch.no_grad():
    predictions = model(x_test)

# Convert predictions to numpy
predictions_np = predictions.cpu().numpy()

# Print last column of predictions and model summary
print("\nPredictions (last 10):")
print(predictions_np[-10:, :])

print("\nModel Summary:")
print(model)
print(f"\nTotal parameters: {sum(p.numel() for p in model.parameters())}")
