great work!

youve corrected and removed encoding for cat columns for both hellinger and gower
used scipy.linalg.pinv, used get_col_types_by_cardinality instead of global vars :)
one hot encoding sparsity avoided by sparse_output=False,  

i have added numba equivalents & test outputs :
python test_metrics_numba.py
Loading CSVs... done.  real=(10253, 54), synth=(10253, 54), numeric cols=41
Column selected for Doane/Hellinger tests: 'nol_carryover_cr_amt'

NN distances computed (sample=500 synth→real, euclidean on 41 scaled cols)

Warming up numba JIT... done.

============================================================
TEST: doanes_bins  (n=20,506, col='nol_carryover_cr_amt' real+synth combined)
  Bins result : 29
  Original :  1779.09 µs/call
  Numba    :    87.29 µs/call
  Speedup  : 20.38x
  PASSED

============================================================
TEST: hellinger_hist_1d_doane  (col='nol_carryover_cr_amt', n_real=10,253, n_synth=10,253)
  Hellinger   : original=0.01847759  numba=0.01847759
  Bin edges   : 29 bins
  Original :  2291.29 µs/call
  Numba    :   598.91 µs/call
  Speedup  : 3.83x
  PASSED

============================================================
TEST: summarize_distances  (n=500 NN distances from CSV sample)
  key         original       numba
  min           0.2275      0.2275
  p01           0.3405      0.3405
  median        1.0101      1.0101
  mean          3.2377      3.2377
  p99          17.8396     17.8396
  max          33.7812     33.7812
  Original :   222.46 µs/call
  Numba    :     8.15 µs/call
  Speedup  : 27.31x
  PASSED

============================================================
TEST: edge cases (NaNs, zero-variance, identical distributions)
  All edge cases PASSED

============================================================
All tests passed!

