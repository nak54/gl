youve corrected and removed encoding for cat columns for both hellinger and gower
used scipy.linalg.pinv, used get_col_types_by_cardinality instead of global vars :)
one hot encoding sparsity avoided by sparse_output=False, rounded to 2 digits, i have added numba equivalents 

