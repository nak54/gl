"""
Test and benchmark original vs numba implementations using real/synthetic CSV data.
Random seed 42 is used only for the sampling step; CSV data is deterministic.

Run with:  /path/to/python3.11 test_metrics_numba.py
"""
import os
import numpy as np
import pandas as pd
import timeit
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import NearestNeighbors

from metrics_Copy import (
    doanes_bins,
    doanes_bins_numba,
    hellinger_hist_1d_doane,
    hellinger_hist_1d_doane_numba,
    summarize_distances,
    summarize_distances_numba_dict,
    clean_for_metrics,
    get_col_types_by_cardinality,
)

SEED = 42
_HERE = os.path.dirname(os.path.abspath(__file__))

# ── Load and clean CSV data ───────────────────────────────────────────────────
print("Loading CSVs...", end=" ", flush=True)
df_real  = pd.read_csv(os.path.join(_HERE, 'rd_1718.csv'))
df_synth = pd.read_csv(os.path.join(_HERE, 'sd_1718.csv'))
df_real, df_synth = clean_for_metrics(df_real, df_synth)
numeric_cols, _ = get_col_types_by_cardinality(df_real)
print(f"done.  real={df_real.shape}, synth={df_synth.shape}, numeric cols={len(numeric_cols)}")

# ── Pick the numeric column with the best non-NaN coverage in both datasets ───
_coverage = [
    (col, df_real[col].notna().sum() + df_synth[col].notna().sum())
    for col in numeric_cols
]
_col = max(_coverage, key=lambda x: x[1])[0]
print(f"Column selected for Doane/Hellinger tests: '{_col}'\n")

COL_REAL     = pd.to_numeric(df_real[_col],  errors='coerce').dropna().to_numpy(dtype=np.float64)
COL_SYNTH    = pd.to_numeric(df_synth[_col], errors='coerce').dropna().to_numpy(dtype=np.float64)
COL_COMBINED = np.concatenate([COL_REAL, COL_SYNTH])

# ── Compute nearest-neighbour distances on a sample (for summarize_distances) ─
_SAMPLE = 500
rng = np.random.default_rng(SEED)
idx_r = rng.choice(len(df_real),  _SAMPLE, replace=False)
idx_s = rng.choice(len(df_synth), _SAMPLE, replace=False)

_X_r = df_real[numeric_cols].iloc[idx_r].fillna(0).to_numpy(dtype=float)
_X_s = df_synth[numeric_cols].iloc[idx_s].fillna(0).to_numpy(dtype=float)
_scaler = StandardScaler().fit(_X_r)
_X_r = _scaler.transform(_X_r)
_X_s = _scaler.transform(_X_s)
_nn = NearestNeighbors(n_neighbors=1, metric='euclidean').fit(_X_r)
DATA_DISTS = _nn.kneighbors(_X_s, return_distance=True)[0].ravel().astype(np.float64)
print(f"NN distances computed (sample={_SAMPLE} synth→real, euclidean on {len(numeric_cols)} scaled cols)\n")


# ── Helpers ───────────────────────────────────────────────────────────────────
def warm_up_numba():
    """Trigger JIT compilation on tiny inputs before timing begins."""
    print("Warming up numba JIT...", end=" ", flush=True)
    doanes_bins_numba(np.arange(1.0, 10.0))
    hellinger_hist_1d_doane_numba(
        np.array([1.0, 2.0, 3.0]),
        np.array([1.5, 2.5, 0.5]),
    )
    summarize_distances_numba_dict(np.array([0.1, 0.5, 1.0, 2.0, 3.0]))
    print("done.\n")


def _timing_lines(t_orig, t_numba, n_reps):
    us_o = t_orig  / n_reps * 1e6
    us_n = t_numba / n_reps * 1e6
    return (
        f"  Original : {us_o:8.2f} µs/call\n"
        f"  Numba    : {us_n:8.2f} µs/call\n"
        f"  Speedup  : {t_orig/t_numba:.2f}x"
    )


# ── Tests ─────────────────────────────────────────────────────────────────────
def test_doanes_bins():
    print("=" * 60)
    print(f"TEST: doanes_bins  (n={len(COL_COMBINED):,}, col='{_col}' real+synth combined)")

    orig = doanes_bins(COL_COMBINED)
    nb   = doanes_bins_numba(COL_COMBINED)

    assert orig == nb, f"FAIL: original={orig}, numba={nb}"
    print(f"  Bins result : {orig}")

    n = 2_000
    t_o = timeit.timeit(lambda: doanes_bins(COL_COMBINED), number=n)
    t_n = timeit.timeit(lambda: doanes_bins_numba(COL_COMBINED), number=n)
    print(_timing_lines(t_o, t_n, n))
    print("  PASSED\n")


def test_hellinger_1d():
    print("=" * 60)
    print(f"TEST: hellinger_hist_1d_doane  (col='{_col}', "
          f"n_real={len(COL_REAL):,}, n_synth={len(COL_SYNTH):,})")

    h_o, edges_o = hellinger_hist_1d_doane(COL_REAL, COL_SYNTH)
    h_n, edges_n = hellinger_hist_1d_doane_numba(COL_REAL, COL_SYNTH)

    np.testing.assert_array_equal(edges_o, edges_n, err_msg="bin edges differ")
    np.testing.assert_allclose(
        h_o, h_n, rtol=1e-10,
        err_msg=f"Hellinger mismatch: original={h_o:.12f}, numba={h_n:.12f}",
    )
    print(f"  Hellinger   : original={h_o:.8f}  numba={h_n:.8f}")
    print(f"  Bin edges   : {len(edges_o)-1} bins")

    n = 500
    t_o = timeit.timeit(lambda: hellinger_hist_1d_doane(COL_REAL, COL_SYNTH), number=n)
    t_n = timeit.timeit(lambda: hellinger_hist_1d_doane_numba(COL_REAL, COL_SYNTH), number=n)
    print(_timing_lines(t_o, t_n, n))
    print("  PASSED\n")


def test_summarize_distances():
    print("=" * 60)
    print(f"TEST: summarize_distances  (n={len(DATA_DISTS):,} NN distances from CSV sample)")

    orig = summarize_distances(DATA_DISTS)
    nb   = summarize_distances_numba_dict(DATA_DISTS)

    assert orig["n"] == nb["n"], f"n mismatch: {orig['n']} vs {nb['n']}"
    for key in ("min", "p01", "p05", "median", "mean", "p95", "p99", "max"):
        np.testing.assert_allclose(
            orig[key], nb[key], rtol=1e-6,
            err_msg=f"[{key}] original={orig[key]}, numba={nb[key]}",
        )

    print(f"  {'key':<8}  {'original':>10}  {'numba':>10}")
    for k in ("min", "p01", "median", "mean", "p99", "max"):
        print(f"  {k:<8}  {orig[k]:>10.4f}  {nb[k]:>10.4f}")

    n = 1_000
    t_o = timeit.timeit(lambda: summarize_distances(DATA_DISTS), number=n)
    t_n = timeit.timeit(lambda: summarize_distances_numba_dict(DATA_DISTS), number=n)
    print(_timing_lines(t_o, t_n, n))
    print("  PASSED\n")


def test_edge_cases():
    print("=" * 60)
    print("TEST: edge cases (NaNs, zero-variance, identical distributions)")

    # doanes_bins: NaN/inf in input
    arr_nan = np.array([1.0, np.nan, 2.0, np.inf, 3.0, -np.inf, 4.0])
    assert doanes_bins(arr_nan) == doanes_bins_numba(arr_nan), "NaN handling differs"

    # doanes_bins: fewer than 3 finite values → must return 1
    arr_tiny = np.array([1.0, np.nan, np.nan])
    assert doanes_bins(arr_tiny) == doanes_bins_numba(arr_tiny) == 1

    # doanes_bins: zero variance → must return 1
    arr_const = np.array([5.0, 5.0, 5.0, 5.0, 5.0])
    assert doanes_bins(arr_const) == doanes_bins_numba(arr_const) == 1

    # Hellinger of a column compared to itself → ≈ 0
    h_o, _ = hellinger_hist_1d_doane(COL_REAL, COL_REAL)
    h_n, _ = hellinger_hist_1d_doane_numba(COL_REAL, COL_REAL)
    np.testing.assert_allclose(h_o, h_n, rtol=1e-10)
    assert h_o < 1e-10, f"identical column should have h≈0, got {h_o}"

    print("  All edge cases PASSED\n")


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    warm_up_numba()
    test_doanes_bins()
    test_hellinger_1d()
    test_summarize_distances()
    test_edge_cases()
    print("=" * 60)
    print("All tests passed!")
