## ---------------------------------------------------------------------------
## 02_clean.R -- text normalisation (port of clean.R / corpus.R)
## ---------------------------------------------------------------------------

## Three views of the same page text, as in the Shiny app:
##   text    - lower case, whitespace/commas/dashes normalised (name search)
##   numbers - digits only, punctuation and blanks removed  (phone search)
##   flat    - text with runs of blanks collapsed            (email search)
clean_pdf_text <- function(pages) {
  text <- tolower(pages)
  text <- gsub("[\n\t]", " ", text)
  text <- gsub("[[:blank:]]+", " ", text)
  text <- gsub(",", " ", text, fixed = TRUE)
  text <- gsub("-", " ", text, fixed = TRUE)

  numbers <- gsub("(?<=[[:digit:]])[[:blank:]](?=[[:digit:]])", "", text, perl = TRUE)
  numbers <- gsub("[[:punct:]]", "", numbers)
  numbers <- gsub("[[:blank:]]", "", numbers)

  flat <- gsub("[[:blank:]]+", " ", text)

  list(text = text, numbers = numbers, flat = flat)
}

## Page text prepared for bag-of-words counting. This folds together the
## clean_ngrams() and create_clean_corpus() steps of the Shiny app: the same
## transformation is applied to the keyword list, so both sides always agree.
clean_for_bow <- function(x) {
  x <- tolower(x)
  x <- gsub("\\\\n|\\\\r|\\\\t", " ", x)          # literal backslash-n etc.
  x <- gsub("[\n\r\t]", " ", x)
  x <- gsub('"', " ", x, fixed = TRUE)
  x <- gsub("(", " ", x, fixed = TRUE)
  x <- gsub(")", " ", x, fixed = TRUE)
  x <- gsub("'", "", x, fixed = TRUE)             # don't split contractions
  x <- gsub("-", "", x, fixed = TRUE)             # e-mail -> email
  x <- gsub("[^0-9a-z+#&/ ]", " ", x)             # keep c++, c#, r&d, and/or
  x <- gsub("[[:blank:]]+", " ", x)
  trimws(x)
}
