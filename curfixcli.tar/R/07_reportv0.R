## ---------------------------------------------------------------------------
## 07_report.R -- CSV, XLSX and PNG outputs
## The Shiny app's plotly charts and sf/GIS maps are deliberately not ported;
## the CLI ships static ggplot2 PNGs instead (see cliR4.6 instructions).
## ---------------------------------------------------------------------------

## Categorical palette (validated: adjacent CVD dE 9.1, normal-vision 19.6 on a
## light surface). Assigned in fixed order, never cycled; past 8 categories the
## rest fold into "Other".
ACR_SERIES <- c("#2a78d6", "#eb6834", "#1baf7a", "#eda100",
                "#e87ba4", "#008300", "#4a3aa7", "#e34948")
ACR_SURFACE <- "#fcfcfb"
ACR_INK <- "#0b0b0b"
ACR_INK2 <- "#52514e"
ACR_GRID <- "#e4e4e0"

acr_theme <- function(base_size = 12) {
  ggplot2::theme_minimal(base_size = base_size) +
    ggplot2::theme(
      plot.background = ggplot2::element_rect(fill = ACR_SURFACE, colour = NA),
      panel.background = ggplot2::element_rect(fill = ACR_SURFACE, colour = NA),
      panel.grid.major.y = ggplot2::element_blank(),
      panel.grid.minor = ggplot2::element_blank(),
      panel.grid.major.x = ggplot2::element_line(colour = ACR_GRID, linewidth = 0.3),
      axis.ticks = ggplot2::element_blank(),
      axis.text = ggplot2::element_text(colour = ACR_INK2),
      axis.title = ggplot2::element_text(colour = ACR_INK2, size = base_size - 1),
      plot.title = ggplot2::element_text(colour = ACR_INK, face = "bold",
                                         size = base_size + 3),
      plot.subtitle = ggplot2::element_text(colour = ACR_INK2, size = base_size - 1),
      plot.caption = ggplot2::element_text(colour = ACR_INK2, size = base_size - 3),
      legend.position = "bottom",
      legend.title = ggplot2::element_blank(),
      legend.text = ggplot2::element_text(colour = ACR_INK2)
    )
}

## Readable, unique bar labels
candidate_labels <- function(df) {
  fn <- if ("Applicant First Name" %in% names(df)) df[["Applicant First Name"]] else ""
  ln <- if ("Applicant Last Name" %in% names(df)) df[["Applicant Last Name"]] else ""
  lab <- trimws(paste(fn, ln))
  blank <- !nzchar(lab) | grepl("^(NA ?)+$", lab)
  lab[blank] <- df$email[blank]
  dup <- lab %in% lab[duplicated(lab)]
  lab[dup] <- sprintf("%s (%s)", lab[dup], df$email[dup])
  lab
}

## The categorical palette has 8 slots and is never cycled: with more
## categories than that, the smallest ones are folded into "Other".
fold_for_chart <- function(df, cats) {
  if (length(cats) <= length(ACR_SERIES)) return(list(df = df, cats = cats))
  weight <- vapply(cats, function(c) sum(as.numeric(df[[c]]), na.rm = TRUE), numeric(1))
  keep <- cats[cats %in% names(sort(weight, decreasing = TRUE))[seq_len(length(ACR_SERIES) - 1L)]]
  rest <- setdiff(cats, keep)
  df[["Other"]] <- rowSums(as.data.frame(lapply(rest, function(c) as.numeric(df[[c]]))))
  list(df = df, cats = c(keep, "Other"))
}

## 1. Ranking: total score per candidate (single series -> no legend,
##    value labels supply the relief the light palette needs).
chart_ranking <- function(scores, cats, path, title, subtitle, top_n) {
  if (!have_pkg("ggplot2")) return(invisible(NULL))
  df <- utils::head(scores[order(-scores[["Total Score"]]), , drop = FALSE], top_n)
  if (!nrow(df)) return(invisible(NULL))
  df$label <- candidate_labels(df)
  df$label <- factor(df$label, levels = rev(df$label))
  p <- ggplot2::ggplot(df, ggplot2::aes(x = .data[["Total Score"]], y = .data$label)) +
    ggplot2::geom_col(fill = ACR_SERIES[1L], width = 0.62) +
    ggplot2::geom_text(ggplot2::aes(label = .data[["Total Score"]]),
                       hjust = -0.35, colour = ACR_INK2, size = 3.2) +
    ggplot2::scale_x_continuous(expand = ggplot2::expansion(mult = c(0, 0.12))) +
    ggplot2::labs(title = title, subtitle = subtitle,
                  x = "Total score", y = NULL,
                  caption = "Scores are relative to this candidate pool (top resume in each category = 5).") +
    acr_theme()
  save_chart(p, path, n_rows = nrow(df))
}

## 2. Composition: stacked category scores (legend always present for >= 2
##    series; 2px surface gap between segments).
chart_stacked <- function(scores, cats, path, title, subtitle, top_n) {
  if (!have_pkg("ggplot2")) return(invisible(NULL))
  df <- utils::head(scores[order(-scores[["Total Score"]]), , drop = FALSE], top_n)
  if (!nrow(df) || !length(cats)) return(invisible(NULL))
  df$label <- candidate_labels(df)
  folded <- fold_for_chart(df, cats)
  df <- folded$df
  cats <- folded$cats
  long <- do.call(rbind, lapply(cats, function(cat) data.frame(
    label = df$label, category = cat, score = as.numeric(df[[cat]]),
    total = df[["Total Score"]], stringsAsFactors = FALSE)))
  long$label <- factor(long$label, levels = rev(df$label))
  long$category <- factor(long$category, levels = cats)
  pal <- stats::setNames(ACR_SERIES[seq_along(cats)], cats)
  p <- ggplot2::ggplot(long, ggplot2::aes(x = .data$score, y = .data$label,
                                          fill = .data$category)) +
    ggplot2::geom_col(width = 0.62, colour = ACR_SURFACE, linewidth = 0.7) +
    ggplot2::scale_fill_manual(values = pal, drop = FALSE) +
    ggplot2::scale_x_continuous(expand = ggplot2::expansion(mult = c(0, 0.06))) +
    ggplot2::labs(title = title, subtitle = subtitle,
                  x = "Score by category (0-5 each)", y = NULL) +
    acr_theme() +
    ggplot2::guides(fill = ggplot2::guide_legend(nrow = 2, byrow = TRUE))
  save_chart(p, path, n_rows = nrow(df))
}

## 3. Coverage: candidate x category heatmap (sequential, one hue light->dark).
chart_heatmap <- function(scores, cats, path, title, subtitle, top_n) {
  if (!have_pkg("ggplot2")) return(invisible(NULL))
  df <- utils::head(scores[order(-scores[["Total Score"]]), , drop = FALSE], top_n)
  if (!nrow(df) || !length(cats)) return(invisible(NULL))
  df$label <- candidate_labels(df)
  long <- do.call(rbind, lapply(cats, function(cat) data.frame(
    label = df$label, category = cat, score = as.numeric(df[[cat]]),
    stringsAsFactors = FALSE)))
  long$label <- factor(long$label, levels = rev(df$label))
  long$category <- factor(long$category, levels = cats)
  p <- ggplot2::ggplot(long, ggplot2::aes(x = .data$category, y = .data$label,
                                          fill = .data$score)) +
    ggplot2::geom_tile(colour = ACR_SURFACE, linewidth = 1.2) +
    ggplot2::geom_text(ggplot2::aes(label = .data$score), size = 3.1,
                       colour = ifelse(long$score > 3, "#ffffff", ACR_INK)) +
    ggplot2::scale_fill_gradient(low = "#eaf1fa", high = "#14467f", limits = c(0, 5)) +
    ggplot2::labs(title = title, subtitle = subtitle, x = NULL, y = NULL) +
    acr_theme() +
    ggplot2::theme(panel.grid.major.x = ggplot2::element_blank(),
                   axis.text.x = ggplot2::element_text(angle = 20, hjust = 1),
                   legend.position = "right")
  save_chart(p, path, n_rows = nrow(df), width = 9 + 0.5 * length(cats))
}

save_chart <- function(p, path, n_rows, width = 10) {
  h <- max(3.5, 0.34 * n_rows + 2.2)
  ggplot2::ggsave(path, p, width = width, height = h, dpi = 150, bg = ACR_SURFACE)
  msg("chart: %s", path)
  invisible(path)
}

## XLSX workbook, styled like the app's output_score.R -----------------------
write_workbook <- function(path, sheets) {
  if (!have_pkg("openxlsx")) {
    acr_warn("openxlsx is not installed; skipping %s (CSVs were still written)", basename(path))
    return(invisible(NULL))
  }
  wb <- openxlsx::createWorkbook()
  head_fill <- openxlsx::createStyle(fgFill = "#AEDEF5", border = "TopBottomLeftRight",
                                     borderStyle = "thin")
  total_fill <- openxlsx::createStyle(fgFill = "#EAB139", border = "TopBottomLeftRight",
                                      borderStyle = "thin")
  quart_fill <- openxlsx::createStyle(fgFill = "#A5BA73")

  for (nm in names(sheets)) {
    df <- sheets[[nm]]
    if (is.null(df) || !nrow(df)) next
    sheet <- substr(nm, 1, 31)
    openxlsx::addWorksheet(wb, sheet)
    openxlsx::writeDataTable(wb, sheet = sheet, x = df, startRow = 1, startCol = 1,
                             tableStyle = "TableStyleMedium17")
    rows <- seq_len(nrow(df)) + 1L
    cat_cols <- attr(df, "category_cols")
    if (length(cat_cols)) {
      j <- match(cat_cols, names(df))
      j <- j[!is.na(j)]
      if (length(j)) openxlsx::addStyle(wb, sheet, head_fill, cols = j, rows = rows,
                                        gridExpand = TRUE)
    }
    if ("Total Score" %in% names(df)) {
      openxlsx::addStyle(wb, sheet, total_fill, cols = match("Total Score", names(df)),
                         rows = rows, gridExpand = TRUE)
    }
    if ("quartile" %in% names(df)) {
      openxlsx::addStyle(wb, sheet, quart_fill, cols = match("quartile", names(df)),
                         rows = rows, gridExpand = TRUE)
    }
    openxlsx::setColWidths(wb, sheet, cols = seq_along(df), widths = "auto")
  }
  openxlsx::saveWorkbook(wb, path, overwrite = TRUE)
  msg("workbook: %s", path)
  invisible(path)
}
