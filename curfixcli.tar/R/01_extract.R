## ---------------------------------------------------------------------------
## 01_extract.R -- page level text extraction (embedded text + Tesseract OCR)
## Replaces parse.R from the Shiny app. Both layers are kept because some
## resumes are real text and others are scans.
## ---------------------------------------------------------------------------

## OCR a single PNG. Uses the tesseract R package when it is installed and
## falls back to the tesseract command line tool, so the CLI also runs on
## machines where the R binding is unavailable.
ocr_png <- function(png, dpi = 300L) {
  if (requireNamespace("tesseract", quietly = TRUE)) {
    return(paste(tesseract::ocr(png), collapse = " "))
  }
  out <- suppressWarnings(
    system2("tesseract", c(shQuote(png), "stdout", "--dpi", as.integer(dpi)),
            stdout = TRUE, stderr = FALSE)
  )
  if (!length(out)) return("")
  paste(out, collapse = "\n")
}

tesseract_available <- function() {
  requireNamespace("tesseract", quietly = TRUE) ||
    nzchar(Sys.which("tesseract"))
}

## Render every page to PNG, OCR it, drop the PNG again.
ocr_pdf_pages <- function(pdf_path, n_pages, dpi = 300L, cores = 1L) {
  png_dir <- file.path(tempdir(), sprintf("acr_png_%s", as.integer(Sys.time())))
  ensure_dir(png_dir)
  on.exit(unlink(png_dir, recursive = TRUE, force = TRUE), add = TRUE)

  pages <- seq_len(n_pages)

  msg("rendering %d page(s) to PNG at %d dpi on %d core(s)", n_pages, dpi, cores)
  pngs <- par_lapply(pages, function(page) {
    pdftools::pdf_convert(pdf_path, format = "png", pages = page, dpi = dpi,
                          filenames = file.path(png_dir, sprintf("page_%04d.png", page)),
                          verbose = FALSE)
  }, cores = cores)
  pngs <- unlist(pngs, use.names = FALSE)

  msg("running OCR on %d page(s)", length(pngs))
  txt <- par_lapply(pngs, function(p) ocr_png(p, dpi = dpi),
                    cores = cores, export = "ocr_png")

  tolower(vapply(txt, function(z) paste(z, collapse = " "), character(1)))
}

## Returns list(text = <chr n_pages>, ocr = <chr n_pages or NULL>, n_pages = int)
## Results are cached under <out_dir>/cache so that -r/--resume can skip this
## (by far the slowest) stage.
extract_pages <- function(pdf_path, out_dir, dpi = 300L, cores = 1L,
                          use_ocr = TRUE, resume = FALSE) {
  require_pkgs("pdftools", "PDF text extraction")

  cache_dir <- ensure_dir(file.path(out_dir, "cache"))
  cache_file <- file.path(cache_dir, "pages.rds")
  fp <- file_fingerprint(pdf_path)

  if (resume && file.exists(cache_file)) {
    cached <- tryCatch(readRDS(cache_file), error = function(e) NULL)
    ok <- !is.null(cached) && same_fingerprint(cached$fingerprint, fp) &&
      (!use_ocr || !is.null(cached$ocr))
    if (ok) {
      msg("reusing cached page text from %s (%d pages)", cache_file, cached$n_pages)
      return(cached)
    }
    if (!is.null(cached)) msg("cache in %s is stale, re-extracting", cache_file)
  }

  info <- pdftools::pdf_info(pdf_path)
  n_pages <- info$pages
  msg("extracting text from %s (%d pages)", basename(pdf_path), n_pages)

  text <- tolower(pdftools::pdf_text(pdf_path))
  if (length(text) < n_pages) text <- c(text, rep("", n_pages - length(text)))

  ocr <- NULL
  if (use_ocr) {
    if (!tesseract_available()) {
      acr_warn("no Tesseract available (neither the R package nor the CLI); continuing with embedded text only")
    } else {
      ocr <- with_timer("OCR", ocr_pdf_pages(pdf_path, n_pages, dpi = dpi, cores = cores))
    }
  } else {
    msg("--no-ocr given: skipping the Tesseract layer")
  }

  res <- list(fingerprint = fp, n_pages = n_pages, dpi = dpi,
              text = text, ocr = ocr)
  saveRDS(res, cache_file)
  msg("cached page text in %s", cache_file, level = 2L)
  res
}
