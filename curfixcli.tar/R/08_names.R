## ---------------------------------------------------------------------------
## 08_names.R -- names sheet loading with phone splitting (data.table)
## Sourced after 03_detect.R, so this load_names() replaces that one.
## ---------------------------------------------------------------------------

PHONE_SOURCE_COLS <- c("Applicant Phone Numbers", "Phone Numbers", "Applicant Phone Number")

## Port of sep_ph.R. "484-620-1978 | 4846201978 | 13046792393" ->
##   Applicant Phone Number = 4846201978, Applicant Other Phones = 3046792393
## Removes a leading country code 1, drops anything that is not n_digits long,
## and removes duplicates (keeping the order they appear in).
split_phone_numbers <- function(tbl, src = NULL, n_digits = 10L) {
  dt <- data.table::as.data.table(tbl)
  if (is.null(src)) src <- PHONE_SOURCE_COLS[PHONE_SOURCE_COLS %in% names(dt)][1L]
  if (is.na(src)) {
    dt[, `:=`(`Applicant Phone Number` = NA_character_,
              `Applicant Other Phones` = NA_character_)]
    return(dt[])
  }
  clean_one <- function(x) {
    d <- gsub("\\D", "", x)
    cc <- !is.na(d) & nchar(d) == n_digits + 1L & startsWith(d, "1")
    d[cc] <- substring(d[cc], 2L)
    d[is.na(d) | nchar(d) != n_digits] <- NA_character_
    d
  }
  parts <- strsplit(as.character(dt[[src]]), "|", fixed = TRUE)
  res <- vapply(parts, function(p) {
    p <- unique(clean_one(trimws(p)))
    p <- p[!is.na(p)]
    c(if (length(p)) p[1L] else NA_character_,
      if (length(p) > 1L) paste(p[-1L], collapse = " | ") else NA_character_)
  }, character(2))
  dt[, `:=`(`Applicant Phone Number` = res[1L, ],
            `Applicant Other Phones` = res[2L, ])]
  n_bad <- dt[!is.na(get(src)) & nzchar(trimws(get(src))) & is.na(`Applicant Phone Number`), .N]
  if (n_bad) acr_warn("%d applicant(s) have phone text but no valid %d-digit number", n_bad, n_digits)
  dt[]
}

read_table_dt <- function(path) {
  ext <- tolower(tools::file_ext(path))
  if (ext %in% c("xlsx", "xls")) {
    require_pkgs("readxl", "reading the names spreadsheet")
    data.table::as.data.table(readxl::read_excel(path, col_types = "text"))
  } else {
    data.table::fread(path, colClasses = "character", encoding = "UTF-8")
  }
}

load_names <- function(path, names_out = NA_character_) {
  require_pkgs("data.table", "processing the names sheet")
  dt <- read_table_dt(path)
  miss <- setdiff(NAMES_REQUIRED, names(dt))
  if (length(miss)) die("names file %s is missing required column(s): %s",
                        basename(path), paste(miss, collapse = ", "))
  dt <- split_phone_numbers(dt)

  n_dup <- sum(duplicated(dt))
  if (n_dup) acr_warn("names sheet has %d duplicated row(s); remove them and rerun", n_dup)

  if (!is.na(names_out)) {
    if (grepl("\\.xlsx$", names_out, ignore.case = TRUE) && have_pkg("writexl")) {
      writexl::write_xlsx(dt, names_out)
    } else data.table::fwrite(dt, names_out)
    msg("names with split phones written to %s", names_out)
  }

  people <- dt[, .(
    firstName = tolower(trimws(`Applicant First Name`)),
    lastName  = tolower(trimws(`Applicant Last Name`)),
    email     = tolower(trimws(`Applicant Email Address`)),
    phone     = data.table::fcoalesce(`Applicant Phone Number`, ""),
    otherPhones = data.table::fcoalesce(`Applicant Other Phones`, "")
  )]
  people[, `:=`(firstNameSearch = norm_needle(firstName),
                lastNameSearch  = norm_needle(lastName),
                emailSearch     = norm_needle(email))]
  people <- unique(people[!is.na(firstName) & nzchar(firstName)])
  n_noemail <- people[is.na(email) | !nzchar(email), .N]
  if (n_noemail) acr_warn("%d applicant(s) have no e-mail address; they can only be matched by name or phone", n_noemail)
  dup_name <- people[, .N, by = .(firstName, lastName)][N > 1L]
  if (nrow(dup_name)) acr_warn("applicants sharing first+last name (resolve manually): %s",
                               paste(dup_name$firstName, dup_name$lastName, collapse = "; "))

  msg("names sheet: %d applicant(s), %d column(s)", nrow(people), ncol(dt))
  list(table = as.data.frame(dt), people = as.data.frame(people))
}