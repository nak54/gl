## ---------------------------------------------------------------------------
## 06_score.R -- aggregate, normalise and score (port of score.R)
##
## Two measures, selectable with -s/--score:
##   binary     -- keyword presence. Per category: (number of dictionary terms
##                 found) / (number of terms in that category).
##   normalized -- keyword frequency relative to resume length, min-max scaled
##                 to [1,5] across all hits, summed per category and divided by
##                 the number of terms in that category.
## Each measure can be weighted by the score_adjustment column (--weights).
## In both cases every category column is finally rescaled so the strongest
## resume in the corpus scores 5 (ceiling(value * 5 / max)), and Total Score is
## the sum of the category scores -- the same relative scoring the app used.
## ---------------------------------------------------------------------------

## Long table of hits enriched with category, weight and resume length.
build_joined <- function(counts, keywords, docs) {
  if (!nrow(counts)) return(counts)
  d <- merge(counts, keywords, by.x = "keyword", by.y = "keyword", all.x = TRUE)
  d <- d[!is.na(d$category), , drop = FALSE]
  d <- merge(d, docs[, c("doc_id", "wordcount", "resumelength")], by = "doc_id", all.x = TRUE)
  ratio <- d$Freq / d$wordcount
  rng <- range(ratio, na.rm = TRUE)
  d$ratio <- ratio
  d$Freq_normalized <- if (is.finite(diff(rng)) && diff(rng) > 0) {
    1 + ((ratio - rng[1L]) / (rng[2L] - rng[1L])) * 4
  } else {
    rep(1, length(ratio))
  }
  d[order(d$doc_id, d$category, d$keyword), , drop = FALSE]
}

## Wide category table for one measure/weighting combination.
## Returns list(scores = <0-5 per category + Total Score + quartile>,
##              proportion = <raw per category value>)
score_matrix <- function(joined, keywords, docs, measure = c("normalized", "binary"),
                         weighted = FALSE) {
  measure <- match.arg(measure)
  cats <- sort(unique(keywords$category))
  terms_per_cat <- tapply(keywords$keyword, keywords$category, function(z) length(unique(z)))

  mat <- matrix(0, nrow = nrow(docs), ncol = length(cats),
                dimnames = list(as.character(docs$doc_id), cats))

  if (nrow(joined)) {
    value <- if (measure == "binary") as.numeric(joined$Freq_binary) else joined$Freq_normalized
    if (weighted) value <- value * joined$score_adjustment
    agg <- aggregate(list(value = value),
                     by = list(doc_id = joined$doc_id, category = joined$category),
                     FUN = sum)
    agg$value <- agg$value / as.numeric(terms_per_cat[agg$category])
    idx <- cbind(match(as.character(agg$doc_id), rownames(mat)),
                 match(agg$category, colnames(mat)))
    ok <- !is.na(idx[, 1L]) & !is.na(idx[, 2L])
    mat[idx[ok, , drop = FALSE]] <- agg$value[ok]
  }

  proportion <- round(mat, 3)

  ## Relative scaling: strongest resume in each category gets 5.
  scaled <- mat
  for (j in seq_len(ncol(scaled))) {
    mx <- max(scaled[, j])
    scaled[, j] <- if (mx > 0) ceiling(scaled[, j] * (5 / mx)) else 0
  }

  total <- if (ncol(scaled) > 1L) rowSums(scaled) else as.numeric(scaled[, 1L])
  quartile <- score_quartile(total)

  scores <- data.frame(doc_id = docs$doc_id, email = docs$email,
                       resumelength = docs$resumelength,
                       check.names = FALSE, stringsAsFactors = FALSE)
  for (j in seq_along(cats)) scores[[cats[j]]] <- as.numeric(scaled[, j])
  scores[["Total Score"]] <- as.numeric(total)
  scores[["quartile"]] <- quartile
  scores <- scores[order(-scores[["Total Score"]]), , drop = FALSE]
  rownames(scores) <- NULL

  prop <- data.frame(doc_id = docs$doc_id, email = docs$email,
                     check.names = FALSE, stringsAsFactors = FALSE)
  for (j in seq_along(cats)) prop[[cats[j]]] <- as.numeric(proportion[, j])

  list(scores = scores, proportion = prop)
}

score_quartile <- function(total) {
  if (!length(total)) return(integer(0))
  q <- stats::quantile(total, c(0, .25, .5, .75, 1), names = FALSE)
  ifelse(total > q[4L], 4L,
         ifelse(total > q[3L], 3L,
                ifelse(total > q[2L], 2L, 1L)))
}

## Attach the applicant columns from the names sheet and put the identifying
## columns first.
attach_applicant_info <- function(df, name_table) {
  email_col <- "Applicant Email Address"
  nt <- name_table
  if (!email_col %in% names(nt)) die("names sheet has no '%s' column", email_col)
  nt[[email_col]] <- tolower(trimws(as.character(nt[[email_col]])))
  nt <- nt[!duplicated(nt[[email_col]]), , drop = FALSE]
  ## avoid an email/email.x collision if the sheet happens to carry that name
  nt <- nt[, setdiff(names(nt), "email"), drop = FALSE]
  out <- merge(df, nt, by.x = "email", by.y = email_col, all.x = TRUE, sort = FALSE)

  lead <- intersect(c("Applicant First Name", "Applicant Middle Name",
                      "Applicant Last Name"), names(out))
  ord <- c(lead, "email", setdiff(names(out), c(lead, "email", "doc_id")))
  out <- out[, ord, drop = FALSE]
  if ("Total Score" %in% names(out)) out <- out[order(-out[["Total Score"]]), , drop = FALSE]
  rownames(out) <- NULL
  out
}

## Detailed per keyword table (the "Detailed Frequency" sheet).
detailed_table <- function(joined, name_table) {
  if (!nrow(joined)) return(joined)
  keep <- c("email", "resumelength", "category", "keyword", "Freq", "Freq_binary",
            "score_adjustment", "ratio", "Freq_normalized", "wordcount")
  d <- joined[, intersect(keep, names(joined)), drop = FALSE]
  names(d)[names(d) == "keyword"] <- "keywords"
  attach_applicant_info(d, name_table)
}

## Keywords matched per candidate and category, collapsed into one cell -- used
## for the chart tooltips in the app, here for the CSV and the chart subtitle.
matched_keywords_table <- function(joined) {
  if (!nrow(joined)) {
    return(data.frame(email = character(), category = character(),
                      keywords_matched = character(), stringsAsFactors = FALSE))
  }
  key <- paste(joined$email, joined$category, sep = "\r")
  agg <- tapply(joined$keyword, key, function(z) paste(sort(unique(z)), collapse = "; "))
  parts <- do.call(rbind, strsplit(names(agg), "\r", fixed = TRUE))
  data.frame(email = parts[, 1L], category = parts[, 2L],
             keywords_matched = as.character(agg), stringsAsFactors = FALSE)
}
