## ---------------------------------------------------------------------------
## 02_clean.R -- text normalisation (port of clean.R / corpus.R)
##
## Default: current consolidated cleaner.
## Optional: pass --legacy-clean to reproduce the earlier clean.R cleaning
## path used before character-count-based "wordcount" was calculated.
##
## Example:
##   Rscript acr_cli.R ... --legacy-clean
## ---------------------------------------------------------------------------

## CLI / programmatic mode selection -----------------------------------------
##
## 02_clean.R reads the raw Rscript arguments directly, so existing calls to
## clean_pdf_text() and clean_for_bow() do not need to change. Tests and other
## R callers can also enable the same mode with:
##
##   options(acr.legacy_clean = TRUE)
##
## A strict argument parser may remove this switch before validating the rest
## of its arguments by calling strip_cleaning_cli_args(args).
legacy_clean_enabled <- function(args = commandArgs(trailingOnly = TRUE)) {
  isTRUE(getOption("acr.legacy_clean", FALSE)) ||
    any(args == "--legacy-clean")
}

strip_cleaning_cli_args <- function(args) {
  args[args != "--legacy-clean"]
}

cleaning_mode <- function(args = commandArgs(trailingOnly = TRUE)) {
  if (legacy_clean_enabled(args)) "legacy" else "current"
}

## Current cleaning functions ------------------------------------------------

.clean_pdf_text_current <- function(pages) {
  text <- tolower(pages)
  text <- gsub("[\n\t]", " ", text)
  text <- gsub("[[:blank:]]+", " ", text)
  text <- gsub(",", " ", text, fixed = TRUE)
  text <- gsub("-", " ", text, fixed = TRUE)

  numbers <- gsub(
    "(?<=[[:digit:]])[[:blank:]](?=[[:digit:]])",
    "",
    text,
    perl = TRUE
  )
  numbers <- gsub("[[:punct:]]", "", numbers)
  numbers <- gsub("[[:blank:]]", "", numbers)

  flat <- gsub("[[:blank:]]+", " ", text)

  list(text = text, numbers = numbers, flat = flat)
}

## Page text prepared for bag-of-words counting. This folds together the
## legacy clean_ngrams() and create_clean_corpus() stages: the same current
## transformation is applied to the keyword list, so both sides agree.
.clean_for_bow_current <- function(x) {
  x <- tolower(x)
  x <- gsub("\\\\n|\\\\r|\\\\t", " ", x)       # literal backslash codes
  x <- gsub("[\n\r\t]", " ", x)
  x <- gsub('"', " ", x, fixed = TRUE)
  x <- gsub("(", " ", x, fixed = TRUE)
  x <- gsub(")", " ", x, fixed = TRUE)
  x <- gsub("'", "", x, fixed = TRUE)              # don't split contractions
  x <- gsub("-", "", x, fixed = TRUE)              # e-mail -> email
  x <- gsub("[^0-9a-z+#&/ ]", " ", x)              # keep c++, c#, r&d, and/or
  x <- gsub("[[:blank:]]+", " ", x)
  trimws(x)
}

## Legacy cleaning compatibility chunk --------------------------------------
##
## These two functions are a base-R port of the former clean.R functions.
## In particular, the legacy BOW cleaner:
##   * changes hyphens, periods, and slashes to spaces;
##   * removes Unicode "Other Symbol" characters such as bullets;
##   * does not apply the current broad character whitelist; and
##   * does not trim leading or trailing blanks.
##
## Those details preserve the earlier character-count denominator when the
## downstream code calculates nchar()/str_count() immediately after cleaning.
.clean_pdf_text_legacy <- function(pages) {
  text <- tolower(pages)
  text <- gsub("\n", " ", text, fixed = TRUE)
  text <- gsub("\t", " ", text, fixed = TRUE)
  text <- gsub("[[:blank:]]+", " ", text)
  text <- gsub(",", " ", text, fixed = TRUE)
  text <- gsub("-", " ", text, fixed = TRUE)

  numbers <- gsub(
    "(?<=[[:digit:]])[[:blank:]](?=[[:digit:]])",
    "",
    text,
    perl = TRUE
  )
  numbers <- gsub("[[:punct:]]", "", numbers)
  numbers <- gsub("[[:blank:]]", "", numbers)

  flat <- gsub("[[:blank:]]+", " ", text)

  ## Named elements retain compatibility with the command-line pipeline even
  ## though the original clean.R returned the same values as an unnamed list.
  list(text = text, numbers = numbers, flat = flat)
}

.clean_for_bow_legacy <- function(x) {
  x <- tolower(x)
  x <- gsub("\n", " ", x, fixed = TRUE)             # actual newline
  x <- gsub("\\n", " ", x, fixed = TRUE)           # literal backslash-n
  x <- gsub('"', " ", x, fixed = TRUE)
  x <- gsub("\t", " ", x, fixed = TRUE)
  x <- gsub("\\p{So}", " ", x, perl = TRUE)       # bullets/other symbols
  x <- gsub(",", " ", x, fixed = TRUE)
  x <- gsub("-", " ", x, fixed = TRUE)
  x <- gsub(".", " ", x, fixed = TRUE)
  x <- gsub("/", " ", x, fixed = TRUE)
  gsub("[[:blank:]]+", " ", x)
}

## Public dispatchers ---------------------------------------------------------
## Existing callers continue to use the original function names. The optional
## legacy argument is useful for unit tests; normal CLI use relies on the flag.
clean_pdf_text <- function(pages, legacy = legacy_clean_enabled()) {
  if (isTRUE(legacy)) {
    .clean_pdf_text_legacy(pages)
  } else {
    .clean_pdf_text_current(pages)
  }
}

clean_for_bow <- function(x, legacy = legacy_clean_enabled()) {
  if (isTRUE(legacy)) {
    .clean_for_bow_legacy(x)
  } else {
    .clean_for_bow_current(x)
  }
}
