## ---------------------------------------------------------------------------
## 00_utils.R -- logging, small helpers, input discovery
## Part of the ACR command-line application (R 4.6)
## ---------------------------------------------------------------------------

ACR <- new.env(parent = emptyenv())
ACR$verbosity <- 1L   # 0 quiet, 1 normal, 2 verbose

`%||%` <- function(a, b) {
  if (is.null(a)) return(b)
  if (length(a) == 0L) return(b)
  if (length(a) == 1L && is.na(a)) return(b)
  a
}

acr_set_verbosity <- function(v) assign("verbosity", as.integer(v), envir = ACR)

msg <- function(fmt, ..., level = 1L) {
  if (ACR$verbosity >= level) {
    cat(sprintf("%s  %s\n", format(Sys.time(), "%H:%M:%S"), sprintf(fmt, ...)))
    utils::flush.console()
  }
  invisible(NULL)
}

acr_warn <- function(fmt, ...) {
  cat(sprintf("WARNING  %s\n", sprintf(fmt, ...)))
  utils::flush.console()
  invisible(NULL)
}

die <- function(fmt, ...) stop(sprintf(fmt, ...), call. = FALSE)

## A stopwatch that prints elapsed wall time for a stage ---------------------
with_timer <- function(label, expr) {
  t0 <- Sys.time()
  out <- force(expr)
  msg("%s finished in %s", label,
      format(round(difftime(Sys.time(), t0, units = "secs"), 1)))
  out
}

## Directories --------------------------------------------------------------
ensure_dir <- function(path) {
  if (!dir.exists(path)) dir.create(path, recursive = TRUE, showWarnings = FALSE)
  invisible(path)
}

## Data frame helpers -------------------------------------------------------

## Drop columns that are entirely NA (the CLI equivalent of the Shiny app's
## remove_na_columns(); keeps output tables readable).
remove_na_columns <- function(df) {
  if (is.null(df) || ncol(df) == 0L) return(df)
  keep <- vapply(df, function(col) any(!is.na(col)), logical(1))
  df[, keep, drop = FALSE]
}

## lead() without dplyr
lead_vec <- function(x, default = NA) c(x[-1L], default)

write_csv_safe <- function(df, path) {
  utils::write.csv(df, path, row.names = FALSE, na = "")
  msg("wrote %s (%d rows)", path, nrow(df), level = 2L)
  invisible(path)
}

## Regex helpers ------------------------------------------------------------

## Escape a literal string for use inside a PCRE pattern.
rx_escape <- function(x) gsub("([.\\\\|()\\[\\]{}^$*+?])", "\\\\\\1", x, perl = TRUE)

## Whole-token pattern: the keyword/name may not be glued to another
## alphanumeric character. Trailing "+"/"#" (c++, c#) survive because the
## look-ahead only rejects alphanumerics.
rx_token <- function(x) paste0("(?<![[:alnum:]])", rx_escape(x), "(?![[:alnum:]])")

## Count matches of a literal token inside a text vector of length 1.
count_token <- function(text, token) {
  m <- gregexpr(rx_token(token), text, perl = TRUE)[[1L]]
  if (length(m) == 1L && m[1L] == -1L) 0L else length(m)
}

has_token <- function(text, token) {
  regexpr(rx_token(token), text, perl = TRUE)[1L] != -1L
}

## Packages ----------------------------------------------------------------
have_pkg <- function(p) isTRUE(requireNamespace(p, quietly = TRUE))

require_pkgs <- function(pkgs, what) {
  missing <- pkgs[!vapply(pkgs, have_pkg, logical(1))]
  if (length(missing)) {
    die(paste0("missing R package(s) for %s: %s\n",
               "  install with: install.packages(c(%s))"),
        what, paste(missing, collapse = ", "),
        paste(sprintf('"%s"', missing), collapse = ", "))
  }
  invisible(TRUE)
}

## Input discovery ---------------------------------------------------------

## Find the single most plausible input file in the project folder.
## patterns are matched case-insensitively against the file name, in order;
## the first pattern that matches exactly one file wins.
discover_input <- function(dir, exts, patterns, label) {
  files <- list.files(dir, full.names = TRUE, recursive = FALSE)
  files <- files[!dir.exists(files)]
  files <- files[tolower(tools::file_ext(files)) %in% exts]
  if (!length(files)) return(NA_character_)
  for (p in patterns) {
    hit <- files[grepl(p, basename(files), ignore.case = TRUE)]
    if (length(hit) == 1L) return(hit[1L])
    if (length(hit) > 1L) {
      acr_warn("several candidate %s files in %s (%s); using %s -- pass the flag to choose",
               label, dir, paste(basename(hit), collapse = ", "), basename(hit[1L]))
      return(hit[1L])
    }
  }
  if (length(files) == 1L) return(files[1L])
  acr_warn("could not pick a %s file automatically in %s (%s)",
           label, dir, paste(basename(files), collapse = ", "))
  NA_character_
}

## Fingerprint of an input file, used to decide whether a cache is still valid
file_fingerprint <- function(path) {
  info <- file.info(path)
  list(path = normalizePath(path, winslash = "/", mustWork = FALSE),
       size = as.numeric(info$size),
       mtime = as.numeric(info$mtime))
}

same_fingerprint <- function(a, b) {
  if (is.null(a) || is.null(b)) return(FALSE)
  isTRUE(a$size == b$size) && isTRUE(abs(a$mtime - b$mtime) < 1) &&
    isTRUE(basename(a$path) == basename(b$path))
}

## Run fun over x, in parallel when cores > 1. Helper functions that fun calls
## must be named in `export`; they are copied to the workers, because a closure
## whose environment is the global environment does not carry its globals along.
par_lapply <- function(x, fun, cores = 1L, export = character()) {
  cores <- max(1L, as.integer(cores))
  if (cores == 1L || length(x) <= 1L) return(lapply(x, fun))
  cl <- parallel::makeCluster(min(cores, length(x)))
  on.exit(parallel::stopCluster(cl), add = TRUE)
  if (length(export)) parallel::clusterExport(cl, export, envir = globalenv())
  parallel::parLapply(cl, x, fun)
}

decide_cores <- function(requested, n_items, max_cores = 40L) {
  avail <- tryCatch(parallel::detectCores(), error = function(e) 1L)
  if (is.na(avail)) avail <- 1L
  n <- if (is.null(requested) || is.na(requested)) max(1L, avail - 1L) else as.integer(requested)
  n <- min(n, max_cores, max(1L, avail), max(1L, n_items))
  max(1L, n)
}
