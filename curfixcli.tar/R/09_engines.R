## ---------------------------------------------------------------------------
## 09_engines.R -- keyword counters, engine comparison, frequency validation
## Every counter returns: doc_id, email, keyword (clean_for_bow form), Freq, Freq_binary
## ---------------------------------------------------------------------------

empty_counts <- function() data.frame(doc_id = integer(), email = character(),
  keyword = character(), Freq = integer(), Freq_binary = integer(), stringsAsFactors = FALSE)

mat_to_counts <- function(mat, docs, terms) {
  nz <- which(mat > 0, arr.ind = TRUE)
  if (!nrow(nz)) return(empty_counts())
  res <- data.frame(doc_id = docs$doc_id[nz[, 1L]], email = docs$email[nz[, 1L]],
                    keyword = terms[nz[, 2L]], Freq = as.integer(mat[nz]),
                    Freq_binary = 1L, stringsAsFactors = FALSE)
  res <- res[order(res$doc_id, res$keyword), , drop = FALSE]
  rownames(res) <- NULL
  res
}

## quanteda counter (the old --legacy). Unigrams plus 2..n-grams, so a unigram
## inside a phrase still counts, as in the regex counter and tokenize.R.
## (v10's tokens_compound(join = FALSE) consumed those tokens: undercount.)
count_keywords_quanteda <- function(docs, keywords, cores = 1L) {
  require_pkgs("quanteda", "the quanteda bag of words")
  quanteda::quanteda_options(threads = max(1L, as.integer(cores)))
  terms <- unique(keywords$keyword)
  if (!length(terms) || !nrow(docs)) return(empty_counts())
  toks <- quanteda::tokens(docs$text, what = "fastestword")
  mat <- as.matrix(quanteda::dfm_match(quanteda::dfm(toks, tolower = FALSE), terms))
  nmax <- max(lengths(strsplit(terms, " ", fixed = TRUE)))
  if (nmax > 1L) {
    ng <- quanteda::tokens_ngrams(toks, n = 2:nmax, concatenator = " ")
    mat <- mat + as.matrix(quanteda::dfm_match(quanteda::dfm(ng, tolower = FALSE), terms))
  }
  mat_to_counts(mat, docs, terms)
}

## ---- faithful port of the Shiny pipeline (bow.R + corpus.R + tokenize.R) ----
load_keywords_raw <- function(path) {
  dt <- read_table_dt(path)
  names(dt) <- tolower(trimws(names(dt)))
  dt <- unique(dt[, .(category = trimws(category), raw = tolower(keyword))])
  dt[, keyword := clean_for_bow(raw)][]          # key used by the other engines
}

clean_original <- function(x) {
  x <- gsub("\uFFFD", "", x, fixed = TRUE)          # bow.R
  x <- iconv(x, "UTF-8", "ASCII", sub = "")
  x <- gsub("\\(", " ", x)                          # corpus.R, same order
  x <- gsub("\\\\n", " ", x); x <- gsub("\\\n", " ", x)
  x <- gsub("\\\\r", " ", x); x <- gsub("\\\\t", " ", x)
  x <- gsub("-", " ", x)
  x <- gsub("'", "", x)
  x <- gsub("[^0123456789a-zA-Z++#&/ ]", "", x)     # deleted, NOT spaced
  x <- tolower(x)
  gsub("[[:space:]]+", " ", x)                      # tm::stripWhitespace
}

## find_optimum_function(): unbounded regex per raw keyword, ties -> pdf_text
choose_extraction_original <- function(pages, raw_kw) {
  if (is.null(pages$ocr)) return(pages$text)
  n <- function(t) sum(vapply(raw_kw, function(k)
    isTRUE(tryCatch(grepl(k, t, perl = TRUE), error = function(e) FALSE)), logical(1)))
  ht <- vapply(pages$text, n, integer(1)); ho <- vapply(pages$ocr, n, integer(1))
  ifelse(ht >= ho, pages$text, pages$ocr)
}

count_keywords_original <- function(raw_docs, kw_raw) {
  require_pkgs("quanteda", "the original-engine bag of words")
  raw_terms <- unique(kw_raw$raw)
  toks <- quanteda::tokens(clean_original(raw_docs$text), remove_numbers = TRUE,
                           remove_punct = TRUE, remove_symbols = TRUE,
                           remove_separators = TRUE)
  toks <- quanteda::tokens_remove(toks, quanteda::stopwords("en"))
  m1 <- as.matrix(quanteda::dfm_match(quanteda::dfm(toks), raw_terms))
  ng <- quanteda::tokens_ngrams(toks, n = 2:4, concatenator = " ")
  m2 <- as.matrix(quanteda::dfm_match(quanteda::dfm(ng), raw_terms))
  res <- mat_to_counts(m1 + m2, raw_docs, raw_terms)
  res$keyword <- kw_raw$keyword[match(res$keyword, kw_raw$raw)]   # align keys
  res
}

## ---- comparison of unweighted frequencies ----
compare_engines <- function(results, keywords, rpt) {
  dts <- lapply(names(results), function(nm) {
    d <- data.table::as.data.table(results[[nm]])[, .(Freq = sum(Freq)), by = .(email, keyword)]
    data.table::setnames(d, "Freq", nm); d })
  m <- Reduce(function(a, b) merge(a, b, by = c("email", "keyword"), all = TRUE), dts)
  eng <- names(results)
  for (e in eng) data.table::set(m, which(is.na(m[[e]])), e, 0L)
  m[, identical := apply(.SD, 1L, function(r) length(unique(r)) == 1L), .SDcols = eng]
  kw <- unique(data.table::as.data.table(keywords)[, .(keyword, category)])
  m <- merge(m, kw, by = "keyword", allow.cartesian = TRUE)
  data.table::fwrite(m[order(email, category, keyword)], rpt("engine_comparison_keywords.csv"))
  bycat <- m[, lapply(.SD, sum), by = .(email, category), .SDcols = eng]
  bycat[, identical := apply(.SD, 1L, function(r) length(unique(r)) == 1L), .SDcols = eng]
  data.table::fwrite(bycat, rpt("engine_comparison_categories.csv"))
  msg("engine comparison: %d/%d keyword rows and %d/%d candidate x category rows identical",
      sum(m$identical), nrow(m), sum(bycat$identical), nrow(bycat))
  invisible(m)
}

## ---- --test-input-frequency ----
## Accepts detailed_frequency.csv or any csv/xlsx with an email column
## (email | Applicant Email Address), keyword|keywords and Freq.
validate_frequency <- function(counts, path, rpt) {
  exp <- read_table_dt(path)
  nm <- names(exp)
  ec <- intersect(c("email", "Applicant Email Address"), nm)[1L]
  kc <- intersect(c("keyword", "keywords"), nm)[1L]
  if (is.na(ec) || is.na(kc) || !"Freq" %in% nm)
    die("%s needs email, keyword(s) and Freq columns", basename(path))
  exp <- exp[, .(email = tolower(trimws(get(ec))), keyword = clean_for_bow(get(kc)),
                 expected = as.integer(Freq))][, .(expected = sum(expected)), by = .(email, keyword)]
  got <- data.table::as.data.table(counts)[email %in% exp$email,
                                           .(got = sum(Freq)), by = .(email, keyword)]
  m <- merge(exp, got, by = c("email", "keyword"), all = TRUE)
  m[is.na(expected), expected := 0L][is.na(got), got := 0L][, ok := expected == got]
  data.table::fwrite(m[order(ok, email, keyword)], rpt("frequency_validation.csv"))
  bad <- m[ok == FALSE]
  if (nrow(bad)) {
    acr_warn("frequency validation FAILED: %d of %d rows differ (see frequency_validation.csv)",
             nrow(bad), nrow(m))
    print_df(as.data.frame(bad), 10L)
  } else msg("frequency validation passed: %d rows identical", nrow(m))
  !nrow(bad)
}