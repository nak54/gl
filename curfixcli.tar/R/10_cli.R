## ---------------------------------------------------------------------------
## 10_cli.R -- CLI helpers carried over unchanged from acr_v10.R
## (parallel, Tesseract threads, folder/combined extraction, linking, paths)
## Sourced last, so tesseract_available() here overrides 01_extract.R.
## ---------------------------------------------------------------------------

resolve_cores <- function(requested) {
  avail <- tryCatch(parallel::detectCores(logical = TRUE), error = function(e) 1L)
  if (is.na(avail) || avail < 1L) avail <- 1L
  n <- if (is.null(requested) || is.na(requested)) avail - 1L else as.integer(requested)
  if (n > avail) acr_warn("-c %d requested but only %d core(s) available; using %d",
                          n, avail, avail)
  max(1L, min(n, avail))
}

par_map <- function(x, fun, cores = 1L, preschedule = TRUE) {
  cores <- min(max(1L, as.integer(cores)), length(x))
  if (cores <= 1L) return(lapply(x, fun))
  if (.Platform$OS.type == "unix") {
    res <- parallel::mclapply(x, fun, mc.cores = cores, mc.preschedule = preschedule)
    bad <- vapply(res, function(r) is.null(r) || inherits(r, "try-error"), logical(1))
    if (any(bad)) {
      first <- res[[which(bad)[1L]]]
      die("%d parallel task(s) failed%s", sum(bad),
          if (inherits(first, "try-error")) paste0(": ", trimws(first)) else
            " (worker died -- try fewer cores with -c)")
    }
    return(res)
  }
  cl <- parallel::makeCluster(cores)
  on.exit(parallel::stopCluster(cl), add = TRUE)
  parallel::clusterExport(cl, ls(globalenv()), envir = globalenv())
  parallel::parLapply(cl, x, fun)
}

tesseract_available <- function() {
  nzchar(system.file(package = "tesseract")) || nzchar(Sys.which("tesseract"))
}

tesseract_plan <- function(cores, n_pages) {
  cores <- max(1L, as.integer(cores))
  workers <- max(1L, min(cores, n_pages))
  list(workers = workers, threads = max(1L, cores %/% workers))
}

set_tesseract_threads <- function(threads) {
  vars <- c("OMP_THREAD_LIMIT", "OMP_NUM_THREADS")
  old <- Sys.getenv(vars, unset = NA)
  do.call(Sys.setenv, stats::setNames(as.list(rep(as.character(threads), 2L)), vars))
  function() {
    for (v in vars) {
      if (is.na(old[[v]])) Sys.unsetenv(v) else
        do.call(Sys.setenv, stats::setNames(list(old[[v]]), v))
    }
  }
}

list_resume_pdfs <- function(dir) {
  f <- list.files(dir, pattern = "\\.pdf$", ignore.case = TRUE,
                  full.names = TRUE, recursive = FALSE)
  if (!length(f)) die("no PDF files found in %s", dir)
  msg("found %d resume PDF(s) in %s", length(f), dir)
  sort(f)
}

## Works for a folder (many PDFs) and a combined PDF (a vector of length 1).
extract_folder <- function(pdfs, dpi = 300L, cores = 1L, ocr_mode = "auto",
                           min_chars = 100L) {
  per_file <- par_map(pdfs, function(p) {
    n <- tryCatch(as.integer(pdftools::pdf_info(p)$pages), error = function(e) 0L)
    if (is.na(n) || n < 1L) return(list(n = 0L, text = character(0), err = TRUE))
    t <- tryCatch(tolower(pdftools::pdf_text(p)), error = function(e) character(0))
    length(t) <- n
    t[is.na(t)] <- ""
    list(n = n, text = t, err = FALSE)
  }, cores = cores)
  bad <- vapply(per_file, `[[`, logical(1), "err")
  if (any(bad)) acr_warn("cannot read %d PDF(s): %s", sum(bad),
                         paste(basename(pdfs[bad]), collapse = ", "))
  pdfs <- pdfs[!bad]; per_file <- per_file[!bad]
  if (!length(pdfs)) die("none of the PDFs could be read")
  n <- vapply(per_file, `[[`, integer(1), "n")
  text <- unlist(lapply(per_file, `[[`, "text"), use.names = FALSE)

  end <- cumsum(n)
  files <- data.frame(file = pdfs, startPage = end - n + 1L, endPage = end,
                      stringsAsFactors = FALSE)
  msg("extracted embedded text: %d file(s), %d page(s) on %d core(s)",
      length(pdfs), sum(n), cores)

  jobs <- do.call(rbind, lapply(seq_along(pdfs), function(i)
    data.frame(file = pdfs[i], page = seq_len(n[i]), k = i, stringsAsFactors = FALSE)))
  jobs$chars <- nchar(gsub("[[:space:]]+", "", text))
  jobs$ocr <- switch(ocr_mode, all = rep(TRUE, nrow(jobs)),
                     none = rep(FALSE, nrow(jobs)), jobs$chars < min_chars)
  jobs$reason <- ifelse(!jobs$ocr, "embedded text",
                        ifelse(ocr_mode == "all", "--ocr-all",
                               sprintf("< %d chars", min_chars)))

  ocr <- NULL
  ocr_plan <- list(workers = 0L, threads = 0L)
  if (ocr_mode == "none") {
    msg("--no-ocr given: embedded text only")
  } else if (!any(jobs$ocr)) {
    msg("every page has embedded text; OCR not needed")
  } else if (!tesseract_available()) {
    acr_warn("%d page(s) look scanned but no Tesseract is available; they will score low",
             sum(jobs$ocr))
    jobs$reason[jobs$ocr] <- "needed OCR, tesseract missing"
    jobs$ocr <- FALSE
  } else {
    sel <- which(jobs$ocr)
    ocr_plan <- tesseract_plan(cores, length(sel))
    restore <- set_tesseract_threads(ocr_plan$threads)
    on.exit(restore(), add = TRUE)
    msg("OCR needed on %d of %d page(s): %d worker(s) x %d tesseract thread(s)",
        length(sel), nrow(jobs), ocr_plan$workers, ocr_plan$threads)
    ocr <- rep("", nrow(jobs))
    ocr[sel] <- with_timer("OCR", ocr_pages(jobs[sel, , drop = FALSE], dpi,
                                            ocr_plan$workers))
  }

  page_log <- data.frame(file = basename(jobs$file), page = jobs$page,
                         embedded_chars = jobs$chars, ocr = jobs$ocr,
                         reason = jobs$reason, stringsAsFactors = FALSE)
  list(text = text, ocr = ocr, n_pages = sum(n), files = files,
       page_log = page_log, ocr_plan = ocr_plan)
}

ocr_pages <- function(jobs, dpi, workers) {
  png_dir <- tempfile("acr_png_")
  ensure_dir(png_dir)
  on.exit(unlink(png_dir, recursive = TRUE, force = TRUE), add = TRUE)
  jobs$png <- file.path(png_dir, sprintf("f%04d_p%04d.png", jobs$k, jobs$page))
  txt <- par_map(seq_len(nrow(jobs)), function(r) {
    j <- jobs[r, ]
    tryCatch({
      png <- pdftools::pdf_convert(j$file, format = "png", pages = j$page, dpi = dpi,
                                   filenames = j$png, verbose = FALSE)
      res <- ocr_png(png, dpi = dpi)
      unlink(png)
      paste(res, collapse = " ")
    }, error = function(e) "")
  }, cores = workers, preschedule = FALSE)
  tolower(vapply(txt, function(z) paste(z, collapse = " "), character(1),
                 USE.NAMES = FALSE))
}

## Folder mode: link each file to an applicant.
match_files <- function(pages, people, cores = 1L) {
  files <- pages$files
  stems <- tolower(tools::file_path_sans_ext(basename(files$file)))
  safe_email <- tolower(gsub("[^A-Za-z0-9._@+-]", "_", people$email))
  safe_email[is.na(safe_email)] <- ""
  layers <- list(clean_pdf_text(pages$text))
  if (!is.null(pages$ocr)) layers[[2L]] <- clean_pdf_text(pages$ocr)

  link_one <- function(i) {
    idx <- seq.int(files$startPage[i], files$endPage[i])
    who <- NA_integer_; how <- NA_character_
    e <- which(nzchar(safe_email) &
                 vapply(safe_email, function(s) grepl(s, stems[i], fixed = TRUE),
                        logical(1), USE.NAMES = FALSE))
    if (length(e)) { who <- e[which.max(nchar(safe_email[e]))]; how <- "filename_email" }
    if (is.na(who)) {
      stem_words <- gsub("[^a-z]+", " ", stems[i])
      nm <- which(vapply(seq_len(nrow(people)), function(x)
        nzchar(people$firstNameSearch[x]) && nzchar(people$lastNameSearch[x]) &&
          has_token(stem_words, people$firstNameSearch[x]) &&
          has_token(stem_words, people$lastNameSearch[x]), logical(1)))
      if (length(nm) == 1L) { who <- nm; how <- "filename_name" }
    }
    for (L in layers) {
      if (!is.na(who)) break
      hit <- search_names(L$text[idx[1L]], people)
      if (nrow(hit)) { who <- match(hit$email[1L], people$email); how <- "name"; break }
      em <- search_field(paste(L$flat[idx], collapse = " "), people, "email")
      if (nrow(em)) { who <- match(em$email[1L], people$email); how <- "email"; break }
      ph <- search_field(paste(L$numbers[idx], collapse = ""), people, "phone")
      if (nrow(ph)) { who <- match(ph$email[1L], people$email); how <- "phone"; break }
    }
    if (is.na(who)) {
      data.frame(email = stems[i], firstName = "", lastName = "",
                 method = "unlinked", stringsAsFactors = FALSE)
    } else {
      data.frame(email = people$email[who], firstName = people$firstName[who],
                 lastName = people$lastName[who], method = how, stringsAsFactors = FALSE)
    }
  }
  rows <- par_map(seq_len(nrow(files)), link_one, cores = cores)
  cand <- cbind(file = basename(files$file), do.call(rbind, rows),
                startPage = files$startPage, endPage = files$endPage,
                stringsAsFactors = FALSE)
  cand$resumeLength <- cand$endPage - cand$startPage + 1L
  dup <- unique(cand$email[duplicated(cand$email)])
  if (length(dup)) acr_warn("several files map to the same applicant: %s",
                            paste(dup, collapse = ", "))
  cand
}

count_keywords_par <- function(docs, keywords, cores = 1L) {
  if (cores <= 1L || nrow(docs) <= 1L) return(count_keywords(docs, keywords))
  chunks <- split(seq_len(nrow(docs)),
                  cut(seq_len(nrow(docs)), min(cores, nrow(docs)), labels = FALSE))
  parts <- par_map(chunks, function(ix) {
    ACR$verbosity <- 0L
    count_keywords(docs[ix, , drop = FALSE], keywords)
  }, cores = cores)
  res <- do.call(rbind, parts)
  rownames(res) <- NULL
  msg("bag of words: %d keyword hit(s) across %d candidate(s) on %d core(s)",
      nrow(res), length(unique(res$doc_id)), cores)
  res
}

## Paths and printing --------------------------------------------------------
is_absolute <- function(p) grepl("^(/|~|[A-Za-z]:[/\\\\])", p)

resolve_path <- function(p, dir) {
  if (is.na(p) || is_absolute(p) || file.exists(p)) return(p)
  alt <- file.path(dir, p)
  if (file.exists(alt)) alt else p
}

prepare_output <- function(out) {
  if (is.na(out) || !nzchar(trimws(out))) die("-o/--out needs a folder name")
  out <- path.expand(trimws(out))
  if (file.exists(out) && !dir.exists(out)) die("-o/--out points at a file: %s", out)
  for (p in c(out, file.path(out, "reports"), file.path(out, "viz"))) {
    ensure_dir(p)
    if (!dir.exists(p)) die("could not create output folder: %s", p)
  }
  if (file.access(out, 2L) != 0L) die("output folder is not writable: %s", out)
  root <- normalizePath(out, winslash = "/", mustWork = TRUE)
  list(root = root, reports = file.path(root, "reports"), viz = file.path(root, "viz"))
}

print_df <- function(df, n = 25L) {
  if (is.null(df) || !nrow(df)) return(invisible(NULL))
  print(utils::head(df, n), row.names = FALSE)
  if (nrow(df) > n) cat(sprintf("... %d more row(s)\n", nrow(df) - n))
  invisible(NULL)
}