# repos <- c(WORK = "http://10.207.92.200/R.new/")
# options(repos = repos)

# Loading libraries
packages <- c('shiny', 'DT', 'readxl', 'shinythemes',
              'pdftools',
              'stringr',
              'parallel','doParallel','tesseract','dplyr','utils','gsubfn',
              'openxlsx','writexl','reshape2','ggplot2','tm','quanteda',
              'stringi', 'plotly', 'jsonlite', 'wesanderson',
              #'sf', 
              'ggthemes','bslib','shinydashboard',
              'markdown', 'fs', 'zip', 'R.utils', 'markdown')

# Installing any of the above packages that need to be installed
new.packages <- packages[!(packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
# if(length(new.packages)) install.packages(new.packages, repos = sprintf(
#   "https://%s:%s@vp2txappndimr01.ds.irsnet.gov/nexus/repository/public-R/",
#   Sys.getenv("NEXUS_USER"),
#   Sys.getenv("NEXUS_PASSWORD")
# ))

# loading all packages
lapply(packages, library, character.only=TRUE)

# navbar page allows for creating multi-page dashboards
ui <-
  dashboardPage(
    skin = "blue",

    dashboardHeader(
      title = "Automated Candidate Review App",
      titleWidth = 350,
      
      # Header Notifications ----
      dropdownMenuOutput("notificationMenu")
      
    ),
    
    # Sidebar ----
    dashboardSidebar(sidebarMenu(id = "tabs",
                                 # style = "position: fixed; overflow: visible;",
                                 tags$script(HTML("$('body').addClass('fixed');")),
      menuItem(
        HTML("&nbsp; &nbsp; Instructions"), 
         tabName = "instructions", 
         icon = icon("info")
         ),
      menuItem(
        HTML(" &nbsp; Upload Resumes"),
        tabName = "step1",
        icon = icon("upload")
      ),
      menuItem(
        HTML("&nbsp; Score Resumes"),
        tabName = "step2",
        icon = icon("star")
      ),
      menuItem(
        HTML("&nbsp; Visualize"),
        tabName = "visualization",
        icon = icon("chart-line")
      ),
      menuItem(
        HTML("&nbsp; About"),
        tabName = "about",
        icon = icon("question")
      ),
      menuItem(
        HTML("&nbsp;Contact the Developers"),
        tabName = "contact",
        icon = icon("comment")
      )
    )),
    dashboardBody(
      tags$script('$(".sidebar-menu a[data-toggle=\'tab\']").click(function(){window.scrollTo({top: 0});})'),
      
      tabItems(
      
      # Tabs ----
      
      ## Instructions ----
      tabItem(
        tabName = "instructions",
        
        fluidRow(
          box(
          width=12,
            
        HTML(markdown::markdownToHTML(file='md/instructions.md', fragment.only=TRUE))
      )
      ),
      
      fluidRow(
      box(
        solidHeader=TRUE,
        status="primary",
        width=12,
        title = "Step 1. Upload Resumes and Names Spreadsheet",
        HTML(markdown::markdownToHTML(file='md/upload.md', fragment.only=TRUE))
      ),
      
      ),
      
      fluidRow(
        
        box(
          solidHeader=TRUE,
          status="primary",
          width=12,
        title = "Step 2. Upload Keywords and Score Resumes",
        HTML(markdown::markdownToHTML(file='md/score.md', fragment.only=TRUE))
      )
      ),
      
      fluidRow(
        box(
          solidHeader=TRUE,
          status="primary",
          width=12, 
          title="Step 3: Visualization",
          HTML(markdown::markdownToHTML(file='md/visualize.md', fragment.only=TRUE))
          
      ))
        
      ),
      
      ## Upload Resumes ----
      tabItem(tabName = "step1",
              
              ### Upload PDF ----
              fluidRow(
                box(
                  solidHeader=TRUE,
                  status="primary",
                  width = 12,
                  title = 'Step 1: Upload Files',
            
                  fluidRow(column(
                    width = 12,
                    
                    # Display a brows bar for the pdf file
                    fileInput(
                      "pdffile",
                      "Upload PDF file containing all resumes",
                      accept = c(".pdf")
                    ),
                    
                    # Display a brows bar for excel sheet
                    fileInput("namefile", "Upload the Names Spreadsheet", accept = c(".xls", ".xlsx")),
                    
                  ))
                  
                  
                )
              ),
              
              uiOutput('step1_names_sheet_ui'),
              
              ### Process Resumes Button ----
              fluidRow(
                box(
                  solidHeader=TRUE,
                  status="primary",
                  width = 12,
                  title='Step 2: Automatically Detect Candidates in PDF',

                uiOutput('step2_detect_candidates_button')
                )
              ),
              
              
              ### Unmatched Candidates ----
              fluidRow(
                box(
                  solidHeader=TRUE,
                  status="primary",
                  width = 12,
                  title = 'Step 3: Manually Specify Pages for Candidates Not Found in Resumes PDF',
                  
                  uiOutput('step3_candidates_not_found')

                  )
                ),
              
              fluidRow(
                box(
                  solidHeader=TRUE,
                  status="primary",
                  width=12, 
                  title= 'Step 4: Split/Download Resumes',
                  
                  uiOutput('step4_split_resumes'),
                  uiOutput('resume_download_button')
                ))
              
              ),
      
      ## Scoring Resumes ----
      tabItem(tabName = "step2",
              
              ### Upload Keywords ----
              fluidRow(
                box(
                  solidHeader=TRUE,
                  status="primary",
                  width = 12,
                  title = 'Step 1: Upload Keywords File',
                  
                  fluidRow(column(
                    width = 12,
                    
                    # Display a brows bar for the pdf file
                    fileInput("bow_file", "Upload CSV/XLSX/XLS file containing keywords and weights", accept = c(".csv", ".xlsx",".xls")),
                    
                    p("Here is a template you can download, fill out, and upload here if you don't already have this file:"),
                    downloadButton("download_keywords_example2", 
                                   "Download Keywords Template")
                    
                  ))
                )
              ),
              
              ### Keywords Table ----
              fluidRow(
                box(
                  solidHeader=TRUE,
                  status="primary",
                  width = 12,
                  title = 'Step 2: View/Change/Download Keywords and Weights',
                  
                  uiOutput('step2_score_resumes')
                  )),
              
              ### Score Resumes ----
              fluidRow(
                
                box(
                  solidHeader=TRUE,
                  status="primary",
                  width=12,
                  title= 'Step 3: Score Resumes and Download Output',

                  #### Weighting ----
                  
                  uiOutput('score_resumes_button'),
                  
                  uiOutput('no_keyword_matches'),
                  
                  uiOutput('score_weighting_buttons'),
                  
                  uiOutput('scored_tables')
                )
              ),
              
              ),
      
      ## Visualization ----
      
      tabItem(tabName = "visualization",
        
        fluidRow(
          box(
            
            solidHeader=TRUE,
            status="primary",
            width=12,
            title= 'Top Scored Resumes',
            
            h3('Top Applicant Filtering'),
            
            column(
              width=8,
              
              tags$style(type = "text/css", ".irs-grid-pol.small {height: 0px;}"),

            ### Slider ----
            uiOutput('n_applicants_slider')),
            
            # sliderInput("n_applicants", 
            #             "Number of Top Applicants to Display", 
            #             min=1, 
            #             max=35, 
            #             value = 10,
            #             step=1,
            #             # ticks=FALSE,
            #             width='90%')),

            column(
              width=2,
            ### Percentile radio
              radioButtons( 
                inputId = "applicants_percentile", 
                label = "Top Applicants, %", 
                choices = list( 
                  "10%" = 10,
                  "25%" = 25, 
                  "50%" = 50 
                ),
                inline=TRUE,
                selected=25
              )), 
            
            column(
              width=2,
            ### Perentile Numeric Input
            numericInput( 
              "applicants_percentile_numeric", 
              "Top Applicants, Custom Percentage", 
              value = 25, 
              min = 5, 
              max = 100 
            )), 
            
            ### Bar Chart ----
            column(
              width=11,
              uiOutput("blank_chart"),
              plotlyOutput("bar_chart")
            ),
            
            column(
              # align='center',
              width=1,
              
              ### Radio buttons ----
              
              #### Chart Type ----
              radioButtons( 
                inputId = "stacked_button", 
                label = "Bar Chart Type", 
                choices = list( 
                  "Plain" =  "basic", 
                  "Stacked by Category" = 'category'
                ),
                selected = "category"
            ),
            
            #### Weighting ----
            radioButtons( 
              inputId = "weighting_button", 
              label = "Keyword Weighting", 
              choices = list( 
                "Weighted" = "weighted",
                "Unweighted" =  "unweighted"
                
              ),
              # selected = "weighted" 
              selected = "unweighted"
            ),
            br(),
            
            #### Download Top Resumes Button ----
            uiOutput('download_resumes_from_slider_ui'),
            
            br(),
            
            #### Reset candidate selection Button ----
            actionButton("reset_selected_candidate_table", 
                         HTML(paste0(strwrap("Reset Candidate Selection", width=20), collapse='</br>')),
                         class= "btn-info btn-sm",
                         style = "color: white;")
            
            
          )
        )),
        
        ### Select Candidate Table ----
        fluidRow(
         box(
           solidHeader=TRUE,
          status="primary",
          width=12,
          collapsible = TRUE,
          title= 'Selected Candidate',
          uiOutput('selected_candidate_ui')
          
        )
        ),
        
        ### Map ----
        fluidRow(
          box(
            solidHeader=TRUE,
            status="primary",
            width=12,
            title= 'Applicant Map',
            plotlyOutput("candidate_map_conus",height = 800),
            column(
              width=6,
            plotlyOutput("candidate_map_ak",height = 800)),
            column(
              width=6,
              plotlyOutput("candidate_map_hi",height = 600))
          )
        )
      ),
 
 ## About Tab ----
 tabItem(
   tabName = "about",

 box(
   width=4,
   # title= 'Pre-Processing',
   icon('file-pen', class = "fa", style = "font-size: 100px; display: flex; justify-content: center;"),
   
   HTML(markdown::markdownToHTML(text=c('<center>',
                                        '<h2 style="text-align:center;">Pre-Processing</h2>',
                                        '</center>',
                                        '<center>',
                                        'The initial processing steps include the attempted extraction of text from the resume PDF directly as well as using Optical Character Recognition (OCR). Because some PDFs contain the contents as text while others are saved as images, both methods are used to maximize the extractable content.',
                                        '</center>'), fragment.only=TRUE))
 ),
 box(
   width=4,
   icon('scissors', class = "fa", style = "font-size: 100px;  display: flex; justify-content: center;"),
   HTML(markdown::markdownToHTML(text=c('<center>',
                                        '<h2 style="text-align:center;">Parsing</h2>',
                                        '</center>',
                                        '<center>',
                                        'The Names Spreadsheet is then used to inform the parsing step, which finds where each candidate resume begins and ends within the single PDF.',
                                        '<br></br>',
                                        'Because no parsing step can catch all nuances with how candidate resumes are formatted, sometimes matches are not made between the information in the Names Spreadsheet and the content in the PDF. Unmatched candidates are then manually found and the starting and ending pages are inputed in the app.', 
                                        '</center>'), fragment.only=TRUE))
   
#    HTML(markdown::markdownToHTML(text=c('### Parsing', 'The Names Table is then used to inform the parsing step, which finds where each candidate resume begins and ends within the single PDF.',
# 'Because no parsing step can catch all nuances with how candidate resumes are formatted, sometimes matches are not made netween the information in the Names Spreadsheet and the content in the PDF. Unmatched candidates are then manually found and the starting and ending pages are inputed in the app.  
# '), fragment.only=TRUE))
 ),
 box(
   width=4,
   icon('star-half-stroke', class = "fa", style = "font-size: 100px;  display: flex; justify-content: center;"),
   HTML(markdown::markdownToHTML(text=c('<center>',
                                        '<h2 style="text-align:center;">Scoring Algorithm Overview</h2>',
                                        '</center>',
                                        '<center>',
                                        'The initial processing steps include the attempted extraction of text from the resume PDF directly as well as using Optical Character Recognition (OCR). Because some PDFs contain the contents as text while others are saved as images, both methods are used to maximize the extractable content.',
                                        '</center>'), fragment.only=TRUE))
   
   # HTML(markdown::markdownToHTML(text=c('### Scoring Algorithm Overview', 'The initial processing steps include the attempted extraction of text from the resume PDF directly as well as using Optical Character Recognition (OCR). Because some PDFs contain the contents as text while others are saved as images, both methods are used to maximize the extractable content.'), fragment.only=TRUE))
 ),
 ),

      
      ## Contact Developer ----
      tabItem(
        tabName = "contact",

        box(
          width=12,

          HTML(markdown::markdownToHTML(text=c("# Want to Report Issues/Bugs? Have suggestions for improvement?",
                                               'Submit bug/issue reports or feature requests:'), 
                                        fragment.only=TRUE)),

        a(
          actionButton(
            inputId = "email1",
            label = "Submit Feedback",
            icon = icon("comment", lib = "font-awesome")
          ),
          href = "https://irsgov.sharepoint.com/:l:/s/ORM-ACRTeam/FE14E8NJpaZFr53-mKx0Z3cB2peffPQp0NK_ZNUz7vmEaQ?nav=MjQ5NGEwMjQtNGUyNS00ZTkwLTkzNmItZGZiZWRiYTAzZTIy",
          target="_blank"
        )

        )
      )
      )
    )
  )
      