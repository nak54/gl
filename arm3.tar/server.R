options(shiny.sessionTimeout = 0) # set to indefinite session timeout

# Sourcing ACR functions in the R subdirectory
sources <- c('R/parse.R','R/search.R','R/clean.R','R/initialize_dataframe.R',
             'R/collapse_resume_df.R','R/compare_text_OCR.R',
             'R/update_resume_df.R', 'R/download.R', 'R/optimize_extract.R',
             'R/corpus.R', 'R/tokenize.R', 'R/map.R', 'R/output_score.R',
             'R/utilities.R', 'R/selection_events.R')

lapply(sources, source)

## Set the maximum upload file size to 500 MB
options(shiny.maxRequestSize = 500 * 1024^2,
        bitmapType="cairo")


# Start the app with the following function. Everything has to go inside this function or the app won't run
function(input, output, session){
  
  # If the App crashes, stop it
  session$onSessionEnded(function() { stopApp() })
  
  # Initialize Reactive Values ----
  
  # Create a reactive value to store the uploaded name sheet for future use
  name_table <- reactiveVal()
  usas_report_names <- reactiveVal()
  
  # Initializing reactive values
  pdf_path <- reactiveVal()
  Processed_df <- reactiveVal()
  unmatched_df <- reactiveVal()
  resume_keywords_df <- reactiveVal()
  resume_keywords_table <- reactiveVal()
  unmatched_df_info <- reactiveVal()
  keywords_df_info <- reactiveVal()
  split_files <- reactiveVal() # List of parsed resume PDF files
  
  # n_grams
  pdf_text_ngrams <- reactiveVal()
  tess_ocr_ngrams <- reactiveVal()
  pdf_text_ngrams_list <- reactiveVal()
  tess_ocr_ngrams_list <- reactiveVal()
  
  resume_ngrams <- reactiveVal()
  resume_ngrams_by_resume <- reactiveVal()
  
  scored_resumes_df <- reactiveVal()
  scored_resumes_weighted_df <- reactiveVal()
  
  score_detailed_df <- reactiveVal()
  score_proportion_df <- reactiveVal()
  score_proportion_weighted_df <- reactiveVal()
  
  # Data frame with matched keywords
  matched_keywords_df <- reactiveVal()
  
  pdf_file_name <- reactiveVal()
  
  # slider values
  n_applicants_reactive <- reactiveVal()
  
  # ### GIS/map functionality disabled because sf is unavailable
  # state_shp <- st_read('www/cb_2018_us_state_20m/cb_2018_us_state_20m.shp')
  #
  # states_shp <- reactiveVal(state_shp)
  # conus_states_shp <- reactiveVal(state_shp %>%
  #                                   filter(STUSPS!='HI') %>%
  #                                   filter(STUSPS!='AK') %>%
  #                                   filter(STUSPS!='PR'))
  # hi_states_shp <- reactiveVal(state_shp %>%
  #                                filter(STUSPS=='HI'))
  # ak_states_shp <- reactiveVal(state_shp %>%
  #                                filter(STUSPS=='AK'))
  #
  # conus_gdi_selected_sf <- reactiveVal()
  # hi_gdi_selected_sf <- reactiveVal()
  # ak_gdi_selected_sf <- reactiveVal()
  # conus_gdi_unselected_sf <- reactiveVal()
  # hi_gdi_unselected_sf <- reactiveVal()
  # ak_gdi_unselected_sf <- reactiveVal()
  #
  # gdi_data <- reactiveVal()
  #
  # conus_plotly_data <- reactiveVal()
  # ak_plotly_data <- reactiveVal()
  # hi_plotly_data <- reactiveVal()
  
  selected_state <- reactiveVal("")
  selected_applicants <- reactiveVal("")
  
  ### Filtered Candidate table on Viz tab
  filtered_candidate_table <- reactiveVal()
  
  # Observed Events ----
  
  ## File Uploads ----
  
  ### Name File ----
  
  observeEvent(input$namefile, {
    
    req(input$namefile)
    
    usas_report <-  read_excel(input$namefile$datapath)
    
    # Display a pop-up message if USAS sheet has duplicates
    if(nrow(usas_report ) != nrow(usas_report %>% distinct())) {
      showModal(modalDialog(
        title = "Duplicate Names Detected",
        "The name sheet contains duplicate names. Remove any duplicated names 
        from this report and run again. Resumes for applicants with identical 
        first/last names must be handled manually outside of this script.",
        easyClose = TRUE,
        footer = NULL
      ))
    } 
    name_table(usas_report)
    # Render a table of names once the table is uploaded
    
    df <- remove_na_columns(name_table())
    targets <- which(colnames(df) %in% c("Application Locations",
                                         "Application Grade Info", 
                                         "Vacancy Job Title", 
                                         "Cert Info"))
    
    output$names_table <- renderDT({
      
      datatable(df ,
                plugins = "ellipsis",
                options = list(
                  scrollX=TRUE,
                  columnDefs = list(list(
                    targets = targets,
                    render = JS("$.fn.dataTable.render.ellipsis( 17, false )")
                  ))
                ), 
                selection = 'none'
                # editable=list(target='column', 
                #disable=list(columns=seq(1,ncol(name_table()[,colSums(is.na(name_table()))<nrow(name_table())])-1)))
      )
    })
    
    
    # Creating UI for Names Sheet Table
    
    output$step1_names_sheet_ui <- renderUI({
      
    ### Names Spreadsheet ----
      fluidRow(
        box(id = 'name_sheet_box',
            width = 12,
            title = 'View Uploaded Names Spreadsheet (Optional; Click the "+") --->',
            collapsible = TRUE,
            collapsed = TRUE, # Started collapsed so it doesn't take up space by default
            
            # Output table (display the uploaded excel as a table) created in the server
            DTOutput("names_table")
        )
      )
    })
    
    # Creating UI for Resume Upload Step 2
    
    output$step2_detect_candidates_button <- renderUI({
      
      list(
           column(
             width=12,
             p(strong("The ACR App will process the PDF file and attempt to 
                 automatically detect individual candidates based on entries
                 in the uploaded Names Spreadsheet above")),
             # Add an action button for resume split
             actionButton("process_resumes", 
                          "Detect Candidates in Resume PDF",
                          class='btn-success btn-lg',
                          style = "color: white;")),
           

           
           column(
             width=12,
             hr(),
             valueBoxOutput('candidates_processed'),
             valueBoxOutput('pages_processed')
            )
           ,
           uiOutput('matched_candidates_ui')
           )
    })
    
    # Creating UI for UnMatched Candidates Table
    
    output$step3_candidates_not_found <- renderUI({
      
      req(unmatched_df())
      
      list(
        
        column(
          width=12,
          p(strong("Review this table and manually add 
                  (double click the cell to modify) the correct 
                           start (`startPage`) and end (`endPage`) page value."))),
        
        column(
          width=12,
          valueBoxOutput('candidates_not_found_box')),
        
        column(
          width=12,
          dataTableOutput("unmatched_candidates_table"),
          actionButton("apply_unmatched_changes", 
                       "Apply Manual Changes",
                       class='btn-primary',
                       style = "color: white;"))
        
      )
    })
    
    # Creating UI for UnMatched Candidates Table
    
    output$step4_split_resumes <- renderUI({
      
      req(Processed_df())
      
      list(
        column(
          width=12,
        
        p(strong("Once all candidates have been matched (i.e., the above table is empty)
                    or you are happy with the candidates found in the resumes
                    PDF, click this button to split up the resumes and 
                    optionally download them")),
        
        actionButton("split", 
                     "Split Individual Resumes",
                     class='btn-success btn-lg',
                     style = "color: white;"))
      )
    })

  })
  
  ### Resume PDF ----
  
  # Observe the uploaded PDF file and display the number of pages
  observeEvent(input$pdffile, {
    req(input$pdffile)
    
    pdf_path(input$pdffile$datapath)
    
    pdf_file_name(str_split(input$pdffile$name, ".pdf")[[1]][[1]])
    
    # # Extract metadata (no. of pages) from a PDF file
    info <- pdf_info(input$pdffile$datapath)
    num_pages <- info$pages
    
    # Display the number of pages in the UI
    # Update the UI to show Processing is complete
    output$page_count <- renderText({
      paste("PDF successfully uploaded. Number of pages: ", num_pages)
    })
    
    
  })
  
  ### Keywords and Weights ----
  
  observeEvent(input$bow_file, {
    req(input$bow_file)
    
    if (grepl('csv', input$bow_file$type)){
      
    # Converting character column to factor so it can be filtered with dropdown  
    bow_weights <-  read.csv(input$bow_file$datapath, colClasses=c('factor','character','numeric'))
    
    file_valid = TRUE
    
    }else if(grepl('xls', input$bow_file$name)){
      
      bow_weights <-  read_excel(input$bow_file$datapath, col_types=c('text','text','numeric'))
      
      bow_weights$category <- as.factor(bow_weights$category)
      
      file_valid = TRUE
      
    }else{
      
      file_valid = FALSE
        ### change button to say 
    }
    
    if (file_valid){
    
    resume_keywords_table(bow_weights)

    bow_weights$category<-tolower(bow_weights$category)
    bow_weights$keyword<-tolower(bow_weights$keyword)
    
    resume_keywords_df(bow_weights)
    
    
    # Render a table of names once the table is uploaded
    output$keywords_table <- renderDataTable({
      datatable(resume_keywords_table(),
                plugins = "ellipsis",
                options = list(search = list(regex = TRUE)
                               ),
                filter = list(
                  position = "top"
                ),
                selection = 'none',
                editable=list(target='cell', 
                              disable=list(columns=seq(1,ncol(resume_keywords_table())-1)))
      )
    })
    }else{

    }
    
    output$score_resumes_button <- renderUI({

      actionButton('find_best_extraction', 
                   'Score Resumes',
                   class= "btn-success btn-lg",
                   style = "color: white;")
      
    })
    
    output$step2_score_resumes <- renderUI({
      
      list(
      dataTableOutput("keywords_table"),
      br(),
      actionButton('apply_keyword_changes', 
                   'Save Changes to Weights', 
                   class='btn-primary',
                   style = "color: white;",
                   icon=icon('floppy-disk')),
      hr(),
      p(strong("Download any changes made to this table for 
                           future use")),
      downloadButton("download_keywords", "Download Edited Keywords and Weights")
      )
      
    })
    
  })
  
  ### N_applicants_reactive Change ----
  
  observeEvent(n_applicants_reactive(), {
    
    req(input$weighting_button)
    req(input$n_applicants)
    req(scored_resumes_df())
    
    if (input$weighting_button == "unweighted"){
      
      top_candidates <- head(scored_resumes_df() %>%
                               arrange(desc(`Total Score`)),
                             n_applicants_reactive())
    }else{
      
      top_candidates <- head(scored_resumes_weighted_df() %>%
                               arrange(desc(`Total Score`)),
                             n_applicants_reactive())
    }
    
    email_vector <- top_candidates$email
    
    # ### Storing GIS layer reactives
    # conus_gdi_selected_sf({
    #   
    #   conus_selected <- gdi_data() %>%
    #     filter(State!='HI') %>%
    #     filter(State!='AK') %>%
    #     filter(State!='PR') %>%
    #     filter(State!='VI') %>%
    #     filter(grepl(paste(email_vector, collapse='|'), Candidates))
    #   
    #   st_as_sf(conus_selected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    #   
    # })
    # 
    # hi_gdi_selected_sf({
    #   
    #   hi_gdi_selected <- gdi_data() %>%
    #     filter(State=='HI') %>%
    #     filter(grepl(paste(email_vector, collapse='|'), Candidates))
    #   
    #   st_as_sf(hi_gdi_selected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    # })
    # 
    # ak_gdi_selected_sf({
    #   
    #   ak_gdi_selected <- gdi_data() %>%
    #     filter(State=='AK') %>%
    #     filter(grepl(paste(email_vector, collapse='|'), Candidates))
    #   
    #   st_as_sf(ak_gdi_selected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    # })
    # 
    # conus_gdi_unselected_sf({
    #   
    #   conus_unselected <- gdi_data() %>%
    #     filter(State!='HI') %>%
    #     filter(State!='AK') %>%
    #     filter(State!='PR') %>%
    #     filter(State!='VI') %>%
    #     filter(!grepl(paste(email_vector, collapse='|'), Candidates))
    #   
    #   st_as_sf(conus_unselected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    #   
    # })
    # 
    # hi_gdi_unselected_sf({
    #   
    #   hi_gdi_unselected <- gdi_data() %>%
    #     filter(State=='HI') %>%
    #     filter(!grepl(paste(email_vector, collapse='|'), Candidates))
    #   
    #   st_as_sf(hi_gdi_unselected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    #   
    # })
    # 
    # ak_gdi_unselected_sf({
    #   
    #   ak_gdi_unselected <- gdi_data() %>%
    #     filter(State=='AK') %>%
    #     filter(!grepl(paste(email_vector, collapse='|'), Candidates))
    #   
    #   st_as_sf(ak_gdi_unselected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    #   
    # })
    # 
    # list[conus_ggplotly, hi_ggplotly, ak_ggplotly] <- create_candidate_map(conus_states_shp(),
    #                                                                        hi_states_shp(),
    #                                                                        ak_states_shp(),
    #                                                                        conus_gdi_selected_sf(),
    #                                                                        hi_gdi_selected_sf(),
    #                                                                        ak_gdi_selected_sf(),
    #                                                                        conus_gdi_unselected_sf(),
    #                                                                        hi_gdi_unselected_sf(),
    #                                                                        ak_gdi_unselected_sf())
    # 
    # conus_plotly_data(conus_ggplotly)
    # ak_plotly_data(ak_ggplotly)
    # hi_plotly_data(hi_ggplotly)
    # 
    # # Rendering the CONUS plotly map
    # output$candidate_map_conus <- renderPlotly({
    #   
    #   conus_ggplotly %>%
    #     event_register('plotly_click')
    # })
    # 
    # # Rendering the Hawaii plotly map
    # output$candidate_map_hi <- renderPlotly({
    #   hi_ggplotly %>%
    #     event_register('plotly_click')
    # })
    # 
    # # Rendering the Alaska plotly map
    # output$candidate_map_ak <- renderPlotly({
    #   ak_ggplotly %>%
    #     event_register('plotly_click')
    # })
    
  })
  
  ### Visualization Tab ----
  
  observeEvent(input$tabs, {
    
    if (input$tabs=='visualization'){
      
      req(scored_resumes_df())
      
      output$selected_candidate_ui <- renderUI({
        
        list(
        dataTableOutput("selected_candidate_table"),
        br(),
        br(),
        p('Download resumes from candidates selected from this table:'),
        downloadButton("download_selected_candidates", "Download Resumes")
        )
      })
      
      output$download_resumes_from_slider_ui <- renderUI({
        
        downloadButton('download_resumes_from_slider', HTML(paste0(strwrap('Download Resumes of Displayed Candidates', width=10), collapse='</br>')))
        
      })
      
    }
    
  })
  
  ### Sliders
  
  #### Update Percentile slider when N Applicant slider changed
  
  observeEvent(input$n_applicants, {

    req(Processed_df())
    
    n_applicants_reactive(input$n_applicants)

  })
  
  #### Update  N Applicant slider when Percentile slider changed

  observeEvent(input$applicants_percentile, {

    req(Processed_df())
    
    n_applicants_reactive({
      ceiling(as.numeric(input$applicants_percentile)/100*nrow(Processed_df()))
      })

  })
  
  observeEvent(input$applicants_percentile_numeric, {
    
    req(Processed_df())
    
    n_applicants_reactive({
      ceiling(input$applicants_percentile_numeric/100*nrow(Processed_df()))
      })

  })
  

  
  ## Action Button ----
  
  ### Apply candidates page updates ----
  
  observeEvent(input$apply_unmatched_changes, {
    
    req(unmatched_df())
    
    unmatched_df(editData(unmatched_df(), unmatched_df_info()))
    
    unmatched_df_info(NULL)
    
    old_unmatched_df <- unmatched_df()
    
    newly_matched_df <- old_unmatched_df %>%
      select(!firstName & !lastName & !email) %>%
      rename(firstName=missingFirstName, 
             lastName=missingLastName,
             email=missingEmail) %>%
      filter(!is.na(startPage) & !is.na(endPage))
    
    newly_matched_df <- newly_matched_df %>%
      mutate(resumeLength = endPage- startPage +1)
    
    unmatched_df(old_unmatched_df %>%
                   filter(is.na(startPage) | is.na(endPage)))
    
    new_processed_df <- Processed_df() %>%
      rbind(newly_matched_df) %>%
      arrange(startPage, endPage)
    
    if (new_processed_df[nrow(new_processed_df)-1, 5] == new_processed_df[nrow(new_processed_df), 5]){
      new_processed_df[nrow(new_processed_df)-1, 5] <- NA
      new_processed_df[nrow(new_processed_df), 6] <- new_processed_df[nrow(new_processed_df), 5] - new_processed_df[nrow(new_processed_df), 4] + 1 
      
      new_processed_df <- new_processed_df %>%
        mutate(resumeLength = endPage- startPage +1) %>%
        mutate(endPage = lead(startPage, 
                              default=last(endPage+resumeLength-1))-1)
      
      new_processed_df[nrow(new_processed_df), 5] <- tail(Processed_df()$endPage,1)
      
      new_processed_df <- new_processed_df %>%
        mutate(resumeLength = endPage- startPage +1)
      
      Processed_df(new_processed_df)
      
    }else{
      
      Processed_df(Processed_df() %>%
                     rbind(newly_matched_df) %>%
                     arrange(startPage, endPage) %>%
                     mutate(endPage = lead(startPage-1, 
                                           default=last(endPage))) %>%
                     mutate(resumeLength = endPage- startPage +1))
      
    }
    
    ### Update infoBox ----
    output$candidates_found_box <- renderValueBox({
      valueBox(
        nrow(Processed_df()), 
        "Candidates Found in PDF", 
        icon = icon("user-check"),
        color = "green"
      )
    })
    
    output$candidates_not_found_box <- renderValueBox({
      valueBox(
        nrow(unmatched_df()), 
        "Candidates NOT Found in PDF", 
        icon = icon("user-slash"),
        color = "red"
      )
    })
    
    
  })
  
  ### Apply keyword weight updates ----
  
  observeEvent(input$apply_keyword_changes, {
    
    req(resume_keywords_table())
    
    resume_keywords_table(editData(resume_keywords_table(), keywords_df_info()))

    # clean up keywords
    bow_weights <- resume_keywords_table()

    bow_weights$category<-tolower(bow_weights$category)
    bow_weights$keyword<-tolower(bow_weights$keyword)
    #
    resume_keywords_df(bow_weights)
    
    keywords_df_info(NULL)

  })
  
  # ### Reset Candidate Selection ----
  # 
  # observeEvent(input$reset_selected_candidate_table, {
  #   
  #   req(scored_resumes_df())
  #   
  #   selected_applicants("")
  #   
  #   selected_state("")
  #   
  #   filtered_candidate_table(remove_na_columns(scored_resumes_df()))
  #   
  #   ### Storing GIS layer reactives
  #   conus_gdi_selected_sf({
  #     
  #     conus_selected <- gdi_data() %>%
  #       filter(State!='HI') %>%
  #       filter(State!='AK') %>%
  #       filter(State!='PR') %>%
  #       filter(State!='VI') %>%
  #       filter(Candidates!="")
  #     
  #     st_as_sf(conus_selected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
  #     
  #   })
  #   
  #   hi_gdi_selected_sf({
  #     
  #     hi_gdi_selected <- gdi_data() %>%
  #       filter(State=='HI') %>%
  #       filter(Candidates!="")
  #     
  #     st_as_sf(hi_gdi_selected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
  #   })
  #   
  #   ak_gdi_selected_sf({
  #     
  #     ak_gdi_selected <- gdi_data() %>%
  #       filter(State=='AK') %>%
  #       filter(Candidates!="")
  #     
  #     st_as_sf(ak_gdi_selected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
  #   })
  #   
  #   conus_gdi_unselected_sf({
  #     
  #     conus_unselected <- gdi_data() %>%
  #       filter(State!='HI') %>%
  #       filter(State!='AK') %>%
  #       filter(State!='PR') %>%
  #       filter(State!='VI') %>%
  #       filter(Candidates=="")
  #     
  #     st_as_sf(conus_unselected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
  #     
  #   })
  #   
  #   hi_gdi_unselected_sf({
  #     
  #     hi_gdi_unselected <- gdi_data() %>%
  #       filter(State=='HI') %>%
  #       filter(Candidates=="")
  #     
  #     st_as_sf(hi_gdi_unselected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
  #     
  #   })
  #   
  #   ak_gdi_unselected_sf({
  #     
  #     ak_gdi_unselected <- gdi_data() %>%
  #       filter(State=='AK') %>%
  #       filter(Candidates=="")
  #     
  #     st_as_sf(ak_gdi_unselected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
  #     
  #   })
  #   
  #   list[conus_ggplotly, hi_ggplotly, ak_ggplotly] <- create_candidate_map(conus_states_shp(),
  #                                                                          hi_states_shp(),
  #                                                                          ak_states_shp(),
  #                                                                          conus_gdi_selected_sf(),
  #                                                                          hi_gdi_selected_sf(),
  #                                                                          ak_gdi_selected_sf(),
  #                                                                          conus_gdi_unselected_sf(),
  #                                                                          hi_gdi_unselected_sf(),
  #                                                                          ak_gdi_unselected_sf())
  #   
  #   conus_plotly_data(conus_ggplotly)
  #   ak_plotly_data(ak_ggplotly)
  #   hi_plotly_data(hi_ggplotly)
  #   
  #   # Rendering the CONUS plotly map
  #   output$candidate_map_conus <- renderPlotly({
  #     
  #     conus_ggplotly %>%
  #       event_register('plotly_click')
  #   })
  #   
  #   # Rendering the Hawaii plotly map
  #   output$candidate_map_hi <- renderPlotly({
  #     hi_ggplotly %>%
  #       event_register('plotly_click')
  #   })
  #   
  #   # Rendering the Alaska plotly map
  #   output$candidate_map_ak <- renderPlotly({
  #     ak_ggplotly %>%
  #       event_register('plotly_click')
  #   })
  # 
  # })
  
  ## Selected Candidate Table Creation ----
  output$selected_candidate_table <- renderDataTable({
    
    req(scored_resumes_df())
    
    targets <- which(colnames(filtered_candidate_table()) %in% c("Application Locations","Application Grade Info", "Vacancy Job Title", "Cert Info"))
    
    datatable(filtered_candidate_table(), 
              plugins = "ellipsis",
              options = list(scrollX=TRUE,
                             select='none',
                             columnDefs = list(list(
                               targets = targets,
                               render = JS("$.fn.dataTable.render.ellipsis( 17, false )")
                             ))
              ))
  })

  
  ## Selection events ----
  
  ### Selecting candidate bar chart ----
  
  observeEvent(event_data(event="plotly_click", source='bar_chart', priority = "event"), {
    
    selected_element <- event_data("plotly_click", source='bar_chart', priority = "event")
    
    email <- tail(str_split(selected_element$x[[1]], "<br /> ")[[1]],1)
    
    req(input$weighting_button)
    
    if (input$weighting_button == "unweighted"){
      
      filtered_candidate_table(remove_na_columns(scored_resumes_df() %>% filter(email==!!email)))
      
    }else{
      
      filtered_candidate_table(remove_na_columns(scored_resumes_weighted_df() %>% filter(email==!!email)))
      
    }
    # 
    # ### Storing GIS layer reactives
    # conus_gdi_selected_sf({
    #   
    #   conus_selected <- gdi_data() %>%
    #     filter(State!='HI') %>%
    #     filter(State!='AK') %>%
    #     filter(State!='PR') %>%
    #     filter(State!='VI') %>%
    #     filter(grepl(email, Candidates),
    #            Candidates!="")
    #   
    #   st_as_sf(conus_selected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    #   
    # })
    # 
    # hi_gdi_selected_sf({
    #   
    #   hi_gdi_selected <- gdi_data() %>%
    #     filter(State=='HI') %>%
    #     filter(grepl(email, Candidates),
    #            Candidates!="")
    #   
    #   st_as_sf(hi_gdi_selected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    # })
    # 
    # ak_gdi_selected_sf({
    #   
    #   ak_gdi_selected <- gdi_data() %>%
    #     filter(State=='AK') %>%
    #     filter(grepl(email, Candidates),
    #            Candidates!="")
    #   
    #   st_as_sf(ak_gdi_selected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    # })
    # 
    # conus_gdi_unselected_sf({
    #   
    #   conus_unselected <- gdi_data() %>%
    #     filter(State!='HI') %>%
    #     filter(State!='AK') %>%
    #     filter(State!='PR') %>%
    #     filter(State!='VI') %>%
    #     filter(!grepl(email, Candidates),
    #            Candidates=="")
    #   
    #   st_as_sf(conus_unselected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    #   
    # })
    # 
    # hi_gdi_unselected_sf({
    #   
    #   hi_gdi_unselected <- gdi_data() %>%
    #     filter(State=='HI') %>%
    #     filter(!grepl(email, Candidates),
    #            Candidates=="")
    #   
    #   st_as_sf(hi_gdi_unselected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    #   
    # })
    # 
    # ak_gdi_unselected_sf({
    #   
    #   ak_gdi_unselected <- gdi_data() %>%
    #     filter(State=='AK') %>%
    #     filter(!grepl(email, Candidates),
    #            Candidates=="")
    #   
    #   st_as_sf(ak_gdi_unselected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    #   
    # })
    # 
    # list[conus_ggplotly, hi_ggplotly, ak_ggplotly] <- create_candidate_map(conus_states_shp(),
    #                                                                        hi_states_shp(),
    #                                                                        ak_states_shp(),
    #                                                                        conus_gdi_selected_sf(),
    #                                                                        hi_gdi_selected_sf(),
    #                                                                        ak_gdi_selected_sf(),
    #                                                                        conus_gdi_unselected_sf(),
    #                                                                        hi_gdi_unselected_sf(),
    #                                                                        ak_gdi_unselected_sf())
    # 
    # conus_plotly_data(conus_ggplotly)
    # ak_plotly_data(ak_ggplotly)
    # hi_plotly_data(hi_ggplotly)
    # 
    # # Rendering the CONUS plotly map
    # output$candidate_map_conus <- renderPlotly({
    #   
    #   conus_ggplotly %>%
    #     event_register('plotly_click')
    # })
    # 
    # # Rendering the Hawaii plotly map
    # output$candidate_map_hi <- renderPlotly({
    #   hi_ggplotly %>%
    #     event_register('plotly_click')
    # })
    # 
    # # Rendering the Alaska plotly map
    # output$candidate_map_ak <- renderPlotly({
    #   ak_ggplotly %>%
    #     event_register('plotly_click')
    # })
    
  })
  
  ### Selecting range in bar chart ----
  
  observeEvent(event_data(event="plotly_selected", source='bar_chart', priority = "event"), {
    
    
    selected_element <- event_data("plotly_selected", source='bar_chart', priority = "event")
    
    selected_element <- selected_element %>%
      distinct(x, .keep_all = TRUE)

      email_vector <- unique(unlist(lapply(str_split(selected_element$x, '<br /> '), '[', 2)))
    
      req(input$weighting_button)
      
      if (input$weighting_button == "unweighted"){
        
        filtered_candidate_table(remove_na_columns(scored_resumes_df() %>% 
                                                     filter(email %in% email_vector)))
      }else{
        
        filtered_candidate_table(remove_na_columns(scored_resumes_weighted_df()%>% 
                                                     filter(email %in% email_vector)))
      }
      
      # ### Storing GIS layer reactives
      # conus_gdi_selected_sf({
      #   
      #   conus_selected <- gdi_data() %>%
      #     filter(State!='HI') %>%
      #     filter(State!='AK') %>%
      #     filter(State!='PR') %>%
      #     filter(State!='VI') %>%
      #     filter(grepl(paste(email_vector, collapse='|'), Candidates))
      #   
      #   st_as_sf(conus_selected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
      #   
      # })
      # 
      # hi_gdi_selected_sf({
      #   
      #   hi_gdi_selected <- gdi_data() %>%
      #     filter(State=='HI') %>%
      #     filter(grepl(paste(email_vector, collapse='|'), Candidates))
      #   
      #   st_as_sf(hi_gdi_selected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
      # })
      # 
      # ak_gdi_selected_sf({
      #   
      #   ak_gdi_selected <- gdi_data() %>%
      #     filter(State=='AK') %>%
      #     filter(grepl(paste(email_vector, collapse='|'), Candidates))
      #   
      #   st_as_sf(ak_gdi_selected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
      # })
      # 
      # conus_gdi_unselected_sf({
      #   
      #   conus_unselected <- gdi_data() %>%
      #     filter(State!='HI') %>%
      #     filter(State!='AK') %>%
      #     filter(State!='PR') %>%
      #     filter(State!='VI') %>%
      #     filter(!grepl(paste(email_vector, collapse='|'), Candidates))
      #   
      #   st_as_sf(conus_unselected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
      #   
      # })
      # 
      # hi_gdi_unselected_sf({
      #   
      #   hi_gdi_unselected <- gdi_data() %>%
      #     filter(State=='HI') %>%
      #     filter(!grepl(paste(email_vector, collapse='|'), Candidates))
      #   
      #   st_as_sf(hi_gdi_unselected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
      #   
      # })
      # 
      # ak_gdi_unselected_sf({
      #   
      #   ak_gdi_unselected <- gdi_data() %>%
      #     filter(State=='AK') %>%
      #     filter(!grepl(paste(email_vector, collapse='|'), Candidates))
      #   
      #   st_as_sf(ak_gdi_unselected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
      #   
      # })
      # 
      # list[conus_ggplotly, hi_ggplotly, ak_ggplotly] <- create_candidate_map(conus_states_shp(),
      #                                                                        hi_states_shp(),
      #                                                                        ak_states_shp(),
      #                                                                        conus_gdi_selected_sf(),
      #                                                                        hi_gdi_selected_sf(),
      #                                                                        ak_gdi_selected_sf(),
      #                                                                        conus_gdi_unselected_sf(),
      #                                                                        hi_gdi_unselected_sf(),
      #                                                                        ak_gdi_unselected_sf())
      # 
      # conus_plotly_data(conus_ggplotly)
      # ak_plotly_data(ak_ggplotly)
      # hi_plotly_data(hi_ggplotly)
      # 
      # # Rendering the CONUS plotly map
      # output$candidate_map_conus <- renderPlotly({
      #   
      #   conus_ggplotly %>%
      #     event_register('plotly_click')
      # })
      # 
      # # Rendering the Hawaii plotly map
      # output$candidate_map_hi <- renderPlotly({
      #   hi_ggplotly %>%
      #     event_register('plotly_click')
      # })
      # 
      # # Rendering the Alaska plotly map
      # output$candidate_map_ak <- renderPlotly({
      #   ak_ggplotly %>%
      #     event_register('plotly_click')
      # })
    
  })
  
  
  ### Selecting candidate location map ----
  
  #### CONUS ----
  
  observeEvent(event_data(event="plotly_click", source='candidate_map_conus', priority = "event"), {
    
    selected_element <- event_data("plotly_click", source='candidate_map_conus', priority = "event")
    
    list[filtered_candidate_table_reactive, 
         selected_state_reactive, 
         selected_applicants_reactive] <- map_click(selected_element,
                                                   conus_gdi_selected_sf,
                                                   selected_state,
                                                   conus_plotly_data,
                                                   selected_applicants,
                                                   states_shp,
                                                   input,
                                                   scored_resumes_df,
                                                   n_applicants_reactive,
                                                   scored_resumes_weighted_df,
                                                   filtered_candidate_table,
                                                   state='CONUS')
    
    filtered_candidate_table(filtered_candidate_table_reactive())
    selected_state(selected_state_reactive())
    selected_applicants(selected_applicants_reactive())
  
  })
  
  #### Hawaii ----
  
  observeEvent(event_data(event="plotly_click", source='candidate_map_hi', priority = "event"), {
    
    selected_element <- event_data("plotly_click", source='candidate_map_hi', priority = "event")
    
    list[filtered_candidate_table_reactive, 
         selected_state_reactive, 
         selected_applicants_reactive] <- map_click(selected_element,
                                                    hi_gdi_selected_sf,
                                                    selected_state,
                                                    hi_plotly_data,
                                                    selected_applicants,
                                                    states_shp,
                                                    input,
                                                    scored_resumes_df,
                                                    n_applicants_reactive,
                                                    scored_resumes_weighted_df,
                                                    filtered_candidate_table,
                                                    state='HI')
    
    filtered_candidate_table(filtered_candidate_table_reactive())
    selected_state(selected_state_reactive())
    selected_applicants(selected_applicants_reactive())

  })
  
  #### Alaska ----
  
  observeEvent(event_data(event="plotly_click", source='candidate_map_ak', priority = "event"), {
    
    selected_element <- event_data("plotly_click", source='candidate_map_ak', priority = "event")
    
    list[filtered_candidate_table_reactive, 
         selected_state_reactive, 
         selected_applicants_reactive] <- map_click(selected_element,
                                                    ak_gdi_selected_sf,
                                                    selected_state,
                                                    ak_plotly_data,
                                                    selected_applicants,
                                                    states_shp,
                                                    input,
                                                    scored_resumes_df,
                                                    n_applicants_reactive,
                                                    scored_resumes_weighted_df,
                                                    filtered_candidate_table,
                                                    state='AK')
    
    filtered_candidate_table(filtered_candidate_table_reactive())
    selected_state(selected_state_reactive())
    selected_applicants(selected_applicants_reactive())
    
  })
  
  
  ### Selecting range of candidates on CONUS map ----
  
  observeEvent(event_data(event="plotly_selected", source='candidate_map_conus', priority = "event"), {
    
    selected_element <- event_data("plotly_selected", source='candidate_map_conus', priority = "event")
    
    list[filtered_candidate_table_reactive, 
         selected_state_reactive, 
         selected_applicants_reactive] <- map_selected(selected_element,
                                                       conus_plotly_data,
                                                       selected_state,
                                                       input,
                                                       selected_applicants,
                                                       scored_resumes_df,
                                                       n_applicants_reactive,
                                                       scored_resumes_weighted_df,
                                                       filtered_candidate_table,
                                                       state='CONUS')
    
    filtered_candidate_table(filtered_candidate_table_reactive())
    selected_state(selected_state_reactive())
    selected_applicants(selected_applicants_reactive())
    
  })
  
  ### Selecting range of candidates on Hawaii map ----
  
  observeEvent(event_data(event="plotly_selected", source='candidate_map_hi', priority = "event"), {
  
  selected_element <- event_data("plotly_selected", source='candidate_map_hi', priority = "event")
  
  list[filtered_candidate_table_reactive, 
       selected_state_reactive, 
       selected_applicants_reactive] <- map_selected(selected_element,
                                                     hi_plotly_data,
                                                     selected_state,
                                                     input,
                                                     selected_applicants,
                                                     scored_resumes_df,
                                                     n_applicants_reactive,
                                                     scored_resumes_weighted_df,
                                                     filtered_candidate_table,
                                                     state='CONUS')
  
  filtered_candidate_table(filtered_candidate_table_reactive())
  selected_state(selected_state_reactive())
  selected_applicants(selected_applicants_reactive())
  
  })
  
  ### Selecting range of candidates on Alaska map ----
  
  observeEvent(event_data(event="plotly_selected", source='candidate_map_ak', priority = "event"), {
    
  
  selected_element <- event_data("plotly_selected", source='candidate_map_ak', priority = "event")
  
  list[filtered_candidate_table_reactive, 
       selected_state_reactive, 
       selected_applicants_reactive] <- map_selected(selected_element,
                                                     ak_plotly_data,
                                                     selected_state,
                                                     input,
                                                     selected_applicants,
                                                     scored_resumes_df,
                                                     n_applicants_reactive,
                                                     scored_resumes_weighted_df,
                                                     filtered_candidate_table,
                                                     state='CONUS')
  
  filtered_candidate_table(filtered_candidate_table_reactive())
  selected_state(selected_state_reactive())
  selected_applicants(selected_applicants_reactive())
  
  })
  
  ## Table Editing Events ----
  
  ### Unmatched candidates table -----
  observeEvent(input$unmatched_candidates_table_cell_edit, {
    
    if (is.null(unmatched_df_info())){
      info <- input$unmatched_candidates_table_cell_edit
    }else{
      info <- rbind(unmatched_df_info(), input$unmatched_candidates_table_cell_edit)
    }
    
    unmatched_df_info(info)
    
  })
  
  ### Keywords table ----
  observeEvent(input$keywords_table_cell_edit, {
    
    if (is.null(keywords_df_info())){
      info <- input$keywords_table_cell_edit
    }else{
      info <- rbind(keywords_df_info(), input$keywords_table_cell_edit)
    }
    
    keywords_df_info(info)
    
  })
  
  
  ## Process Resumes Button ----
  
  observeEvent(input$process_resumes, {
    
    req(input$pdffile)
    req(input$namefile)
    
    # Setting the number of cores to use for parsing and OCR
    max_num_cores <- max(1, floor(parallel::detectCores()*0.7))
    
    old <- Sys.time()
    
    ### Parsing PDF file ----
    
    # Convert each page to PNG and read and perform OCR on each
    list[resume_data_pdf_text, 
         resume_data_pdf_text_ocr, 
         pdf_text_ngrams_return, 
         pdf_text_ngrams_list_return, 
         tess_ocr_ngrams_return, 
         tess_ocr_ngrams_list_return] <- parse_pdfs(input, max_num_cores)
    
    n_pages <- length(resume_data_pdf_text)
    mins_per_page_min <- 0.04/60
    mins_per_page_max <- 0.22/60
    
    time_estimate_min <- round(n_pages*mins_per_page_min, 1)
    time_estimate_max <- round(n_pages*mins_per_page_max, 1)
    
    likely_time <- round((-0.017*log(n_pages)+0.2781)*n_pages/60, 1)
    
    # Add a progress bar for the whole OCR process
    withProgress(message = sprintf('Finding candidates in the extracted text. \n\n This step should take 
                                   appoximately: \n %s to %s minutes and likely %s minutes.', time_estimate_min, time_estimate_max, likely_time), value = 0, {
                 
                 pdf_text_ngrams(pdf_text_ngrams_return)
                 pdf_text_ngrams_list(pdf_text_ngrams_list_return)
                 tess_ocr_ngrams(tess_ocr_ngrams_return)
                 tess_ocr_ngrams_list(tess_ocr_ngrams_list_return)
                 
                 incProgress(0.1)
                 
                 # browser()
                 
                 # Cleaning ngrams
                 pdf_text_ngrams(clean_ngrams(pdf_text_ngrams()))
                 tess_ocr_ngrams(clean_ngrams(tess_ocr_ngrams()))
                 
                 
                 ### Clean text extracted by ----
                 
                 #### Text ----
                 list[resume_data_clean_text, 
                      resume_data_clean_numbers, 
                      resume_data] <- clean_pdf_text(resume_data_pdf_text)
                 
                 #### OCR ----
                 list[resume_data_clean_text_ocr, 
                      resume_data_clean_numbers_ocr, 
                      resume_data_ocr] <- clean_pdf_text(resume_data_pdf_text_ocr)
                 
                 incProgress(0.1)
                 
                 ### Search Resume ----
                 
                 #### By Name ----
                 
                 # Get list of first and last names (from USAS sheet) to search for
                 usas_report_names(name_table() %>%
                                     transmute(
                                       firstName = str_to_lower(`Applicant First Name`),
                                       lastName = str_to_lower(`Applicant Last Name`),
                                       email = str_to_lower(`Applicant Email Address`),
                                       phone = str_replace_all(`Applicant Phone Number`, "[()+-. ]", "")
                                     ) %>%
                                     distinct() %>%
                                     filter(!is.na(firstName)))
                 
                 # Create a variable to store unmatched names for the future steps
                 to_do_list <- usas_report_names()
                 
                 # Initializing data frame to hold data about resume pages obtained from pdf_text
                 resume_df <- initialize_dataframe()
                 
                 # Initializing data frame to hold data about resume pages obtained from tesseract OCR
                 resume_df_ocr <- initialize_dataframe()
                 
                 # --- Begin name search for pdf_text data ---
                 list[, resume_df, to_do_list] <- search_identifier(resume_data, 
                                                                    resume_df,
                                                                    resume_df, 
                                                                    usas_report_names(), 
                                                                    to_do_list, 
                                                                    'name')
                 
                 incProgress(0.1)
                 
                 # Update the to do list for email search
                 to_do_list_email <- to_do_list
                 
                 # Name search for tesseract OCR data
                 list[resume_df, 
                      resume_df_ocr, 
                      to_do_list] <- search_identifier(resume_data_ocr, 
                                                       resume_df_ocr, 
                                                       resume_df,
                                                       usas_report_names(), 
                                                       to_do_list, 
                                                       'email')
                 
                 incProgress(0.1)
                 
                 # Update the to do list for email search
                 to_do_list_email_ocr <- to_do_list
                 
                 
                 
                 #### By Email ----
                 
                 # --- Begin email search for pdf_text data for unmatched applicants ---
                 list[to_do_list_email, 
                      resume_df,
                      resume_data] <- update_resume_df(to_do_list_email, 
                                                       resume_df, 
                                                       resume_data)
                 
                 incProgress(0.1)
                 
                 
                 to_do_list_phone <- to_do_list_email
                 
                 # --- Begin email search for tesseract OCR data for unmatched applicants---
                 list[to_do_list_email_ocr,
                      resume_df_ocr,
                      resume_data_ocr] <- update_resume_df(to_do_list_email_ocr, 
                                                           resume_df_ocr, 
                                                           resume_data_ocr)
                 
                 incProgress(0.1)
                 
                 to_do_list_phone_ocr <- to_do_list_email_ocr
                 
                 
                 
                 #### By Phone ----
                 
                 # --- Begin phone search for pdf_text data for unmatched applicants ---
                 list[to_do_list_phone, 
                      resume_df,
                      resume_data] <- update_resume_df(to_do_list_phone, 
                                                       resume_df, 
                                                       resume_data_clean_numbers)
                 
                 # --- Begin phone search for tesseract OCR data for unmatched applicants ---
                 list[to_do_list_phone_ocr, 
                      resume_df_ocr,
                      resume_data_ocr] <- update_resume_df(to_do_list_phone_ocr, 
                                                           resume_df_ocr, 
                                                           resume_data_clean_numbers_ocr)
                 
                 incProgress(0.1)
                 
                 
                 
                 ### Collapse resume data frame ----
                 
                 # --- Begin collapse resume data frame for pdf_text data ---
                 resume_df_transformed <- collapse_resume_df(resume_data, 
                                                             resume_df)
                 
                 # --- Begin collapse resume data frame for tesseract OCR data ---
                 resume_df_transformed_ocr <- collapse_resume_df(resume_data_ocr, 
                                                                 resume_df_ocr)
                 
                 incProgress(0.1)
                 
                 
                 
                 ### Compare pdf_text split to tesseract OCR split ----
                 list[resume_df_transformed_final ,
                      glued_list] <- compare_text_OCR(resume_data, 
                                                      resume_df_transformed, 
                                                      to_do_list_phone, 
                                                      resume_df_transformed_ocr, 
                                                      to_do_list_phone_ocr, 
                                                      usas_report_names())
                 
                 incProgress(0.1)
                 
                 Processed_df(resume_df_transformed_final)
                 
                 unmatched_df(glued_list)
                 
                 new <- Sys.time() - old
                 
                 print(new)
                 
               })
    
    
    ### Notifications and infoBox ----
    
    number_processed <- nrow(Processed_df())
    
    number_unmatched <- nrow(unmatched_df())
    
    total_candidates <- number_processed + number_unmatched
    
    output$matched_candidates_ui <- renderUI({
      

      ### Matched Candidates ----
      fluidRow(
        box(
          width = 12,
          title = 'Candidates Found in Resumes PDF',
          
          column(
            width=12,
            valueBoxOutput('candidates_found_box')),
          
          column(width=12,
                 dataTableOutput("matched_candidates_table"))
      )
      )
      
    })
    
    output$candidates_processed <- renderValueBox({
      valueBox(
        total_candidates, "Total Candidates", icon = icon("user"),
        color = "teal"
      )
    })
    
    output$pages_processed <- renderValueBox({
      valueBox(
        length(resume_data_pdf_text), 
        "Resume Pages Processed", 
        icon = icon("file-pdf"),
        color = "aqua"
      )
    })
    
    output$candidates_found_box <- renderValueBox({
      valueBox(
        number_processed, 
        "Candidates Found in PDF", 
        icon = icon("user-check"),
        color = "green"
      )
    })
    
    output$candidates_not_found_box <- renderValueBox({
      valueBox(
        number_unmatched, 
        "Candidates NOT Found in PDF", 
        icon = icon("user-slash"),
        color = "red"
      )
      
    })
    
    
    ### Render Unmatched Table ----
    output$unmatched_candidates_table <- renderDataTable({
      datatable(unmatched_df(), 
                options = list(scrollX=TRUE,
                               columnDefs = list(list(visible=FALSE, targets=c(1, 5, 6, 9 )))),
                select='none',
                editable=list(target='cell', disable = list(columns=c(seq(1, ncol(unmatched_df())-3), ncol(unmatched_df()))))
      )
    })
    
    ### Render matched candidates table ----
    output$matched_candidates_table <- renderDataTable({
      datatable(Processed_df(), 
                options = list(scrollX=TRUE),
                select='none'      )
    })
    
    ### Set sliderInput based on number of candidates
    
    output$n_applicants_slider <- renderUI({
      
      sliderInput("n_applicants", 
                  "Number of Top Applicants to Display", 
                  min=1, 
                  max=nrow(Processed_df()), 
                  value = nrow(Processed_df()),
                  step=1,
                  # ticks=FALSE,
                  width='90%')
    
    })
    
  })
  
  ## Split Resumes ----
  
  
  ### Save Individual resumes ----
  observeEvent(input$split, {
    
    req(Processed_df())
    req(pdf_path())
    
    split_files(save_individual_resumes(pdf_path, Processed_df()))
    
    output$resume_download_button <- renderUI({
      
      list(
        column(
          width=12,
        hr(),
           p(strong('Resumes have been successfully split. You may now download them
               to view offline if desired.')),
      
      downloadButton("downloadzip", "(Optional) Download individual\n Resumes")
      )
      )
    })
    
  })
  
  ## Score Resumes ----
  
  
  ### Determine the best text extraction function ----
  
  observeEvent(input$find_best_extraction, {
    
    
    
    req(Processed_df())
    
    list[best_ngrams, best_ngrams_by_resume] <- find_optimum_function(split_files(),
                                                                      pdf_text_ngrams(), 
                                                                      pdf_text_ngrams_list(),
                                                                      tess_ocr_ngrams(),
                                                                      tess_ocr_ngrams_list(),
                                                                      resume_keywords_df(),
                                                                      Processed_df())
    
    resume_ngrams(best_ngrams)
    
    resume_ngrams_by_resume(best_ngrams_by_resume)
    
    # Run BoW Analysis ----
    
    ## Load the resume pdf data and user defined keywords ----
    list[resumes_unlisted,count_df] <- bow(resume_keywords_df(), 
                                           resume_ngrams_by_resume())
    
    ## Create and clean the text corpus ----
    
    resumes_unlisted <- create_clean_corpus(resumes_unlisted)
    
    ## Tokenize text and filter ----
    
    final_df <- tokenize(resumes_unlisted, 
                         resume_keywords_df(), 
                         split_files())
    
    # Overwriting resumeLength in count_df since length is 1
    count_df$resumelength <- Processed_df()$resumeLength
    
    if(nrow(final_df)==0){
      

      output$no_keyword_matches <- renderUI({
        
        list(
        hr(),
        strong('No keywords were found in the resume PDF. Check that the correct keyword file was uploaded. ',
               style="color:red")
        )
      })
      
    }else{
      
      output$no_keyword_matches <- renderUI({})
    
    
    list[scores_df_binary, 
         scores_df_binary_weighted, 
         outputdf2, 
         outputdf3, 
         outputdf4] <- aggregate_normalize_score(resume_keywords_df(), 
                                                 final_df, 
                                                 count_df,
                                                 split_files(), 
                                                 name_table())
    
    scored_resumes_df(scores_df_binary)
    
    filtered_candidate_table(remove_na_columns(scored_resumes_df()))
    
    scored_resumes_weighted_df(scores_df_binary_weighted)
    
    score_detailed_df(outputdf2)
    
    # Creating concatenated keywords matched data frame
    matched_keywords_df(score_detailed_df() %>% 
      group_by(email, category) %>% 
      mutate(keywords_matched = paste0(keywords, collapse = "; ")) %>%
        distinct(email,category, keywords_matched))
    
    score_proportion_df(outputdf3)
    score_proportion_weighted_df(outputdf4)
    
    
    ### Output Scored Table ----
    output$scored_table <- renderDataTable({
      
      df<-remove_na_columns(scored_resumes_df())
      targets <- which(colnames(df) %in% c("Application Locations","Application Grade Info", "Vacancy Job Title", "Cert Info"))
      
      datatable(df, 
                plugins = "ellipsis",
                options = list(scrollX=TRUE,
                               select='none',
                               columnDefs = list(list(
                                 targets = targets,
                                 render = JS("$.fn.dataTable.render.ellipsis( 17, false )")
                               ))
                ))
    })
    
    ### Output Scored Table (Weighted) ----
    output$scored_weighted_table <- renderDataTable({
      
      df<-remove_na_columns(scored_resumes_weighted_df())
      targets <- which(colnames(df) %in% c("Application Locations","Application Grade Info", "Vacancy Job Title", "Cert Info"))
      
      datatable(df, 
                plugins = "ellipsis",
                options = list(scrollX=TRUE,
                               select='none',
                               columnDefs = list(list(
                                 targets = targets,
                                 render = JS("$.fn.dataTable.render.ellipsis( 17, false )")
                               ))
                ))
    })
    
    ### Output Detailed Frequency Table ----
    output$score_detailed_table <- renderDataTable({
      
      df<-remove_na_columns(outputdf2)
      targets <- which(colnames(df) %in% c("Application Locations",
                                           "Application Grade Info", 
                                           "Vacancy Job Title", 
                                           "Cert Info"))
      
      datatable(df, 
                options = list(scrollX=TRUE,
                               select='none',
                               plugins = "ellipsis",
                               columnDefs = list(list(
                                 targets = targets,
                                 render = JS("$.fn.dataTable.render.ellipsis( 17, false )")
                               ))
                ))
    })
    
    ### Output Proportion Table ----
    output$score_proportion_table <- renderDataTable({
      datatable(outputdf3[,colSums(is.na(outputdf3))<nrow(outputdf3)], 
                options = list(scrollX=TRUE,
                               select='none'))
    })
    
    ### Output Proportion Table (Weighted) ----
    output$score_proportion_weighted_table <- renderDataTable({
      datatable(outputdf4[,colSums(is.na(outputdf4))<nrow(outputdf4)], 
                options = list(scrollX=TRUE,
                               select='none'))
    })
    
    #### Render Weight Radio Buttons
    
    #### Download Buttons for Score Tables ----
    output$score_weighting_buttons <- renderUI({
      
      list(
        
        br(),

        radioButtons( 
          inputId = "weighting_score_table_button", 
          label = "Keyword Weighting", 
          choices = list( 
            "Weighted" = "weighted",
            "Unweighted" =  "unweighted"
            
          ),
          selected = "unweighted",
          inline=T
        ),
        
        br()
      )
        
    })
    
    #### Download Buttons for Score Tables ----
    output$scored_tables <- renderUI({
      
      
      req(input$weighting_score_table_button)
      
      if (input$weighting_score_table_button == "unweighted"){
        
      tabBox(
        width=12,
        
        tabPanel("Score Frequency",
                 dataTableOutput("scored_table")
        ),
        
        tabPanel("Detailed Frequency",
                 dataTableOutput("score_detailed_table")
                 ),
        tabPanel("Proportion",
                 dataTableOutput("score_proportion_table")
                 )
      )
        }else{
          
                    tabBox(
            width=12,
                tabPanel("Score Frequency (Weighted)",
                 dataTableOutput("scored_weighted_table")
        ),
        
        tabPanel("Detailed Frequency",
                 dataTableOutput("score_detailed_table")
                 ),
        
        tabPanel("Proportion (Weighted)",
                 dataTableOutput("score_proportion_weighted_table")
                 )
        
      )
        }
    })
    
    
    ### Creation of Plots ----
    
    ### Bar Chart ----
    
    output$bar_chart <- renderPlotly({
      
      req(input$n_applicants)
      req(input$stacked_button)
      req(input$weighting_button)
      
      if (input$weighting_button == "unweighted"){
        
        if(all(selected_applicants()==c(""))){
          df <- head(scored_resumes_df() %>%
                       arrange(desc(`Total Score`)) %>%
                       filter(grepl(selected_state(), `Application Locations`)),
                     n_applicants_reactive())
        
        }else{
          
          df <- head(scored_resumes_df() %>%
                       arrange(desc(`Total Score`)) %>%
                       filter(grepl(selected_state(), `Application Locations`)) %>%
                       filter(email %in% selected_applicants()),
                     n_applicants_reactive()) 
        }
        
        if(all(selected_state()!=c(""))){
          title <- sprintf('Top Applicants By Score (Unweighted) in %s',  state.name[grep(selected_state(), state.abb)] )
        }else{
          title <- 'Top Applicants By Score (Unweighted)'
        }
        
      }else{
        if(all(selected_applicants()!=c(""))){
          
        df <- head(scored_resumes_weighted_df() %>%
                     arrange(desc(`Total Score`)) %>%
                     filter(grepl(selected_state(), `Application Locations`)) %>%
                     filter(email %in% selected_applicants()),
                   n_applicants_reactive()) 
        }else{
          df <- head(scored_resumes_weighted_df() %>%
                       arrange(desc(`Total Score`)) %>%
                       filter(grepl(selected_state(), `Application Locations`)),
                     n_applicants_reactive()) 
        }
        
        if(all(selected_state()!=c(""))){
          title <- sprintf('Top Applicants By Score (Weighted) in %s',  state.name[grep(selected_state(), state.abb)] )
        }else{
          title <- 'Top Applicants By Score (Weighted)'
        }
      }
      
      
      filtered_candidate_table(remove_na_columns(df))
      
      if (input$tabs == "visualization"){

        if(nrow(df)==0){
          
          plot_ly(
            x=1,
            y=1,
            text="No candidates are available for the selected State",
            type='scatter',
            textfont=list(size=30)
          ) %>%
            layout(xaxis=list(showgrid=FALSE,
                              zeroline=FALSE,
                              showticklabels=FALSE),
                   yaxis= list(showgrid=FALSE,
                               zeroline=FALSE,
                               showticklabels=FALSE),
                   title = "",
                   dragmode='select')

        }else{
        
        df$full_name <- paste(df$`Applicant First Name`,  
                              df$`Applicant Last Name`, 
                              '\n', 
                              df$email)
        
        categories <- as.vector(resume_keywords_df() %>%
                                  distinct(category))
        
        melted <- df %>%
          melt(measure.vars=categories[[1]]) %>%
          left_join(matched_keywords_df(), by=c('email'='email', 'variable'='category'))

        if (input$stacked_button=='basic'){
          
          plot_ly(df, 
                  x = ~full_name, 
                  y = ~`Total Score`, 
                  type = 'bar',
                  source='bar_chart') %>%
            layout(bargap = 0.5,
                   title = title,
                   plot_bgcolor = "#e5ecf6", 
                   xaxis = list(title = 'Applicant Name and Email', 
                                categoryorder = "total descending",
                                tickangle = 0
                   ), 
                   yaxis = list(title = 'Total Score'),
                   dragmode='select') %>%
            event_register('plotly_click')
            
        }else if(input$stacked_button=='category'){
          
          plot_ly(melted, 
                  x = ~full_name, 
                  name = ~variable,
                  y=~value, 
                  type = 'bar',
                  textangle = 0,
                  hovertext = ~paste0("Category: ", variable, "<br>", "Score: ", value, "<br><br>", "Keywords: ",keywords_matched),
                  hoverinfo = "text",
                  text=~variable,
                  source='bar_chart'
                  ) %>%
            layout(bargap = 0.5,
                   barmode = 'stack',
                   hoverlabel = list(align = "left"),
                   title = title,
                   plot_bgcolor = "#e5ecf6", 
                   xaxis = list(title = 'Applicant Name and Email', 
                                categoryorder = "total descending",
                                tickangle = 0
                   ), 
                   yaxis = list(title = 'Total Score'),
                   showlegend = FALSE,
                   dragmode='select') %>%
            event_register('plotly_click')
          
        }else{}
        }
      }
      
      
    })
    
    # #### Creation of data for maps ----
    # 
    # # GDI data
    # gdi_data({
    #   
    #   scored_resumes_df <- scored_resumes_df()
    #   
    #   gdi_data <- read_excel('www/jimsconsdataplus-2025-03-31072930.425.xlsx', skip=2) %>%
    #     filter(!is.na(Latitude))
    #   
    #   gdi_data$city_state <- paste0(str_to_title(gdi_data$City), ", ", gdi_data$State)
    #   
    #   gdi_data$Vacant_color <- gdi_data$`Vacant Workstation Count`
    #   
    #   gdi_data$Vacant_color[gdi_data$Vacant_color==0] <- 0.1
    #   
    #   chosen_cities <- scored_resumes_df$`Application Locations`
    #   
    #   # Extracting the list of "city, state" pairs
    #   chosen_cities_extracted <- str_extract_all(chosen_cities, "([^,| ]+[^,|]+), ([A-Z]{2})")
    #   
    #   scored_resumes_df$chosen_cities <- chosen_cities_extracted
    #   
    #   #function to extract candidate info to apply to each city
    #   return_candidates<- function(gdi_city_state){
    #     
    #     output <- scored_resumes_df %>%
    #       filter(str_detect(`Application Locations`, gdi_city_state)) %>% # gdi_data$city_state[[333]]
    #       mutate(applicant_info = paste0("Applicant Name: ", `Applicant First Name`, " ",`Applicant Last Name`, "<br>",
    #                                      "Email:", email))
    #     
    #     output_string <- paste(output$applicant_info, collapse = "<br><br>")
    #     
    #     return(output_string)
    #     
    #   }
    #   
    #   gdi_data <- gdi_data %>%
    #     mutate(Candidates= lapply(city_state, return_candidates))
    #   
    # })
    # 
    # 
    # ### Storing GIS layer reactives
    # conus_gdi_selected_sf({
    #   
    #   conus_selected <- gdi_data() %>%
    #     filter(State!='HI') %>%
    #     filter(State!='AK') %>%
    #     filter(State!='PR') %>%
    #     filter(State!='VI') %>%
    #     filter(Candidates!="")
    #   
    #   st_as_sf(conus_selected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    #   
    # })
    # 
    # hi_gdi_selected_sf({
    #   
    #   hi_gdi_selected <- gdi_data() %>%
    #     filter(State=='HI') %>%
    #     filter(Candidates!="")
    #   
    #   st_as_sf(hi_gdi_selected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    # })
    # 
    # ak_gdi_selected_sf({
    #   
    #   ak_gdi_selected <- gdi_data() %>%
    #     filter(State=='AK') %>%
    #     filter(Candidates!="")
    #   
    #   st_as_sf(ak_gdi_selected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    # })
    # 
    # conus_gdi_unselected_sf({
    #   
    #   conus_unselected <- gdi_data() %>%
    #     filter(State!='HI') %>%
    #     filter(State!='AK') %>%
    #     filter(State!='PR') %>%
    #     filter(State!='VI') %>%
    #     filter(Candidates=="")
    #   
    #   st_as_sf(conus_unselected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    #   
    # })
    # 
    # hi_gdi_unselected_sf({
    #   
    #   hi_gdi_unselected <- gdi_data() %>%
    #     filter(State=='HI') %>%
    #     filter(Candidates=="")
    #   
    #   st_as_sf(hi_gdi_unselected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    #   
    # })
    # 
    # ak_gdi_unselected_sf({
    #   
    #   ak_gdi_unselected <- gdi_data() %>%
    #     filter(State=='AK') %>%
    #     filter(Candidates=="")
    #   
    #   st_as_sf(ak_gdi_unselected, coords = c("Longitude", "Latitude"), crs = st_crs(4296))
    #   
    # })
    # 
    # ### Map ----
    # 
    # list[conus_ggplotly, hi_ggplotly, ak_ggplotly] <- create_candidate_map(conus_states_shp(),
    #                                                                        hi_states_shp(),
    #                                                                        ak_states_shp(),
    #                                                                        conus_gdi_selected_sf(),
    #                                                                        hi_gdi_selected_sf(),
    #                                                                        ak_gdi_selected_sf(),
    #                                                                        conus_gdi_unselected_sf(),
    #                                                                        hi_gdi_unselected_sf(),
    #                                                                        ak_gdi_unselected_sf())
    # 
    # 
    # 
    # conus_plotly_data(conus_ggplotly)
    # ak_plotly_data(ak_ggplotly)
    # hi_plotly_data(hi_ggplotly)
    # 
    # # Rendering the CONUS plotly map
    # output$candidate_map_conus <- renderPlotly({
    #   
    #   conus_ggplotly %>%
    #     event_register('plotly_click')
    # })
    # 
    # # Rendering the Hawaii plotly map
    # output$candidate_map_hi <- renderPlotly({
    #   hi_ggplotly %>%
    #     event_register('plotly_click')
    # })
    # 
    # # Rendering the Alaska plotly map
    # output$candidate_map_ak <- renderPlotly({
    #   ak_ggplotly %>%
    #     event_register('plotly_click')
    # })
    
    # Add Table Download Button
    output$score_resumes_button <- renderUI({
      
      list(
      actionButton('find_best_extraction', 
                   'Score Resumes',
                   class= "btn-success btn-lg",
                   style = "color: white;"),
      
      downloadButton("download_score_excel_output", 
                     "Download Output Tables",
                     class='btn-warning btn-lg') # actionButton("download_score_excel_output", "Download Table"),

      )
      
    })
    }
    
  })
  
  # Download Functions ----
  
  ## Keywords Example ----
  output$download_keywords_example <- downloadHandler(
    filename =function() {
      paste("bow-keywords-example.csv")
    },
    
    content = function(file) {
      
      file.copy("www/bow-keywords-example.csv", file)
      
    }
  )
  
  ## Keywords Example 2 ----
  output$download_keywords_example2 <- downloadHandler(
    filename =function() {
      paste("bow-keywords-example.csv")
    },
    
    content = function(file) {
      
      file.copy("www/bow-keywords-example.csv", file)
      
    }
  )
  
  ## Individual Resumes ----
  output$downloadzip <- downloadHandler(
    filename =function() {
      paste0("split_pdfs_", Sys.Date(), ".zip")
    },
    
    content = function(file) {
      
      split_files <- save_individual_resumes(pdf_path, Processed_df())
      
      zip(file, getRelativePath(split_files), mode = 'cherry-pick')
      
    }
  )
  
  ## Download Selected Candidates ----
  output$download_selected_candidates <- downloadHandler(
    filename =function() {
      sprintf("select_candidates_%s_%s.zip", pdf_file_name(), Sys.Date())
    },
    
    content = function(file) {
      
      if (is.null(input$selected_candidate_table_rows_selected)){
        selected_indices <- input$selected_candidate_table_rows_all
        
      }else{
        selected_indices <- input$selected_candidate_table_rows_selected
      }
      
      selected_candidates_email <- scored_resumes_df()[selected_indices,]$email
      
      top_Processed_df <- Processed_df() %>%
        filter(email %in% selected_candidates_email)
      
      split_files <- save_individual_resumes(pdf_path, top_Processed_df)
      
      zip(file, getRelativePath(split_files), mode = 'cherry-pick')
      
    }
  )
  
  
  
  ## Top Resumes from Slider ----
  output$download_resumes_from_slider <- downloadHandler(
    filename =function() {
      sprintf("top_%s_candidates_%s_%s.zip", n_applicants_reactive(), pdf_file_name(), Sys.Date())
    },
    
    content = function(file) {
      
      top_candidates_email <- scored_resumes_df() %>%
        arrange(desc(`Total Score`)) %>%
        slice_head(n=n_applicants_reactive()) %>%
        pull(email)
      
      top_Processed_df <- Processed_df() %>%
        filter(email %in% top_candidates_email)
      
      split_files <- save_individual_resumes(pdf_path, top_Processed_df)
      
      zip(file, getRelativePath(split_files), mode = 'cherry-pick')

    }
  )
  
  ## Edited weights ----
  output$download_keywords <- downloadHandler(
    filename =function() {
      paste("edited_bow_keywords_", Sys.Date(), ".csv")
    },
    
    content = function(file) {
      req(resume_keywords_df)
      
      # Get edited keywords from the reactive value
      edited_keywords <- resume_keywords_df()
      
      write.csv(edited_keywords, file, row.names = FALSE)
    }
  )
  
  ## Score Tables Download ----
  
  output$download_score_excel_output <- downloadHandler(
      filename =function() {
        
        sprintf("%s-%s-%s-ResumeRank.xlsx", Sys.Date(), pdf_file_name(), input$weighting_score_table_button)
        
      },
      
      content = function(file) {
        
        if(input$weighting_score_table_button=='unweighted'){
          wb <- output_score(scored_resumes_df(), 
                             score_detailed_df(),
                             score_proportion_df(), 
                             resume_keywords_df()
          )
        }else if(input$weighting_score_table_button=='weighted'){
          wb <- output_score(scored_resumes_weighted_df(), 
                             score_detailed_df(),
                             score_proportion_weighted_df(), 
                             resume_keywords_df()
          )
        }
        
        saveWorkbook(wb, file, overwrite = TRUE)
        
      }
    )
}
