
search_identifier <- function(resume_data, resume_df, resume_df_global, usas_report_names, to_do_list, search_variable){
  for (i in 1:length(resume_data)) {
    
    
    #get basic page data
    page_number <- i
    characters_per_page <- str_count(resume_data[i])
    
    #add page properties to resume data frame
    resume_df <- resume_df %>%
      add_row(
        pageNumber = page_number,
        charactersPerPage = characters_per_page
      )
    
    #reset flags
    usas_names_detected <- 0
    app_match_count <- 0  
    
    #search for first/last name matches
    for (x in 1:nrow(usas_report_names)) {
      
      #reset variables
      first_name_loc = 0
      last_name_loc = 0
      loc_diff = 0
      
      #patterns
      first_name_pattern <- paste(c("(?<![:alpha:])", usas_report_names$firstName[x], "(?![:alpha:])"), collapse = "")
      last_name_pattern <-  paste(c("(?<![:alpha:])", usas_report_names$lastName[x], "(?![:alpha:])"), collapse = "")
      
      #check if both first name and last name are on the resume page
      if (str_detect(resume_data[i], first_name_pattern) && str_detect(resume_data[i], last_name_pattern)) {
        
        #get the location of the first name
        first_name_loc <- str_locate(resume_data[i], first_name_pattern)
        
        #get the location of the second name
        last_name_loc <- str_locate(resume_data[i], last_name_pattern)
        
        #calculate the distance between first and last name
        loc_diff <- last_name_loc - first_name_loc
        
        #check positioning of names
        if (
          #check if first name is listed at the top of the page# DOES THIS NEED TO BE CHANGED FOR OUR 2000 PAGE PACKETS?
          first_name_loc[1] < 400 &&
          
          #check if resume is a USAJobs "Reference" page
          !str_detect(resume_data[i], "references:") &&
          
          #check if first and last name are in correct order
          loc_diff[1] > 0 && 
          
          #check if firt and last name are a reasonable distance apart from each other 
          loc_diff[1] < 50 ) {
          match <- TRUE
          app_match_count <- app_match_count + 1
        } else {
          match <- FALSE
        }
      } else {
        match <- FALSE
      }
      
      #write data to resume data frame for first match that is found.  
      if(match == TRUE && app_match_count == 1) {
        
        resume_df$firstName[i] <- usas_report_names$firstName[x]
        resume_df$firstNameLoc[i] <- first_name_loc
        resume_df$lastName[i] <- usas_report_names$lastName[x]
        resume_df$lastNameLoc[i] <- last_name_loc
        resume_df$nameLocDiff[i] <- loc_diff
        resume_df$email[i] <- usas_report_names$email[x]
        
        #remove record from to-do tacking list
        #to_do_list <- to_do_list %>% filter(firstName != usas_report_names$firstName[x] & lastName != usas_report_names$lastName[x])
        to_do_list <- to_do_list %>% filter(email != usas_report_names$email[x]) #filter using the email because lastname can be the same for some applicants.
      } 
      
      if (search_variable == 'name'){
      
      #if a resume page already has a match, only increase the app_match_count and do not overwrite the data
      if (match == TRUE ) {
        resume_df$usasNamesDetected[i] <- app_match_count
      }
      }else{
        if (match == TRUE ) {
          
          resume_df_global$usasNamesDetected[i] <- app_match_count
        }
      }
      
    } 
  } 
  return(list(resume_df_global, resume_df, to_do_list))
  
}