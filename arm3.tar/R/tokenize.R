
tokenize <- function(resumes_unlisted, resume_keywords, split_files){
  
  #Tokenization involves dividing big chunks of text into smaller parts called
  #tokens. This is done by removing or isolating characters like whitespaces
  #and punctuation characters.
  
  # Using quanteda package for unigram/bigram tokenizer. 
  unigrams_raw <- quanteda::tokens(resumes_unlisted, #tokens() only works on character, corpus, list, tokens objects
                                   remove_numbers = TRUE,
                                   remove_punct=TRUE,
                                   remove_symbols = TRUE,
                                   remove_separators = TRUE,
  ) 
  
  unigrams_raw <- tokens_remove(unigrams_raw,stopwords("en"))
  
  keywords_csv <- as.character(resume_keywords$keyword) #BoW keywords that will be matched with resume
  
  #VECTORIZE/Lapply THE LOOP FOR SPEED
  x <- lapply(unigrams_raw,table) #seems like a table is needed before data frame is created
  y <- lapply(x, as.data.frame)
  
  resumes <- bind_rows(y,.id="column_lab") #combine all the dataframe elements of the list
  unifiltered_df <- resumes %>% filter(Var1 %in% keywords_csv) #filter dataframe to only rows that match keywords
  #VECTORIZE/Lapply THE LOOP FOR SPEED
  
  colnames(unifiltered_df)[colnames(unifiltered_df) == "Var1"] = "keywords"
  
  #BIGRAM: create counts of bigrams within resume.
  bigrams_raw <- quanteda::tokens_ngrams(unigrams_raw, n = 2:4, concatenator = " ")
  
  #VECTORIZE/Lapply THE LOOP FOR SPEED
  currentTs <- Sys.time()
  
  x2 <- lapply(bigrams_raw,table) #seems like a table is needed before data frame is created
  y2 <- lapply(x2, as.data.frame)
  
  biresumes <- bind_rows(y2,.id="column_lab") #combine all the dataframe elements of the list
  bifiltered_df <- biresumes %>% filter(Var1 %in% keywords_csv) #filter dataframe to only rows that match keywords
  #test fuzzy matching here.
  
  
  elapsed <- Sys.time() - currentTs
  print(elapsed)
  #VECTORIZE/Lapply THE LOOP FOR SPEED
  
  colnames(bifiltered_df)[colnames(bifiltered_df) == "Var1"] = "keywords"
  
  final_df <- rbind(unifiltered_df,bifiltered_df) # combine unigram and bigram dataframes
  final_df <- mutate(final_df, Freq_binary = case_when(Freq>0 ~ 1, Freq<=0 ~ 0))
  
  filename_df <- as.data.frame(split_files) #create data frame to include file name
  filename_df$column_lab <- paste0("content",seq(1:length(split_files)),sep = "") #create column_lab for merging
  
  final_df <- merge(final_df,filename_df, by.x = 'column_lab', by.y = "column_lab") #merge in file name
  
  return(final_df)
  
  
}