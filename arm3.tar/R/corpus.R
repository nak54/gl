create_clean_corpus <- function(resumes_unlisted){

#CHUNK 2: Create and clean the text corpus. ####################################
resumes_corp <- Corpus(VectorSource(resumes_unlisted)) # create a corpus. This allows for more data cleaning options.
resumes_corp_v <- VCorpus(VectorSource(resumes_unlisted)) #Must use VCorpus to use the BigramTokenizer() function

# DATA CLEANING: Cleaning the text to take out all of the stop words and numbers. NOTE: order of data cleaning is important.
toSpace2<-content_transformer(function(x, pattern) gsub(pattern, " ",x)) #This will NOT make a space for when it takes something out
resumes_corp<-tm_map(resumes_corp,toSpace2,"\\(") #This takes out open parentheses

toSpace<-content_transformer(function(x, pattern) gsub(pattern, " ",x)) #This will make a space for when it takes something out
resumes_corp<-tm_map(resumes_corp,toSpace,"\\\\n") #This takes out new line "\\n"
resumes_corp<-tm_map(resumes_corp,toSpace,"\\\n") #This takes out new line "\n"
resumes_corp<-tm_map(resumes_corp,toSpace,"\\\\r") #This takes out return "\\r"
resumes_corp<-tm_map(resumes_corp,toSpace,"\\\\t") #This takes out tab "\\t"
resumes_corp<-tm_map(resumes_corp,toSpace,"-") #This takes out tab "\\t"

toSpace2<-content_transformer(function(x, pattern) gsub(pattern, "",x)) #This will NOT make a space for when it takes something out
resumes_corp<-tm_map(resumes_corp,toSpace2,"'") #This takes out apostrophe

removeSpecialChars <- function(x) gsub("[^0123456789a-zA-Z++#&/ ]","",x) # Remove everything that is not alphabetic symbol or ++ (e.g., [^a-zA-Z0-9])
resumes_corp <- tm_map(resumes_corp, removeSpecialChars)

resumes_corp<-tm_map(resumes_corp, content_transformer(tolower)) #Formatting to lower case
#COMMENTING OUT BELOW LINE BECAUSE KEYWORDS INCLUDE STOP WORDS.
#resumes_corp<- tm_map(resumes_corp, removeWords, stopwords("english")) #This removes stop words such as "a", "the"...
resumes_corp<- tm_map(resumes_corp, stripWhitespace) #This removes extra white space

#Can also remove specific words...currently not used but kept for future.
#Unwanted_Words <- c("get", "dont", "march", "april", "may") #add words to this list that you want removed
#Unwanted_Words <- as.character(unlist(read.csv("/home/hvbvb/LBI-Data-Solutions/Resume-Screening-Tool/Input/Unwanted_Words.csv")))
#resumes_corp<- tm_map(resumes_corp, removeWords, Unwanted_Words ) #You can also remove other words that you dont want

resumes_unlisted <- unlist(resumes_corp) #unlist the corpus for use in the tokens() function
resumes_unlisted["content3"] #check output
length(resumes_unlisted) #note, previous steps adds a "NA" element at the end. 

return(resumes_unlisted)

}
