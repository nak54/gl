#### 2.1 Apply pdf_text and tesseract OCR to the pdf file ------------------

parse_pdfs <- function(input, max_num_cores){
  
  n_pages <- pdf_info(input$pdffile$datapath)$pages
  mins_per_page_min <- 0.2/60
  mins_per_page_max <- 1/60
  
  time_estimate_min <- round(n_pages*mins_per_page_min, 1)
  time_estimate_max <- round(n_pages*mins_per_page_max, 1)
  
  likely_time <- round((-0.09*log(n_pages)+0.9772)*n_pages/60, 1)
  
  # Add a progress bar for the OCR process
  withProgress(message = sprintf('Processing the resumes PDF and extracting the text. \n\n
               This step should take appoximately: \n %s to %s minutes and likely %s minutes.', time_estimate_min, time_estimate_max, likely_time), value = 0, {
    
    
    # Apply tesseract OCR to the pdf file
    # --- Begin Parallel Processing for pdf OCR ---

    # Storing the number of pages in the PDF file and its path to send to cluster
    n_pages <- pdf_info(input$pdffile$datapath)$pages
    pdf_file <- input$pdffile$datapath
    
    # Determining how many cores to use when splitting PDFs
    if (n_pages<max_num_cores){
      num_cores <- n_pages
    }else{
      num_cores <- max_num_cores
    }
    
    # Reducing cores if system is CPU-limited
    if (detectCores()<num_cores){
      num_cores = detectCores()-1
    } 
    
    # browser()
    
    # Set up parallel backend
    cl <- makeCluster(num_cores)
    registerDoParallel(cl)
    
    # Convert all PDF pages to PNG in parallel  
    pngfile_list <- foreach(page = 1:n_pages, 
                          .packages = c('pdftools')) %dopar% {  
                            
                            # Convert single page to PNG  
                            pdf_convert(pdf_file,  
                                        format = "png",  
                                        pages = page,  
                                        dpi = 600,
                                        filenames=file.path(dirname(pdf_file), sprintf('%s.png', page)))  
                          }
    
    incProgress(0.6)
    
    clusterExport(cl, c("pdf_convert","ocr", "unlink")) # Export the "function" to all cluster nodes. ocr() to extract text.
    
    # Running pdf_text in parallel
    result_pdf_text <- str_to_lower(pdf_text(input$pdffile$datapath))
    pdf_text_ngrams_list <- result_pdf_text
    pdf_text_ngrams<- unlist(tolower(result_pdf_text))
    incProgress(0.1)
    
    # Running tesseract OCR in parallel 
    result_tess  <- parSapply(cl, pngfile_list, ocr)
    tess_ocr_ngrams_list<- result_tess
    tess_ocr_ngrams <- lapply(result_tess, function(x){ paste(x, collapse = " ")})
    tess_ocr_ngrams <- unlist(tolower(tess_ocr_ngrams))
    incProgress(0.1)
    
    # Remove the PNG images
    file.remove(unlist(pngfile_list))
    incProgress(0.1)
    
    # stop the cluster when done
    stopCluster(cl)

})
  
  # Lowercase the OCR text output.
  resume_data_pdf_text_ocr <- str_to_lower(result_tess)
  resume_data_pdf_text <- str_to_lower(result_pdf_text)
  
  incProgress(0.1)
  
  
  return(list(resume_data_pdf_text, 
              resume_data_pdf_text_ocr, 
              pdf_text_ngrams, 
              pdf_text_ngrams_list, 
              tess_ocr_ngrams, 
              tess_ocr_ngrams_list))
  
}