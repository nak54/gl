remove_na_columns <- function(df){
  
  return(df[,colSums(is.na(df))<nrow(df)])
}