

compare_text_OCR <- function(resume_data, resume_df_transformed, to_do_list_phone, resume_df_transformed_ocr, to_do_list_phone_ocr, usas_report_names){
  
  resume_pages_pdf_text <- resume_df_transformed
  resume_pages_pdf_text_ocr <- resume_df_transformed_ocr
  
  unmatched_pdf_text <- to_do_list_phone
  unmatched_pdf_text_ocr <- to_do_list_phone_ocr
  
  unmatched_joined <- merge(unmatched_pdf_text, unmatched_pdf_text_ocr, by.x = "email", by.y = "email", all= FALSE)
  
  OCR_PDF_TEXT_joined <- merge(resume_pages_pdf_text, resume_pages_pdf_text_ocr, by.x = "email", by.y = "email", all= TRUE)
  
  Final1 <- OCR_PDF_TEXT_joined[#(OCR_PDF_TEXT_joined$resumeLength.x>=OCR_PDF_TEXT_joined$resumeLength.y) &
    (OCR_PDF_TEXT_joined$startPage.x<=OCR_PDF_TEXT_joined$startPage.y) &
      !is.na(OCR_PDF_TEXT_joined$resumeLength.x) &
      !is.na(OCR_PDF_TEXT_joined$resumeLength.y),1:4]
  Final2 <- OCR_PDF_TEXT_joined[#(OCR_PDF_TEXT_joined$resumeLength.x<OCR_PDF_TEXT_joined$resumeLength.y) &
    (OCR_PDF_TEXT_joined$startPage.x>OCR_PDF_TEXT_joined$startPage.y) &
      !is.na(OCR_PDF_TEXT_joined$resumeLength.x) &
      !is.na(OCR_PDF_TEXT_joined$resumeLength.y),c(1,7:9)]
  Final3 <- OCR_PDF_TEXT_joined[is.na(OCR_PDF_TEXT_joined$resumeLength.x) & !is.na(OCR_PDF_TEXT_joined$resumeLength.y),c(1,7:9)]
  Final4 <- OCR_PDF_TEXT_joined[!is.na(OCR_PDF_TEXT_joined$resumeLength.x) & is.na(OCR_PDF_TEXT_joined$resumeLength.y),1:4]
  
  Final1 <- Final1 %>%
    rename(
      firstName = firstName.x,
      lastName = lastName.x,
      startPage = startPage.x,
      #endPage = endPage.x,
      #resumeLength = resumeLength.x
    )
  
  Final2 <- Final2 %>%
    rename(
      firstName = firstName.y,
      lastName = lastName.y,
      startPage = startPage.y,
      #endPage = endPage.y,
      #resumeLength = resumeLength.y
    )
  
  Final3 <- Final3 %>%
    rename(
      firstName = firstName.y,
      lastName = lastName.y,
      startPage = startPage.y,
      #endPage = endPage.y,
      #resumeLength = resumeLength.y
    )
  
  Final4 <- Final4 %>%
    rename(
      firstName = firstName.x,
      lastName = lastName.x,
      startPage = startPage.x,
      #endPage = endPage.x,
      #resumeLength = resumeLength.x
    )
  
  resume_pages_final <- rbind(Final1,Final2,Final3,Final4)
  
  resume_df_transformed_final <- resume_pages_final[order(resume_pages_final$startPage),]
  resume_df_transformed_final$endPage <- lead(resume_df_transformed_final$startPage)-1
  #resume_df_transformed$resumeLength <- resume_df_transformed$endPage - resume_df_transformed$startPage+1
  
  ## MUST ADD CODING FOR END PAGE FOR LAST PERSON
  resume_df_transformed_final[nrow(resume_df_transformed_final),ncol(resume_df_transformed_final)] <- length(resume_data)
  resume_df_transformed_final$resumeLength <- resume_df_transformed_final$endPage - resume_df_transformed_final$startPage+1
  
  ### Step 4. Produce the glued list ----------------------------------------
  glued <- merge(usas_report_names, unmatched_joined, by.x = "email", by.y = "email", all.x=TRUE)
  glued <- glued[order(glued$lastName,glued$firstName),]
  
  index <- which(!is.na(glued$phone.y))
  
  glued_list <- as.data.frame(glued[index,1])
  colnames(glued_list) <- "email"
  
  # browser()
  
  glued_list$missingFirstName <- glued[index,5]
  glued_list$missingLastName <- glued[index,6]
  glued_list$missingEmail <- glued[index,1]
  
  glued_list <- merge(glued_list, resume_df_transformed_final, by.x = "email", by.y = "email", all.x=TRUE)
  

  return(list(resume_df_transformed_final, glued_list))
}