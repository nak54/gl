
bow <- function(resume_keywords_df, resumes_ngrams){
  
# Load the resume pdf data and user defined keywords. #################
#read in the keywords, clusters, and applicant data
resume_keywords <- resume_keywords_df %>%
  mutate(category = tolower(category)) %>%
  mutate(keyword = tolower(keyword))
  

count_df <- data.frame(column_lab = character(),
                       wordcount = integer(),
                       resumelength = integer(),
                       stringsAsFactors = FALSE)

# resumes_ngrams must be collasped to perform analysis on each individual resume
for (i in 1:length(resumes_ngrams))
{
  
  app <- resumes_ngrams[i] #parse each resume and lower case character string.
  app_collapse <- paste(app,collapse=" ") #collapse the resumes into a single char vector (one element) but keep the list

  count_df[i,1] <- paste("content",i,sep = "") #create a data frame with the total count of words for each resume.
  count_df[i,2] <- str_count(app_collapse) # Currently counts the number of characters, not words. If words, desired, add pattern='\\w+' 
  count_df[i,3] <- length(resumes_ngrams[[i]])

  resumes_ngrams[i] <- app_collapse
}

resumes_unlisted <- resumes_ngrams

#The replacement character �, a black diamond with a white question mark, is a symbol found in the Unicode standard at codepoint U+FFFD in the Specials table. 
#It is used to replace an unknown or unrepresentable character, or indicate problems when a system is not able to render a stream of data to a correct symbol
resumes_unlisted <- gsub("\uFFFD", "", resumes_unlisted, fixed=TRUE)
resumes_unlisted <- iconv(resumes_unlisted,"UTF-8","ASCII", sub = "") #convert strange unicode characters. Provides cleaner data set.


# resumes_unlisted <- unlist(resumes_ngrams) #unlist the resumes. now single character vector. Each vector element is a full resume.

return(list(resumes_unlisted, count_df))

}