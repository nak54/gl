
aggregate_normalize_score <- function(resume_keywords, final_df, count_df, split_files, name_table){
  
  # Normalize applicant email addresses for reliable joins
  name_table <- name_table %>%
    mutate(
      `Applicant Email Address` =
        str_to_lower(str_trim(`Applicant Email Address`))
    )
  
  #CHUNK 4: Aggregate, Normalize, and Score ######################################
  # merge in the categories (aka "clusters") from the user-defined "keyword dictionary"
  #collaspe category/cluster dataframe
  
  denom <- resume_keywords %>%
    group_by(category) %>%
    summarise(count = n())
  
  joined_df <- merge(final_df, 
                     resume_keywords, 
                     by.x = "keywords", 
                     by.y = "keyword", 
                     all.x = TRUE, 
                     all.y = FALSE)
  
  #ADJUST SPECIFIC KEYWORDS FOR LEVEL OF IMPORTANCE
  # joined_df$Freq_binary <- joined_df$Freq_binary*joined_df$score_adjustment
  
  joined_df <- merge(joined_df, 
                     denom, 
                     by.x = "category", 
                     by.y = "category", 
                     all.x = TRUE)
  
  joined_df <- merge(joined_df, 
                     count_df, 
                     by.x="column_lab", 
                     by.y="column_lab", 
                     all.x = TRUE)
  
  resume_length <- joined_df %>% 
    group_by(split_files) %>% 
    summarise_if(is.numeric, mean)
  
  resume_length <- resume_length[,c(1,ncol(resume_length))]
  
  create_scores_table <- function(weighted=FALSE){
    
    # Define normalized frequency: This is frequency of word occurrences relative to the number of words in the resume
    ratio <- joined_df$Freq/joined_df$wordcount # find the ratio of number of occurrences of a keyword to the total word count in resume
    min_val <- min(ratio) # get the min ratio
    max_val <- max(ratio) # get the max ratio
    joined_df$Freq_normalized <- 1+((ratio - min_val)/(max_val-min_val))*4 # apply min_max scaling and make the range to be [1,5]
    
    if (weighted){
      
      joined_df$Freq_normalized <- joined_df$Freq_normalized * joined_df$score_adjustment
    }
    
    
    # Group the data by cluster, name, and/or file. 
    clusters_ud <- joined_df %>% group_by(category, 
                                          column_lab, 
                                          split_files) %>% 
      mutate(Freq = sum(Freq), 
             Freq_normalized=sum(Freq_normalized)) %>% 
      summarise_if(is.numeric, 
                   mean)
    
    clusters_ud$adj_freq_normalized <- clusters_ud$Freq_normalized/clusters_ud$count
    
    transform_df_binary_prop <- reshape2::dcast(clusters_ud, 
                                                split_files~category, 
                                                fun=sum,
                                                value.var = "adj_freq_normalized") #collapse data
    
    transform_df_binary_prop$email <- sapply(strsplit(transform_df_binary_prop$split_files, "/"), tail, 1)
    transform_df_binary_prop$email <- unlist(strsplit(transform_df_binary_prop$email, "_resume.pdf"))
    
    transform_df_binary_prop$email <-
      str_to_lower(str_trim(transform_df_binary_prop$email))
    
    # CREATE SCORES using the min and max of total. This score would be relative to the resumes in the corpus.
    scores_df_binary <- transform_df_binary_prop
    n<-ncol(scores_df_binary) #number of columns will vary by the number of user-defined categories/clusters
    
    ################################################################################
    ################################################################################
    #Additional Percentile/SD feature generation????
    ################################################################################
    ################################################################################
    
    
    #Scoring for binary frequency
    for (i in 2:(n-1))
    {
      max <- max(scores_df_binary[i])
      factor <- 5/max 
      scores_df_binary[i] <- ceiling(scores_df_binary[i] * factor) #use round?
    }
    
    #sum up the score for each category
    
    if(n>3){
    scores_df_binary$total <- rowSums(scores_df_binary[,c(2:(n-1))]) 
    }else{
      scores_df_binary$total <- scores_df_binary[,c(2:(n-1))]
    }
    
    scores_df_binary <- scores_df_binary[order(-scores_df_binary$total),]
    
    scores_df_binary <- merge(scores_df_binary, 
                              resume_length, 
                              by.x="split_files", 
                              by.y="split_files", 
                              all.x = TRUE)
    
    #Create column for Quartiles
    qrt0 <- quantile(scores_df_binary$total, 0)
    qrt1 <- quantile(scores_df_binary$total, .25)
    qrt2 <- quantile(scores_df_binary$total, .5)
    qrt3 <- quantile(scores_df_binary$total, .75)
    qrt4 <- quantile(scores_df_binary$total, 1)
    
    scores_df_binary$quartile <- ifelse(scores_df_binary$total > qrt3 & scores_df_binary$total <= qrt4 , 4,
                                        ifelse(scores_df_binary$total > qrt2 & scores_df_binary$total <= qrt3 , 3,
                                               ifelse(scores_df_binary$total > qrt1 & scores_df_binary$total <= qrt2 , 2, 1))) 
    
    # #------------- Add resumes with 0 entries ---------------------------
    
    for (c in unique(resume_keywords$category)){    # Add the missing clusters from the cluster sheet
      if (!c %in% names(scores_df_binary)){
        scores_df_binary[[c]] <-0
      }
    }
    
    missing_files <- data.frame( split_files = split_files[!split_files %in% scores_df_binary$split_files]) # those resumes that do not contain any of the keywords
    
    new_rows <- data.frame(file=missing_files) # create a dataframe of those resumes
    
    if (nrow(new_rows)>0){
      for  (c in colnames(scores_df_binary)[-1]){  # assign 0 to all clusters for these resumes
        
        if(c=='email'){
          new_rows[[c]]<-""
        }else{
        new_rows[[c]]<-0
        }
      }
      
      scores_df_binary <- bind_rows(scores_df_binary, new_rows) %>% #bind_rows is more flexible than rbind
        select(-total, everything())  # shift "total" to the right end
    }else{
      scores_df_binary <- scores_df_binary %>%
        select(-total, everything())
    }
    
    scores_df_binary$email <- sapply(strsplit(scores_df_binary$split_files, "/"), tail, 1)
    scores_df_binary$email <- unlist(strsplit(scores_df_binary$email, "_resume.pdf"))
    
    scores_df_binary$email <-
      str_to_lower(str_trim(scores_df_binary$email))
    
    #scores_df_binary <- merge(scores_df_binary, usas_report_names, by.x="split_files", by.y="split_files", all.x = TRUE)
    scores_df_binary <- merge(scores_df_binary, name_table, by.x="email", by.y="Applicant Email Address")
    
    # Clean up columns and reorder
    scores_df_binary <- scores_df_binary %>%
      select(-one_of(c('split_files'))) %>%
      rename(`Total Score`=total) %>%
      relocate(`Applicant First Name`, .before=email) %>%
      relocate(`Applicant Middle Name`, .before=email) %>%
      relocate(`Applicant Last Name`, .before=email)
    
    # Ensure all keyword categories exist in the proportion dataframe
    # even when no resumes contain matching keywords.
    
    all_categories <- unique(as.character(resume_keywords$category))
    
    for (cat in all_categories) {
      
      if (!is.na(cat) && nzchar(trimws(cat)) &&
          !cat %in% names(transform_df_binary_prop)) {
        
        transform_df_binary_prop[[cat]] <- rep(
          0,
          nrow(transform_df_binary_prop)
        )
        
      }
      
    }
    
    return(list(scores_df_binary, transform_df_binary_prop))
    
  }
  
  list[scores_df_binary, transform_df_binary_prop] <- create_scores_table()
  
  list[scores_df_binary_weighted, transform_df_binary_weighted_prop] <-  create_scores_table(weighted = TRUE)
  
  joined_df$email <- sapply(strsplit(joined_df$split_files, "/"), tail, 1)
  joined_df$email <- unlist(strsplit(joined_df$email, "_resume.pdf"))

  outputdf2 <- joined_df %>%
    left_join(name_table, by=c("email"="Applicant Email Address"))
  
  outputdf2 <- outputdf2 %>%
    select(`Applicant First Name`,
           `Applicant Last Name`,
           email,
           resumelength,
           everything(),
           -split_files,
           -column_lab)
  
  names_df <- name_table %>%
    select(`Applicant Email Address`,
           `Applicant First Name`,
           `Applicant Last Name`,)
  
  outputdf3 <- transform_df_binary_prop %>%
    select(-one_of(c('split_files')))  %>%
    left_join(names_df, by=c("email"="Applicant Email Address")) %>%
    select(`Applicant First Name`,
           `Applicant Last Name`,
           email,
           everything()) %>%
    mutate_if(is.numeric, round, 3)
  
  outputdf4 <- transform_df_binary_weighted_prop %>%
    select(-one_of(c('split_files')))  %>%
    left_join(names_df, by=c("email"="Applicant Email Address")) %>%
    select(`Applicant First Name`,
           `Applicant Last Name`,
           email,
           everything()) %>%
    mutate_if(is.numeric, round, 3)

  return(list(scores_df_binary, scores_df_binary_weighted, outputdf2, outputdf3, outputdf4))
  
  
}