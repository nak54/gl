update_resume_df <- function(to_do_list, resume_df, resume_data){
  
  if (nrow(to_do_list) > 0) {
    
    #setup temp df to hold list of remaining applicants
    remaining_applicants <- to_do_list
    
    #loop through resume data and look for matches by email instead of first/last name
    for (i in 1:length(resume_data)) {
      
      #loop through remaining applicants
      for (x in 1:nrow(remaining_applicants)) {
        
        if (str_detect(resume_data[i], remaining_applicants$email[x])) {
          
          #write data to resume_df
          resume_df$firstName[i] <- remaining_applicants$firstName[x]
          resume_df$lastName[i] <- remaining_applicants$lastName[x]
          resume_df$email[i] <- remaining_applicants$email[x]
          
          resume_df$usasNamesDetected <- 0
          
          ##update to_do list
          to_do_list <- to_do_list %>% filter(email != remaining_applicants$email[x])
        }
      }
    }
  }
  
  return(list(to_do_list, resume_df, resume_data))
  
}