
map_click <- function(selected_element,
                      gdi_selected_sf,
                      selected_state,
                      plotly_data,
                      selected_applicants,
                      states_shp,
                      input,
                      scored_resumes_df,
                      n_applicants_reactive,
                      scored_resumes_weighted_df,
                      filtered_candidate_table,
                      state
                            ){
  
  if(selected_element$curveNumber==3){
    
    applicants_string <- gdi_selected_sf()[selected_element$pointNumber+1, ]$Candidates
    
    email_vector <- str_split(applicants_string, '<br>')[[1]]
    
    selected_applicants(gsub('Email:', '', email_vector[grepl('Email:', email_vector)]))
    
    selected_state("")
    
  }else if(selected_element$curveNumber==1){
    
    data <- plotly_data()
    
    if (state=='AK'){
      state <- data$x$data[[1]]$text[[1]]
    }else if(state=="HI"){
      state <- data$x$data[[1]]$text[[1]]
    }else{
      
      state <- data$x$data[[2]]$text[[selected_element$pointNumber+1]]
    }
    
    selected_state(state.abb[grep(state, state.name)])
    
    selected_applicants("")
    
  }else{
    
    point <- st_point(c(selected_element$x, selected_element$y))
    
    selected_state(states_shp[which(st_intersects(point, states_shp, sparse=FALSE)), ]$STUSPS)
    
    selected_applicants("")
    
  }
  
  if (input$weighting_button == "unweighted"){
    
    if(all(selected_applicants()==c(""))){
      df <- head(scored_resumes_df() %>%
                   arrange(desc(`Total Score`)) %>%
                   filter(grepl(selected_state(), `Application Locations`)),
                 n_applicants_reactive())
      
    }else{
      
      df <- head(scored_resumes_df() %>%
                   arrange(desc(`Total Score`)) %>%
                   filter(grepl(selected_state(), `Application Locations`)) %>%
                   filter(email %in% selected_applicants()),
                 n_applicants_reactive())
    }
    
  }else{
    if(all(selected_applicants()!=c(""))){
      
      df <- head(scored_resumes_weighted_df() %>%
                   arrange(desc(`Total Score`)) %>%
                   filter(grepl(selected_state(), `Application Locations`)) %>%
                   filter(email %in% selected_applicants()),
                 n_applicants_reactive())
    }else{
      df <- head(scored_resumes_weighted_df() %>%
                   arrange(desc(`Total Score`)) %>%
                   filter(grepl(selected_state(), `Application Locations`)),
                 n_applicants_reactive())
    }
  }
  
  filtered_candidate_table(remove_na_columns(df))
  
  return(list(filtered_candidate_table, selected_state, selected_applicants))
  
}


map_selected <- function(selected_element,
                         conus_plotly_data,
                         selected_state,
                         input,
                         selected_applicants,
                         scored_resumes_df,
                         n_applicants_reactive,
                         scored_resumes_weighted_df,
                         filtered_candidate_table,
                         state
                         ){
  
    selected_element <- selected_element %>%
      filter(curveNumber==3)
    
    if(nrow(selected_element)>0){
      
      data <- conus_plotly_data()
      
      locations <- data$x$data[[4]]$text
      
      applicants_string <- locations[selected_element$pointNumber]
      
      email_vector <- unique(unlist(lapply(str_split(applicants_string, '<br>'), '[', 6)))
      
      selected_applicants(gsub('Email:', '', email_vector[grepl('Email:', email_vector)]))
      
      selected_state("")
    }
    
    if (input$weighting_button == "unweighted"){
      
      if(all(selected_applicants()==c(""))){
        df <- head(scored_resumes_df() %>%
                     arrange(desc(`Total Score`)) %>%
                     filter(grepl(selected_state(), `Application Locations`)),
                   n_applicants_reactive())
        
      }else{
        
        df <- head(scored_resumes_df() %>%
                     arrange(desc(`Total Score`)) %>%
                     filter(grepl(selected_state(), `Application Locations`)) %>%
                     filter(email %in% selected_applicants()),
                   n_applicants_reactive())
      }
      
    }else{
      if(all(selected_applicants()!=c(""))){
        
        df <- head(scored_resumes_weighted_df() %>%
                     arrange(desc(`Total Score`)) %>%
                     filter(grepl(selected_state(), `Application Locations`)) %>%
                     filter(email %in% selected_applicants()),
                   n_applicants_reactive())
      }else{
        df <- head(scored_resumes_weighted_df() %>%
                     arrange(desc(`Total Score`)) %>%
                     filter(grepl(selected_state(), `Application Locations`)),
                   n_applicants_reactive())
      }
    }
    
    filtered_candidate_table(remove_na_columns(df))
    
    return(list(filtered_candidate_table, selected_state, selected_applicants))
    
  
}