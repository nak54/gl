
# keyword match count function

find_matches <- function(text, keywords){ 
  matches <- c()
  for (keyword in keywords){
    if (str_detect(text, regex(keyword))){
      matches <- c(matches, keyword)
    }
  }
  
  return (total_matches = length(matches))
}

find_optimum_function <- function(pdf_files, 
                                  pdf_text_ngrams,
                                  pdf_text_ngrams_list,
                                  tess_ocr_ngrams,
                                  tess_ocr_ngrams_list,
                                  resume_keywords_df,
                                  Processed_df){
  
  
  
  # pull the keyword column
  keywords <- as_tibble(resume_keywords_df) %>%
    pull(keyword) %>%
    tolower() # lowercase words
  
  
  # get the number of matches
  words_ngram <- unlist(lapply(pdf_text_ngrams, find_matches, keywords=keywords)) # find number of keyword matches of pdf_text data
  # words_pdf_ocr_ngram <- unlist(lapply(pdf_ocr_ngrams, find_matches)) # find number of keyword matches of pdf_ocr_text data
  words_tess_ocr_ngram <- unlist(lapply(tess_ocr_ngrams, find_matches, keywords=keywords))# find number of keyword matches of tesseract ocr data
  
  ## Comparing number of matches for each function ----
  
  
  
  # pdf_text_ngrams_by_resume <- list()
  # tess_ocr_ngrams_by_resume <- list()
  resumes_ngrams_by_resume <- list()

  # for (i in 1:nrow(Processed_df)){
  #   pdf_text_ngrams_by_resume[[i]] <- pdf_text_ngrams[seq(Processed_df$startPage[[i]], Processed_df$endPage[[i]])]
  #   tess_ocr_ngrams_by_resume[[i]] <- tess_ocr_ngrams[seq(Processed_df$startPage[[i]], Processed_df$endPage[[i]])]
  # }

  match_count_df <-tibble(
    match_count_pdf_text = words_ngram,
    match_count_tesseract_ocr = words_tess_ocr_ngram
  )
  
  ## 4.2 Create final resume text vector based on the best function
  max_index <- integer()
  resumes_ngrams<- vector("list")
  cols <- match_count_df[, 1:2] # select the 2 leftmost columns
  
  
  for (i in 1:length(pdf_text_ngrams)){   # if the number of matches from pdf_text > pdf_ocr, choose pdf_text for that resume if not, choose ocr
    max_index[i] <- which.max(cols[i,])
    
    if (max_index[i] == 1) {
      resumes_ngrams[[i]] <- tolower(pdf_text_ngrams[[i]])
    } else{ 
      resumes_ngrams[[i]] <- tolower(tess_ocr_ngrams[[i]])
    }
  }
  

  for (i in 1:nrow(Processed_df)){
    resumes_ngrams_by_resume[[i]] <- paste(resumes_ngrams[seq(Processed_df$startPage[[i]], Processed_df$endPage[[i]])], collapse = " ")
  }
  
  return(list(resumes_ngrams, resumes_ngrams_by_resume))
  
  
}