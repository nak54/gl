
initialize_dataframe <- function(){

# Stand up data frame to hold data about resume pages obtained from pdf_text
df <- tibble(
  pageNumber = numeric(),
  charactersPerPage = numeric(),
  usasNamesDetected = numeric(),
  firstName = character(),
  firstNameLoc = numeric(),
  lastName = character(),
  lastNameLoc = numeric(),
  nameLocDiff = numeric(),
  emailMatch = logical(),
  email = logical(),
  emailMatchPage = numeric()
)

return(df)

}