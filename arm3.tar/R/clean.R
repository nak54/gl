#### 2.2 Clean resume data (both pdf_text and Tesseract ORC data) -----------


clean_pdf_text <- function(resume_data_text){
  
  # # Clean text 
  # resume_data <- resume_data_text %>%
  #   str_to_lower() %>%
  #   str_replace_all("\n", " ") %>%
  #   str_replace_all("\t", " ") %>%
  #   str_replace_all("[:blank:]+", " ") %>%
  #   str_replace_all(",", " ") %>%
  #   str_replace_all("-", " ") %>%
  # 
  # # Clean numbers
  #   str_replace_all("(?<=[:digit:])[:blank:](?=[:digit:])", "") %>%
  #   str_replace_all("[:punct:]", "") %>%
  #   str_replace_all("[:blank:]", "") %>%
  # 
  # # Remove extra spaces and tabs
  #   str_replace_all("[:blank:]+", " ")
  # 
  # 
  
  # Clean text 
  resume_data_clean_text <- resume_data_text %>%
    str_to_lower() %>%
    str_replace_all("\n", " ") %>%
    str_replace_all("\t", " ") %>%
    str_replace_all("[:blank:]+", " ") %>%
    str_replace_all(",", " ") %>%
    str_replace_all("-", " ")
  
  # Clean numbers
  resume_data_clean_numbers <- resume_data_clean_text %>%
    str_replace_all("(?<=[:digit:])[:blank:](?=[:digit:])", "") %>%
    str_replace_all("[:punct:]", "") %>%
    str_replace_all("[:blank:]", "")
  
  # Remove extra spaces and tabs
  resume_data <- resume_data_clean_text %>%
    str_replace_all("[:blank:]+", " ")
  
  return(list(resume_data_clean_text, resume_data_clean_numbers, resume_data))

}

clean_ngrams <- function(ngrams){
  
  ngrams %>%
  str_replace_all("\\n" , " ")%>% # removes \n
  str_replace_all("\\\\n" , " ")%>% #removes \\n
  str_replace_all("\\\"", " ")%>% # removes \"
  str_replace_all("\\t", " ") %>% # removes tabs
  stri_replace_all_regex("\\p{So}", " ") %>% # removes diammonds and question marks
  str_replace_all(",", " ") %>% #removes ,
  str_replace_all("-", " ")%>% # removes -
  str_replace_all("\\.", " ") %>% #removes periods
  str_replace_all("/", " ") %>%
  str_replace_all("[[:blank:]]+", " ")  # removes /
  
  
}