output_score <- function(scored_resumes_df, score_detailed_df, score_proportion_df, resume_keywords_df) {
  
  scored_resumes_df <- scored_resumes_df %>%
    select(`Applicant First Name`,
           `Applicant Last Name`,
           email,
           resumelength,
           unique(resume_keywords_df$category),
           `Total Score`,
           quartile
           )
  
  score_detailed_df <- score_detailed_df %>%
    select(`Applicant First Name`,
           `Applicant Last Name`,
           email,
           resumelength,
           category,
           keywords,
           Freq,
           Freq_binary,
           score_adjustment,
           count,
           wordcount)
  
  score_proportion_df <- score_proportion_df %>%
    select(`Applicant First Name`,
           `Applicant Last Name`,
           email,
           unique(resume_keywords_df$category)
      
    )
  
  wb <- createWorkbook()
  
  # Creating the Score Frequency Worksheet
  
  addWorksheet(wb = wb, sheetName = "Score Frequency")
  
  writeDataTable(wb, 
                 sheet = "Score Frequency", 
                 scored_resumes_df, 
                 startRow = 1, 
                 startCol = 1, 
                 tableStyle = "TableStyleMedium17")
  
  length_column <- grep("resumelength", colnames(scored_resumes_df))
  total_score_column <- grep("Total Score", colnames(scored_resumes_df))
  quartile_column <- grep("quartile", colnames(scored_resumes_df))
  
  n_rows <- nrow(scored_resumes_df)
  n_cols <- ncol(scored_resumes_df)
  
  rank_formatting <- createStyle(fgFill="#AEDEF5", 
                                 borderStyle=openxlsx_getOp("borderStyle", "thin"),
                                 border="TopBottomLeftRight")
  
  total_Score_formatting <- createStyle(fgFill="#EAB139", 
                                 borderStyle=openxlsx_getOp("borderStyle", "thin"),
                                 border="TopBottomLeftRight")
  
  quartile_formatting <- createStyle(fgFill="#A5BA73")
  
  addStyle(wb = wb, 
           sheet = "Score Frequency", 
           style = rank_formatting, 
           cols = (length_column+1):(total_score_column-1), 
           rows= 1:n_rows+1,
           gridExpand = TRUE)
  
  addStyle(wb = wb, 
           sheet = "Score Frequency", 
           style = total_Score_formatting, 
           cols = total_score_column, 
           rows= 1:n_rows+1,
           gridExpand = TRUE)
  
  addStyle(wb = wb, 
           sheet = "Score Frequency", 
           style = quartile_formatting, 
           cols = quartile_column, 
           rows= 1:n_rows+1,
           gridExpand = TRUE)
  
  
  
  # Creating the Detailed Frequency Worksheet
  addWorksheet(wb = wb, sheetName = "Detailed Frequency")
  
  writeDataTable(wb, 
                 sheet = "Detailed Frequency", 
                 score_detailed_df, 
                 startRow = 1, 
                 startCol = 1, 
                 tableStyle = "TableStyleMedium17")
  
  # Creating the Proportion Worksheet
  
  addWorksheet(wb = wb, sheetName = "Proportion")
  
  writeDataTable(wb, 
                 sheet = "Proportion", 
                 score_proportion_df, 
                 startRow = 1, 
                 startCol = 1, 
                 tableStyle = "TableStyleMedium17")
  
  
  
  
  # writeData(wb = wb, sheet = "Score Frequency", x = supplies, headerStyle = headerStyle)
  
  return(wb)
  
}