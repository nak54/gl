
collapse_resume_df <- function(resume_data, resume_df){

#collapse data frame (1 record per applicant)
resume_df_transformed <- resume_df %>%
  filter(!is.na(email)) %>%
  # fill(firstName) %>%
  # fill(lastName) %>%
  # fill(email) %>%
  #left_join(usas_report_names, by = c("firstName", "lastName", "email")) %>%
  group_by(firstName, lastName, email) %>%
  summarise(
    startPage = min(pageNumber),
    # endPage = lead(startPage)-1,
    # resumeLength = endPage - startPage + 1
  )

resume_df_transformed <- resume_df_transformed[order(resume_df_transformed$startPage),]
resume_df_transformed$endPage <- lead(resume_df_transformed$startPage)-1
resume_df_transformed$resumeLength <- resume_df_transformed$endPage - resume_df_transformed$startPage+1

## MUST ADD CODING FOR END PAGE FOR LAST PERSON
resume_df_transformed[nrow(resume_df_transformed),ncol(resume_df_transformed)-1] <- length(resume_data)
resume_df_transformed$resumeLength <- resume_df_transformed$endPage - resume_df_transformed$startPage+1

return(resume_df_transformed)

}