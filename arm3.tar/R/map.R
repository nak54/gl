
create_candidate_map <- function(conus_states_shp,
                                 hi_states_shp,
                                 ak_states_shp,
                                 
                                 conus_gdi_selected_sf,
                                 hi_gdi_selected_sf,
                                 ak_gdi_selected_sf,
                                 
                                 conus_gdi_unselected_sf,
                                 hi_gdi_unselected_sf,
                                 ak_gdi_unselected_sf){
  
  # Creating bounds for Hawaii, Alaska, and CONUS for map
  conus_x_lim <- c(-124.54, -67.09)
  conus_y_lim <- c(24.85, 49.48)
  hi_y_lim <- c(18.92, 22.23)
  hi_x_lim <- c(-160.25, -154.81)
  ak_y_lim <- c(51.21, 71.44)
  ak_x_lim <- c(-179.15, -129.98)

  # Creating states map
  conus_map <- ggplot(conus_states_shp,
                      crs = st_crs(4296)
                    ) +
    geom_sf(fill = "#69b3a2",
            color = "black",
            linewidth=0.25,
            hovermode=FALSE,
            aes(text=NAME)
            )
  
  # Adding Office locations
  conus_map <- conus_map +
    geom_sf(data = conus_gdi_unselected_sf,
            crs = st_crs(4296),
            aes(fill=Vacant_color,
                text = paste0(deparse(substitute(`Building Number`)), ": ", `Building Number`, "<br>",
                              deparse(substitute(`Vacant Workstation Count`)), ": ", `Vacant Workstation Count`, "<br><br>")),
            shape=1,
            alpha=0.75,
            size=2)
  
  if (grepl('Windows', Sys.getenv('OS'))){
    conus_map <- conus_map +
      scale_fill_gradient(
        trans = "log",
        low = 'red',
        high= 'blue')
  }else{
    
    conus_map <- conus_map +
      scale_fill_gradientn(
        trans = "log",
        colors = rev(wesanderson::wes_palette("Zissou1", 10, type = "continuous")))
    
  }
  
  # Adding locations selected if they exist
  
  if (nrow(conus_gdi_selected_sf)>0){
    
    conus_map <- conus_map +
      geom_sf(data = conus_gdi_selected_sf,
              aes(fill=Vacant_color,
                  text = paste0(deparse(substitute(`Building Number`)), ": ", `Building Number`, "<br>",
                                deparse(substitute(`Vacant Workstation Count`)), ": ", `Vacant Workstation Count`, "<br><br>",
                                "Candidates:<br>", Candidates, "<br>")),
              crs = st_crs(4296),
              shape=23,
              size=3)
    
    if (grepl('Windows', Sys.getenv('OS'))){
      conus_map <- conus_map +
        scale_fill_gradient(
          trans = "log",
          low = 'red',
          high= 'blue')
    }else{
      
      conus_map <- conus_map +
        scale_fill_gradientn(
          trans = "log",
          colors = rev(wesanderson::wes_palette("Zissou1", 10, type = "continuous")))
      
    }

    
    conus_map <- conus_map +
      theme_map() +
      theme(legend.position = "none")
  }
  
  
  hi_map <- ggplot(hi_states_shp, crs = st_crs(4296)) +
    geom_sf(fill = "#69b3a2",
            color = "black",
            linewidth=0.25,
            hovermode=FALSE,
            aes(text=NAME)
    ) + 
    geom_sf(data = hi_gdi_unselected_sf,
            crs = st_crs(4296),
            aes(fill=Vacant_color,
                text = paste0(deparse(substitute(`Building Number`)), ": ", `Building Number`, "<br>",
                              deparse(substitute(`Vacant Workstation Count`)), ": ", `Vacant Workstation Count`, "<br><br>")),
            shape=1,
            alpha=0.75,
            size=3)
  
  if (grepl('Windows', Sys.getenv('OS'))){
    hi_map <- hi_map +
      scale_fill_gradient(
        trans = "log",
        low = 'red',
        high= 'blue')
  }else{
    
    hi_map <- hi_map +
      scale_fill_gradientn(
        trans = "log",
        colors = rev(wesanderson::wes_palette("Zissou1", 10, type = "continuous")))
    
  }
  
  hi_map <- hi_map +
    coord_fixed(ratio=1.5, xlim = hi_x_lim, ylim = hi_y_lim) +
    theme_map() +
    theme(legend.position = "none")
  
  # Adding selected locations if they exist
  
  if (nrow(hi_gdi_selected_sf)>0){
    hi_map <- hi_map +
      geom_sf(data = hi_gdi_selected_sf,
              aes(fill=Vacant_color,
                  text = paste0(deparse(substitute(`Building Number`)), ": ", `Building Number`, "<br>",
                                deparse(substitute(`Vacant Workstation Count`)), ": ", `Vacant Workstation Count`, "<br><br>",
                                "Candidates:<br>", Candidates, "<br>")),
              crs = st_crs(4296),
              shape=23,
              size=2)
    
    if (grepl('Windows', Sys.getenv('OS'))){
      hi_map <- hi_map +
        scale_fill_gradient(
          trans = "log",
          low = 'red',
          high= 'blue')
    }else{
      hi_map <- hi_map +
      scale_fill_gradientn(
        trans = "log",
        colors = rev(wesanderson::wes_palette("Zissou1", 10, type = "continuous")))
      
    }

    hi_map <- hi_map +
      coord_fixed(ratio=1.5, xlim = hi_x_lim, ylim = hi_y_lim) +
      theme_map() +
      theme(legend.position = "none")
  }
  
  ak_map <- ggplot(ak_states_shp, crs = st_crs(4296)) +
    geom_sf(fill = "#69b3a2",
            color = "black",
            linewidth=0.25,
            hovermode=FALSE,
            aes(text=NAME)
    ) +
    geom_sf(data = ak_gdi_unselected_sf,
            crs = st_crs(4296),
            aes(fill=Vacant_color,
                text = paste0(deparse(substitute(`Building Number`)), ": ", `Building Number`, "<br>",
                              deparse(substitute(`Vacant Workstation Count`)), ": ", `Vacant Workstation Count`, "<br><br>")),
            shape=1,
            alpha=0.75,
            size=2)
  
  if (grepl('Windows', Sys.getenv('OS'))){
    ak_map <- ak_map +
      scale_fill_gradient(
        trans = "log",
        low = 'red',
        high= 'blue')
  }else{
    
    ak_map <- ak_map +
      scale_fill_gradientn(
        trans = "log",
        colors = rev(wesanderson::wes_palette("Zissou1", 10, type = "continuous")))
    
  }
  
  ak_map <- ak_map +
    coord_fixed(ratio=1.5, xlim = ak_x_lim, ylim = ak_y_lim) +
    theme_map() +
    theme(legend.position = "none")
  
  # Adding selected locations if they exist
  
  if (nrow(ak_gdi_selected_sf)>0){
    ak_map <- ak_map +
      geom_sf(data = ak_gdi_selected_sf,
              aes(fill=Vacant_color,
                  text = paste0(deparse(substitute(`Building Number`)), ": ", `Building Number`, "<br>",
                                deparse(substitute(`Vacant Workstation Count`)), ": ", `Vacant Workstation Count`, "<br><br>",
                                "Candidates:<br>", Candidates, "<br>")),
              crs = st_crs(4296),
              shape=23,
              size=2)
    
    if (grepl('Windows', Sys.getenv('OS'))){
      ak_map <- ak_map +
        scale_fill_gradient(
          trans = "log",
          low = 'red',
          high= 'blue')
    }else{
      
      ak_map <- ak_map +
        scale_fill_gradientn(
          trans = "log",
          colors = rev(wesanderson::wes_palette("Zissou1", 10, type = "continuous")))
      
    }

    
    ak_map <- ak_map +
      coord_fixed(ratio=1.5, xlim = ak_x_lim, ylim = ak_y_lim) +
      theme_map() +
      theme(legend.position = "none")
  }
  
  conus_ggplotly <- ggplotly(conus_map, 
                             height=800, 
                             tooltip='text',
                             source='candidate_map_conus') %>%
    layout(dragmode='select')
  
  conus_ggplotly$x$data[[2]]$hoverinfo<-'none'

  
  
  hi_ggplotly <- ggplotly(hi_map, 
                          height=800, 
                          tooltip='text',
                          source='candidate_map_hi') %>%
    layout(dragmode='select')
  
  hi_ggplotly$x$data[[1]]$hoverinfo<-'none'
  
  
  ak_ggplotly <- ggplotly(ak_map, 
                          height=800, 
                          tooltip='text',
                          source='candidate_map_ak') %>%
    layout(dragmode='select')
  
  ak_ggplotly$x$data[[1]]$hoverinfo<-'none'
  
  
  return(list(conus_ggplotly, hi_ggplotly, ak_ggplotly))
  
}