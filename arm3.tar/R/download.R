
save_individual_resumes <- function(pdf_path, Processed_df){
  

  # Get the resume_df_transformed_final from the reactive value
  resume_df_transformed_end <- Processed_df
  req(resume_df_transformed_end)
  
  temp_dir <- tempdir()
  split_files <- c()
  
  for (i in 1:nrow(resume_df_transformed_end)) {
    
    #split PDFs
    output_file_name <- paste0(temp_dir,"/", resume_df_transformed_end$email[i], "_resume.pdf")
    pdf_subset(pdf_path(), pages = resume_df_transformed_end$startPage[i] : resume_df_transformed_end$endPage[i], output = output_file_name)
    
    split_files <- c(split_files, output_file_name)
  }
  
  return(split_files)
}

download_df <- function(df, file_name, extension){
  
  downloadHandler(
    filename =function() {
      paste(file_name, ".", extension, sep = "")
    },
    
    content = function(file) {
      req(df)
      
      if (extension=='csv'){
        write.csv(df, file, row.names = FALSE)
      }
      
    }
  )
  
}