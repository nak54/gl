#to inspect mda_text
import pandas as pd
import numpy as np
dfmda=pd.read_parquet('mda_merged_sic_naics_24_25.parquet')
dfmda
dfmda.columns
pd.set_option('display.max_colwidth', None)
dfmda.iloc[np.random.randint(0, len(dfmda), 5)]['mda_text']