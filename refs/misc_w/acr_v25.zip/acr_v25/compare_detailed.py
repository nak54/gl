#!/usr/bin/env python3
"""Compare the Detailed Frequency sheet of two ResumeRank workbooks.
usage: compare_detailed.py REFERENCE.xlsx CANDIDATE.xlsx
"""
import sys
import pandas as pd

ref = pd.read_excel(sys.argv[1], sheet_name="Detailed Frequency")
got = pd.read_excel(sys.argv[2], sheet_name="Detailed Frequency")

print("columns equal:", list(ref.columns) == list(got.columns))
if list(ref.columns) != list(got.columns):
    print(" ref:", list(ref.columns)); print(" got:", list(got.columns))
print(f"rows: ref={len(ref)} got={len(got)}")

key = ["email", "category", "keywords"]
num = ["resumelength", "Freq", "Freq_binary", "score_adjustment", "count", "wordcount"]

def norm(d):
    d = d.copy()
    for c in key:
        d[c] = d[c].astype(str)
    d["n"] = d.groupby(key).cumcount()   # keep duplicate rows distinct
    return d

r, g = norm(ref), norm(got)
m = r.merge(g, on=key + ["n"], how="outer", suffixes=("_ref", "_got"), indicator=True)
only_ref = m[m._merge == "left_only"]
only_got = m[m._merge == "right_only"]
both = m[m._merge == "both"]
print(f"rows only in ref: {len(only_ref)} | only in got: {len(only_got)} | in both: {len(both)}")
if len(only_ref):
    print("-- only in reference (first 25):")
    print(only_ref[key + ["Freq_ref", "wordcount_ref"]].head(25).to_string(index=False))
if len(only_got):
    print("-- only in candidate (first 25):")
    print(only_got[key + ["Freq_got", "wordcount_got"]].head(25).to_string(index=False))
for c in num:
    d = both[both[c + "_ref"] != both[c + "_got"]]
    print(f"{c}: {len(d)} mismatching row(s)")
    if len(d):
        print(d[key + [c + "_ref", c + "_got"]].head(15).to_string(index=False))

# per-candidate summary
rs = ref.groupby("email").agg(rows=("Freq", "size"), freq=("Freq", "sum"), wc=("wordcount", "first"))
gs = got.groupby("email").agg(rows=("Freq", "size"), freq=("Freq", "sum"), wc=("wordcount", "first"))
s = rs.join(gs, lsuffix="_ref", rsuffix="_got", how="outer")
bad = s[(s.rows_ref != s.rows_got) | (s.freq_ref != s.freq_got) | (s.wc_ref != s.wc_got)]
print(f"candidates differing: {len(bad)} of {len(s)}")
if len(bad):
    print(bad.to_string())
ok = (len(only_ref) == 0 and len(only_got) == 0 and
      all((both[c + "_ref"] == both[c + "_got"]).all() for c in num))
print("MATCH" if ok else "DIFFERENT")
sys.exit(0 if ok else 1)
