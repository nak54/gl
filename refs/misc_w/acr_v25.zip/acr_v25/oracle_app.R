## oracle_app.R -- run the Shiny app's own pipeline functions (no Shiny) on the
## demo inputs, using the CLI's candidate page ranges, and write the unweighted
## ResumeRank workbook the app would produce from the same text.
## usage: Rscript oracle_app.R APP_R_DIR PDF NAMES.xlsx KEYWORDS.csv CANDIDATES.csv OUT.xlsx [--legacy-clean-port]
suppressPackageStartupMessages({
  library(stringr); library(stringi); library(tm); library(quanteda); library(dplyr)
  library(reshape2); library(openxlsx); library(readxl); library(pdftools); library(tibble)
})
args <- commandArgs(trailingOnly = TRUE)
app_dir <- args[1]; pdf <- args[2]; names_f <- args[3]; kw_f <- args[4]; cand_f <- args[5]; out <- args[6]

## gsubfn-style list[a, b] <- f() used by the app
list <- structure(NA, class = "result")
"[<-.result" <- function(x, ..., value) {
  args <- as.list(match.call()); args <- args[-c(1:2, length(args))]
  length(value) <- length(args)
  for (i in seq(along = args)) {
    a <- args[[i]]
    if (!missing(a)) eval.parent(substitute(a <- v, list(a = a, v = value[[i]])))
  }
  x
}
for (f in c("clean.R", "bow.R", "corpus.R", "tokenize.R", "score.R", "output_score.R", "optimize_extract.R"))
  source(file.path(app_dir, f))

## parse_pdfs() equivalent, embedded text only
result_pdf_text <- str_to_lower(pdf_text(pdf))
pdf_text_ngrams <- unlist(tolower(result_pdf_text))
pdf_text_ngrams <- clean_ngrams(pdf_text_ngrams)          # server.R line 1256

## keyword upload (server.R observeEvent(input$bow_file), csv branch)
bow_weights <- read.csv(kw_f, colClasses = c("factor", "character", "numeric"))
bow_weights$category <- tolower(bow_weights$category)
bow_weights$keyword <- tolower(bow_weights$keyword)
resume_keywords_df <- bow_weights

name_table <- read_excel(names_f)
cand <- read.csv(cand_f, stringsAsFactors = FALSE)
Processed_df <- data.frame(startPage = cand$startPage, endPage = cand$endPage,
                           resumeLength = cand$resumeLength, email = cand$email)
split_files <- file.path("split", sprintf("%s_resume.pdf", cand$email))

## find_optimum_function() with a single layer: pdf_text always wins
resumes_ngrams_by_resume <- lapply(seq_len(nrow(Processed_df)), function(i)
  paste(pdf_text_ngrams[seq(Processed_df$startPage[i], Processed_df$endPage[i])], collapse = " "))

list[resumes_unlisted, count_df] <- bow(resume_keywords_df, resumes_ngrams_by_resume)
resumes_unlisted <- create_clean_corpus(resumes_unlisted)
final_df <- tokenize(resumes_unlisted, resume_keywords_df, split_files)
count_df$resumelength <- Processed_df$resumeLength
list[scores_df_binary, scores_df_binary_weighted, outputdf2, outputdf3, outputdf4] <-
  aggregate_normalize_score(resume_keywords_df, final_df, count_df, split_files, name_table)
wb <- output_score(scores_df_binary, outputdf2, outputdf3, resume_keywords_df)
saveWorkbook(wb, out, overwrite = TRUE)
cat("oracle:", nrow(outputdf2), "detailed rows,", nrow(scores_df_binary), "scored candidates ->", out, "\n")
