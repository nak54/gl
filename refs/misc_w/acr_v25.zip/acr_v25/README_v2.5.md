# ACR CLI v2.5 — app-faithful `--legacy --legacy-clean`

Reproduces the Shiny app's (`ui.R` / `server.R`) `*-ResumeRank.xlsx` workbooks
from the command line. R 4.6; packages: pdftools, data.table, readxl, openxlsx,
quanteda, stopwords, stringi (comes with quanteda), optional ggplot2, tesseract.

```
Rscript acr.R -p demo_resumes.pdf -n demo_names.xlsx -k demo_keywords.csv -o out ^
        --legacy --legacy-clean --ocr-all
```

writes `out/reports/<date>-demo_resumes-unweighted-ResumeRank.xlsx` and
`...-weighted-ResumeRank.xlsx` (Score Frequency / Detailed Frequency / Proportion),
plus `detailed_frequency.csv`, `scores_app_*.csv`, `proportion_app_*.csv`,
`candidates.csv`, `page_extraction_choice.csv`.

## What the two flags do

| flag | ports | effect |
|---|---|---|
| `--legacy-clean` | `clean.R` | `clean_pdf_text()` / `clean_ngrams()` run as ICU regexes (stringi), exactly like the app's stringr calls — `[:blank:]` covers no-break/thin spaces, `\p{So}` bullets become spaces, no trimming. `wordcount` = character count of this text (`str_count`). |
| `--legacy` (= `--engine app`) | `optimize_extract.R`, `bow.R`, `corpus.R`, `tokenize.R`, `score.R`, `output_score.R` | Keyword file used as uploaded (lower-cased, **not trimmed, not de-duplicated**); per-page text/OCR choice by raw-regex keyword matches, tie → embedded text; `iconv` to ASCII + tm-style cleaning; quanteda `tokens(remove_numbers, remove_punct, remove_symbols)` → stop words removed → unigrams + 2–4-grams; merge keeps duplicate keyword rows; `count` = rows per category; one measure (min–max scaled Freq/wordcount), unweighted + weighted workbooks named like the app's download. `-s/--score` is ignored. OCR dpi defaults to 600 (the app's value). |

Without `--legacy` the previous engines (`regex`, `quanteda`) and the
`acr_scores_<score>_<weighting>.xlsx` layout are unchanged.

## Verification

* `oracle_app.R` runs the app's own R functions (sourced from the app's `R/`
  folder, no Shiny) on the same text and page ranges. On the demo inputs the
  CLI's three sheets are identical to the oracle, including row order
  (`compare_detailed.py` → `MATCH`, 709/709 rows).
* Against `2026-09-04-demo_resumes-Unweighted-ResumeRank.xlsx`, the remaining
  differences are in the text layer, not the logic: that workbook was produced
  with tesseract OCR winning the per-page vote on many pages (Unicode hyphens
  from OCR give `powerbi`, drop `scikit`, etc.) and with the OCR layer finding
  `apinknovember@yahoo.com` (letter-spaced name on page 23). Run with
  `--ocr-all` on the same machine/tesseract/poppler as the app to reproduce
  those; `--test-input-frequency <app workbook>` reports any remaining
  per-keyword differences in `frequency_validation.csv`.

## Known app quirks reproduced on purpose

* keywords with trailing blanks in the file (`"Program Management "`, `"PMP "`,
  `"Sprint "` …) never match — same as the app;
* `c++`, `c#`, `r&d` lose their symbols in quanteda and count as `c`, `c`, `r d`;
* resumes with no keyword hit get `resumelength 0`, `quartile 0` in Score
  Frequency and no row in Proportion.
