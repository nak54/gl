## ---------------------------------------------------------------------------
## 02_clean.R -- text normalisation (port of clean.R / corpus.R)
##
## Default: current consolidated cleaner.
## --legacy-clean: reproduce the Shiny app's clean.R exactly. The app used
## stringr, i.e. ICU regular expressions, where [:blank:] also covers Unicode
## spaces (no-break space, thin space ...). Base-R regexes do not, so the
## legacy cleaners run on stringi (ICU) when it is installed -- it always is
## when quanteda is -- and fall back to the closest PCRE equivalent (\h).
## This matters because the app's "wordcount" is a character count taken
## straight after this cleaning step.
## ---------------------------------------------------------------------------

## CLI / programmatic mode selection -----------------------------------------
legacy_clean_enabled <- function(args = commandArgs(trailingOnly = TRUE)) {
  isTRUE(getOption("acr.legacy_clean", FALSE)) ||
    any(args == "--legacy-clean")
}

strip_cleaning_cli_args <- function(args) {
  args[args != "--legacy-clean"]
}

cleaning_mode <- function(args = commandArgs(trailingOnly = TRUE)) {
  if (legacy_clean_enabled(args)) "legacy" else "current"
}

have_stringi <- function() isTRUE(requireNamespace("stringi", quietly = TRUE))

## ICU regex replace (stringr semantics) with a PCRE fallback.
icu_sub <- function(x, pattern, replacement, pcre = pattern) {
  if (have_stringi()) {
    stringi::stri_replace_all_regex(x, pattern, replacement)
  } else {
    gsub(pcre, replacement, x, perl = TRUE)
  }
}

## Current cleaning functions ------------------------------------------------

.clean_pdf_text_current <- function(pages) {
  text <- tolower(pages)
  text <- gsub("[\n\t]", " ", text)
  text <- gsub("[[:blank:]]+", " ", text)
  text <- gsub(",", " ", text, fixed = TRUE)
  text <- gsub("-", " ", text, fixed = TRUE)

  numbers <- gsub(
    "(?<=[[:digit:]])[[:blank:]](?=[[:digit:]])",
    "",
    text,
    perl = TRUE
  )
  numbers <- gsub("[[:punct:]]", "", numbers)
  numbers <- gsub("[[:blank:]]", "", numbers)

  flat <- gsub("[[:blank:]]+", " ", text)

  list(text = text, numbers = numbers, flat = flat)
}

## Page text prepared for bag-of-words counting. This folds together the
## legacy clean_ngrams() and create_clean_corpus() stages: the same current
## transformation is applied to the keyword list, so both sides agree.
.clean_for_bow_current <- function(x) {
  x <- tolower(x)
  x <- gsub("\\\\n|\\\\r|\\\\t", " ", x)       # literal backslash codes
  x <- gsub("[\n\r\t]", " ", x)
  x <- gsub('"', " ", x, fixed = TRUE)
  x <- gsub("(", " ", x, fixed = TRUE)
  x <- gsub(")", " ", x, fixed = TRUE)
  x <- gsub("'", "", x, fixed = TRUE)              # don't split contractions
  x <- gsub("-", "", x, fixed = TRUE)              # e-mail -> email
  x <- gsub("[^0-9a-z+#&/ ]", " ", x)              # keep c++, c#, r&d, and/or
  x <- gsub("[[:blank:]]+", " ", x)
  trimws(x)
}

## Legacy cleaning (clean.R of the Shiny app) ---------------------------------
##
## clean_pdf_text(): the three vectors used by the name / e-mail / phone search.
## Every str_replace_all() of the app is reproduced with the same ICU pattern.
.clean_pdf_text_legacy <- function(pages) {
  text <- tolower(pages)                                   # str_to_lower
  text <- icu_sub(text, "\n", " ")
  text <- icu_sub(text, "\t", " ")
  text <- icu_sub(text, "[:blank:]+", " ", pcre = "\\h+")
  text <- gsub(",", " ", text, fixed = TRUE)
  text <- gsub("-", " ", text, fixed = TRUE)

  numbers <- icu_sub(text, "(?<=[:digit:])[:blank:](?=[:digit:])", "",
                     pcre = "(?<=[[:digit:]])\\h(?=[[:digit:]])")
  numbers <- icu_sub(numbers, "[:punct:]", "", pcre = "[[:punct:]]")
  numbers <- icu_sub(numbers, "[:blank:]", "", pcre = "\\h")

  flat <- icu_sub(text, "[:blank:]+", " ", pcre = "\\h+")

  list(text = text, numbers = numbers, flat = flat)
}

## clean_ngrams(): the page text the app's bag of words starts from. The app
## lower-cased the pages in parse_pdfs() first; tolower() here is the same.
## Not trimmed, periods / slashes / hyphens become spaces, "Other Symbol"
## characters (bullets) become spaces. The character count of this text is
## the app's "wordcount".
.clean_for_bow_legacy <- function(x) {
  x <- tolower(x)
  x <- icu_sub(x, "\n", " ")                 # str_replace_all("\\n", " ")
  x <- gsub("\\n", " ", x, fixed = TRUE)     # str_replace_all("\\\\n", " ") literal \n
  x <- gsub('"', " ", x, fixed = TRUE)       # str_replace_all("\\\"", " ")
  x <- icu_sub(x, "\t", " ")                 # str_replace_all("\\t", " ")
  x <- icu_sub(x, "\\p{So}", " ")            # stri_replace_all_regex("\\p{So}", " ")
  x <- gsub(",", " ", x, fixed = TRUE)
  x <- gsub("-", " ", x, fixed = TRUE)
  x <- gsub(".", " ", x, fixed = TRUE)       # str_replace_all("\\.", " ")
  x <- gsub("/", " ", x, fixed = TRUE)
  icu_sub(x, "[[:blank:]]+", " ", pcre = "\\h+")
}

## The app's wordcount: stringr::str_count(text) with the default empty
## pattern counts characters (grapheme clusters), not words.
legacy_char_count <- function(x) {
  if (have_stringi()) {
    as.integer(stringi::stri_count_boundaries(x, type = "character"))
  } else {
    nchar(x, type = "chars")
  }
}

## Public dispatchers ---------------------------------------------------------
clean_pdf_text <- function(pages, legacy = legacy_clean_enabled()) {
  if (isTRUE(legacy)) {
    .clean_pdf_text_legacy(pages)
  } else {
    .clean_pdf_text_current(pages)
  }
}

clean_for_bow <- function(x, legacy = legacy_clean_enabled()) {
  if (isTRUE(legacy)) {
    .clean_for_bow_legacy(x)
  } else {
    .clean_for_bow_current(x)
  }
}
