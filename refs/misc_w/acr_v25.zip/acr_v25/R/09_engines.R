## ---------------------------------------------------------------------------
## 09_engines.R -- keyword counters, engine comparison, frequency validation
## Every counter returns: doc_id, email, keyword, Freq, Freq_binary
##   regex    (05_bow.R)     whole-token regex on clean_for_bow() text
##   quanteda (here)         unigrams + 2..n-grams on clean_for_bow() text
##   app      (11_legacy.R)  the Shiny app's tokenize.R, selected by --legacy
## ---------------------------------------------------------------------------

empty_counts <- function() data.frame(doc_id = integer(), email = character(),
  keyword = character(), Freq = integer(), Freq_binary = integer(), stringsAsFactors = FALSE)

mat_to_counts <- function(mat, docs, terms) {
  nz <- which(mat > 0, arr.ind = TRUE)
  if (!nrow(nz)) return(empty_counts())
  res <- data.frame(doc_id = docs$doc_id[nz[, 1L]], email = docs$email[nz[, 1L]],
                    keyword = terms[nz[, 2L]], Freq = as.integer(mat[nz]),
                    Freq_binary = 1L, stringsAsFactors = FALSE)
  res <- res[order(res$doc_id, res$keyword), , drop = FALSE]
  rownames(res) <- NULL
  res
}

## quanteda counter. Unigrams plus 2..n-grams, so a unigram inside a phrase
## still counts, as in the regex counter and tokenize.R.
count_keywords_quanteda <- function(docs, keywords, cores = 1L) {
  require_pkgs("quanteda", "the quanteda bag of words")
  quanteda::quanteda_options(threads = max(1L, as.integer(cores)))
  terms <- unique(keywords$keyword)
  if (!length(terms) || !nrow(docs)) return(empty_counts())
  toks <- quanteda::tokens(docs$text, what = "fastestword")
  mat <- as.matrix(quanteda::dfm_match(quanteda::dfm(toks, tolower = FALSE), terms))
  nmax <- max(lengths(strsplit(terms, " ", fixed = TRUE)))
  if (nmax > 1L) {
    ng <- quanteda::tokens_ngrams(toks, n = 2:nmax, concatenator = " ")
    mat <- mat + as.matrix(quanteda::dfm_match(quanteda::dfm(ng, tolower = FALSE), terms))
  }
  mat_to_counts(mat, docs, terms)
}

## ---- comparison of unweighted frequencies across engines ----
## Keywords are compared in their clean_for_bow() form so the app engine's raw
## keys ("c++", "program management ") line up with the other engines.
compare_engines <- function(results, keywords, rpt) {
  dts <- lapply(names(results), function(nm) {
    d <- data.table::as.data.table(results[[nm]])
    d[, keyword := clean_for_bow(keyword)]
    d <- d[, .(Freq = sum(Freq)), by = .(email, keyword)]
    data.table::setnames(d, "Freq", nm); d })
  m <- Reduce(function(a, b) merge(a, b, by = c("email", "keyword"), all = TRUE), dts)
  eng <- names(results)
  for (e in eng) data.table::set(m, which(is.na(m[[e]])), e, 0L)
  m[, identical := apply(.SD, 1L, function(r) length(unique(r)) == 1L), .SDcols = eng]
  kw <- unique(data.table::as.data.table(keywords)[, .(keyword, category)])
  m <- merge(m, kw, by = "keyword", allow.cartesian = TRUE)
  data.table::fwrite(m[order(email, category, keyword)], rpt("engine_comparison_keywords.csv"))
  bycat <- m[, lapply(.SD, sum), by = .(email, category), .SDcols = eng]
  bycat[, identical := apply(.SD, 1L, function(r) length(unique(r)) == 1L), .SDcols = eng]
  data.table::fwrite(bycat, rpt("engine_comparison_categories.csv"))
  msg("engine comparison: %d/%d keyword rows and %d/%d candidate x category rows identical",
      sum(m$identical), nrow(m), sum(bycat$identical), nrow(bycat))
  invisible(m)
}

## ---- --test-input-frequency ----
## Accepts a Detailed Frequency sheet / detailed_frequency.csv or any csv/xlsx
## with an email column (email | Applicant Email Address), keyword|keywords and
## Freq. Rows are summed per e-mail x keyword, so duplicated keyword rows in
## an app workbook compare correctly against a de-duplicated engine.
validate_frequency <- function(counts, path, rpt, keyword_key = clean_for_bow) {
  exp <- read_table_dt_sheet(path)
  nm <- names(exp)
  ec <- intersect(c("email", "Applicant Email Address"), nm)[1L]
  kc <- intersect(c("keyword", "keywords"), nm)[1L]
  if (is.na(ec) || is.na(kc) || !"Freq" %in% nm)
    die("%s needs email, keyword(s) and Freq columns", basename(path))
  exp <- exp[, .(email = tolower(trimws(get(ec))), keyword = keyword_key(get(kc)),
                 expected = as.integer(Freq))]
  exp <- unique(exp)                                   # one row per distinct hit
  exp <- exp[, .(expected = sum(expected)), by = .(email, keyword)]
  got <- data.table::as.data.table(counts)
  got[, keyword := keyword_key(keyword)]
  got <- got[email %in% exp$email, .(got = sum(Freq)), by = .(email, keyword)]
  m <- merge(exp, got, by = c("email", "keyword"), all = TRUE)
  m[is.na(expected), expected := 0L][is.na(got), got := 0L][, ok := expected == got]
  data.table::fwrite(m[order(ok, email, keyword)], rpt("frequency_validation.csv"))
  bad <- m[ok == FALSE]
  if (nrow(bad)) {
    acr_warn("frequency validation FAILED: %d of %d rows differ (see frequency_validation.csv)",
             nrow(bad), nrow(m))
    print_df(as.data.frame(bad), 10L)
  } else msg("frequency validation passed: %d rows identical", nrow(m))
  !nrow(bad)
}

## Read a sheet of an app workbook for --test-input-frequency: pdf/xlsx with a
## "Detailed Frequency" sheet is read from that sheet, anything else as-is.
read_table_dt_sheet <- function(path, sheet = "Detailed Frequency") {
  ext <- tolower(tools::file_ext(path))
  if (ext %in% c("xlsx", "xls")) {
    require_pkgs("readxl", "reading the frequency file")
    sheets <- readxl::excel_sheets(path)
    sh <- if (sheet %in% sheets) sheet else 1L
    return(data.table::as.data.table(readxl::read_excel(path, sheet = sh, col_types = "text")))
  }
  read_table_dt(path)
}
