## ---------------------------------------------------------------------------
## 05_bow.R -- keyword dictionary, per page extraction choice, bag of words
## Port of optimize_extract.R / bow.R / corpus.R / tokenize.R
## ---------------------------------------------------------------------------

KEYWORDS_REQUIRED <- c("category", "keyword")

## Read the keywords/weights file. Expected columns: category, keyword and
## (optionally) score_adjustment; the comparison is case insensitive.
load_keywords <- function(path) {
  ext <- tolower(tools::file_ext(path))
  kw <- if (ext %in% c("xlsx", "xls")) {
    require_pkgs("readxl", "reading the keywords file")
    as.data.frame(readxl::read_excel(path))
  } else {
    utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
  }
  names(kw) <- trimws(names(kw))
  lower <- tolower(names(kw))
  for (want in KEYWORDS_REQUIRED) {
    j <- which(lower == want)
    if (!length(j)) die("keywords file %s has no '%s' column", basename(path), want)
    names(kw)[j[1L]] <- want
  }
  j <- which(lower %in% c("score_adjustment", "weight", "score adjustment"))
  if (length(j)) {
    names(kw)[j[1L]] <- "score_adjustment"
  } else {
    kw$score_adjustment <- 1
    acr_warn("no score_adjustment column in %s; all weights set to 1", basename(path))
  }

  kw$category <- trimws(as.character(kw$category))
  kw$keyword <- clean_for_bow(kw$keyword)
  kw$score_adjustment <- suppressWarnings(as.numeric(kw$score_adjustment))
  kw$score_adjustment[is.na(kw$score_adjustment)] <- 1
  kw <- kw[nzchar(kw$keyword) & nzchar(kw$category), c("category", "keyword", "score_adjustment")]
  kw <- unique(kw)
  rownames(kw) <- NULL

  msg("keywords: %d term(s) across %d categor(ies)", nrow(kw),
      length(unique(kw$category)))
  kw
}

## Per page, keep the extraction (embedded text vs OCR) that hits more of the
## keyword dictionary -- find_optimum_function() in the Shiny app.
choose_extraction <- function(pages, keywords) {
  text_clean <- clean_for_bow(pages$text)
  if (is.null(pages$ocr)) {
    msg("only one text layer available; using embedded PDF text for every page")
    return(list(pages = text_clean,
                source = rep("pdf_text", length(text_clean)),
                matches = data.frame(page = seq_along(text_clean),
                                     pdf_text = NA_integer_, ocr = NA_integer_)))
  }
  ocr_clean <- clean_for_bow(pages$ocr)
  if (length(ocr_clean) < length(text_clean)) {
    ocr_clean <- c(ocr_clean, rep("", length(text_clean) - length(ocr_clean)))
  }
  ocr_clean <- ocr_clean[seq_along(text_clean)]
  terms <- unique(keywords$keyword)

  ## One alternation regex per page instead of one regex per keyword: this is
  ## only a relative score used to pick a layer, so the small undercount from
  ## overlapping terms does not matter (longest terms are tried first).
  terms_sorted <- terms[order(-nchar(terms))]
  pat <- paste0("(?<![[:alnum:]])(", paste(rx_escape(terms_sorted), collapse = "|"),
                ")(?![[:alnum:]])")
  n_hits <- function(txt) {
    if (is.na(txt) || !nzchar(txt)) return(0L)
    m <- gregexpr(pat, txt, perl = TRUE)[[1L]]
    if (length(m) == 1L && m[1L] == -1L) return(0L)
    length(unique(regmatches(txt, gregexpr(pat, txt, perl = TRUE))[[1L]]))
  }
  hits_text <- vapply(text_clean, n_hits, integer(1), USE.NAMES = FALSE)
  hits_ocr <- vapply(ocr_clean, n_hits, integer(1), USE.NAMES = FALSE)

  use_text <- hits_text >= hits_ocr
  chosen <- ifelse(use_text, text_clean, ocr_clean)
  msg("extraction choice: %d page(s) from embedded text, %d from OCR",
      sum(use_text), sum(!use_text))
  list(pages = chosen,
       source = ifelse(use_text, "pdf_text", "tesseract_ocr"),
       matches = data.frame(page = seq_along(chosen),
                            pdf_text = hits_text, ocr = hits_ocr,
                            used = ifelse(use_text, "pdf_text", "tesseract_ocr"),
                            stringsAsFactors = FALSE))
}

## One document per candidate: the chosen text of that candidate's pages.
build_documents <- function(chosen_pages, cand) {
  docs <- character(nrow(cand))
  start <- as.integer(cand$startPage)
  end <- pmax(as.integer(cand$endPage), start)
  for (i in seq_len(nrow(cand))) {
    idx <- seq.int(start[i], end[i])
    idx <- idx[idx >= 1L & idx <= length(chosen_pages)]
    docs[i] <- paste(chosen_pages[idx], collapse = " ")
  }
  ## character count per document; the Shiny app's "wordcount" is also a
  ## character count (stringr::str_count), the column name is kept for
  ## output compatibility.
  wc <- if (legacy_clean_enabled()) legacy_char_count(docs) else nchar(docs)
  data.frame(doc_id = seq_len(nrow(cand)),
             email = cand$email,
             text = docs,
             wordcount = pmax(wc, 1L),   # guard against empty resumes
             resumelength = end - start + 1L,
             stringsAsFactors = FALSE)
}

## Bag of words: one row per candidate x keyword actually present.
## Freq is the number of occurrences, Freq_binary is presence (0/1).
count_keywords <- function(docs, keywords) {
  terms <- unique(keywords$keyword)
  out <- vector("list", nrow(docs))
  for (i in seq_len(nrow(docs))) {
    txt <- docs$text[i]
    freq <- vapply(terms, function(k) count_token(txt, k), integer(1), USE.NAMES = FALSE)
    hit <- freq > 0L
    if (!any(hit)) next
    out[[i]] <- data.frame(doc_id = docs$doc_id[i],
                           email = docs$email[i],
                           keyword = terms[hit],
                           Freq = freq[hit],
                           Freq_binary = 1L,
                           stringsAsFactors = FALSE)
  }
  out <- out[!vapply(out, is.null, logical(1))]
  if (!length(out)) {
    return(data.frame(doc_id = integer(), email = character(), keyword = character(),
                      Freq = integer(), Freq_binary = integer(),
                      stringsAsFactors = FALSE))
  }
  res <- do.call(rbind, out)
  msg("bag of words: %d keyword hit(s) across %d candidate(s)",
      nrow(res), length(unique(res$doc_id)))
  res
}
