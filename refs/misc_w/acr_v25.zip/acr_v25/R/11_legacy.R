## ---------------------------------------------------------------------------
## 11_legacy.R -- faithful port of the Shiny app's scoring pipeline
##   optimize_extract.R -> bow.R -> corpus.R -> tokenize.R -> score.R
##   -> output_score.R
##
## Selected with --legacy (engine "app"). Together with --legacy-clean the
## Detailed Frequency / Score Frequency / Proportion sheets reproduce the
## app's *-ResumeRank.xlsx workbooks, quirks included:
##   * the keyword table is used as uploaded: lower-cased, NOT trimmed and
##     NOT de-duplicated. A keyword listed twice produces two rows per
##     resume, and "count" is the number of rows (not distinct terms) in
##     the category.
##   * quanteda's word tokenizer with remove_punct/remove_symbols strips
##     "+", "#", "&", so "c++" is counted as "c".
##   * stop words are removed before the 2-4-grams are formed.
##   * "wordcount" is the character count of the cleaned resume text.
##   * the unweighted score is the min-max scaled Freq/wordcount measure,
##     summed per category and divided by count; weighted multiplies by
##     score_adjustment first. Both are rescaled so the best resume per
##     category scores 5.
## ---------------------------------------------------------------------------

LEGACY_ENGINE <- "app"

## Keyword table as the app sees it: category/keyword lower-cased, nothing
## else. read.csv(colClasses = c(factor, character, numeric)) in the app
## implies exactly these three columns, in this order; here they are found
## by name (case-insensitive) so the current keyword files keep working.
load_keywords_app <- function(path) {
  ext <- tolower(tools::file_ext(path))
  kw <- if (ext %in% c("xlsx", "xls")) {
    require_pkgs("readxl", "reading the keywords file")
    as.data.frame(readxl::read_excel(path, col_types = "text"), stringsAsFactors = FALSE)
  } else {
    utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE,
                    colClasses = "character", encoding = "UTF-8")
  }
  lower <- tolower(trimws(names(kw)))
  pick <- function(opts) { j <- which(lower %in% opts); if (length(j)) kw[[j[1L]]] else NULL }
  category <- pick("category"); keyword <- pick("keyword")
  if (is.null(category) || is.null(keyword))
    die("keywords file %s needs 'category' and 'keyword' columns", basename(path))
  adj <- pick(c("score_adjustment", "weight", "score adjustment"))
  if (is.null(adj)) {
    adj <- rep(1, length(keyword))
    acr_warn("no score_adjustment column in %s; all weights set to 1", basename(path))
  }
  out <- data.frame(category = tolower(as.character(category)),
                    keyword = tolower(as.character(keyword)),
                    score_adjustment = suppressWarnings(as.numeric(adj)),
                    stringsAsFactors = FALSE)
  out <- out[!is.na(out$keyword) & !is.na(out$category), , drop = FALSE]
  out$score_adjustment[is.na(out$score_adjustment)] <- 1
  rownames(out) <- NULL
  n_dup <- sum(duplicated(out$keyword))
  n_ws <- sum(out$keyword != trimws(out$keyword) | out$category != trimws(out$category))
  msg("keywords (app mode): %d row(s), %d categor(ies); %d duplicated keyword(s), %d with leading/trailing blanks kept as-is",
      nrow(out), length(unique(out$category)), n_dup, n_ws)
  out
}

## optimize_extract.R: per page, the layer (embedded text vs OCR) matching
## more keywords wins, keywords are used as ICU regular expressions and a
## tie goes to the embedded text. Pages are the clean_for_bow() text.
choose_extraction_app <- function(pages, kw_app) {
  text_clean <- clean_for_bow(pages$text)
  if (is.null(pages$ocr)) {
    msg("only one text layer available; using embedded PDF text for every page")
    return(list(pages = text_clean, source = rep("pdf_text", length(text_clean)),
                matches = data.frame(page = seq_along(text_clean),
                                     pdf_text = NA_integer_, ocr = NA_integer_)))
  }
  ocr_clean <- clean_for_bow(pages$ocr)
  length(ocr_clean) <- length(text_clean)
  ocr_clean[is.na(ocr_clean)] <- ""
  kws <- kw_app$keyword                                   # duplicates included, as in the app
  detect <- if (have_stringi()) {
    function(txt, k) tryCatch(isTRUE(stringi::stri_detect_regex(txt, k)), error = function(e) FALSE)
  } else {
    function(txt, k) tryCatch(isTRUE(grepl(k, txt, perl = TRUE)), error = function(e) FALSE)
  }
  n_hits <- function(txt) sum(vapply(kws, function(k) detect(txt, k), logical(1)))
  hits_text <- vapply(text_clean, n_hits, integer(1), USE.NAMES = FALSE)
  hits_ocr <- vapply(ocr_clean, n_hits, integer(1), USE.NAMES = FALSE)
  use_text <- hits_text >= hits_ocr                        # which.max(): first wins a tie
  msg("extraction choice (app rule): %d page(s) from embedded text, %d from OCR",
      sum(use_text), sum(!use_text))
  list(pages = ifelse(use_text, text_clean, ocr_clean),
       source = ifelse(use_text, "pdf_text", "tesseract_ocr"),
       matches = data.frame(page = seq_along(text_clean), pdf_text = hits_text,
                            ocr = hits_ocr, used = ifelse(use_text, "pdf_text", "tesseract_ocr"),
                            stringsAsFactors = FALSE))
}

## bow.R + corpus.R: the text that is tokenised.
clean_corpus_app <- function(x) {
  x <- gsub("�", "", x, fixed = TRUE)                   # bow.R
  x <- iconv(x, "UTF-8", "ASCII", sub = "")
  x <- gsub("\\(", " ", x)                                   # corpus.R, same order
  x <- gsub("\\\\n", " ", x)
  x <- gsub("\\\n", " ", x)
  x <- gsub("\\\\r", " ", x)
  x <- gsub("\\\\t", " ", x)
  x <- gsub("-", " ", x)
  x <- gsub("'", "", x)
  x <- gsub("[^0123456789a-zA-Z++#&/ ]", "", x)              # deleted, not spaced
  x <- tolower(x)
  gsub("[[:space:]]+", " ", x)                               # tm::stripWhitespace
}

## tokenize.R: unigrams + 2..4-grams after stop word removal, filtered to the
## keyword list. Returns doc_id, email, keyword, Freq, Freq_binary.
count_keywords_app <- function(docs, kw_app) {
  require_pkgs(c("quanteda", "stopwords"), "the app (legacy) bag of words")
  if (!nrow(docs)) return(empty_counts())
  keywords_csv <- unique(kw_app$keyword)
  toks <- quanteda::tokens(clean_corpus_app(docs$text), remove_numbers = TRUE,
                           remove_punct = TRUE, remove_symbols = TRUE,
                           remove_separators = TRUE)
  toks <- quanteda::tokens_remove(toks, stopwords::stopwords("en"))
  ngrams <- quanteda::tokens_ngrams(toks, n = 2:4, concatenator = " ")
  one <- function(i) {
    tab <- c(table(as.character(toks[[i]])), table(as.character(ngrams[[i]])))
    tab <- tab[names(tab) %in% keywords_csv]
    if (!length(tab)) return(NULL)
    data.frame(doc_id = docs$doc_id[i], email = docs$email[i], keyword = names(tab),
               Freq = as.integer(tab), Freq_binary = 1L, stringsAsFactors = FALSE)
  }
  out <- Filter(Negate(is.null), lapply(seq_len(nrow(docs)), one))
  if (!length(out)) return(empty_counts())
  res <- do.call(rbind, out)
  rownames(res) <- NULL
  msg("bag of words (app): %d keyword hit(s) across %d candidate(s)",
      nrow(res), length(unique(res$doc_id)))
  res
}

## score.R, first half: the long table behind every sheet. One row per hit
## x keyword-table row (so duplicated keywords duplicate rows), count = rows
## per category, ratio min-max scaled to [1, 5].
build_joined_app <- function(counts, kw_app, docs) {
  if (!nrow(counts)) return(counts)
  denom <- as.data.frame(table(category = kw_app$category), stringsAsFactors = FALSE)
  names(denom)[2L] <- "count"
  d <- merge(counts, kw_app, by = "keyword", all.x = TRUE, all.y = FALSE)
  d <- d[!is.na(d$category), , drop = FALSE]
  d <- merge(d, denom, by = "category", all.x = TRUE)
  d <- merge(d, docs[, c("doc_id", "wordcount", "resumelength")], by = "doc_id", all.x = TRUE)
  ratio <- d$Freq / d$wordcount
  rng <- range(ratio)
  d$ratio <- ratio
  d$Freq_normalized <- if (diff(rng) > 0) 1 + ((ratio - rng[1L]) / (rng[2L] - rng[1L])) * 4 else
    rep(NaN, length(ratio))                      # the app divides by zero here too
  d$column_lab <- paste0("content", d$doc_id)
  ## the app's row order: merge() on column_lab sorts the labels as strings
  d <- d[order(d$column_lab, d$category, d$keyword, method = "radix"), , drop = FALSE]
  rownames(d) <- NULL
  d
}

## score.R create_scores_table(): list(scores, proportion) for one weighting.
score_matrix_app <- function(joined, kw_app, docs, weighted = FALSE) {
  cats_file <- unique(kw_app$category)                 # keyword-file order (output_score)
  value <- joined$Freq_normalized
  if (weighted) value <- value * joined$score_adjustment
  agg <- stats::aggregate(list(value = value),
                          by = list(doc_id = joined$doc_id, category = joined$category), FUN = sum)
  agg$count <- as.numeric(joined$count[match(agg$category, joined$category)])
  agg$adj <- agg$value / agg$count

  ids <- sort(unique(agg$doc_id))
  cats_hit <- sort(unique(agg$category))               # dcast() sorts the columns
  prop <- matrix(0, nrow = length(ids), ncol = length(cats_hit),
                 dimnames = list(as.character(ids), cats_hit))
  prop[cbind(match(agg$doc_id, ids), match(agg$category, cats_hit))] <- agg$adj

  scaled <- prop
  for (j in seq_len(ncol(scaled))) {
    mx <- max(scaled[, j])
    scaled[, j] <- if (is.finite(mx) && mx > 0) ceiling(scaled[, j] * (5 / mx)) else 0
  }
  total <- if (ncol(scaled) > 1L) rowSums(scaled) else as.numeric(scaled[, 1L])

  scores <- data.frame(doc_id = ids, email = docs$email[match(ids, docs$doc_id)],
                       check.names = FALSE, stringsAsFactors = FALSE)
  for (cl in cats_hit) scores[[cl]] <- as.numeric(scaled[, cl])
  scores[["Total Score"]] <- as.numeric(total)
  scores$resumelength <- docs$resumelength[match(ids, docs$doc_id)]
  scores$quartile <- score_quartile(total)             # quantiles over resumes with hits only
  for (cl in setdiff(cats_file, names(scores))) scores[[cl]] <- 0

  ## resumes without a single keyword: all zeros (resumelength and quartile too)
  missing <- docs[!docs$doc_id %in% ids, , drop = FALSE]
  if (nrow(missing)) {
    zero <- scores[rep(NA_integer_, nrow(missing)), , drop = FALSE]
    zero[] <- lapply(zero, function(col) if (is.character(col)) "" else 0)
    zero$doc_id <- missing$doc_id
    zero$email <- missing$email
    scores <- rbind(scores, zero)
  }
  scores <- scores[order(scores$email, method = "radix"), , drop = FALSE]  # merge(name_table) sorts by email
  rownames(scores) <- NULL

  pr <- data.frame(doc_id = ids, email = docs$email[match(ids, docs$doc_id)],
                   check.names = FALSE, stringsAsFactors = FALSE)
  for (cl in cats_hit) pr[[cl]] <- round(as.numeric(prop[, cl]), 3)
  for (cl in setdiff(cats_file, names(pr))) pr[[cl]] <- 0
  pr <- pr[order(pr$email, method = "radix"), , drop = FALSE]
  rownames(pr) <- NULL
  list(scores = scores, proportion = pr, categories = cats_file)
}

## output_score.R column layouts -------------------------------------------
app_name_cols <- function(df, name_table) {
  nt <- as.data.frame(name_table, stringsAsFactors = FALSE, check.names = FALSE)
  ec <- "Applicant Email Address"
  if (!ec %in% names(nt)) die("names sheet has no '%s' column", ec)
  nt[[ec]] <- tolower(trimws(as.character(nt[[ec]])))
  nt <- nt[!duplicated(nt[[ec]]), , drop = FALSE]
  i <- match(df$email, nt[[ec]])
  for (cl in c("Applicant First Name", "Applicant Last Name")) {
    df[[cl]] <- if (cl %in% names(nt)) as.character(nt[[cl]])[i] else NA_character_
  }
  df$.in_names <- !is.na(i)
  df
}

score_sheet_app <- function(scores, cats, name_table) {
  d <- app_name_cols(scores, name_table)
  d <- d[d$.in_names, , drop = FALSE]                 # merge(): inner join on e-mail
  out <- d[, c(REPORT_NAME_COLS, "resumelength", cats, "Total Score", "quartile"), drop = FALSE]
  rownames(out) <- NULL
  attr(out, "category_cols") <- cats
  out
}

proportion_sheet_app <- function(prop, cats, name_table) {
  d <- app_name_cols(prop, name_table)
  out <- d[, c(REPORT_NAME_COLS, cats), drop = FALSE]
  rownames(out) <- NULL
  out
}

detailed_sheet_app <- function(joined, name_table) {
  if (!nrow(joined)) {
    return(as.data.frame(stats::setNames(replicate(length(DETAILED_REPORT_COLS), character(0),
                                                   simplify = FALSE), DETAILED_REPORT_COLS),
                         stringsAsFactors = FALSE, check.names = FALSE))
  }
  d <- app_name_cols(joined, name_table)
  d$keywords <- d$keyword
  out <- d[, DETAILED_REPORT_COLS, drop = FALSE]
  rownames(out) <- NULL
  out
}

## matched keywords per candidate x category (the app's matched_keywords_df)
matched_keywords_app <- function(detailed) {
  if (!nrow(detailed)) return(data.frame(email = character(), category = character(),
                                         keywords_matched = character(), stringsAsFactors = FALSE))
  key <- paste(detailed$email, detailed$category, sep = "\r")
  agg <- tapply(detailed$keywords, key, paste0, collapse = "; ")
  parts <- do.call(rbind, strsplit(names(agg), "\r", fixed = TRUE))
  data.frame(email = parts[, 1L], category = parts[, 2L],
             keywords_matched = as.character(agg), stringsAsFactors = FALSE)
}

## The app's download name: <date>-<pdf name>-<weighting>-ResumeRank.xlsx
app_workbook_name <- function(pdf, weighting) {
  sprintf("%s-%s-%s-ResumeRank.xlsx", format(Sys.Date()),
          tools::file_path_sans_ext(basename(pdf)), weighting)
}
