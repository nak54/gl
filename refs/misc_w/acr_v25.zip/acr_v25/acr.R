#!/usr/bin/env Rscript
## acr.R -- Automated Candidate Review, command line edition (R 4.6)
ACR_VERSION <- "2.5.0"

acr_script_dir <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  f <- sub("^--file=", "", args[grepl("^--file=", args)])
  if (length(f)) return(dirname(normalizePath(f[1L], winslash = "/", mustWork = FALSE)))
  getwd()
}
ACR_HOME <- acr_script_dir()
helper_dir <- file.path(ACR_HOME, "R")
## Only canonical NN_name.R helpers: backups such as 07_reportb4.R, 02_clean0.R
## or 02_cleanv2.R sort after the real file and would silently override it.
helpers <- sort(list.files(helper_dir, pattern = "^[0-9]{2}_[A-Za-z]+\\.R$", full.names = TRUE))
if (!length(helpers)) stop("no helper files found in ", helper_dir, call. = FALSE)
for (f in helpers) source(f, local = FALSE)
suppressPackageStartupMessages(library(data.table))

needed <- c("load_names", "split_phone_numbers", "detect_candidates", "finalise_pages",
            "merge_manual", "search_names", "search_field", "load_keywords",
            "choose_extraction", "build_documents", "count_keywords", "build_joined",
            "score_matrix", "attach_applicant_info", "detailed_table",
            "matched_keywords_table", "chart_ranking", "chart_stacked", "chart_heatmap",
            "write_workbook", "count_keywords_quanteda", "compare_engines",
            "validate_frequency", "report_categories", "score_report_sheet",
            "proportion_report_sheet", "detailed_report_sheet", "write_score_report",
            ## 11_legacy.R (app-faithful pipeline)
            "load_keywords_app", "choose_extraction_app", "count_keywords_app",
            "build_joined_app", "score_matrix_app", "score_sheet_app",
            "proportion_sheet_app", "detailed_sheet_app", "matched_keywords_app",
            "app_workbook_name", "legacy_char_count")
miss <- needed[!vapply(needed, exists, logical(1), mode = "function")]
if (length(miss)) stop("helpers missing: ", paste(miss, collapse = ", "),
                       " (R/ must contain 02_clean.R, 09_engines.R and 11_legacy.R from v2.5)", call. = FALSE)

stamp <- function() format(Sys.time(), "%Y%m%d_%H%M%S")

## ---------------------------------------------------------------------------
## Combined PDF: detect -> manual merge -> require-all gate -> split
## ---------------------------------------------------------------------------
write_unmatched <- function(people, matched_emails, extra = NULL, dir) {
  um <- as.data.table(people)[!email %in% matched_emails,
          .(firstName, lastName, email, phone, otherPhones,
            reason = "not detected (name/email/phone)",
            startPage = NA_integer_, endPage = NA_integer_)]
  if (!is.null(extra) && nrow(extra)) um <- rbind(um, extra, fill = TRUE)
  if (!nrow(um)) return(list(n = 0L, path = NA_character_))
  path <- file.path(dir, sprintf("unmatched_names_%s.csv", stamp()))
  fwrite(um, path)
  acr_warn("%d unmatched name(s) written to %s (fill startPage/endPage, rerun with --manual)",
           nrow(um), path)
  list(n = nrow(um), path = path)
}

split_combined_pdf <- function(pdf, cand, dir) {
  ensure_dir(dir)
  safe <- gsub("[^A-Za-z0-9._@+-]", "_", cand$email)
  out <- file.path(dir, sprintf("%s_resume.pdf", safe))
  for (i in seq_len(nrow(cand))) {
    pdftools::pdf_subset(pdf, pages = cand$startPage[i]:cand$endPage[i], output = out[i])
  }
  msg("split %s into %d resume PDF(s) in %s", basename(pdf), nrow(cand), dir)
  out
}

link_combined <- function(o, pages, people, op) {
  det <- detect_candidates(pages, people, pages$n_pages)
  matched <- merge_manual(det$matched, o$manual, pages$n_pages)
  um <- write_unmatched(people, matched$email, dir = op$reports)
  if (o$require_all && um$n) {
    die("-r/--require-all: %d of %d applicant(s) were not found in %s; see %s",
        um$n, nrow(people), basename(o$pdf), um$path)
  }
  files <- if (o$split) split_combined_pdf(o$pdf, matched, op$split_dir) else
    sprintf("%s_resume.pdf", gsub("[^A-Za-z0-9._@+-]", "_", matched$email))
  data.frame(file = basename(files), email = matched$email,
             firstName = matched$firstName, lastName = matched$lastName,
             method = matched$method, startPage = matched$startPage,
             endPage = matched$endPage, resumeLength = matched$resumeLength,
             stringsAsFactors = FALSE)
}

## ---------------------------------------------------------------------------
## Command line
## ---------------------------------------------------------------------------
USAGE <- r"(
Automated Candidate Review (ACR) -- command line edition

Usage:
  Rscript acr.R -p RESUMES.pdf|RESUME_FOLDER -n NAMES.csv|.xlsx -k KEYWORDS.csv -o OUT [options]

Inputs:
  -d, --dir DIR              fallback base folder for inputs        [data]
  -p, --pdf PATH             combined resume PDF (split by detected names) or a
                             folder of per-candidate PDFs
  -n, --names FILE           USAS names (.csv/.xlsx). "Applicant Phone Numbers" /
                             "Phone Numbers" is split into Applicant Phone Number +
                             Applicant Other Phones
  -k, --keywords FILE        category,keyword[,score_adjustment]
      --manual FILE          filled-in unmatched_names_*.csv (startPage/endPage)
      --names-out FILE       also write the names sheet with split phones

Output:
  -o, --out DIR              reports/, viz/, split/                 [acr_output]
                             reports/acr_scores_<score>_<weighting>.xlsx, each with
                             Score Frequency, Detailed Frequency, Proportion sheets
      --no-split             do not write the per-candidate PDFs to split/

Matching:
  -r, --require-all          stop if any applicant is unmatched (before splitting)

Processing:
  -e, --engine NAME          regex | quanteda | app                 [regex]
      --legacy               same as --engine app: the Shiny app's bag of words
                             (quanteda tokenizer, stop words removed, 2-4-grams,
                             keyword file used as uploaded: duplicates kept,
                             count = rows per category). Writes the app's
                             <date>-<pdf>-<weighting>-ResumeRank.xlsx workbooks.
      --legacy-clean         the Shiny app's clean.R text normalisation (ICU
                             regexes; wordcount = characters of that text).
                             --legacy --legacy-clean reproduces the app output.
      --compare              run all engines, write engine_comparison_*.csv
      --test-input-frequency FILE
                             validate per-candidate keyword Freq against FILE
                             (csv, or an xlsx with a Detailed Frequency sheet);
                             exit status 2 on any mismatch
      --no-ocr | --ocr-all   (--ocr-all recommended for combined-PDF name detection;
                             the app always OCRs every page at 600 dpi)
      --min-chars N          [100]   -c, --cores N   --dpi N [300; 600 with --legacy]

Scoring:
  -s, --score LIST  binary,normalized|both   --weights LIST  weighted,unweighted|both
                    (-s is ignored with --legacy: the app has one measure)
  -t, --top N [25]  --pct P   -q/--quiet  -v/--verbose  -V/--version  -h/--help
)"

default_opts <- function() {
  list(dir = "data", pdf = NA_character_, names = NA_character_,
       keywords = NA_character_, out = "acr_output", engine = "regex",
       legacy_clean = FALSE, compare = FALSE, test_freq = NA_character_, manual = NA_character_,
       names_out = NA_character_, require_all = FALSE, split = TRUE,
       ocr = "auto", min_chars = 100L, cores = NA_integer_, dpi = NA_integer_,
       score = c("binary", "normalized"), weights = c("unweighted", "weighted"),
       top = 25L, pct = NA_real_, verbosity = 1L)
}

split_list <- function(x) { out <- trimws(unlist(strsplit(x, "[,;[:space:]]+"))); out[nzchar(out)] }
match_choices <- function(x, allowed, flag) {
  x <- tolower(x)
  if (any(c("both", "all") %in% x)) return(allowed)
  bad <- setdiff(x, allowed)
  if (length(bad)) die("%s: unknown value(s) %s", flag, paste(bad, collapse = ", "))
  x[order(match(x, allowed))]
}

ENGINES <- c("regex", "quanteda", "app")

parse_args <- function(argv) {
  o <- default_opts(); i <- 1L
  while (i <= length(argv)) {
    a <- argv[i]; val <- NA_character_
    if (grepl("^--[^=]+=", a)) { val <- sub("^--[^=]+=", "", a); a <- sub("=.*$", "", a) }
    getval <- function() {
      if (!is.na(val)) return(val)
      if (i + 1L > length(argv)) die("option %s needs a value", a)
      i <<- i + 1L; argv[i]
    }
    switch(a,
      "-d" = , "--dir" = { o$dir <- getval() },
      "-p" = , "--pdf" = { o$pdf <- getval() },
      "-n" = , "--names" = { o$names <- getval() },
      "-k" = , "--keywords" = { o$keywords <- getval() },
      "-o" = , "--out" = { o$out <- getval() },
      "--manual" = { o$manual <- getval() },
      "--names-out" = { o$names_out <- getval() },
      "-r" = , "--require-all" = { o$require_all <- TRUE },
      "--no-split" = { o$split <- FALSE },
      "-e" = , "--engine" = {
        e <- tolower(getval()); if (e == "original") e <- "app"
        o$engine <- match_choices(e, ENGINES, "--engine")[1L] },
      "--legacy" = { o$engine <- "app" },
      "--legacy-clean" = { o$legacy_clean <- TRUE },
      "--compare" = { o$compare <- TRUE },
      "--test-input-frequency" = { o$test_freq <- getval() },
      "-c" = , "--cores" = { o$cores <- as.integer(getval()) },
      "--dpi" = { o$dpi <- as.integer(getval()) },
      "--min-chars" = { o$min_chars <- as.integer(getval()) },
      "-s" = , "--score" = { o$score <- split_list(getval()) },
      "--weights" = { o$weights <- split_list(getval()) },
      "-t" = , "--top" = { o$top <- as.integer(getval()) },
      "--pct" = { o$pct <- as.numeric(getval()) },
      "--no-ocr" = { o$ocr <- "none" },
      "--ocr-all" = { o$ocr <- "all" },
      "-q" = , "--quiet" = { o$verbosity <- 0L },
      "-v" = , "--verbose" = { o$verbosity <- 2L },
      "-V" = , "--version" = { cat("acr.R", ACR_VERSION, "\n"); quit(save = "no", status = 0L) },
      "-h" = , "--help" = { cat(USAGE, "\n"); quit(save = "no", status = 0L) },
      die("unknown option: %s (try --help)", a))
    i <- i + 1L
  }
  o$score <- match_choices(o$score, c("binary", "normalized"), "--score")
  o$weights <- match_choices(o$weights, c("unweighted", "weighted"), "--weights")
  if (is.na(o$top) || o$top < 1L) o$top <- 25L
  if (is.na(o$dpi)) o$dpi <- if (o$engine == "app") 600L else 300L
  if (o$dpi < 72L) o$dpi <- 300L
  if (is.na(o$min_chars) || o$min_chars < 0L) o$min_chars <- 100L
  if (!is.na(o$cores) && o$cores < 1L) die("-c/--cores must be >= 1")
  o
}

resolve_inputs <- function(o) {
  for (k in c("pdf", "names", "keywords"))
    if (is.na(o[[k]])) die("--%s is required", k)
  for (k in c("pdf", "names", "keywords", "manual", "test_freq"))
    if (!is.na(o[[k]])) o[[k]] <- path.expand(resolve_path(o[[k]], o$dir))
  if (!file.exists(o$pdf)) die("resume PDF/folder not found: %s", o$pdf)
  o$combined <- !dir.exists(o$pdf)
  if (o$combined && !grepl("\\.pdf$", o$pdf, ignore.case = TRUE)) die("-p must be a .pdf or a folder")
  if (!file.exists(o$names)) die("names file not found: %s", o$names)
  if (!file.exists(o$keywords)) die("keywords file not found: %s", o$keywords)
  if (!is.na(o$test_freq) && !file.exists(o$test_freq)) die("frequency file not found: %s", o$test_freq)
  o
}

## ---------------------------------------------------------------------------
## Pipeline
## ---------------------------------------------------------------------------
run_engine <- function(engine, docs, keywords, kw_app, cores) {
  switch(engine,
    regex = count_keywords_par(docs, keywords, cores = cores),
    quanteda = count_keywords_quanteda(docs, keywords, cores = cores),
    app = count_keywords_app(docs, kw_app))
}

make_charts <- function(o, scores, cats, tag, sub, viz) {
  top_n <- if (!is.na(o$pct)) max(1L, ceiling(o$pct / 100 * nrow(scores))) else o$top
  sub <- sprintf("%s | top %d of %d", sub, min(top_n, nrow(scores)), nrow(scores))
  png <- function(k) viz(sprintf("%s_%s.png", k, tag))
  chart_ranking(scores, cats, png("top_candidates"), "Top applicants by total score", sub, top_n)
  chart_stacked(scores, cats, png("score_by_category"), "Score composition by keyword category", sub, top_n)
  chart_heatmap(scores, cats, png("category_heatmap"), "Category coverage per applicant", sub, top_n)
}

run_acr <- function(o) {
  acr_set_verbosity(o$verbosity)

  ## R/02_clean.R dispatches clean_pdf_text() and clean_for_bow() from this
  ## option. Separate from --legacy, which selects the app engine.
  previous_legacy_clean <- getOption("acr.legacy_clean", NULL)
  on.exit(options(acr.legacy_clean = previous_legacy_clean), add = TRUE)
  options(acr.legacy_clean = isTRUE(o$legacy_clean))
  clean_mode <- if (isTRUE(o$legacy_clean)) "legacy" else "current"
  app_mode <- o$engine == "app"

  require_pkgs(c("pdftools", "data.table"), "ACR")
  if (o$engine != "regex" || o$compare) require_pkgs("quanteda", "the quanteda/app engines")
  o <- resolve_inputs(o)
  op <- prepare_output(o$out)
  op$split_dir <- file.path(op$root, "split")
  rpt <- function(f) file.path(op$reports, f)
  viz <- function(f) file.path(op$viz, f)
  cores <- resolve_cores(o$cores)
  msg("ACR %s | engine %s | cleaning %s | %s input | cores %d | dpi %d",
      ACR_VERSION, o$engine, clean_mode,
      if (o$combined) "combined PDF" else "folder", cores, o$dpi)
  if (app_mode && !o$legacy_clean)
    acr_warn("--legacy without --legacy-clean: app bag of words on the current cleaner; add --legacy-clean to reproduce the app's workbooks")

  names_in <- load_names(o$names, o$names_out)
  people <- names_in$people
  keywords <- load_keywords(o$keywords)
  kw_app <- if (app_mode || o$compare) load_keywords_app(o$keywords) else NULL

  ## --- extract + link -------------------------------------------------------
  pdfs <- if (o$combined) o$pdf else list_resume_pdfs(o$pdf)
  pages <- with_timer("extraction", extract_folder(pdfs, dpi = o$dpi, cores = cores,
                                    ocr_mode = o$ocr, min_chars = o$min_chars))
  write_csv_safe(pages$page_log, rpt("ocr_pages.csv"))

  if (o$combined) {
    cand <- with_timer("detection + split", link_combined(o, pages, people, op))
  } else {
    cand <- with_timer("linking", match_files(pages, people, cores = cores))
    unl <- cand[cand$method == "unlinked", , drop = FALSE]
    extra <- if (nrow(unl)) data.table(firstName = "", lastName = "", email = unl$email,
               reason = sprintf("file %s not linked", unl$file),
               startPage = unl$startPage, endPage = unl$endPage) else NULL
    um <- write_unmatched(people, cand$email, extra, op$reports)
    if (o$require_all && um$n) die("-r/--require-all: %d unmatched; see %s", um$n, um$path)
  }
  write_csv_safe(cand, rpt("candidates.csv"))
  print_df(cand[, c("file", "firstName", "lastName", "email", "resumeLength", "method")])

  ## --- bag of words ---------------------------------------------------------
  sel <- if (app_mode) choose_extraction_app(pages, kw_app) else choose_extraction(pages, keywords)
  write_csv_safe(sel$matches, rpt("page_extraction_choice.csv"))
  docs <- build_documents(sel$pages, cand)

  engines <- if (o$compare) ENGINES else o$engine
  results <- lapply(setNames(engines, engines), function(e)
    with_timer(sprintf("bag of words (%s)", e), run_engine(e, docs, keywords, kw_app, cores)))
  if (o$compare) compare_engines(results, keywords, rpt)
  counts <- results[[o$engine]]

  freq_ok <- if (is.na(o$test_freq)) NA else
    validate_frequency(counts, o$test_freq, rpt,
                       keyword_key = if (app_mode) tolower else clean_for_bow)

  if (app_mode) {
    status <- run_report_app(o, counts, kw_app, docs, names_in, rpt, viz)
  } else {
    status <- run_report_current(o, counts, keywords, docs, names_in, rpt, viz, clean_mode)
  }

  writeLines(c(sprintf("ACR %s run on %s", ACR_VERSION, format(Sys.time())),
               sprintf("input: %s (%s)", o$pdf, if (o$combined) "combined" else "folder"),
               sprintf("names: %s | keywords: %s", o$names, o$keywords),
               sprintf("engine: %s | cleaning: %s | ocr: %s | dpi: %d | compare: %s | require-all: %s",
                       o$engine, clean_mode, o$ocr, o$dpi, o$compare, o$require_all),
               sprintf("frequency validation: %s", if (is.na(freq_ok)) "not run" else if (freq_ok) "passed" else "FAILED")),
             file.path(op$root, "run_log.txt"))
  if (isFALSE(freq_ok)) return(2L)
  status
}

## Current scoring: one workbook per score type x weighting ------------------
run_report_current <- function(o, counts, keywords, docs, names_in, rpt, viz, clean_mode) {
  joined <- build_joined(counts, keywords, docs)
  if (!nrow(joined)) acr_warn("no keywords were found in the resumes")
  cats <- sort(unique(keywords$category))
  detailed <- detailed_table(joined, names_in$table)
  if (nrow(detailed)) write_csv_safe(detailed, rpt("detailed_frequency.csv"))
  matched_kw <- matched_keywords_table(joined)
  if (nrow(matched_kw)) write_csv_safe(matched_kw, rpt("matched_keywords.csv"))

  report_cats <- report_categories(cats)
  for (measure in o$score) for (w in o$weights) {
    tag <- sprintf("%s_%s", measure, w)
    sm <- score_matrix(joined, keywords, docs, measure = measure, weighted = w == "weighted")
    scores <- attach_applicant_info(sm$scores, names_in$table)
    prop <- attach_applicant_info(sm$proportion, names_in$table)

    score_sheet <- score_report_sheet(scores, report_cats)
    prop_sheet <- proportion_report_sheet(prop, report_cats, score_sheet$email)
    detailed_sheet <- detailed_report_sheet(joined, keywords, names_in$table, score_sheet$email)
    write_csv_safe(score_sheet, rpt(sprintf("scores_%s.csv", tag)))
    write_csv_safe(prop_sheet, rpt(sprintf("proportion_%s.csv", tag)))
    write_score_report(rpt(sprintf("acr_scores_%s.xlsx", tag)),
                       score_sheet, detailed_sheet, prop_sheet)
    make_charts(o, scores, cats, tag,
                sprintf("%s, %s | engine %s | cleaning %s", measure, w, o$engine, clean_mode), viz)
  }
  0L
}

## App scoring: <date>-<pdf>-<weighting>-ResumeRank.xlsx, as the Shiny app ---
run_report_app <- function(o, counts, kw_app, docs, names_in, rpt, viz) {
  if (!identical(o$score, c("binary", "normalized")))
    msg("-s/--score is ignored with --legacy: the app has a single measure")
  joined <- build_joined_app(counts, kw_app, docs)
  if (!nrow(joined)) acr_warn("no keywords were found in the resumes")
  detailed_sheet <- detailed_sheet_app(joined, names_in$table)
  write_csv_safe(detailed_sheet, rpt("detailed_frequency.csv"))
  matched_kw <- matched_keywords_app(detailed_sheet)
  if (nrow(matched_kw)) write_csv_safe(matched_kw, rpt("matched_keywords.csv"))

  for (w in o$weights) {
    sm <- score_matrix_app(joined, kw_app, docs, weighted = w == "weighted")
    score_sheet <- score_sheet_app(sm$scores, sm$categories, names_in$table)
    prop_sheet <- proportion_sheet_app(sm$proportion, sm$categories, names_in$table)
    write_csv_safe(score_sheet, rpt(sprintf("scores_app_%s.csv", w)))
    write_csv_safe(prop_sheet, rpt(sprintf("proportion_app_%s.csv", w)))
    write_score_report(rpt(app_workbook_name(o$pdf, w)), score_sheet, detailed_sheet, prop_sheet)
    make_charts(o, score_sheet, sm$categories, sprintf("app_%s", w),
                sprintf("app scoring, %s | cleaning %s", w,
                        if (o$legacy_clean) "legacy" else "current"), viz)
  }
  0L
}

if (nzchar(Sys.getenv("ACR_SOURCE_ONLY"))) {
  cat("ACR_SOURCE_ONLY is set: functions loaded, pipeline not run\n")
} else {
  status <- tryCatch(run_acr(parse_args(commandArgs(trailingOnly = TRUE))),
                     error = function(e) { cat(sprintf("ERROR  %s\n", conditionMessage(e))); 1L })
  quit(save = "no", status = status)
}
