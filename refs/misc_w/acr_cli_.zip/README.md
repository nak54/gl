# ACR command line edition (R 4.6)

`acr.R` runs the whole Automated Candidate Review pipeline from a terminal, with no
Shiny server: it reads the resume packet, finds where each candidate's resume starts
and ends, splits the PDF, scores the resumes against a keyword dictionary, and writes
CSV / XLSX / PNG into an output folder.

The app's interactive plotly charts and the `sf`-based GIS maps are **not** ported (as
instructed). Static `ggplot2` PNGs are written instead, so the CLI has no `sf`,
`plotly`, `shiny`, `DT`, `tm` or `quanteda` dependency at all.

## Install

```bash
Rscript install_deps.R
```

Required packages: **pdftools, readxl, ggplot2, openxlsx**.
Optional: **tesseract** — if the R package is missing, the `tesseract` command line
tool is used instead; if neither exists, the OCR layer is skipped with a warning.
Everything else is base R (no dplyr/stringr/reshape2/tm/quanteda).

## Run

```bash
# everything, inputs discovered in the project folder
Rscript acr.R -d demo_short_anonymized -o acr_output

# explicit inputs
Rscript acr.R -p DS_demo_resumes.pdf -n DS_demo_names.xlsx -k DS_demo_keywords.csv -o acr_output

# after filling in the pages of the candidates that were not found
Rscript acr.R -r -d demo_short_anonymized

# re-score only, reusing the cached page text
Rscript acr.R -r --stages score,report -s normalized --weights weighted -t 40
```

`Rscript acr.R --help` lists every option. The ones asked for in `cliR4.6`:

| flag | meaning |
|---|---|
| `-n, --names` | names spreadsheet (USAS export, `.xlsx/.xls/.csv`) |
| `-k, --keywords` | keyword dictionary + weights (`category,keyword,score_adjustment`) |
| `-p, --pdf` | the single PDF holding all resumes |
| `-d, --dir` | project folder used to discover any input not given explicitly |
| `-o, --out` | output folder (default `acr_output`) — images and CSVs land here |
| `-r, --resume` | resume operations: reuse the cached page text, merge the edited unmatched CSV, and split **only the resumes that are missing** |
| `-s, --score` | `binary`, `normalized` or `both` (default both) |
| `--weights` | `weighted`, `unweighted` or `both` (default both) |
| `-m, --manual` | explicit CSV of manually located candidates |
| `-i, --interactive` | type the missing page numbers at the prompt instead of editing the CSV |
| `--stages` | run part of the pipeline: `extract,detect,split,score,report` |
| `--no-ocr`, `--dpi`, `-c/--cores` | OCR layer controls |
| `--strict`, `-q`, `-v`, `-V`, `-h` | stop on unmatched, quiet, verbose, version, help |

## Candidates that cannot be found

Detection uses the same three passes as the app: first/last name near the top of a
page (in order, within 50 characters, skipping USAJobs "references:" pages), then
e-mail address, then phone number — on the embedded PDF text **and** on the OCR text,
keeping whichever layer found the candidate earlier.

Whoever is still missing is printed to the console and written to
`<out>/unmatched_candidates.csv`:

```
email,missingFirstName,missingLastName,startPage,endPage
someone@example.com,someone,example,,
```

Fill in `startPage` / `endPage`, then re-run with `-r` (or pass the file with `-m`).
The previous version of that file is kept as `unmatched_candidates.previous.csv`.
With `-i` the script asks for the two page numbers on the console instead.

## Scoring

Both measures count keyword hits per candidate (whole-token matching, so `r` does not
match inside `scalar`, and `c++` / `c#` survive), then aggregate per category:

* **binary** — how many of the category's dictionary terms appear at all, divided by
  the number of terms in that category.
* **normalized** — occurrences relative to resume length, min-max scaled to `[1,5]`
  across all hits, summed per category, divided by the number of terms in the category.

`--weights weighted` multiplies each hit by its `score_adjustment`. In both cases each
category column is finally rescaled so the best resume in the pool scores 5
(`ceiling(value * 5 / max)`), and `Total Score` is the sum of the category scores —
the same relative scoring the Shiny app produced. Quartiles are computed on the total.

## Output folder

```
acr_output/
  candidates.csv                  firstName,lastName,email,startPage,endPage,resumeLength,method
  unmatched_candidates.csv        fill in the page numbers and re-run with -r
  page_extraction_choice.csv      per page: keyword hits from text vs OCR, layer used
  detailed_frequency.csv          one row per candidate x keyword
  matched_keywords.csv            keywords matched per candidate and category
  scores_<measure>_<weighting>.csv        category scores 0-5, Total Score, quartile
  proportion_<measure>_<weighting>.csv    the un-rescaled per-category values
  acr_scores.xlsx                 the same tables, styled like the app's download
  images/top_candidates_<...>.png         ranking by total score
  images/score_by_category_<...>.png      stacked category composition
  images/category_heatmap_<...>.png       candidate x category coverage
  resumes/<email>_resume.pdf      one PDF per candidate
  cache/pages.rds                 extracted text + OCR (what -r reuses)
  run_log.txt
```

## Where each piece of the Shiny app went

| Shiny app | CLI |
|---|---|
| `server.R` / `ui.R` | `acr.R` (options, stage order, console output) |
| `parse.R` | `R/01_extract.R` (parallel render + OCR, cached for `-r`) |
| `clean.R`, `corpus.R` | `R/02_clean.R` |
| `initialize_dataframe.R`, `search.R`, `update_resume_df.R`, `collapse_resume_df.R`, `compare_text_OCR.R` | `R/03_detect.R` |
| `download.R` | `R/04_split.R` |
| `optimize_extract.R`, `bow.R`, `tokenize.R` | `R/05_bow.R` |
| `score.R` | `R/06_score.R` |
| `output_score.R` | `R/07_report.R` (XLSX) |
| plotly charts | `R/07_report.R` (static PNGs) |
| `map.R`, `selection_events.R`, `utilities.R` (map helpers) | dropped — no `sf`/GIS output |

Notes on the port:

* `tokenize.R`, `update_resume_df.R` and `utilities.R` were not among the files
  provided; their behaviour was rebuilt from the call sites in `server.R`
  (keyword tokenisation, e-mail/phone search, `remove_na_columns`).
* Keywords and resume text go through the *same* cleaning function, so hyphenated and
  punctuated terms match reliably; names and e-mail addresses are normalised the same
  way as the page text, which the app did not do (hyphenated names such as
  `Ha-Yoon` were only found by e-mail or phone there).
* `wordcount` is a character count, as in the app (the column name is kept so the
  outputs line up with the old spreadsheets).
