## ---------------------------------------------------------------------------
## install_deps.R -- install what acr.R needs (run once)
##   Rscript install_deps.R
## Set the WORK repo first if you are on the internal network:
##   options(repos = c(WORK = "http://10.207.92.200/R.new/"))
## ---------------------------------------------------------------------------

required <- c("pdftools",   # pdf_text / pdf_convert / pdf_subset
              "readxl",     # names + keyword spreadsheets
              "ggplot2",    # the PNG charts
              "openxlsx")   # the scored workbook

optional <- c("tesseract")  # OCR layer; the tesseract CLI is used if absent

repos <- getOption("repos")
if (is.null(repos) || any(repos == "@CRAN@")) {
  options(repos = c(CRAN = "https://cloud.r-project.org"))
}

install_missing <- function(pkgs, label) {
  miss <- pkgs[!vapply(pkgs, function(p) requireNamespace(p, quietly = TRUE), logical(1))]
  if (!length(miss)) {
    cat(sprintf("%s: all present\n", label))
    return(invisible(NULL))
  }
  cat(sprintf("%s: installing %s\n", label, paste(miss, collapse = ", ")))
  install.packages(miss)
}

install_missing(required, "required")
install_missing(optional, "optional")

cat("\nR version:", R.version.string, "\n")
cat("tesseract CLI:", if (nzchar(Sys.which("tesseract"))) Sys.which("tesseract") else "not found", "\n")
