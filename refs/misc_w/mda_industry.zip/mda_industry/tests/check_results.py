#!/usr/bin/env python
"""Assertions against a synthetic run, plus simulated gold labels for 09_validate.py score."""
import json, sys
from pathlib import Path
import numpy as np, pandas as pd
root = Path(sys.argv[1]); w = root / "work"
out = pd.read_parquet(w/"industry_labels.parquet"); truth = pd.read_parquet(root/"truth.parquet")
chunks = pd.read_parquet(w/"chunks.parquet"); filings = pd.read_parquet(w/"filings.parquet")
d = out.merge(truth, on="accession"); e = d[~d.excluded_sic]
assert not chunks.text.str.contains("POISON").any(), "dropped sections leaked into chunks"
assert not filings.kept_text.str.contains("POISON").any()
assert filings.sic.str.len().eq(4).all()
assert (out.sic_sec == "7370").any() and (out.loc[out.sic_sec == "7370","match_level"] == "prefix3").all(), "SEC group code fallback"
assert out.loc[out.sic_sec == "7370","naics_xwalk"].str.contains("513").all()
assert set(out.loc[out.excluded_sic, "review_reason"]) == {""}
assert "513" in set(out.naics3_pred) and "511" not in set(out.naics3_pred), "NAICS vintage chain"
xw = pd.read_parquet(w/"ref/sic_xwalk_resolved.parquet").groupby("sic")["naics3"].apply(set).to_dict()
consistent = np.mean([p in xw.get(sp, set()) for p, sp in zip(e.naics3_pred, e.sic_pred)])
assert consistent == 1.0, f"sic_pred must fall under naics3_pred: {consistent}"
acc_true = (e.naics3_pred == e.true_naics3).mean()
m = e[e.miscoded]; caught = (~m.agrees_with_sic).mean(); recovered = (m.naics3_pred == m.true_naics3).mean()
false_flag = (~e[~e.miscoded].agrees_with_sic).mean()
sec = e[e.second != ""]; second_hit = np.mean([s in x.split(";") for s, x in zip(sec.second, sec.naics3_secondary)])
print(f"accuracy vs planted truth={acc_true:.3f}; miscoded flagged={caught:.3f}, corrected={recovered:.3f}; clean flagged={false_flag:.3f}; secondary recall={second_hit:.3f}")
assert acc_true > .85 and caught > .8 and recovered > .8 and false_flag < .1 and second_hit > .7
key = pd.read_csv(w/"validation_key.csv", dtype={"accession":str})
g = key.merge(truth, on="accession")[["accession","true_naics3"]].rename(columns={"true_naics3":"gold_naics3"})
g.to_csv(w/"gold_simulated.csv", index=False)
print("checks passed")
