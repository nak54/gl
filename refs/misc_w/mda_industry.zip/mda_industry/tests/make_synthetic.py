#!/usr/bin/env python
"""Generate fake reference files, filings, and truth for testing pipeline mechanics."""
import sys
from pathlib import Path
import numpy as np
import pandas as pd

root = Path(sys.argv[1]); ref = root / "reference_files"; ref.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(7)
# NAICS3 (2022): (2002 code, SIC list with title, vocabulary)
IND = {
 "513": ("511210", [("7372", "SERVICES-PREPACKAGED SOFTWARE")], "software subscription cloud platform licenses developers saas application"),
 "334": ("334413", [("3674", "SEMICONDUCTORS & RELATED DEVICES")], "semiconductor wafer chips fabrication foundry integrated circuits"),
 "325": ("325412", [("2834", "PHARMACEUTICAL PREPARATIONS")], "drug clinical trials fda therapeutic oncology patients pharmaceutical"),
 "522": ("522110", [("6021", "NATIONAL COMMERCIAL BANKS")], "deposits loans branches net interest margin borrowers mortgage"),
 "211": ("211111", [("1311", "CRUDE PETROLEUM & NATURAL GAS")], "crude oil natural gas drilling wells barrels reserves permian"),
 "221": ("221122", [("4911", "ELECTRIC SERVICES")], "electric utility ratepayers transmission generation regulators grid"),
 "481": ("481111", [("4512", "AIR TRANSPORTATION, SCHEDULED")], "airline passengers aircraft flights seat miles fleet routes"),
 "455": ("452111", [("5311", "RETAIL-DEPARTMENT STORES")], "stores shoppers merchandise apparel comparable store sales retail"),
 "336": ("336111", [("3711", "MOTOR VEHICLES & PASSENGER CAR BODIES")], "vehicles trucks dealers automotive assembly plants electric vehicle"),
 "622": ("622110", [("8062", "SERVICES-GENERAL MEDICAL & SURGICAL HOSPITALS")], "hospitals admissions physicians inpatient medicare surgical beds"),
}
sic_rows = [(s, n[0]) for n in IND.values() for s, _ in n[1]] + [("7371", "541511"), ("8099", "621999")]
sic = pd.DataFrame(sic_rows, columns=["SIC", "NAICS"])
head = [["Census concordance", None, None, None], [None]*4]
def write(path, header, rows):
    pd.DataFrame(head + [header] + rows).to_excel(path, header=False, index=False)
write(ref/"sic1987_to_naics2002.xlsx", ["1987 SIC","SIC Title","2002 NAICS","NAICS Title"],
      [[int(a), "t", int(b), "t"] for a,b in sic_rows] + [["Aux","x",999999,"x"]])
# Identity steps, with renumberings like the real 2022 changes.
codes = sorted(set(sic.NAICS))
new = {"511210":"513210", "452111":"455110"}
for s, d in [(2002,2007),(2007,2012),(2012,2017)]:
    write(ref/f"naics{s}_to_naics{d}.xlsx", [f"{s} NAICS Code",f"{s} Title",f"{d} NAICS Code",f"{d} Title"], [[int(c),"t",int(c),"t"] for c in codes])
# Reversed direction, to exercise detection.
write(ref/"naics2017_to_naics2022.xlsx", ["2022 NAICS Code","2022 Title","2017 NAICS Code","2017 Title"],
      [[int(new.get(c,c)), "Title "+new.get(c,c), int(c), "t"] for c in codes])
titles = [[k, v[2].split()[0].title()+" Industry"] for k,v in IND.items()] + [["541","Professional Services"],["621","Ambulatory Care"],["54","Professional"],["62","Health Care"]]
pd.DataFrame([["Seq","Code","Title"]]+[[i,c,t+"T"] for i,(c,t) in enumerate(titles)]).to_excel(ref/"naics2022_codes.xlsx", header=False, index=False)
sec = [(s,t) for n in IND.values() for s,t in n[1]] + [("7370","SERVICES-COMPUTER PROGRAMMING, DATA PROCESSING"),("6770","BLANK CHECKS")]
pd.DataFrame(sec, columns=["SIC Code","Industry Title"]).to_csv(ref/"sec_sic_list.csv", index=False)
GENERIC = "management believes results reflect market conditions customers growth costs".split()
keys = list(IND)
def paragraph(vocab, n=120):
    words = list(rng.choice(vocab.split(), n//3)) + list(rng.choice(GENERIC, n - n//3))
    return "Text " + " ".join(words) + "."
def doc(true, second, flat, single_seg=False):
    v = IND[true][2]; sep = " " if flat else "\n"
    parts = ["Overview", paragraph(v), "Results of Operations", paragraph(v)]
    if second:
        parts += ["Segment Results", paragraph(IND[second][2]), paragraph(v)]
    elif single_seg:
        parts += ["Segment Results", paragraph(v), paragraph(v)]
    parts += ["Liquidity and Capital Resources", "POISON Text "+paragraph("covenant revolver credit facility"),
              "Critical Accounting Policies", "POISON Text "+paragraph("goodwill impairment estimates")]
    return sep.join(parts)
rows, truth = [], []
for c in range(1, 241):
    true = keys[c % len(keys)]
    miscoded = c % 13 == 0
    filed = keys[(c+3) % len(keys)] if miscoded else true
    filed_sic = IND[filed][1][0][0]
    if filed == "513" and c % 20 == 0: filed_sic = "7370"  # SEC group code: exercises prefix fallback
    second = keys[(c+1) % len(keys)] if c % 7 == 0 else None
    for y in (2019, 2024, 2025):
        rows.append((f"{c:010d}-{y}", f"{c:010d}", y, int(filed_sic), f"Co{c}", doc(true, second, c % 2 == 0, c % 5 == 0)))
        truth.append((f"{c:010d}-{y}", true, miscoded, second or ""))
for c in range(300, 306):
    rows.append((f"{c:010d}-2024", f"{c:010d}", 2024, 6770, f"Shell{c}", "Overview " + paragraph("trust account business combination sponsor")))
    truth.append((f"{c:010d}-2024", "523", False, ""))
pd.DataFrame(rows, columns=["accession","cik","year","sic","company","mda_text"]).to_parquet(root/"filings_in.parquet")
pd.DataFrame(truth, columns=["accession","true_naics3","miscoded","second"]).to_parquet(root/"truth.parquet")
