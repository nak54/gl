#!/usr/bin/env bash
# Synthetic end-to-end test and shuffled-label negative control. Uses hashed vectors, so no model download.
set -euo pipefail
cd "$(dirname "$0")/.."
T="${1:-$(mktemp -d)}"; W="$T/work"; rm -rf "$W"
python3 tests/make_synthetic.py "$T"
python3 01_build_refs.py --workdir "$W" --refdir "$T/reference_files"
python3 02_filter_mda.py --workdir "$W" --input "$T/filings_in.parquet"
python3 03_embed_filings.py --workdir "$W" --backend hash
python3 04_build_labels.py --workdir "$W"
python3 05_train_classifier.py --workdir "$W" > "$T/train.log"
python3 06_rank_sic.py --workdir "$W"
python3 07_llm_review.py --workdir "$W" --mock
python3 08_build_output.py --workdir "$W"
python3 09_validate.py sample --workdir "$W" --n 60
python3 tests/check_results.py "$T"
python3 09_validate.py score --workdir "$W" --gold "$W/gold_simulated.csv" --bootstrap 100 | python3 -c "import json,sys; r=json.load(sys.stdin); print({k:round(r[k]['naics3_accuracy'],3) for k in ('sic_crosswalk_baseline','model','final_with_llm')}, r['model']['accuracy_95ci'])"
# Negative control: shuffled company SICs should collapse agreement to about chance.
N="$T/neg"; rm -rf "$N"; mkdir -p "$N"; cp -r "$W/ref" "$N/ref"
python3 - "$W" "$N" <<'P'
import sys, numpy as np, pandas as pd, shutil
w, n = sys.argv[1:]
f = pd.read_parquet(f"{w}/filings.parquet").drop(columns=["naics3_xwalk_primary","naics_xwalk","match_level","excluded_sic","train_eligible"])
m = f.drop_duplicates("cik")[["cik","sic"]]
m["sic"] = np.random.default_rng(1).permutation(m["sic"].values)
f = f.drop(columns="sic").merge(m, on="cik")
order = pd.read_parquet(f"{w}/filings.parquet")["accession"]
f.set_index("accession").loc[order].reset_index().to_parquet(f"{n}/filings.parquet", index=False)
for x in ("chunks.parquet","chunk_vectors.npy","filing_vectors.npy","embedding_meta.json"): shutil.copy(f"{w}/{x}", f"{n}/{x}")
P
python3 04_build_labels.py --workdir "$N" >/dev/null
python3 05_train_classifier.py --workdir "$N" > "$T/neg.log"
python3 -c "import json,sys; m=json.load(open('$N/metrics.json')); print('NEGATIVE CONTROL naics3 top1:', round(m['oof_eligible']['naics3_top1_in_sic_candidates'],3)); assert m['oof_eligible']['naics3_top1_in_sic_candidates']<0.25"
python3 -c "import json; m=json.load(open('$W/metrics.json')); print('temporal', {y:(v.get('train'),round(v.get('naics3_top1_in_sic_candidates',0),3)) for y,v in m['temporal_holdout'].items()})"
echo ALL TESTS PASSED
