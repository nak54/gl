#!/usr/bin/env python
"""Rank 4-digit SICs within predicted NAICS3 using dense and TF-IDF title similarity plus the model prior."""
from __future__ import annotations
import json
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from common import EXCLUDED_SICS, base_parser, embed_texts


def main():
    parser = base_parser(__doc__)
    parser.add_argument("--rrf-k", type=int, default=10)
    parser.add_argument("--top-k", type=int, default=3)
    args = parser.parse_args()
    preds = pd.read_parquet(args.workdir / "predictions_oof.parquet")
    filings = pd.read_parquet(args.workdir / "filings.parquet")
    vectors = np.load(args.workdir / "filing_vectors.npy")
    xwalk = pd.read_parquet(args.workdir / "ref/sic_xwalk_resolved.parquet")
    sic_titles = pd.read_parquet(args.workdir / "ref/sic_titles.parquet")
    naics_titles = pd.read_parquet(args.workdir / "ref/naics_titles.parquet").set_index("naics")["title"].to_dict()
    meta = json.loads((args.workdir / "embedding_meta.json").read_text())

    sics = sic_titles[~sic_titles["sic"].isin(EXCLUDED_SICS) & sic_titles["sic"].isin(xwalk["sic"])].reset_index(drop=True)
    documents = []
    for row in sics.itertuples():
        linked = xwalk.loc[xwalk["sic"] == row.sic, "naics6"].map(naics_titles).dropna().unique()[:8]
        documents.append(row.sic_title.replace("-", " ").lower() + ". " + ". ".join(linked))

    dense = vectors @ embed_texts(documents, meta["backend"], meta["model"]).T
    tfidf = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True, stop_words="english", min_df=2)
    tfidf.fit(filings["kept_text"])
    sparse_sim = (tfidf.transform(filings["kept_text"]) @ tfidf.transform(documents).T).toarray()

    share = xwalk.groupby(["sic", "naics3"])["weight"].sum().to_dict()
    sic_n3 = xwalk.groupby("sic")["naics3"].apply(set).to_dict()
    sic_list = sics["sic"].tolist()
    records = []
    for i, row in enumerate(preds.itertuples()):
        probs = dict(zip(row.naics3_top3.split(";"), map(float, row.naics3_top3_probs.split(";"))))
        positions = [j for j, sic in enumerate(sic_list) if sic_n3[sic] & set(probs)]
        if not positions:
            records.append(("", np.nan))
            continue
        prior = np.array([max(probs.get(n3, 0) * share.get((sic_list[j], n3), 0) for n3 in sic_n3[sic_list[j]]) for j in positions])
        score = np.zeros(len(positions))
        for signal in (dense[i, positions], sparse_sim[i, positions], prior):
            ranks = (-signal).argsort().argsort() + 1
            score += 1 / (args.rrf_k + ranks)
        # SICs under the top NAICS3 rank first, so sic_pred always fits naics3_pred.
        naics_rank = {code: r for r, code in enumerate(row.naics3_top3.split(";"))}
        tier = np.array([min(naics_rank.get(n3, 99) for n3 in sic_n3[sic_list[j]]) for j in positions])
        order = np.lexsort((-score, tier))
        ordered = [sic_list[positions[j]] for j in order]
        filed = ordered.index(row.sic) + 1 if row.sic in ordered else np.nan
        records.append((";".join(ordered[:args.top_k]), filed))
    preds["sic_top3"], preds["filed_sic_rank"] = zip(*records)
    preds["sic_pred"] = preds["sic_top3"].str.split(";").str[0]
    preds.to_parquet(args.workdir / "predictions_oof.parquet", index=False)

    eligible = preds[preds["train_eligible"]]
    print(f"Filed SIC at rank 1: {(eligible.filed_sic_rank == 1).mean():.1%}  top {args.top_k}: {(eligible.filed_sic_rank <= args.top_k).mean():.1%}  (filed SIC is not injected into candidates)")


if __name__ == "__main__":
    main()
