"""Shared paths, code helpers, and embedding backends."""
from __future__ import annotations
import argparse, re
from pathlib import Path
import numpy as np
import pandas as pd

YEARS = {2019, 2024, 2025}
# Non-operating / structural SEC codes: predicted, but never used as training labels.
EXCLUDED_SICS = {"6189", "6726", "6770", "8880", "8888", "9721", "9995", "9999"}
SECTOR_MERGE = {"31": "31-33", "32": "31-33", "33": "31-33", "44": "44-45",
                "45": "44-45", "48": "48-49", "49": "48-49"}


def sector(code) -> str:
    two = str(code)[:2]
    return SECTOR_MERGE.get(two, two)


def pad_sic(value) -> str | None:
    """Normalize to 4 digits. Handles 100, 100.0, and '0100'."""
    if pd.isna(value):
        return None
    text = str(value).strip()
    if re.fullmatch(r"\d+\.0+", text):
        text = text.split(".")[0]
    return text.zfill(4) if re.fullmatch(r"\d{1,4}", text) else None


def base_parser(description: str) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("--workdir", type=Path, default=Path("work"))
    return parser


def resolve_xwalk(base: pd.DataFrame, sics) -> pd.DataFrame:
    """Map SICs to NAICS6 and fall back from exact to 3-digit to 2-digit prefix.

    SEC lists group codes such as 7370 and 3570 that are absent from the 4-digit
    1987 concordance. The match level records how far each mapping fell back.
    """
    base = base[["sic", "naics6"]].drop_duplicates()
    rows, exact = [], set(base["sic"])
    for sic in sorted({s for s in sics if s}):
        if sic in exact:
            hit, level = base[base["sic"] == sic], "exact"
        else:
            hit, level = base[base["sic"].str.startswith(sic[:3])], "prefix3"
            if hit.empty:
                hit, level = base[base["sic"].str.startswith(sic[:2])], "prefix2"
        if hit.empty:
            continue
        naics = sorted(set(hit["naics6"]))
        rows += [(sic, n, n[:3], sector(n), level, 1 / len(naics)) for n in naics]
    return pd.DataFrame(rows, columns=["sic", "naics6", "naics3", "naics2", "match_level", "weight"])


def embed_texts(texts: list[str], backend: str, model_name: str, batch_size: int = 32) -> np.ndarray:
    """Return L2-normalized vectors. The hash backend is for smoke tests only."""
    if backend == "sentence-transformers":
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer(model_name)
        return np.asarray(model.encode(texts, batch_size=batch_size, normalize_embeddings=True,
                                       show_progress_bar=True), dtype=np.float32)
    from sklearn.feature_extraction.text import HashingVectorizer
    from sklearn.random_projection import SparseRandomProjection
    from sklearn.preprocessing import normalize
    hashed = HashingVectorizer(n_features=2**16, stop_words="english", alternate_sign=False).transform(texts)
    projected = SparseRandomProjection(n_components=256, random_state=0).fit_transform(hashed)
    return normalize(np.asarray(projected.todense() if hasattr(projected, "todense") else projected),
                     axis=1).astype(np.float32)
