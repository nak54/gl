# MD&A industry classifier

Assigns SIC, NAICS2, and NAICS3 labels to 2019, 2024, and 2025 MD&A filings. The filed SIC serves as a noisy training label, not the answer.

## Setup

```bash
pip install -r requirements.txt
```

### Input Parquet

Required: `accession`, `cik`, `year`, `sic`, `mda_text`. Optional: `ticker`, `company`. Use `--text-col` if your text column has another name.

### Reference files

Put these in `reference_files/`. Excel files can be `.xls` or `.xlsx`.

| File | Source |
|---|---|
| `sic1987_to_naics2002` | Census: 1987 SIC to 2002 NAICS |
| `naics2002_to_naics2007` | Census: 2002 NAICS to 2007 NAICS |
| `naics2007_to_naics2012` | Census: 2007 NAICS to 2012 NAICS |
| `naics2012_to_naics2017` | Census: 2012 NAICS to 2017 NAICS |
| `naics2017_to_naics2022` | Census: 2017/2022 concordance in either direction |
| `naics2022_codes` | Census: 2022 NAICS 2-6 digit code list |
| `sec_sic_list.csv` | SEC SIC code list, saved with columns `SIC Code`, `Industry Title` |

Census concordances: https://www.census.gov/naics/concordances/concordances.html
SEC list: https://www.sec.gov/search-filings/standard-industrial-classification-sic-code-list

## Run

```bash
./run_all.sh path/to/filings.parquet work                 # LLM dry run
export ANTHROPIC_API_KEY=...
python 07_llm_review.py --workdir work --limit 25         # Inspect a small batch first
python 07_llm_review.py --workdir work                    # Resumes and finishes the queue
python 08_build_output.py --workdir work
python 09_validate.py sample --workdir work               # Fill in gold_naics3 from the 10-K
python 09_validate.py score --workdir work --gold work/validation_sheet.csv
```

Main result: `work/industry_labels.parquet` and `.csv`.

## Scripts

| Script | Purpose |
|---|---|
| `01_build_refs.py` | Chains SIC 1987 to NAICS 2022 so all years share one taxonomy |
| `02_filter_mda.py` | Validates input, keeps business sections, and chunks at 220 words |
| `03_embed_filings.py` | Embeds chunks and builds filing vectors |
| `04_build_labels.py` | Builds weighted labels, with fallback for SEC group codes such as 7370 |
| `05_train_classifier.py` | Trains NAICS2 then NAICS3, with CIK-grouped out-of-fold predictions and a drift check |
| `06_rank_sic.py` | Ranks SICs inside predicted NAICS3 using dense, TF-IDF, and prior signals |
| `07_llm_review.py` | Reviews flagged filings with constrained choices and verified quotes |
| `08_build_output.py` | Builds the final table |
| `09_validate.py` | Creates a blinded labeling sheet and scores it with sampling weights |

## Key columns

- `sic_sec`, `sic_title`: filed SIC and title
- `naics_xwalk`: all NAICS3 candidates for the filed SIC
- `naics2_pred`, `naics3_pred`, `pred_conf`: model output
- `naics3_secondary`: other industries suggested by segment text
- `agrees_with_sic`: predicted NAICS3 is among the crosswalk candidates
- `naics3_final`, `naics2_final`, `sic_final`, `final_source`: final labels and origin
- `needs_human_review`: flagged and not resolved by a verified LLM answer

## Tuning

Secondary-industry defaults (`--secondary-min-prob 0.12`, `--secondary-min-lift 2`) were set on synthetic data. Re-tune them on hand labels. Review thresholds are `--conf-threshold` and `--margin-threshold` in script 07.

`final_model.joblib` stores the fitted objects as a dictionary for later scoring.

## Test

```bash
bash tests/run_tests.sh
```

This uses synthetic data and hashed vectors, so its scores say nothing about real accuracy.
