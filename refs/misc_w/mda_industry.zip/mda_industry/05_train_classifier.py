#!/usr/bin/env python
"""Hierarchical NAICS2 -> NAICS3 logistic regression with CIK-grouped out-of-fold predictions.

Writes predictions_oof.parquet, metrics.json, and final_model.joblib.
"""
from __future__ import annotations
import json
from dataclasses import dataclass, field
import joblib
import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedGroupKFold
from common import base_parser, sector


@dataclass
class Model:
    tfidf: TfidfVectorizer
    sector_clf: LogisticRegression | None
    sector_classes: list
    subsector: dict = field(default_factory=dict)  # sector -> classifier or constant string
    n3_classes: list = field(default_factory=list)


def features(model_tfidf, texts, vectors, tfidf_weight=1.0, dense_weight=1.0):
    return sparse.hstack([model_tfidf.transform(texts) * tfidf_weight,
                          sparse.csr_matrix(vectors) * dense_weight], format="csr")


def expand(labels: pd.DataFrame, positions: dict, level: str, allowed=None):
    frame = labels[(labels["level"] == level) & labels["accession"].isin(positions)]
    if allowed is not None:
        frame = frame[frame["code"].isin(allowed)]
    rows = frame["accession"].map(positions).to_numpy()
    return rows, frame["code"].to_numpy(), frame["weight"].to_numpy()


def fit_lr(X, y, weights, c):
    return LogisticRegression(C=c, class_weight="balanced", max_iter=1000).fit(X, y, sample_weight=weights)


def supported_classes(labels, filings, level, min_ciks):
    frame = labels[labels["level"] == level].merge(filings[["accession", "cik"]], on="accession")
    counts = frame.groupby("code")["cik"].nunique()
    return set(counts[counts >= min_ciks].index)


def fit_model(filings, vectors, labels, train_pos, args) -> Model:
    train = filings.iloc[train_pos]
    tfidf = TfidfVectorizer(ngram_range=(1, 2), min_df=args.min_df, max_df=0.6, sublinear_tf=True,
                            stop_words="english", max_features=args.max_features)
    tfidf.fit(train["kept_text"])
    X = features(tfidf, train["kept_text"], vectors[train_pos])
    positions = dict(zip(train["accession"], range(len(train))))
    sectors_ok = supported_classes(labels[labels.accession.isin(positions)], train, "naics2", args.min_ciks)
    rows, y, w = expand(labels, positions, "naics2", sectors_ok)
    if len(set(y)) < 2:
        raise SystemExit("Need at least two supported NAICS2 classes")
    clf = fit_lr(X[rows], y, w, args.c)

    n3_ok = supported_classes(labels[labels.accession.isin(positions)], train, "naics3", args.min_ciks)
    rows3, y3, w3 = expand(labels, positions, "naics3", n3_ok)
    parents = np.array([sector(code) for code in y3])
    subsector = {}
    for sec in clf.classes_:
        mask = parents == sec
        classes = set(y3[mask])
        if len(classes) == 1:
            subsector[sec] = next(iter(classes))
        elif len(classes) >= 2:
            subsector[sec] = fit_lr(X[rows3[mask]], y3[mask], w3[mask], args.c)
    n3_classes = sorted(set(y3))
    return Model(tfidf, clf, list(clf.classes_), subsector, n3_classes)


def predict(model: Model, texts, vectors):
    X = features(model.tfidf, texts, vectors)
    p2 = model.sector_clf.predict_proba(X)
    p3 = np.zeros((X.shape[0], len(model.n3_classes)))
    idx3 = {c: i for i, c in enumerate(model.n3_classes)}
    for j, sec in enumerate(model.sector_classes):
        sub = model.subsector.get(sec)
        if sub is None:
            continue
        if isinstance(sub, str):
            p3[:, idx3[sub]] += p2[:, j]
        else:
            conditional = sub.predict_proba(X)
            for k, code in enumerate(sub.classes_):
                p3[:, idx3[code]] += p2[:, j] * conditional[:, k]
    p3 = p3 / np.maximum(p3.sum(axis=1, keepdims=True), 1e-12)
    return p2, p3


def top_k(probabilities, classes, k=3):
    order = np.argsort(-probabilities, axis=1)[:, :k]
    return [[(classes[j], float(row[j])) for j in idx] for row, idx in zip(probabilities, order)]


def assign_folds(filings, n_splits, seed):
    eligible = filings[filings["train_eligible"]]
    primary = eligible["naics3_xwalk_primary"].map(sector)
    sgkf = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    fold_of = {}
    for fold, (_, test) in enumerate(sgkf.split(eligible, primary, eligible["cik"])):
        fold_of.update({c: fold for c in eligible.iloc[test]["cik"]})
    rest = sorted(set(filings["cik"]) - set(fold_of))
    fold_of.update({c: i % n_splits for i, c in enumerate(rest)})
    return filings["cik"].map(fold_of).to_numpy()


def hit_rates(frame, candidates):
    top1_n3 = np.mean([p in c for p, c in zip(frame["naics3_pred"], candidates)])
    top3_n3 = np.mean([bool(set(t.split(";")) & c) for t, c in zip(frame["naics3_top3"], candidates)])
    top1_n2 = np.mean([p in {sector(x) for x in c} for p, c in zip(frame["naics2_pred"], candidates)])
    return float(top1_n2), float(top1_n3), float(top3_n3)


def score(frame):
    known = frame[frame["naics3_xwalk_primary"].notna()]
    candidates = [set(x.split(";")) for x in known["naics_xwalk"]]
    n2, n3, n3top3 = hit_rates(known, candidates)
    return {"n": int(len(known)), "naics2_top1_in_sic_candidates": n2, "naics3_top1_in_sic_candidates": n3,
            "naics3_top3_in_sic_candidates": n3top3,
            "naics2_macro_f1_vs_primary": float(f1_score(known["naics3_xwalk_primary"].map(sector), known["naics2_pred"], average="macro", zero_division=0)),
            "naics3_macro_f1_vs_primary": float(f1_score(known["naics3_xwalk_primary"], known["naics3_pred"], average="macro", zero_division=0))}


def main():
    parser = base_parser(__doc__)
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--c", type=float, default=4.0)
    parser.add_argument("--min-df", type=int, default=3)
    parser.add_argument("--max-features", type=int, default=150_000)
    parser.add_argument("--min-ciks", type=int, default=5, help="Minimum distinct companies required to train a class")
    parser.add_argument("--secondary-min-prob", type=float, default=0.12)
    parser.add_argument("--secondary-min-lift", type=float, default=2.0, help="Segment probability divided by filing-level probability")
    args = parser.parse_args()

    filings = pd.read_parquet(args.workdir / "filings.parquet")
    labels = pd.read_parquet(args.workdir / "labels.parquet")
    vectors = np.load(args.workdir / "filing_vectors.npy")
    chunks = pd.read_parquet(args.workdir / "chunks.parquet")
    chunk_vectors = np.load(args.workdir / "chunk_vectors.npy")
    assert len(vectors) == len(filings) and len(chunk_vectors) == len(chunks)

    accession_pos = dict(zip(filings["accession"], range(len(filings))))
    folds = assign_folds(filings, args.folds, args.seed)
    eligible = filings["train_eligible"].to_numpy()
    result = pd.DataFrame(index=filings.index, columns=["naics2_pred", "naics2_conf", "naics3_pred", "pred_conf", "pred_margin", "naics2_top3", "naics3_top3", "naics3_top3_probs", "naics3_secondary"], dtype=object)
    for fold in range(args.folds):
        test_pos = np.where(folds == fold)[0]
        train_pos = np.where((folds != fold) & eligible)[0]
        assert not set(filings.iloc[test_pos]["cik"]) & set(filings.iloc[train_pos]["cik"]), "CIK leakage"
        model = fit_model(filings, vectors, labels, train_pos, args)
        test = filings.iloc[test_pos]
        p2, p3 = predict(model, test["kept_text"], vectors[test_pos])
        tops2, tops3 = top_k(p2, model.sector_classes), top_k(p3, model.n3_classes)
        for pos, t2, t3 in zip(test_pos, tops2, tops3):
            margin = t3[0][1] - (t3[1][1] if len(t3) > 1 else 0.0)
            result.iloc[pos, :8] = [t2[0][0], t2[0][1], t3[0][0], t3[0][1], margin,
                                    ";".join(c for c, _ in t2), ";".join(c for c, _ in t3), ";".join(f"{p:.4f}" for _, p in t3)]
        # Segment chunks are scored with the same out-of-fold model to surface secondary industries.
        seg_mask = chunks["section"].eq("segment") & chunks["accession"].isin(test["accession"])
        if seg_mask.any():
            seg = chunks[seg_mask]
            _, seg_p3 = predict(model, seg["text"], chunk_vectors[seg.index.to_numpy()])
            seg_frame = pd.DataFrame(seg_p3, columns=model.n3_classes)
            mean = seg_frame.groupby(seg["accession"].to_numpy()).mean()
            filing_probs = pd.DataFrame(p3, columns=model.n3_classes, index=test["accession"])
            for accession, row in mean.iterrows():
                baseline = filing_probs.loc[accession]
                primary = baseline.idxmax()
                lift = row / baseline.clip(lower=1e-6)
                keep = (row >= args.secondary_min_prob) & (lift >= args.secondary_min_lift) & (row.index != primary)
                result.iloc[accession_pos[accession], 8] = ";".join(row[keep].sort_values(ascending=False).index)
        print(f"fold {fold}: train={len(train_pos):,} test={len(test_pos):,}")

    output = pd.concat([filings.drop(columns=["kept_text"]), result], axis=1)
    for column in ("naics2_conf", "pred_conf", "pred_margin"):
        output[column] = output[column].astype(float)
    output["naics3_secondary"] = output["naics3_secondary"].fillna("").astype(str)
    candidates = output["naics_xwalk"].map(lambda x: set(x.split(";")) if x else set())
    output["agrees_with_sic"] = [p in c for p, c in zip(output["naics3_pred"], candidates)]
    output["sector_agrees_with_sic"] = [p in {sector(x) for x in c} for p, c in zip(output["naics2_pred"], candidates)]
    output.to_parquet(args.workdir / "predictions_oof.parquet", index=False)

    metrics = {"weak_label_note": "SIC-derived labels are noisy. Use 09_validate.py against hand labels for true accuracy.",
               "oof_eligible": score(output[eligible]),
               "oof_by_year": {str(y): score(g) for y, g in output[eligible].groupby("year")},
               "temporal_holdout": {}}
    # Drift check: test on one year using held-out companies, and train only on other years and other companies.
    held_out = np.isin(folds, [0, 1])
    for year in sorted(filings["year"].unique()):
        test_pos = np.where((filings["year"] == year) & eligible & held_out)[0]
        train_pos = np.where((filings["year"] != year) & eligible & ~held_out)[0]
        assert not set(filings.iloc[test_pos]["cik"]) & set(filings.iloc[train_pos]["cik"]), "CIK leakage"
        if len(train_pos) < 50 or len(test_pos) == 0:
            metrics["temporal_holdout"][str(year)] = {"skipped": f"train={len(train_pos)} test={len(test_pos)}"}
            continue
        model = fit_model(filings, vectors, labels, train_pos, args)
        test = filings.iloc[test_pos]
        p2, p3 = predict(model, test["kept_text"], vectors[test_pos])
        frame = test.copy()
        frame["naics2_pred"] = [model.sector_classes[i] for i in p2.argmax(1)]
        frame["naics3_pred"] = [model.n3_classes[i] for i in p3.argmax(1)]
        frame["naics3_top3"] = [";".join(c for c, _ in t) for t in top_k(p3, model.n3_classes)]
        metrics["temporal_holdout"][str(year)] = {"train": int(len(train_pos)), **score(frame)}

    final = fit_model(filings, vectors, labels, np.where(eligible)[0], args)
    joblib.dump(vars(final), args.workdir / "final_model.joblib")
    (args.workdir / "metrics.json").write_text(json.dumps(metrics, indent=2))
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
