#!/usr/bin/env python
"""Merge SEC fields, model predictions, and verified LLM decisions into the final table."""
from __future__ import annotations
import json
import pandas as pd
from common import base_parser, sector


def main():
    args = base_parser(__doc__).parse_args()
    out = pd.read_parquet(args.workdir / "predictions_oof.parquet")
    sic_titles = pd.read_parquet(args.workdir / "ref/sic_titles.parquet").set_index("sic")["sic_title"]
    naics_titles = pd.read_parquet(args.workdir / "ref/naics_titles.parquet").set_index("naics")["title"]
    path = args.workdir / "llm_reviews.jsonl"
    reviews = pd.DataFrame([json.loads(x) for x in path.read_text().splitlines() if x.strip()]) if path.exists() else pd.DataFrame()
    if not reviews.empty:
        reviews = reviews.drop_duplicates("accession", keep="last").rename(columns={"naics3": "llm_naics3", "sic": "llm_sic", "rationale": "llm_rationale", "evidence": "llm_evidence"})
        out = out.merge(reviews, on="accession", how="left")
    else:
        for column in ("llm_naics3", "llm_sic", "llm_rationale", "llm_evidence", "evidence_verified"):
            out[column] = None
    accepted = out["llm_naics3"].notna() & out["llm_naics3"].ne("NONE") & out["evidence_verified"].eq(True)
    out["naics3_final"] = out["naics3_pred"].where(~accepted, out["llm_naics3"])
    out["naics2_final"] = out["naics3_final"].map(sector)
    out["final_source"] = accepted.map({True: "llm", False: "model"})
    out["needs_human_review"] = (out["review_reason"] != "") & ~accepted
    sic_accepted = accepted & out["llm_sic"].notna() & out["llm_sic"].ne("NONE")
    out["sic_final"] = out["sic_pred"].where(~sic_accepted, out["llm_sic"])
    out = out.rename(columns={"sic": "sic_sec"})
    out["sic_title"] = out["sic_sec"].map(sic_titles)
    out["naics3_final_title"] = out["naics3_final"].map(naics_titles)
    columns = [c for c in ("accession", "cik", "ticker", "company", "year") if c in out] + [
        "sic_sec", "sic_title", "match_level", "naics_xwalk", "naics2_pred", "naics3_pred", "naics3_secondary",
        "pred_conf", "pred_margin", "agrees_with_sic", "sector_agrees_with_sic", "naics3_top3", "sic_pred", "sic_top3",
        "review_reason", "llm_naics3", "llm_sic", "llm_rationale", "llm_evidence", "evidence_verified",
        "naics3_final", "naics3_final_title", "naics2_final", "sic_final", "final_source", "needs_human_review", "excluded_sic", "filter_fallback"]
    final = out[columns]
    final.to_parquet(args.workdir / "industry_labels.parquet", index=False)
    final.to_csv(args.workdir / "industry_labels.csv", index=False)
    print(final[["final_source", "needs_human_review"]].value_counts().to_string())
    print(f"NAICS3 agrees with SIC crosswalk: {final.agrees_with_sic.mean():.1%}; rows={len(final):,}")


if __name__ == "__main__":
    main()
