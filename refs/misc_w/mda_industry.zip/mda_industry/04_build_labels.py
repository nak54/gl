#!/usr/bin/env python
"""Turn filed SICs into weighted, noisy NAICS2/NAICS3 candidate labels."""
from __future__ import annotations
import pandas as pd
from common import EXCLUDED_SICS, base_parser, resolve_xwalk


def main():
    args = base_parser(__doc__).parse_args()
    filings = pd.read_parquet(args.workdir / "filings.parquet")
    base = pd.read_parquet(args.workdir / "ref/sic_naics6.parquet")
    sic_titles = pd.read_parquet(args.workdir / "ref/sic_titles.parquet")
    xwalk = resolve_xwalk(base, set(filings["sic"]) | set(sic_titles["sic"]))
    xwalk.to_parquet(args.workdir / "ref/sic_xwalk_resolved.parquet", index=False)

    match = xwalk.groupby("sic")["match_level"].first()
    filings["match_level"] = filings["sic"].map(match).fillna("none")
    filings["excluded_sic"] = filings["sic"].isin(EXCLUDED_SICS)
    filings["train_eligible"] = (~filings["excluded_sic"]) & filings["match_level"].isin(["exact", "prefix3"]) & (filings["kept_words"] > 0)

    n3 = xwalk.groupby(["sic", "naics3"], as_index=False)["weight"].sum()
    n2 = xwalk.groupby(["sic", "naics2"], as_index=False)["weight"].sum()
    rows = []
    for level, table, column in (("naics2", n2, "naics2"), ("naics3", n3, "naics3")):
        merged = filings[["accession", "sic"]].merge(table, on="sic")
        rows.append(merged.rename(columns={column: "code"}).assign(level=level)[["accession", "level", "code", "weight"]])
    pd.concat(rows).to_parquet(args.workdir / "labels.parquet", index=False)

    primary = n3.sort_values(["sic", "weight", "naics3"], ascending=[True, False, True]).groupby("sic")["naics3"].first()
    candidates = n3.groupby("sic")["naics3"].apply(lambda s: ";".join(sorted(s)))
    filings["naics3_xwalk_primary"] = filings["sic"].map(primary)
    filings["naics_xwalk"] = filings["sic"].map(candidates).fillna("")
    filings.to_parquet(args.workdir / "filings.parquet", index=False)
    print(filings.groupby("match_level").size().to_dict(), f"excluded={filings.excluded_sic.sum()} eligible={filings.train_eligible.sum()}")
    unmatched = sorted(filings.loc[(filings.match_level == "none") & ~filings.excluded_sic, "sic"].unique())
    if unmatched:
        print("WARNING no crosswalk for SIC:", unmatched[:30])


if __name__ == "__main__":
    main()
