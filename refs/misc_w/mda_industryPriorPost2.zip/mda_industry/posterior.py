"""Combine an economic prior with MD&A evidence.

For filing i with filed SIC s and candidate codes c linked to s:

    P(c | text_i, s)  ∝  max(prior(c | s), floor)^alpha  *  P(c | text_i) / pi(c)

P(c | text) is the classifier's calibrated out-of-fold probability and pi(c) is the class prior
the classifier learned, divided out so the prior is not counted twice. alpha sets how far the
economic prior is trusted (0 ignores it). The floor lets strong text pick a rare link.
"""
from __future__ import annotations
import numpy as np

EPS = 1e-12


def implied_prior(sector_classes, subsector: dict, classes) -> np.ndarray:
    """Class prior implied by class_weight='balanced' at both levels of the hierarchy.

    Balanced weighting makes the sector model act as if sectors were equally likely, and each
    subsector model as if its children were equally likely, so pi(c) = 1/|sectors| * 1/|children|.
    This is an approximation: regularization and soft labels shift it somewhat.
    """
    index = {c: i for i, c in enumerate(classes)}
    prior = np.zeros(len(classes))
    active = [s for s in sector_classes if subsector.get(s) is not None]
    for sec in active:
        sub = subsector[sec]
        members = [sub] if isinstance(sub, str) else list(sub.classes_)
        for code in members:
            prior[index[code]] += 1 / (len(active) * len(members))
    return prior / max(prior.sum(), EPS)


def apply_temperature(p: np.ndarray, temperature: float) -> np.ndarray:
    logits = np.log(np.clip(p, EPS, 1.0)) / temperature
    logits -= logits.max(axis=1, keepdims=True)
    exp = np.exp(logits)
    return exp / exp.sum(axis=1, keepdims=True)


def fit_temperature(p: np.ndarray, y: np.ndarray, grid=None) -> float:
    """Temperature that minimizes negative log-likelihood of labels y (column indices)."""
    grid = np.exp(np.linspace(np.log(0.2), np.log(5.0), 81)) if grid is None else grid
    rows = np.arange(len(y))
    losses = [-np.log(apply_temperature(p, t)[rows, y] + EPS).mean() for t in grid]
    return float(grid[int(np.argmin(losses))])


def constrained_posterior(p: np.ndarray, pi: np.ndarray, classes, priors, alpha=1.0, floor=0.01) -> list[dict]:
    """Posterior over each row's candidate codes.

    p: (n, K) calibrated probabilities. pi: (K,) or (n, K) training class prior.
    priors: list of {code: weight}, one per row; an empty dict gives an empty result.
    A candidate the model cannot score (absent from classes) gets the neutral likelihood 1.0,
    which is what p/pi equals on average when the text carries no information.
    """
    index = {c: i for i, c in enumerate(classes)}
    pi = np.broadcast_to(pi, p.shape)
    likelihood = np.divide(p, pi, out=np.zeros_like(p, dtype=float), where=pi > 0)
    out = []
    for i, prior in enumerate(priors):
        if not prior:
            out.append({})
            continue
        codes = list(prior)
        weights = np.maximum(np.array([prior[c] for c in codes], dtype=float), floor) ** alpha
        evidence = np.array([likelihood[i, index[c]] if c in index else 1.0 for c in codes])
        score = weights * evidence
        score = score if score.sum() > 0 else weights
        out.append(dict(zip(codes, score / score.sum())))
    return out


def out_of_set_mass(p: np.ndarray, classes, candidate_sets) -> np.ndarray:
    """Probability the text puts outside the filed SIC's candidates. High values flag a suspect SIC."""
    index = {c: i for i, c in enumerate(classes)}
    inside = np.array([p[i, [index[c] for c in cands if c in index]].sum() if cands else 0.0
                       for i, cands in enumerate(candidate_sets)])
    return np.clip(1 - inside, 0, 1)


def similarity_posterior(filing_vector: np.ndarray, candidate_vectors: np.ndarray, prior: np.ndarray,
                         tau=0.05, alpha=1.0, floor=0.01) -> tuple[np.ndarray, np.ndarray]:
    """Posterior over a few candidates using embedding similarity as the likelihood.

    Used for 6-digit NAICS, where there are too few firms to train a classifier. The likelihood
    is exp(cosine / tau), so smaller tau trusts the text more. Vectors must be L2-normalized.
    """
    similarity = candidate_vectors @ filing_vector
    logits = similarity / tau
    likelihood = np.exp(logits - logits.max())
    score = np.maximum(prior, floor) ** alpha * likelihood
    return score / score.sum(), similarity


def format_dist(dist: dict, digits=3) -> str:
    return ";".join(f"{c}:{w:.{digits}f}" for c, w in sorted(dist.items(), key=lambda kv: -kv[1]))


def parse_dist(text) -> dict:
    if not isinstance(text, str) or not text:
        return {}
    return {code: float(w) for code, w in (part.split(":") for part in text.split(";"))}
