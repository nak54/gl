#!/usr/bin/env python
"""Build the weighted SIC -> NAICS 2022 crosswalk and title tables from Census, BLS and SEC files.

Each SIC's split across NAICS codes is weighted from the Census 1997 Bridge if present,
otherwise the BLS CES employment ratios, otherwise an equal split (see priors.py).
Writes ref/sic_naics6.parquet (sic, naics6, weight, source, quality), ref/prior_audit.parquet,
ref/sic_titles.parquet and ref/naics_titles.parquet.
"""
from __future__ import annotations
import re
from pathlib import Path
import pandas as pd
from common import base_parser, pad_sic
from priors import build_priors, propagate, read_bls_ratios, read_bridge, weights_from_bls, weights_from_bridge

CODE = re.compile(r"^\d{2,6}$")


def clean_code(value) -> str | None:
    if pd.isna(value):
        return None
    text = re.sub(r"\.0+$", "", str(value).strip())
    return text if CODE.match(text) else None


def find_file(refdir: Path, stem: str) -> Path:
    matches = sorted(p for p in refdir.glob(f"{stem}.*") if p.suffix.lower() in {".xls", ".xlsx"})
    if not matches:
        raise SystemExit(f"Missing {stem}.xls or .xlsx in {refdir}. See README.")
    return matches[0]


def optional_file(refdir: Path, stem: str, suffixes) -> Path | None:
    matches = sorted(p for p in refdir.glob(f"{stem}.*") if p.suffix.lower() in suffixes)
    return matches[0] if matches else None


def read_table(path: Path) -> pd.DataFrame:
    sheets = pd.read_excel(path, sheet_name=None, header=None, dtype=object)
    return max(sheets.values(), key=len)


def parse_concordance(path: Path, src_year: int, dst_year: int) -> pd.DataFrame:
    """Detect code columns from data, and direction from year headers when present."""
    raw = read_table(path)
    share = raw.apply(lambda col: col.map(clean_code).notna().mean())
    code_cols = [c for c in raw.columns if share[c] > 0.5][:2]
    if len(code_cols) < 2:
        raise ValueError(f"{path}: expected two code columns, found {code_cols}")
    a, b = code_cols
    first = raw[a].map(clean_code).first_valid_index()
    header = raw.iloc[:first]
    years = [next((int(y) for y in re.findall(r"(?:19|20)\d\d", " ".join(header[c].dropna().astype(str)))), None)
             for c in (a, b)]
    if years == [dst_year, src_year]:
        a, b = b, a
    out = pd.DataFrame({"src": raw[a].map(clean_code), "dst": raw[b].map(clean_code)}).dropna()
    title_col = b + 1 if b + 1 in raw.columns and b + 1 not in code_cols else None
    out["dst_title"] = raw.loc[out.index, title_col].astype(str).str.strip() if title_col is not None else ""
    return out.drop_duplicates()


def main():
    parser = base_parser(__doc__)
    parser.add_argument("--refdir", type=Path, default=Path("reference_files"))
    parser.add_argument("--bridge-measures", default="shipments,employees,payroll,establishments",
                        help="Bridge measures to try in order")
    parser.add_argument("--keep-outside-links", action="store_true",
                        help="Keep BLS/Bridge links absent from the Census concordance")
    args = parser.parse_args()
    out = args.workdir / "ref"
    out.mkdir(parents=True, exist_ok=True)

    sic2002 = parse_concordance(find_file(args.refdir, "sic1987_to_naics2002"), 1987, 2002)
    sic2002["src"] = sic2002["src"].str.zfill(4)
    links = sic2002[sic2002["dst"].str.len() == 6].rename(columns={"src": "sic", "dst": "naics"})[["sic", "naics"]]
    steps = {(src, dst): parse_concordance(find_file(args.refdir, f"naics{src}_to_naics{dst}"), src, dst)
             for src, dst in [(2002, 2007), (2007, 2012), (2012, 2017), (2017, 2022)]}

    bridge = bridge_step = bls = None
    bridge_path = optional_file(args.refdir, "census_bridge_sic_naics1997", {".csv"})
    if bridge_path:
        bridge = weights_from_bridge(read_bridge(bridge_path), tuple(args.bridge_measures.split(",")))
        bridge_step = parse_concordance(find_file(args.refdir, "naics1997_to_naics2002"), 1997, 2002)
        print(f"Bridge weights for {bridge.sic.nunique():,} SICs from {bridge_path.name}")
    bls_path = optional_file(args.refdir, "bls_sic_naics2002_ratios", {".csv", ".htm", ".html"})
    if bls_path:
        universe = set(steps[(2002, 2007)]["src"]) | set(links["naics"])
        bls = weights_from_bls(read_bls_ratios(bls_path), universe)
        print(f"BLS weights for {bls.sic.nunique():,} SIC series from {bls_path.name}")
    prior, audit = build_priors(links, bridge, bridge_step, bls, restrict_to_concordance=not args.keep_outside_links)

    titles = {}
    for (src, dst), step in steps.items():
        prior, lost = propagate(prior, step)
        if (lost > 0.001).any():
            print(f"WARNING {src}->{dst}: {int((lost > 0.001).sum())} SICs lost weight on codes with no successor, e.g. {lost[lost > 0.001].round(3).head(5).to_dict()}")
        if dst == 2022:
            titles = dict(zip(step["dst"], step["dst_title"]))
    chain = prior.rename(columns={"naics": "naics6"})
    chain.to_parquet(out / "sic_naics6.parquet", index=False)
    top = chain.groupby("sic")["weight"].max()
    audit = audit.merge(top.rename("top_share").reset_index(), on="sic", how="left")
    audit.to_parquet(out / "prior_audit.parquet", index=False)
    used, rejected = audit[audit["status"] == "used"], audit[audit["status"] == "rejected"]
    print("prior sources:", used["source"].value_counts().to_dict(), f"split SICs (top share < 0.8): {(top < 0.8).sum():,}")
    if len(rejected):
        print(f"WARNING {len(rejected)} SIC sources rejected (under {0.5:.0%} of weight inside the concordance), e.g.",
              rejected.head(5)[["sic", "source", "retained_share"]].round(3).to_dict("records"))

    code_table = read_table(find_file(args.refdir, "naics2022_codes"))
    code_col = code_table.apply(lambda c: c.map(lambda v: bool(re.fullmatch(r"\d{2,6}(-\d{2})?", re.sub(r"\.0+$", "", str(v).strip()))))).mean().idxmax()
    text_share = code_table.apply(lambda c: c.map(lambda v: isinstance(v, str) and bool(re.search("[A-Za-z]{3}", v))).mean())
    title_col = text_share.drop(code_col).idxmax()
    for code, title in zip(code_table[code_col], code_table[title_col]):
        code = re.sub(r"\.0+$", "", str(code).strip())
        if re.fullmatch(r"\d{2,6}(-\d{2})?", code):
            titles[code] = re.sub(r"(?<=[a-z)])T$", "", str(title).strip())
    naics_titles = pd.DataFrame(sorted(titles.items()), columns=["naics", "title"])
    descriptions_path = optional_file(args.refdir, "naics2022_descriptions", {".xls", ".xlsx"})
    naics_titles["description"] = ""
    if descriptions_path:
        table = read_table(descriptions_path)
        code_col = table.apply(lambda c: c.map(lambda v: bool(re.fullmatch(r"\d{6}", re.sub(r"\.0+$", "", str(v).strip()))))).mean().idxmax()
        lengths = table.apply(lambda c: c.map(lambda v: len(v) if isinstance(v, str) else 0).mean()).drop(code_col)
        text = dict(zip(table[code_col].map(lambda v: re.sub(r"\.0+$", "", str(v).strip())), table[lengths.idxmax()].fillna("").astype(str)))
        naics_titles["description"] = naics_titles["naics"].map(text).fillna("").str.slice(0, 2000)
    naics_titles.to_parquet(out / "naics_titles.parquet", index=False)

    sec_path = args.refdir / "sec_sic_list.csv"
    sec = pd.read_csv(sec_path, dtype=str)
    sec.columns = [c.strip().lower() for c in sec.columns]
    code_name = next(c for c in sec.columns if "sic" in c and "title" not in c)
    title_name = next(c for c in sec.columns if "title" in c)
    sic_titles = pd.DataFrame({"sic": sec[code_name].map(pad_sic), "sic_title": sec[title_name].str.strip()}).dropna().drop_duplicates("sic")
    sic_titles.to_parquet(out / "sic_titles.parquet", index=False)
    print(f"crosswalk rows={len(chain):,} SICs={chain.sic.nunique():,} NAICS6={chain.naics6.nunique():,}; SEC titles={len(sic_titles):,}")


if __name__ == "__main__":
    main()
