#!/usr/bin/env python
"""Validate filings, keep business-bearing MD&A sections, and chunk them.

Input columns: accession, cik, year, sic, mda_text. Optional: ticker, company.
Writes filings.parquet (one row per filing) and chunks.parquet.
"""
from __future__ import annotations
import re
from pathlib import Path
import pandas as pd
from common import YEARS, base_parser, pad_sic

KEEP, DROP = "keep", "drop"
HEADINGS = [
    (r"(?:Business |Company |Executive )?Overview|Executive Summary|Our Business|Description of (?:the )?Business|Nature of (?:the )?(?:Business|Operations)", "overview", KEEP),
    (r"(?:Segment|Business Segment|Reportable Segment)s?(?: Results| Information| Performance| Review)?|Results (?:of Operations )?by (?:Business )?Segment", "segment", KEEP),
    (r"(?:Net )?(?:Revenues?|Sales)(?: and [A-Z][a-z]+)?|Products and Services|Our Products|Key Products", "revenue", KEEP),
    (r"Results of Operations|Operating Results", "results", KEEP),
    (r"Liquidity(?: and Capital Resources)?|Capital Resources|Cash Flows?|Sources and Uses of Cash|Contractual Obligations|Off[- ]Balance[- ]Sheet (?:Arrangements|Commitments)", "liquidity", DROP),
    (r"Revenue Recognition|Critical Accounting (?:Policies|Estimates)(?: and (?:Estimates|Policies|Judgments))?|Significant Accounting Policies", "critical_accounting", DROP),
    (r"(?:Recent(?:ly)?|New(?:ly)?) (?:Issued |Adopted )?Accounting (?:Pronouncements|Standards|Guidance)", "accounting_standards", DROP),
    (r"Quantitative and Qualitative Disclosures? About Market Risk|Market Risk", "market_risk", DROP),
    (r"(?:Cautionary|Special) (?:Note|Statement)s?(?: Regarding| Concerning| About)? Forward[- ]Looking Statements?|Forward[- ]Looking Statements?", "forward_looking", DROP),
    (r"Non-GAAP (?:Financial )?Measures?", "non_gaap", DROP),
]
HEADINGS.sort(key=lambda h: h[2] != DROP)
HEADING_RE = re.compile(
    r"(?:(?<=^)|(?<=\n)|(?<=[.;:!?]\s)|(?<=[.;:!?]\s\s))[ \t]*(?P<h>" +
    "|".join(f"(?P<g{i}>{pattern})" for i, (pattern, _, _) in enumerate(HEADINGS)) +
    r")(?=[ \t]*(?:\n|$|[:.—-]\s|\s+[A-Z0-9]))"
)
SENTENCE_LOOKBEHIND = re.compile(r"\b(?:see|under|in|the|and|of|to|our|within)\s*$", re.I)


def split_sections(text: str) -> list[tuple[str, str, str]]:
    """Return (name, disposition, body). Handles lined and flattened extractions."""
    marks = []
    for match in HEADING_RE.finditer(text):
        if SENTENCE_LOOKBEHIND.search(text[max(0, match.start() - 12):match.start()]):
            continue
        index = next(int(k[1:]) for k, v in match.groupdict().items() if k != "h" and v)
        marks.append((match.start(), match.end(), HEADINGS[index][1], HEADINGS[index][2]))
    if not marks:
        return [("unsectioned", KEEP, text)]
    sections = [("preamble", KEEP, text[:marks[0][0]])] if marks[0][0] > 0 else []
    for i, (_, end, name, disposition) in enumerate(marks):
        stop = marks[i + 1][0] if i + 1 < len(marks) else len(text)
        sections.append((name, disposition, text[end:stop]))
    return [s for s in sections if s[2].strip()]


def word_chunks(text: str, size: int, overlap: int) -> list[str]:
    words = text.split()
    step = size - overlap
    return [" ".join(words[i:i + size]) for i in range(0, max(len(words) - overlap, 1), step)]


def main():
    parser = base_parser(__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--text-col", default="mda_text")
    parser.add_argument("--min-kept-words", type=int, default=150)
    parser.add_argument("--chunk-words", type=int, default=220, help="Stays under mpnet's 384-token default limit")
    parser.add_argument("--chunk-overlap", type=int, default=30)
    args = parser.parse_args()
    args.workdir.mkdir(parents=True, exist_ok=True)

    df = pd.read_parquet(args.input).rename(columns={args.text_col: "mda_text"})
    missing = {"accession", "cik", "year", "sic", "mda_text"} - set(df.columns)
    if missing:
        raise SystemExit(f"Missing input columns: {sorted(missing)}")
    if df["accession"].duplicated().any():
        raise SystemExit("accession must be unique")
    df["year"] = df["year"].astype(int)
    if bad := set(df["year"]) - YEARS:
        raise SystemExit(f"Unexpected years: {sorted(bad)}")
    df["sic"] = df["sic"].map(pad_sic)
    if df["sic"].isna().any():
        raise SystemExit(f"{df.sic.isna().sum()} filings lack a valid SIC")
    df["cik"] = df["cik"].astype(str).str.lstrip("0")
    df["mda_text"] = df["mda_text"].fillna("")

    chunks, kept_text, fallback, names = [], [], [], []
    for row in df.itertuples():
        sections = split_sections(row.mda_text)
        kept = [(n, b) for n, d, b in sections if d == KEEP]
        words = sum(len(b.split()) for _, b in kept)
        used_fallback = words < args.min_kept_words
        if used_fallback:
            kept = [("full_text", row.mda_text)]
        fallback.append(used_fallback)
        kept_text.append(" ".join(b for _, b in kept))
        names.append(",".join(sorted({n for n, _ in kept})))
        for section, body in kept:
            for chunk in word_chunks(body, args.chunk_words, args.chunk_overlap):
                if chunk:
                    chunks.append((row.accession, section, chunk))

    keep_cols = [c for c in ("accession", "cik", "year", "sic", "ticker", "company") if c in df.columns]
    filings = df[keep_cols].copy()
    filings["kept_text"], filings["filter_fallback"], filings["sections_kept"] = kept_text, fallback, names
    filings["kept_words"] = filings["kept_text"].str.split().str.len().fillna(0).astype(int)
    filings.to_parquet(args.workdir / "filings.parquet", index=False)
    chunk_df = pd.DataFrame(chunks, columns=["accession", "section", "text"])
    chunk_df["chunk_id"] = range(len(chunk_df))
    chunk_df.to_parquet(args.workdir / "chunks.parquet", index=False)
    print(f"filings={len(filings):,} chunks={len(chunk_df):,} fallback={filings.filter_fallback.mean():.1%} by_year={filings.year.value_counts().sort_index().to_dict()}")
    print("sections:", chunk_df.section.value_counts().to_dict())


if __name__ == "__main__":
    main()
