#!/usr/bin/env python
"""Hand-label validation.

  sample: writes a blinded labeling sheet, oversampling disagreements, with a separate design key.
  score:  scores the model, final labels, and SIC baseline with sampling weights and CIK-bootstrap CIs.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import f1_score
from common import sector


def sample(args):
    labels = pd.read_parquet(args.workdir / "industry_labels.parquet")
    filings = pd.read_parquet(args.workdir / "filings.parquet")[["accession", "kept_text"]]
    labels = labels[~labels["excluded_sic"]].copy()
    labels["stratum"] = np.select([~labels["agrees_with_sic"] | labels["sic_suspect"], labels["split_sic"], labels["pred_conf"] < 0.5],
                                  ["disagree", "split_sic", "low_conf"], "agree_confident")
    quotas = {"disagree": int(args.n * 0.3), "split_sic": int(args.n * 0.25), "low_conf": int(args.n * 0.15)}
    quotas["agree_confident"] = args.n - sum(quotas.values())
    parts = []
    for stratum, quota in quotas.items():
        group = labels[labels["stratum"] == stratum]
        # One filing per company per stratum where possible, so clusters don't dominate.
        shuffled = group.sample(frac=1, random_state=args.seed)
        chosen = shuffled.drop_duplicates("cik").head(quota)
        if len(chosen) < quota:
            chosen = pd.concat([chosen, shuffled.drop(chosen.index).head(quota - len(chosen))])
        if len(chosen):
            parts.append(chosen.assign(sampling_weight=len(group) / len(chosen)))
    picked = pd.concat(parts).sample(frac=1, random_state=args.seed)
    key = picked[["accession", "stratum", "sampling_weight"]]
    key.to_csv(args.workdir / "validation_key.csv", index=False)
    sheet = picked.merge(filings, on="accession")
    id_cols = [c for c in ("accession", "company", "ticker", "year") if c in sheet]
    sheet = sheet[id_cols + ["kept_text"]].rename(columns={"kept_text": "mda_excerpt"})
    sheet["mda_excerpt"] = sheet["mda_excerpt"].str[:4000]
    sheet["gold_naics3"], sheet["gold_naics6"], sheet["notes"] = "", "", ""
    sheet.to_csv(args.workdir / "validation_sheet.csv", index=False)
    print(f"Wrote {len(sheet)} rows to validation_sheet.csv. Fill gold_naics3 from the company's 10-K, not from predictions.")
    print(key["stratum"].value_counts().to_string())


def weighted_metrics(frame, column, weights):
    gold3 = frame["gold_naics3"]
    gold2 = gold3.map(sector)
    pred3 = frame[column].fillna("none").astype(str)
    pred2 = pred3.map(sector)
    return {"naics2_accuracy": float(np.average(gold2 == pred2, weights=weights)),
            "naics3_accuracy": float(np.average(gold3 == pred3, weights=weights)),
            "naics2_macro_f1": float(f1_score(gold2, pred2, average="macro", sample_weight=weights, zero_division=0)),
            "naics3_macro_f1": float(f1_score(gold3, pred3, average="macro", sample_weight=weights, zero_division=0))}


def bootstrap(frame, column, n, seed):
    rng = np.random.default_rng(seed)
    groups = [g for _, g in frame.groupby("cik")]
    keys = ["naics2_accuracy", "naics3_accuracy"]
    draws = {k: [] for k in keys}
    for _ in range(n):
        resampled = pd.concat([groups[i] for i in rng.integers(0, len(groups), len(groups))])
        metrics = weighted_metrics(resampled, column, resampled["sampling_weight"])
        for k in keys:
            draws[k].append(metrics[k])
    return {k: [float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5))] for k, v in draws.items()}


def score(args):
    labels = pd.read_parquet(args.workdir / "industry_labels.parquet")
    filings = pd.read_parquet(args.workdir / "filings.parquet")[["accession", "naics3_xwalk_primary"]]
    key = pd.read_csv(args.workdir / "validation_key.csv", dtype={"accession": str})
    gold_full = pd.read_csv(args.gold, dtype=str)
    keep = ["accession", "gold_naics3"] + (["gold_naics6"] if "gold_naics6" in gold_full else [])
    gold = gold_full[keep].dropna(subset=["gold_naics3"])
    gold["gold_naics3"] = gold["gold_naics3"].str.strip().str[:3]
    frame = gold.merge(key, on="accession").merge(labels, on="accession").merge(filings, on="accession")
    if frame.empty:
        raise SystemExit("No labeled rows matched the validation key")
    weights = frame["sampling_weight"]
    report = {"n_labeled": int(len(frame)), "note": "Accuracy and F1 are weighted by the inverse sampling rate."}
    for name, column in (("sic_crosswalk_baseline", "naics3_xwalk_primary"), ("model", "naics3_pred"),
                         ("posterior", "naics3_constrained"), ("final_with_llm", "naics3_final")):
        report[name] = {**weighted_metrics(frame, column, weights), "accuracy_95ci": bootstrap(frame, column, args.bootstrap, args.seed)}
    in_top3 = [g in t.split(";") for g, t in zip(frame["gold_naics3"], frame["naics3_top3"])]
    report["model"]["naics3_top3_accuracy"] = float(np.average(in_top3, weights=weights))
    split = frame[frame["split_sic"]]
    if len(split):
        report["split_sic_filings"] = {name: float(np.average(split["gold_naics3"] == split[col].fillna("").astype(str), weights=split["sampling_weight"]))
                                       for name, col in (("prior_top", "naics3_prior_top"), ("text_model", "naics3_pred"), ("posterior", "naics3_constrained"), ("final", "naics3_final"))}
        report["split_sic_filings"]["n"] = int(len(split))
    if "gold_naics6" in gold_full and gold_full["gold_naics6"].notna().any():
        g6 = frame.dropna(subset=["gold_naics6"])
        report["naics6"] = {"n": int(len(g6)), "final_accuracy": float(np.average(g6["gold_naics6"] == g6["naics6_final"].fillna(""), weights=g6["sampling_weight"]))}
    report["by_sector"] = {s: {"n": int(len(g)), "final_naics3_accuracy": float(np.average(g["gold_naics3"] == g["naics3_final"], weights=g["sampling_weight"]))}
                           for s, g in frame.groupby(frame["gold_naics3"].map(sector))}
    report["by_year"] = {str(y): {"n": int(len(g)), "final_naics3_accuracy": float(np.average(g["gold_naics3"] == g["naics3_final"], weights=g["sampling_weight"]))} for y, g in frame.groupby("year")}
    report["by_stratum"] = {s: {"n": int(len(g)), "final_naics3_accuracy": float((g["gold_naics3"] == g["naics3_final"]).mean())} for s, g in frame.groupby("stratum")}
    (args.workdir / "validation_report.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("mode", choices=["sample", "score"])
    parser.add_argument("--workdir", type=Path, default=Path("work"))
    parser.add_argument("--n", type=int, default=300)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--gold", type=Path, help="Completed validation_sheet.csv")
    parser.add_argument("--bootstrap", type=int, default=500)
    args = parser.parse_args()
    sample(args) if args.mode == "sample" else score(args)


if __name__ == "__main__":
    main()
