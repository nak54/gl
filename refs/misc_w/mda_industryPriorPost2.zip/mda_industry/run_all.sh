#!/usr/bin/env bash
# Usage: ./run_all.sh path/to/filings.parquet [workdir]   Set LLM=1 to run the Claude review.
set -euo pipefail
INPUT="$1"; WORK="${2:-work}"
python 01_build_refs.py --workdir "$WORK"
python 02_filter_mda.py --workdir "$WORK" --input "$INPUT"
python 03_embed_filings.py --workdir "$WORK"
python 04_build_labels.py --workdir "$WORK"
python 05_train_classifier.py --workdir "$WORK"
python 06_rank_sic.py --workdir "$WORK"
if [[ "${LLM:-0}" == "1" ]]; then python 07_llm_review.py --workdir "$WORK"; else python 07_llm_review.py --workdir "$WORK" --dry-run; fi
python 08_build_output.py --workdir "$WORK"
python 09_validate.py sample --workdir "$WORK"
