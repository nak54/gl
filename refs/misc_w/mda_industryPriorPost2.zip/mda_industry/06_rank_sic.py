#!/usr/bin/env python
"""Rank 4-digit SICs within predicted NAICS3, and choose 6-digit NAICS from prior x embedding similarity.

6-digit NAICS: candidates are the filed SIC's 6-digit links under the chosen NAICS3 (the constrained
NAICS3, or the unconstrained one if the SIC is suspect), weighted by the economic prior. The MD&A
filing vector is compared with each candidate's NAICS title and description (posterior.similarity_posterior).
"""
from __future__ import annotations
import json
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from common import EXCLUDED_SICS, base_parser, embed_texts
from posterior import format_dist, similarity_posterior


def add_naics6(preds, vectors, xwalk, args, meta):
    names = pd.read_parquet(args.workdir / "ref/naics_titles.parquet").fillna("")
    if "description" not in names:
        names["description"] = ""
    docs = {r.naics: f"{r.title}. {r.description}".strip(". ") or r.naics for r in names.itertuples() if len(r.naics) == 6}
    six_by_n3 = {}
    for code in docs:
        six_by_n3.setdefault(code[:3], []).append(code)
    suspect = preds["sic_suspect"].fillna(False).astype(bool)
    target = preds["naics3_pred"].where(suspect | preds["naics3_constrained"].isna(), preds["naics3_constrained"])
    links = xwalk.groupby("sic")
    plans = []
    for sic, n3, is_suspect in zip(preds["sic"], target, suspect):
        rows = links.get_group(sic) if sic in links.groups and not is_suspect else xwalk.iloc[:0]
        rows = rows[rows["naics3"] == n3]
        if len(rows):
            plans.append((rows["naics6"].tolist(), rows["weight"].to_numpy() / rows["weight"].sum(), "sic_links"))
        else:
            codes = six_by_n3.get(n3, [])
            plans.append((codes, np.full(len(codes), 1 / max(len(codes), 1)), "all_under_naics3" if codes else "none"))
    needed = sorted({c for codes, _, _ in plans for c in codes})
    position = {c: k for k, c in enumerate(needed)}
    embedded = embed_texts([docs.get(c, c) for c in needed], meta["backend"], meta["model"]) if needed else np.zeros((0, vectors.shape[1]))
    results, cache = [], []
    for i, (codes, prior, basis) in enumerate(plans):
        if not codes:
            results.append((None, np.nan, "", basis))
            continue
        post, similarity = similarity_posterior(vectors[i], embedded[[position[c] for c in codes]], prior, args.tau, args.alpha, args.floor)
        cache.append((preds["accession"].iloc[i], target.iloc[i], basis, ";".join(codes),
                      ";".join(f"{w:.6g}" for w in prior), ";".join(f"{x:.6g}" for x in similarity)))
        best = int(np.argmax(post))
        results.append((codes[best], float(post[best]), format_dist(dict(zip(codes, post))), basis))
    preds["naics6_pred"], preds["naics6_conf"], preds["naics6_posterior"], preds["naics6_basis"] = zip(*results)
    # Saved for 10_tune.py, which recomputes 6-digit choices for other tau values.
    pd.DataFrame(cache, columns=["accession", "target_naics3", "basis", "codes", "prior", "similarity"]).to_parquet(
        args.workdir / "naics6_candidates.parquet", index=False)
    print("6-digit basis:", preds["naics6_basis"].value_counts().to_dict())
    return preds


def main():
    parser = base_parser(__doc__)
    parser.add_argument("--rrf-k", type=int, default=10)
    parser.add_argument("--top-k", type=int, default=3)
    parser.add_argument("--tau", type=float, default=0.05, help="Similarity temperature for 6-digit choice; smaller trusts text more")
    parser.add_argument("--alpha", type=float, default=1.0)
    parser.add_argument("--floor", type=float, default=0.01)
    args = parser.parse_args()
    preds = pd.read_parquet(args.workdir / "predictions_oof.parquet")
    filings = pd.read_parquet(args.workdir / "filings.parquet")
    vectors = np.load(args.workdir / "filing_vectors.npy")
    xwalk = pd.read_parquet(args.workdir / "ref/sic_xwalk_resolved.parquet")
    sic_titles = pd.read_parquet(args.workdir / "ref/sic_titles.parquet")
    naics_titles = pd.read_parquet(args.workdir / "ref/naics_titles.parquet").set_index("naics")["title"].to_dict()
    meta = json.loads((args.workdir / "embedding_meta.json").read_text())

    sics = sic_titles[~sic_titles["sic"].isin(EXCLUDED_SICS) & sic_titles["sic"].isin(xwalk["sic"])].reset_index(drop=True)
    documents = []
    for row in sics.itertuples():
        linked = xwalk.loc[xwalk["sic"] == row.sic, "naics6"].map(naics_titles).dropna().unique()[:8]
        documents.append(row.sic_title.replace("-", " ").lower() + ". " + ". ".join(linked))

    dense = vectors @ embed_texts(documents, meta["backend"], meta["model"]).T
    tfidf = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True, stop_words="english", min_df=2)
    tfidf.fit(filings["kept_text"])
    sparse_sim = (tfidf.transform(filings["kept_text"]) @ tfidf.transform(documents).T).toarray()

    share = xwalk.groupby(["sic", "naics3"])["weight"].sum().to_dict()
    sic_n3 = xwalk.groupby("sic")["naics3"].apply(set).to_dict()
    sic_list = sics["sic"].tolist()
    records = []
    for i, row in enumerate(preds.itertuples()):
        probs = dict(zip(row.naics3_top3.split(";"), map(float, row.naics3_top3_probs.split(";"))))
        positions = [j for j, sic in enumerate(sic_list) if sic_n3[sic] & set(probs)]
        if not positions:
            records.append(("", np.nan))
            continue
        prior = np.array([max(probs.get(n3, 0) * share.get((sic_list[j], n3), 0) for n3 in sic_n3[sic_list[j]]) for j in positions])
        score = np.zeros(len(positions))
        for signal in (dense[i, positions], sparse_sim[i, positions], prior):
            ranks = (-signal).argsort().argsort() + 1
            score += 1 / (args.rrf_k + ranks)
        # SICs under the top NAICS3 rank first, so sic_pred always fits naics3_pred.
        naics_rank = {code: r for r, code in enumerate(row.naics3_top3.split(";"))}
        tier = np.array([min(naics_rank.get(n3, 99) for n3 in sic_n3[sic_list[j]]) for j in positions])
        order = np.lexsort((-score, tier))
        ordered = [sic_list[positions[j]] for j in order]
        filed = ordered.index(row.sic) + 1 if row.sic in ordered else np.nan
        records.append((";".join(ordered[:args.top_k]), filed))
    preds["sic_top3"], preds["filed_sic_rank"] = zip(*records)
    preds["sic_pred"] = preds["sic_top3"].str.split(";").str[0]
    preds = add_naics6(preds, vectors, xwalk, args, meta)
    preds.to_parquet(args.workdir / "predictions_oof.parquet", index=False)

    eligible = preds[preds["train_eligible"]]
    print(f"Filed SIC at rank 1: {(eligible.filed_sic_rank == 1).mean():.1%}  top {args.top_k}: {(eligible.filed_sic_rank <= args.top_k).mean():.1%}  (filed SIC is not injected into candidates)")


if __name__ == "__main__":
    main()
