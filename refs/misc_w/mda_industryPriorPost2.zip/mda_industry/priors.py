"""Economic priors for SIC -> NAICS splits.

For each SIC, the prior gives each linked NAICS code a weight from the first source that covers it:

  bridge  Census 1997 Economic Census Bridge (NAICS 1997): each piece's share of the SIC's
          shipments/receipts, falling back to employees, payroll, then establishments.
  bls     BLS CES SIC-to-NAICS 2002 employment ratios (QCEW, first quarter 2001).
  equal   Equal split over the Census concordance links.

Weights are then carried to NAICS 2022 by multiplying through each concordance step.
"""
from __future__ import annotations
import re
from pathlib import Path
import numpy as np
import pandas as pd
from common import pad_sic

MEASURES = ("shipments", "employees", "payroll", "establishments")
_NUM = r"(\d[\d,]*)\s*(k?)"
RANGE_RE = re.compile(_NUM + r"\s*-\s*" + _NUM, re.I)
PRIOR_COLUMNS = ["sic", "naics", "weight", "source", "quality"]


def _number(digits: str, thousands: str) -> float:
    value = float(digits.replace(",", ""))
    return value * 1000 if thousands else value


def parse_value(value) -> tuple[float, str]:
    """Parse a Bridge cell. Returns (value, quality) with quality exact, range_mid, or missing.

    '1,470,495' -> exact. 'D (10k-24999)' -> midpoint of the published range. 'D' -> missing.
    """
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return np.nan, "missing"
    if isinstance(value, (int, float, np.integer, np.floating)):
        return float(value), "exact"
    text = str(value).strip()
    match = RANGE_RE.search(text)
    if match:
        low, high = _number(*match.group(1, 2)), _number(*match.group(3, 4))
        return (low + high) / 2, "range_mid"
    cleaned = text.replace(",", "").replace("$", "")
    if re.fullmatch(r"\d+(\.\d+)?", cleaned):
        return float(cleaned), "exact"
    return np.nan, "missing"


def read_bridge(path: Path) -> pd.DataFrame:
    """Tidy Bridge CSV: one row per SIC x NAICS 1997 piece, no SIC total rows.

    Columns: sic, naics, and at least one of shipments, employees, payroll, establishments.
    Cells may hold Census 'D (low-high)' suppression text.
    """
    frame = pd.read_csv(path, dtype=str)
    frame.columns = [c.strip().lower() for c in frame.columns]
    if not {"sic", "naics"} <= set(frame.columns) or not set(MEASURES) & set(frame.columns):
        raise ValueError(f"{path}: needs sic, naics, and one of {MEASURES}")
    return frame


def weights_from_bridge(frame: pd.DataFrame, measures=MEASURES) -> pd.DataFrame:
    """Share of each SIC's value in each NAICS piece, computed from the piece values.

    The printed Bridge percentages ('96% of 311941') give the piece's share of the NAICS code,
    which is the reverse direction, so they are never used. Zero-value pieces are dropped.
    A measure is used only if every piece of the SIC has a value or a published range.
    """
    frame = frame.assign(sic=frame["sic"].map(pad_sic), naics=frame["naics"].astype(str).str.extract(r"(\d{6})")[0])
    frame = frame.dropna(subset=["sic", "naics"])
    rows = []
    for sic, group in frame.groupby("sic"):
        for measure in measures:
            if measure not in group:
                continue
            parsed = [parse_value(v) for v in group[measure]]
            values = np.array([v for v, _ in parsed], dtype=float)
            if np.isnan(values).any() or values.sum() <= 0:
                continue
            pieces = pd.Series(values, index=group["naics"].to_numpy()).groupby(level=0).sum()
            pieces = pieces[pieces > 0]
            quality = "range_mid" if any(q == "range_mid" for _, q in parsed) else "exact"
            rows += [(sic, code, value / pieces.sum(), f"bridge_{measure}", quality) for code, value in pieces.items()]
            break
    return pd.DataFrame(rows, columns=PRIOR_COLUMNS)


def _flatten(columns) -> list[str]:
    return [" ".join(str(x) for x in c if "Unnamed" not in str(x)) if isinstance(c, tuple) else str(c) for c in columns]


def read_bls_ratios(path: Path) -> pd.DataFrame:
    """Read the BLS 'SIC 4-digit to NAICS 2002 ratios' table, saved as HTML or CSV."""
    path = Path(path)
    if path.suffix.lower() in {".htm", ".html"}:
        tables = pd.read_html(path)
        table = next(t for t in tables if any("ratio" in c.lower() for c in _flatten(t.columns)))
    else:
        table = pd.read_csv(path, dtype=str)
    table.columns = _flatten(table.columns)
    lower = {c.lower(): c for c in table.columns}

    def find(*keys):
        return next(original for name, original in lower.items() if all(k in name for k in keys))

    sic_col, naics_col, ratio_col = find("sic", "code"), find("naics", "code"), find("ratio")
    ratio = pd.to_numeric(table[ratio_col].astype(str).str.replace("%", "").str.strip(), errors="coerce")
    return pd.DataFrame({"sic_code": table[sic_col].astype(str), "naics_code": table[naics_col].astype(str), "ratio": ratio})


def weights_from_bls(frame: pd.DataFrame, naics_universe) -> pd.DataFrame:
    """Turn CES ratios into SIC -> NAICS 2002 6-digit weights.

    CES codes carry a supersector prefix ('20-1542'). Combined NAICS series such as 213000 are
    spread equally across the 6-digit codes they contain. Ratios under 1% are absent from the
    BLS table, so each SIC is rescaled to sum to 1. SIC codes ending in 0 are 3-digit group
    series and are kept with is_group=True for build_priors to apply to member SICs.
    """
    universe = sorted(set(naics_universe))
    universe_set = set(universe)
    tail = lambda code: str(code).split("-")[-1].strip()
    data = frame.assign(sic=frame["sic_code"].map(tail), naics=frame["naics_code"].map(tail)).dropna(subset=["ratio"])
    data = data[data["sic"].str.fullmatch(r"\d{4}") & data["naics"].str.fullmatch(r"\d{6}") & (data["ratio"] > 0)]
    rows = []
    for row in data.itertuples():
        children = [row.naics] if row.naics in universe_set else [u for u in universe if u.startswith(row.naics.rstrip("0"))]
        rows += [(row.sic, child, row.ratio / len(children)) for child in children]
    out = pd.DataFrame(rows, columns=["sic", "naics", "weight"]).groupby(["sic", "naics"], as_index=False)["weight"].sum()
    totals = out.groupby("sic")["weight"].transform("sum")
    out["quality"] = np.where(totals < 99.5, "rescaled", "exact")
    out["weight"] = out["weight"] / totals
    out["source"] = "bls_employment"
    out["is_group"] = out["sic"].str.endswith("0")
    return out[PRIOR_COLUMNS + ["is_group"]]


def propagate(prior: pd.DataFrame, step: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    """Carry weights through one concordance step (src -> dst), multiplying shares along each path.

    A src code that splits is divided equally among its dst codes unless the step has a 'share'
    column. Mass on codes with no successor is dropped and each SIC is renormalized; the
    returned Series gives the share of each SIC's weight that was lost.
    """
    links = step[["src", "dst"] + (["share"] if "share" in step else [])].drop_duplicates(["src", "dst"]).copy()
    if "share" not in links:
        links["share"] = 1 / links.groupby("src")["dst"].transform("count")
    merged = prior.merge(links, left_on="naics", right_on="src")
    merged["weight"] = merged["weight"] * merged["share"]
    keys = ["sic", "dst"] + [c for c in ("source", "quality") if c in prior]
    out = merged.groupby(keys, as_index=False)["weight"].sum().rename(columns={"dst": "naics"})
    before = prior.groupby("sic")["weight"].sum()
    after = out.groupby("sic")["weight"].sum().reindex(before.index, fill_value=0)
    out["weight"] = out["weight"] / out.groupby("sic")["weight"].transform("sum")
    return out, (1 - after / before).rename("lost_share")


def build_priors(links: pd.DataFrame, bridge=None, bridge_step=None, bls=None,
                 restrict_to_concordance=True, min_retained=0.5) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Choose one prior per SIC at NAICS 2002, in order bridge > bls > equal.

    links: Census SIC -> NAICS 2002 concordance (sic, naics).
    bridge: output of weights_from_bridge (NAICS 1997); bridge_step: 1997 -> 2002 concordance.
    bls: output of weights_from_bls (NAICS 2002).
    With restrict_to_concordance, links outside the concordance (for example BLS auxiliary
    'managing offices') are dropped. A source is used only if it keeps at least min_retained
    of its mass after that, so a SIC never takes weights that mostly fall elsewhere.
    Returns (prior, audit).
    """
    links = links[["sic", "naics"]].drop_duplicates()
    allowed = set(map(tuple, links.to_numpy()))
    equal = links.assign(weight=1 / links.groupby("sic")["naics"].transform("count"), source="equal", quality="equal")

    sources = []
    if bridge is not None and len(bridge):
        if bridge_step is None:
            raise ValueError("bridge weights are NAICS 1997 and need the 1997 -> 2002 concordance")
        sources.append(propagate(bridge, bridge_step)[0])
    if bls is not None and len(bls):
        direct = bls[~bls["is_group"]]
        groups = bls[bls["is_group"]]
        expanded = [direct[PRIOR_COLUMNS]]
        have = set(direct["sic"])
        for group_sic, group in groups.groupby("sic"):
            members = sorted({s for s in links["sic"] if s[:3] == group_sic[:3] and s not in have})
            expanded += [group[PRIOR_COLUMNS].assign(sic=m, quality="group_series") for m in members]
        sources.append(pd.concat(expanded, ignore_index=True))

    chosen, audit = {}, []
    for frame in sources:
        for sic, group in frame.groupby("sic"):
            if sic in chosen:
                continue
            kept = group[[(sic, n) in allowed for n in group["naics"]]] if restrict_to_concordance else group
            retained = kept["weight"].sum()
            if retained < min_retained:
                audit.append((sic, group["source"].iloc[0], "rejected", float(retained)))
                continue
            chosen[sic] = kept.assign(weight=kept["weight"] / retained)
            audit.append((sic, group["source"].iloc[0], "used", float(retained)))
    for sic, group in equal.groupby("sic"):
        if sic not in chosen:
            chosen[sic] = group
            audit.append((sic, "equal", "used", 1.0))
    prior = pd.concat(chosen.values(), ignore_index=True)[PRIOR_COLUMNS]
    return prior, pd.DataFrame(audit, columns=["sic", "source", "status", "retained_share"])
