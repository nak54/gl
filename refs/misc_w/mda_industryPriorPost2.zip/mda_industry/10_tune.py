#!/usr/bin/env python
"""Tune --alpha and --floor (script 05) and --tau (script 06) on hand labels.

Stage 1 (seconds): reuse the out-of-fold probabilities saved by script 05 and the 6-digit
candidate similarities saved by script 06, and recompute the posterior for every grid setting.
Stage 2 (--confirm): alpha and floor also change relabeling in script 05, so stage 1 is an
approximation. --confirm reruns 05 and 06 with the chosen setting in a copy of the workdir and
reports the real result next to the stage 1 estimate.

Companies (CIKs) are split into tuning and holdout sets. Settings are chosen on tuning filings
only. The holdout is scored once, for prior-only, text-only and the chosen setting.

Selection: the setting with the best weighted accuracy on split-SIC filings, unless a setting
closer to the defaults (alpha=1, floor=0.01, larger tau) is not significantly worse in a paired
bootstrap over companies.

Gold file: the completed validation_sheet.csv, or any CSV with accession, gold_naics3 and
optionally gold_naics6. Sampling weights come from validation_key.csv; rows not in the key get 1.
"""
from __future__ import annotations
import argparse, json, shutil, subprocess, sys
from pathlib import Path
import numpy as np
import pandas as pd
from posterior import apply_temperature, constrained_posterior, parse_dist

HERE = Path(__file__).resolve().parent
ALPHAS = [0.0, 0.25, 0.5, 1.0, 1.5, 2.0]
FLOORS = [0.001, 0.01, 0.05]
EPS = 1e-6


def load_gold(gold_path: Path, key_path: Path | None) -> pd.DataFrame:
    gold = pd.read_csv(gold_path, dtype=str)
    if "gold_naics3" not in gold:
        raise SystemExit(f"{gold_path} needs a gold_naics3 column")
    gold["gold_naics3"] = gold["gold_naics3"].str.strip().str[:3]
    gold["gold_naics6"] = gold["gold_naics6"].str.strip() if "gold_naics6" in gold else np.nan
    gold = gold.dropna(subset=["gold_naics3"])
    gold = gold[gold["gold_naics3"].str.fullmatch(r"\d{3}")]
    weights = pd.Series(1.0, index=gold.index)
    if key_path and key_path.exists():
        key = pd.read_csv(key_path, dtype={"accession": str}).set_index("accession")["sampling_weight"]
        weights = gold["accession"].map(key).fillna(1.0)
    return gold.assign(sampling_weight=weights.astype(float))[["accession", "gold_naics3", "gold_naics6", "sampling_weight"]]


def cik_split(ciks, holdout: float, seed: int) -> set:
    unique = np.array(sorted(set(ciks)))
    rng = np.random.default_rng(seed)
    return set(rng.permutation(unique)[: int(round(len(unique) * holdout))])


def weighted_accuracy(correct, weights) -> float:
    return float(np.average(correct, weights=weights)) if len(correct) else float("nan")


def paired_bootstrap(correct: np.ndarray, weights: np.ndarray, clusters: np.ndarray, n: int, seed: int) -> np.ndarray:
    """Accuracy of each setting (columns of correct) in n company-cluster bootstrap resamples."""
    codes, cluster_index = np.unique(clusters, return_inverse=True)
    sums = np.zeros((len(codes), correct.shape[1]))
    np.add.at(sums, cluster_index, correct * weights[:, None])
    totals = np.bincount(cluster_index, weights=weights, minlength=len(codes))
    counts = np.random.default_rng(seed).multinomial(len(codes), np.full(len(codes), 1 / len(codes)), size=n)
    return (counts @ sums) / np.maximum(counts @ totals, EPS)[:, None]


def choose(grid: pd.DataFrame, boot: np.ndarray, preference) -> tuple[int, np.ndarray]:
    """Best point estimate, then the most preferred setting not significantly worse than it."""
    best = int(grid["accuracy"].to_numpy().argmax())
    upper = np.percentile(boot - boot[:, [best]], 97.5, axis=0)
    tied = np.where(upper >= 0)[0]
    pick = min(tied, key=lambda j: preference(grid.iloc[j]))
    return int(pick), upper


def tune_naics3(gold, filings, oof, predictions, tuning_mask, args):
    P3, PI, classes = oof["P3"], oof["PI"], [str(c) for c in oof["classes"]]
    P3c = apply_temperature(P3, float(oof["temperature"]))
    position = {a: i for i, a in enumerate(oof["accession"])}
    rows = gold.merge(filings[["accession", "cik", "split_sic", "naics3_prior"]], on="accession")
    rows = rows.merge(predictions[["accession", "naics3_pred", "sic_suspect"]], on="accession")
    rows = rows[rows["accession"].isin(position)].reset_index(drop=True)
    idx = rows["accession"].map(position).to_numpy()
    priors = [parse_dist(x) for x in rows["naics3_prior"]]
    p, pi = P3c[idx], PI[idx]
    rows["tuning"] = rows["cik"].isin(tuning_mask)
    rows["gold_in_candidates"] = [g in pr for g, pr in zip(rows["gold_naics3"], priors)]
    rows["prior_top"] = [max(pr, key=pr.get) if pr else None for pr in priors]

    settings = [(a, f) for a in ALPHAS for f in FLOORS]
    choices, gold_prob = [], []
    for alpha, floor in settings:
        posts = constrained_posterior(p, pi, classes, priors, alpha=alpha, floor=floor)
        choices.append([max(d, key=d.get) if d else None for d in posts])
        gold_prob.append([d.get(g, 0.0) for d, g in zip(posts, rows["gold_naics3"])])
    choices, gold_prob = np.array(choices, dtype=object).T, np.array(gold_prob).T
    correct = choices == rows["gold_naics3"].to_numpy()[:, None]

    split = rows["split_sic"].to_numpy(bool)
    tune_split = split & rows["tuning"].to_numpy()
    hold_split = split & ~rows["tuning"].to_numpy()
    w = rows["sampling_weight"].to_numpy()
    ll_mask = tune_split & rows["gold_in_candidates"].to_numpy()
    grid = pd.DataFrame(settings, columns=["alpha", "floor"])
    grid["accuracy"] = [weighted_accuracy(correct[tune_split, j], w[tune_split]) for j in range(len(settings))]
    grid["log_loss"] = [float(np.average(-np.log(np.maximum(gold_prob[ll_mask, j], EPS)), weights=w[ll_mask])) if ll_mask.any() else np.nan
                        for j in range(len(settings))]
    final = np.where(rows["sic_suspect"].to_numpy(bool)[:, None], rows["naics3_pred"].to_numpy()[:, None], choices)
    tune_all = rows["tuning"].to_numpy()
    grid["final_accuracy_all_tuning"] = [weighted_accuracy(final[tune_all, j] == rows["gold_naics3"].to_numpy()[tune_all], w[tune_all])
                                         for j in range(len(settings))]

    report = {"labeled_rows": int(len(rows)), "tuning_split_rows": int(tune_split.sum()), "holdout_split_rows": int(hold_split.sum()),
              "gold_outside_sic_candidates_share": float(np.average(~rows.loc[split, "gold_in_candidates"], weights=w[split])) if split.any() else None}
    if tune_split.sum() < args.min_rows:
        report["skipped"] = f"only {tune_split.sum()} split-SIC tuning rows; need {args.min_rows}. Label more split-SIC filings."
        return grid, report, None
    if tune_split.sum() < 50:
        report["warning"] = "Fewer than 50 split-SIC tuning rows: confidence intervals will be wide."

    boot = paired_bootstrap(correct[tune_split].astype(float), w[tune_split], rows.loc[tune_split, "cik"].to_numpy(), args.bootstrap, args.seed)
    grid["ci_low"], grid["ci_high"] = np.percentile(boot, 2.5, axis=0), np.percentile(boot, 97.5, axis=0)
    pick, upper = choose(grid, boot, lambda r: (abs(r["alpha"] - 1.0), abs(np.log10(r["floor"] / 0.01)), r["log_loss"]))
    grid["not_worse_than_best"] = upper >= 0
    chosen = grid.iloc[pick]

    text_only = settings.index((0.0, 0.01))
    prior_correct = (rows["prior_top"] == rows["gold_naics3"]).to_numpy()
    def score(mask):
        return {"prior_only": weighted_accuracy(prior_correct[mask], w[mask]),
                "text_only_alpha0": weighted_accuracy(correct[mask, text_only], w[mask]),
                "chosen": weighted_accuracy(correct[mask, pick], w[mask]),
                "n": int(mask.sum())}
    report.update({"chosen": {"alpha": float(chosen["alpha"]), "floor": float(chosen["floor"])},
                   "best_point_estimate": grid.iloc[int(grid["accuracy"].to_numpy().argmax())][["alpha", "floor", "accuracy"]].to_dict(),
                   "tuning_split": score(tune_split), "holdout_split": score(hold_split) if hold_split.any() else None})
    return grid, report, (float(chosen["alpha"]), float(chosen["floor"]))


def tune_naics6(gold, filings, candidates, tuning_mask, alpha, floor, args):
    rows = gold.dropna(subset=["gold_naics6"]).merge(candidates, on="accession").merge(filings[["accession", "cik"]], on="accession")
    rows = rows[rows["gold_naics6"].str.fullmatch(r"\d{6}") & (rows["target_naics3"] == rows["gold_naics6"].str[:3])]
    rows = rows[rows["codes"].str.count(";") >= 1].reset_index(drop=True)
    report = {"rows": int(len(rows))}
    if rows.empty:
        report["skipped"] = "No labeled filings with gold_naics6 and two or more 6-digit candidates under the right NAICS3."
        return pd.DataFrame(), report, None
    codes = [c.split(";") for c in rows["codes"]]
    priors = [np.array(x.split(";"), float) for x in rows["prior"]]
    sims = [np.array(x.split(";"), float) for x in rows["similarity"]]
    gaps = [np.sort(s)[-1] - np.sort(s)[-2] for s in sims]
    tau0 = max(float(np.median(gaps)) / 1.5, 1e-3)
    taus = sorted({round(tau0 * m, 6) for m in (0.25, 0.5, 1, 2, 4, 8)} | {args.current_tau})
    rows["tuning"] = rows["cik"].isin(tuning_mask)
    gold6 = rows["gold_naics6"].to_numpy()

    def pick_codes(tau, a):
        out = []
        for c, pr, s in zip(codes, priors, sims):
            logits = s / tau
            score = np.maximum(pr, floor) ** a * np.exp(logits - logits.max())
            out.append(c[int(np.argmax(score))])
        return np.array(out)

    correct = np.column_stack([pick_codes(t, alpha) == gold6 for t in taus])
    w = rows["sampling_weight"].to_numpy()
    tune, hold = rows["tuning"].to_numpy(), ~rows["tuning"].to_numpy()
    grid = pd.DataFrame({"tau": taus, "accuracy": [weighted_accuracy(correct[tune, j], w[tune]) for j in range(len(taus))]})
    report.update({"tuning_rows": int(tune.sum()), "holdout_rows": int(hold.sum()), "tau_start_estimate": tau0})
    if tune.sum() < args.min_rows:
        report["skipped"] = f"only {tune.sum()} 6-digit tuning rows; need {args.min_rows}."
        return grid, report, None
    boot = paired_bootstrap(correct[tune].astype(float), w[tune], rows.loc[tune, "cik"].to_numpy(), args.bootstrap, args.seed)
    grid["ci_low"], grid["ci_high"] = np.percentile(boot, 2.5, axis=0), np.percentile(boot, 97.5, axis=0)
    pick, upper = choose(grid, boot, lambda r: -r["tau"])        # larger tau leans on the prior: more conservative
    grid["not_worse_than_best"] = upper >= 0
    tau = float(grid.iloc[pick]["tau"])
    prior_correct = np.array([c[int(np.argmax(pr))] for c, pr in zip(codes, priors)]) == gold6
    text_correct = np.array([c[int(np.argmax(s))] for c, s in zip(codes, sims)]) == gold6
    def score(mask):
        return {"prior_only": weighted_accuracy(prior_correct[mask], w[mask]), "text_only": weighted_accuracy(text_correct[mask], w[mask]),
                "chosen": weighted_accuracy(correct[mask, pick], w[mask]), "n": int(mask.sum())}
    report.update({"chosen_tau": tau, "tuning": score(tune), "holdout": score(hold) if hold.any() else None})
    return grid, report, tau


def confirm(args, alpha, floor, tau, gold, filings, tuning_mask):
    """Rerun 05 and 06 with the chosen setting in a copy of the workdir and score the real output."""
    target = args.workdir.with_name(args.workdir.name + "_tune_confirm")
    shutil.rmtree(target, ignore_errors=True)
    shutil.copytree(args.workdir, target)
    subprocess.run([sys.executable, str(HERE / "05_train_classifier.py"), "--workdir", str(target), "--alpha", str(alpha), "--floor", str(floor)],
                   check=True, stdout=subprocess.DEVNULL)
    tau_args = ["--tau", str(tau)] if tau is not None else []
    subprocess.run([sys.executable, str(HERE / "06_rank_sic.py"), "--workdir", str(target), "--alpha", str(alpha), "--floor", str(floor)] + tau_args,
                   check=True, stdout=subprocess.DEVNULL)
    pred = pd.read_parquet(target / "predictions_oof.parquet")
    rows = gold.merge(pred[["accession", "cik", "split_sic", "naics3_constrained", "naics6_pred"]], on="accession")
    out = {"workdir": str(target)}
    for name, mask in (("tuning", rows["cik"].isin(tuning_mask)), ("holdout", ~rows["cik"].isin(tuning_mask))):
        part = rows[mask & rows["split_sic"]]
        out[f"{name}_split_accuracy"] = weighted_accuracy((part["naics3_constrained"] == part["gold_naics3"]).to_numpy(), part["sampling_weight"]) if len(part) else None
        g6 = rows[mask & rows["gold_naics6"].notna()]
        out[f"{name}_naics6_accuracy"] = weighted_accuracy((g6["naics6_pred"] == g6["gold_naics6"]).to_numpy(), g6["sampling_weight"]) if len(g6) else None
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--workdir", type=Path, default=Path("work"))
    parser.add_argument("--gold", type=Path, required=True, help="Completed validation_sheet.csv or similar")
    parser.add_argument("--key", type=Path, help="validation_key.csv with sampling weights (default: workdir/validation_key.csv)")
    parser.add_argument("--holdout", type=float, default=0.3, help="Share of labeled companies held out")
    parser.add_argument("--bootstrap", type=int, default=1000)
    parser.add_argument("--min-rows", type=int, default=15, help="Minimum tuning rows needed to tune at all")
    parser.add_argument("--current-tau", type=float, default=0.05, help="Tau used in the last 06 run; always included in the grid")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--confirm", action="store_true", help="Rerun 05 and 06 with the chosen setting and score it")
    args = parser.parse_args()

    filings = pd.read_parquet(args.workdir / "filings.parquet")
    predictions = pd.read_parquet(args.workdir / "predictions_oof.parquet")
    oof_path, cand_path = args.workdir / "oof_probs.npz", args.workdir / "naics6_candidates.parquet"
    if not oof_path.exists() or not cand_path.exists():
        raise SystemExit("Missing oof_probs.npz or naics6_candidates.parquet: rerun scripts 05 and 06 with the current version.")
    oof = np.load(oof_path, allow_pickle=False)
    gold = load_gold(args.gold, args.key or args.workdir / "validation_key.csv")
    gold = gold[gold["accession"].isin(filings["accession"])]
    labeled_ciks = filings.loc[filings["accession"].isin(gold["accession"]), "cik"]
    holdout = cik_split(labeled_ciks, args.holdout, args.seed)
    tuning_ciks = set(labeled_ciks) - holdout

    grid3, report3, chosen = tune_naics3(gold, filings, oof, predictions, tuning_ciks, args)
    alpha, floor = chosen if chosen else (1.0, 0.01)
    grid6, report6, tau = tune_naics6(gold, filings, pd.read_parquet(cand_path), tuning_ciks, alpha, floor, args)
    report = {"tuning_companies": len(tuning_ciks), "holdout_companies": len(holdout), "naics3": report3, "naics6": report6,
              "note": "Stage 1 holds the out-of-fold probabilities fixed. Use --confirm for the full rerun."}
    if args.confirm and chosen:
        report["confirm"] = confirm(args, alpha, floor, tau, gold, filings, tuning_ciks)

    grid3.to_csv(args.workdir / "tune_grid_naics3.csv", index=False)
    grid6.to_csv(args.workdir / "tune_grid_naics6.csv", index=False)
    (args.workdir / "tune_report.json").write_text(json.dumps(report, indent=2, default=float))
    pd.set_option("display.width", 160)
    print("NAICS3 grid (split-SIC tuning filings):")
    print(grid3.round(3).to_string(index=False))
    if len(grid6):
        print("\n6-digit grid:")
        print(grid6.round(4).to_string(index=False))
    print("\n" + json.dumps(report, indent=2, default=lambda x: round(float(x), 4)))
    if chosen:
        tau_text = f" --tau {tau:g}" if tau is not None else ""
        print(f"\nApply with:\n  python 05_train_classifier.py --workdir {args.workdir} --alpha {alpha:g} --floor {floor:g}"
              f"\n  python 06_rank_sic.py --workdir {args.workdir} --alpha {alpha:g} --floor {floor:g}{tau_text}")


if __name__ == "__main__":
    main()
