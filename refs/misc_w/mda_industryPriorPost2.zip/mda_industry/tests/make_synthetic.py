#!/usr/bin/env python
"""Generate fake reference files, filings and truth for end-to-end tests.

Scenarios with known truth:
  * 10 single-link industries; every 13th company files a wrong SIC (miscoded).
  * SIC 1099 splits across NAICS3 212 and 213. The BLS-style prior is 71/29, but 40% of these
    companies are really 213, so the prior's top code alone is right only 60% of the time.
  * SIC 2035 splits within NAICS3 311 across 311421 / 311941 / 311999. The Bridge-style prior is
    21/79/0.03, but companies are 50/50 between the first two, so 6-digit choice must use the text.
  * 12 SIC 1099 companies have only generic text; the posterior should fall back to the prior (212).
  * Anchor companies (SIC 1021 -> 212, SIC 1081 -> 213) give the classifier clean examples.
  * Shell companies (SIC 6770) are excluded from training.
"""
import sys
from pathlib import Path
import numpy as np
import pandas as pd

root = Path(sys.argv[1])
ref = root / "reference_files"
ref.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(7)

# NAICS3 key: (NAICS 2002 6-digit, [(SIC, SEC title)], vocabulary)
IND = {
    "513": ("511210", [("7372", "SERVICES-PREPACKAGED SOFTWARE")], "software subscription cloud platform licenses developers saas application"),
    "334": ("334413", [("3674", "SEMICONDUCTORS & RELATED DEVICES")], "semiconductor wafer chips fabrication foundry integrated circuits"),
    "325": ("325412", [("2834", "PHARMACEUTICAL PREPARATIONS")], "drug clinical trials fda therapeutic oncology patients pharmaceutical"),
    "522": ("522110", [("6021", "NATIONAL COMMERCIAL BANKS")], "deposits loans branches net interest margin borrowers mortgage"),
    "211": ("211111", [("1311", "CRUDE PETROLEUM & NATURAL GAS")], "crude oil natural gas wells barrels reserves permian"),
    "221": ("221122", [("4911", "ELECTRIC SERVICES")], "electric utility ratepayers transmission generation regulators grid"),
    "481": ("481111", [("4512", "AIR TRANSPORTATION, SCHEDULED")], "airline passengers aircraft flights seat miles fleet routes"),
    "455": ("452111", [("5311", "RETAIL-DEPARTMENT STORES")], "stores shoppers merchandise apparel comparable store sales retail"),
    "336": ("336111", [("3711", "MOTOR VEHICLES & PASSENGER CAR BODIES")], "vehicles trucks dealers automotive assembly plants electric vehicle"),
    "622": ("622110", [("8062", "SERVICES-GENERAL MEDICAL & SURGICAL HOSPITALS")], "hospitals admissions physicians inpatient medicare surgical beds"),
}
VOCAB6 = {
    "212234": "ore copper mine mill tonnes grade concentrate smelter pit",
    "213114": "contractor services rigs clients daywork utilization crews backlog",
    "311421": "fruit vegetable canning canned harvest growers cans peaches",
    "311941": "mayonnaise dressing sauce condiments salad ketchup jars",
}
TITLES6 = {
    "212234": "Copper and Nickel Ore Mining",
    "213114": "Support Activities for Metal Mining contractor services",
    "311421": "Fruit and Vegetable Canning",
    "311941": "Mayonnaise, Dressing, and Other Prepared Sauce Manufacturing",
    "311999": "All Other Miscellaneous Food Manufacturing",
}
GENERIC = "management believes results reflect market conditions customers growth costs".split()

sic_links = [(s, n[0]) for n in IND.values() for s, _ in n[1]]
sic_links += [("7371", "541511"), ("8099", "621999"), ("1021", "212234"), ("1081", "213114"),
              ("1099", "212234"), ("1099", "213114"), ("2035", "311421"), ("2035", "311941"), ("2035", "311999")]
head = [["Census concordance", None, None, None], [None] * 4]


def write(path, header, rows):
    pd.DataFrame(head + [header] + rows).to_excel(path, header=False, index=False)


write(ref / "sic1987_to_naics2002.xlsx", ["1987 SIC", "SIC Title", "2002 NAICS", "NAICS Title"],
      [[int(a), "t", int(b), "t"] for a, b in sic_links] + [["Aux", "x", 999999, "x"]])
codes = sorted({b for _, b in sic_links})
renumber = {"511210": "513210", "452111": "455110"}
write(ref / "naics1997_to_naics2002.xlsx", ["1997 NAICS", "1997 Title", "2002 NAICS", "2002 Title"], [[int(c), "t", int(c), "t"] for c in codes])
for src, dst in [(2002, 2007), (2007, 2012), (2012, 2017)]:
    write(ref / f"naics{src}_to_naics{dst}.xlsx", [f"{src} NAICS Code", f"{src} Title", f"{dst} NAICS Code", f"{dst} Title"],
          [[int(c), "t", int(c), "t"] for c in codes])
write(ref / "naics2017_to_naics2022.xlsx", ["2022 NAICS Code", "2022 Title", "2017 NAICS Code", "2017 Title"],  # reversed direction
      [[int(renumber.get(c, c)), TITLES6.get(c, "Title " + renumber.get(c, c)), int(c), "t"] for c in codes])
titles = [[k, v[2].split()[0].title() + " Industry"] for k, v in IND.items()]
titles += [["541", "Professional Services"], ["621", "Ambulatory Care"], ["212", "Mining except Oil"], ["213", "Support Activities for Mining"],
           ["311", "Food Manufacturing"]] + [[c, t] for c, t in TITLES6.items()]
pd.DataFrame([["Seq", "Code", "Title"]] + [[i, c, t + "T"] for i, (c, t) in enumerate(titles)]).to_excel(ref / "naics2022_codes.xlsx", header=False, index=False)
sec = [(s, t) for n in IND.values() for s, t in n[1]] + [
    ("7370", "SERVICES-COMPUTER PROGRAMMING, DATA PROCESSING"), ("6770", "BLANK CHECKS"), ("1021", "COPPER ORES"),
    ("1081", "METAL MINING SERVICES"), ("1099", "MISCELLANEOUS METAL ORES"), ("2035", "PICKLED FRUITS, VEGETABLES, SAUCES")]
pd.DataFrame(sec, columns=["SIC Code", "Industry Title"]).to_csv(ref / "sec_sic_list.csv", index=False)

# Census Bridge (NAICS 1997), SIC 2035 published figures; 311999 piece suppressed with a range.
pd.DataFrame({"SIC": ["2035", "2035", "2035"], "NAICS": ["311421", "311941", "311999"],
              "shipments": ["1,470,495", "5,583,554", "D (1000-2499)"], "employees": ["7,935", "12,681", "D"],
              "establishments": ["129", "225", "3"]}).to_csv(ref / "census_bridge_sic_naics1997.csv", index=False)
# BLS CES ratios: 1099 uses a combined series (212200) and an auxiliary link outside the concordance.
# The 2035 rows must lose to the Bridge.
bls = [("10-1099", "10-212200", 70.0), ("10-1099", "10-213114", 28.0), ("10-1099", "60-551114", 2.0),
       ("30-2035", "30-311421", 50.0), ("30-2035", "30-311941", 50.0)]
rows_html = "".join(f"<tr><td>{s}</td><td>x</td><td>{n}</td><td>y</td><td>{r}</td></tr>" for s, n, r in bls)
(ref / "bls_sic_naics2002_ratios.html").write_text(
    "<html><body><table><tr><th>CES SIC Tabulating Code</th><th>SIC Industry</th><th>CES NAICS Tabulating Code</th>"
    f"<th>NAICS Industry</th><th>SIC to NAICS Employment Ratio</th></tr>{rows_html}</table></body></html>")


def paragraph(vocab, n=120):
    words = list(rng.choice(vocab.split(), n // 3)) + list(rng.choice(GENERIC, n - n // 3))
    return "Text " + " ".join(words) + "."


def doc(vocab, second_vocab, flat, single_seg=False):
    sep = " " if flat else "\n"
    parts = ["Overview", paragraph(vocab), "Results of Operations", paragraph(vocab)]
    if second_vocab:
        parts += ["Segment Results", paragraph(second_vocab), paragraph(vocab)]
    elif single_seg:
        parts += ["Segment Results", paragraph(vocab), paragraph(vocab)]
    parts += ["Liquidity and Capital Resources", "POISON Text " + paragraph("covenant revolver credit facility"),
              "Critical Accounting Policies", "POISON Text " + paragraph("goodwill impairment estimates")]
    return sep.join(parts)


rows, truth = [], []
keys = list(IND)


def add(c, sic, vocab, true3, true6="", miscoded=False, second="", second_vocab=None, scenario="single", years=(2019, 2024, 2025)):
    for y in years:
        rows.append((f"{c:010d}-{y}", f"{c:010d}", y, int(sic), f"Co{c}", doc(vocab, second_vocab, c % 2 == 0, c % 5 == 0)))
        truth.append((f"{c:010d}-{y}", true3, true6, miscoded, second, scenario))


for c in range(1, 241):
    true = keys[c % len(keys)]
    miscoded = c % 13 == 0
    filed = keys[(c + 3) % len(keys)] if miscoded else true
    filed_sic = IND[filed][1][0][0]
    if filed == "513" and c % 20 == 0:
        filed_sic = "7370"                      # SEC group code: exercises prefix fallback
    second = keys[(c + 1) % len(keys)] if c % 7 == 0 else ""
    add(c, filed_sic, IND[true][2], true, miscoded=miscoded, second=second,
        second_vocab=IND[second][2] if second else None, scenario="miscoded" if miscoded else "single")
for c in range(401, 416):
    add(c, "1021", VOCAB6["212234"], "212", "212234", scenario="anchor")
for c in range(416, 431):
    add(c, "1081", VOCAB6["213114"], "213", "213114", scenario="anchor")
for c in range(431, 481):
    code = "212234" if c % 5 in (0, 1, 2) else "213114"
    add(c, "1099", VOCAB6[code], code[:3], code, scenario="split_naics3")
for c in range(521, 533):
    add(c, "1099", " ".join(GENERIC), "212", scenario="split_weak_text")   # no industry words: prior should decide
for c in range(481, 521):
    code = "311421" if c % 2 == 0 else "311941"
    add(c, "2035", VOCAB6[code], "311", code, scenario="split_naics6")
for c in range(300, 306):
    add(c, "6770", "trust account business combination sponsor", "523", scenario="shell", years=(2024,))

pd.DataFrame(rows, columns=["accession", "cik", "year", "sic", "company", "mda_text"]).to_parquet(root / "filings_in.parquet")
pd.DataFrame(truth, columns=["accession", "true_naics3", "true_naics6", "miscoded", "second", "scenario"]).to_parquet(root / "truth.parquet")
