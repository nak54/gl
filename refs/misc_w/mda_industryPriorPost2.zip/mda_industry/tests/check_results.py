#!/usr/bin/env python
"""Assertions on a synthetic run against planted truth, plus simulated gold labels for 09_validate.py."""
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd

root = Path(sys.argv[1])
w = root / "work"
out = pd.read_parquet(w / "industry_labels.parquet")
truth = pd.read_parquet(root / "truth.parquet")
chunks = pd.read_parquet(w / "chunks.parquet")
filings = pd.read_parquet(w / "filings.parquet")
xwalk = pd.read_parquet(w / "ref/sic_xwalk_resolved.parquet")
d = out.merge(truth, on="accession")
e = d[~d.excluded_sic]
results = {}


def check(name, value, ok):
    results[name] = round(float(value), 3) if not isinstance(value, str) else value
    assert ok, f"FAILED {name}: {value}"


# Text filtering and crosswalk mechanics
check("no dropped sections in chunks", 1.0 - chunks.text.str.contains("POISON").mean(), not chunks.text.str.contains("POISON").any())
check("7370 group code resolved by prefix", float((out.loc[out.sic_sec == "7370", "match_level"] == "prefix3").all()),
      (out.loc[out.sic_sec == "7370", "match_level"] == "prefix3").all())
check("NAICS vintage renumbered 511->513", float("513" in set(out.naics3_pred)), "513" in set(out.naics3_pred) and "511" not in set(out.naics3_pred))

# Prior sources and weights
src = out.groupby("sic_sec")["prior_source"].first()
check("2035 prior from Bridge", src["2035"], src["2035"] == "bridge_shipments")
check("1099 prior from BLS", src["1099"], src["1099"] == "bls_employment")
check("7372 prior equal", src["7372"], src["7372"] == "equal")
w2035 = xwalk[xwalk.sic == "2035"].set_index("naics6")["weight"]
check("2035 Bridge share 311941", w2035["311941"], abs(w2035["311941"] - 5583554 / (1470495 + 5583554 + 1749.5)) < 1e-6)
w1099 = xwalk[xwalk.sic == "1099"].set_index("naics6")["weight"]
check("1099 BLS share 212234 (rescaled, auxiliary dropped)", w1099["212234"], abs(w1099["212234"] - 70 / 98) < 1e-6 and "551114" not in w1099)

# Split across NAICS3: the posterior must beat the prior's top code
s3 = e[e.scenario == "split_naics3"]
prior_acc = (s3.naics3_prior_top == s3.true_naics3).mean()
post_acc = (s3.naics3_constrained == s3.true_naics3).mean()
check("split SIC 1099: prior-top accuracy", prior_acc, abs(prior_acc - 0.6) < 0.01)
check("split SIC 1099: posterior accuracy", post_acc, post_acc >= 0.9 and post_acc > prior_acc + 0.25)
minority = s3[s3.true_naics3 == "213"]
check("split SIC 1099: minority piece recovered", (minority.naics3_constrained == "213").mean(), (minority.naics3_constrained == "213").mean() >= 0.85)
check("split SIC 1099: not flagged suspect", s3.sic_suspect.mean(), s3.sic_suspect.mean() < 0.05)

# Uninformative text: the posterior should fall back to the prior rather than flag a suspect SIC
weak = e[e.scenario == "split_weak_text"]
check("weak text: posterior follows prior top", (weak.naics3_constrained == "212").mean(), (weak.naics3_constrained == "212").mean() >= 0.9)
check("weak text: not flagged suspect", weak.sic_suspect.mean(), weak.sic_suspect.mean() <= 0.1)
check("weak text: confidence stays near prior (0.71)", weak.constrained_conf.mean(), 0.5 <= weak.constrained_conf.mean() <= 0.95)

# Split within NAICS3: 6-digit choice from embeddings x Bridge prior
s6 = e[e.scenario == "split_naics6"]
prior6 = (s6.true_naics6 == "311941").mean()
acc6 = (s6.naics6_final == s6.true_naics6).mean()
check("split SIC 2035: prior-top 6-digit accuracy", prior6, abs(prior6 - 0.5) < 0.01)
check("split SIC 2035: posterior 6-digit accuracy", acc6, acc6 >= 0.85)
check("split SIC 2035: never picks suppressed tiny piece", (s6.naics6_final == "311999").mean(), (s6.naics6_final == "311999").mean() == 0)
check("split SIC 2035: NAICS3 stays 311", (s6.naics3_final == "311").mean(), (s6.naics3_final == "311").mean() >= 0.95)

# Wrong SICs: flagged and corrected by the unconstrained model
m = e[e.miscoded]
check("miscoded flagged sic_suspect", m.sic_suspect.mean(), m.sic_suspect.mean() >= 0.8)
check("miscoded corrected in final", (m.naics3_final == m.true_naics3).mean(), (m.naics3_final == m.true_naics3).mean() >= 0.8)
clean = e[(e.scenario == "single") & ~e.miscoded]
check("clean single-link false suspect rate", clean.sic_suspect.mean(), clean.sic_suspect.mean() < 0.05)
check("clean single-link posterior = SIC code", (clean.naics3_constrained == clean.true_naics3).mean(),
      (clean.naics3_constrained == clean.true_naics3).mean() >= 0.95)

# Overall
overall = (e.naics3_final == e.true_naics3).mean()
check("overall final NAICS3 accuracy", overall, overall >= 0.93)
sec = e[e.second != ""]
recall = np.mean([s in x.split(";") for s, x in zip(sec.second, sec.naics3_secondary)])
check("secondary industry recall", recall, recall > 0.7)
assert set(out.loc[out.excluded_sic, "review_reason"]) == {""}
metrics = json.loads((w / "metrics.json").read_text())
results["relabel history"] = [{k: round(v, 4) if isinstance(v, float) else v for k, v in h.items()} for h in metrics["relabel_history"]]

key = pd.read_csv(w / "validation_key.csv", dtype={"accession": str})
gold = key.merge(truth, on="accession")[["accession", "true_naics3", "true_naics6"]]
gold.rename(columns={"true_naics3": "gold_naics3", "true_naics6": "gold_naics6"}).replace("", np.nan).to_csv(w / "gold_simulated.csv", index=False)
print(json.dumps(results, indent=1))
print("checks passed")
