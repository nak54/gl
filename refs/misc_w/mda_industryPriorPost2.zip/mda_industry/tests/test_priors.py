"""Unit tests for economic priors. Figures for SIC 2035, 2077 and 1099 are the published Census and BLS values."""
import numpy as np
import pandas as pd
import pytest
from priors import build_priors, parse_value, propagate, read_bls_ratios, weights_from_bls, weights_from_bridge
from common import resolve_xwalk


def as_dict(frame, sic):
    sub = frame[frame["sic"] == sic]
    return dict(zip(sub["naics"], sub["weight"]))


@pytest.mark.parametrize("cell, value, quality", [
    ("1,470,495", 1470495.0, "exact"),
    ("D (10k-24999)", 17499.5, "range_mid"),
    ("D (1000-2499)", 1749.5, "range_mid"),
    ("D (1-19)", 10.0, "range_mid"),
    ("0", 0.0, "exact"),
    (225, 225.0, "exact"),
])
def test_parse_value(cell, value, quality):
    assert parse_value(cell) == (pytest.approx(value), quality)


@pytest.mark.parametrize("cell", ["D", "", None, float("nan"), "S"])
def test_parse_value_missing(cell):
    value, quality = parse_value(cell)
    assert np.isnan(value) and quality == "missing"


def test_bridge_uses_piece_values_not_printed_percent():
    # Census prints "9% of 311421" and "96% of 311941": shares of the NAICS codes, not of SIC 2035.
    bridge = pd.DataFrame({"sic": ["2035", "2035"], "naics": ["311421", "311941"],
                           "shipments": ["1,470,495", "5,583,554"]})
    w = as_dict(weights_from_bridge(bridge), "2035")
    assert w["311421"] == pytest.approx(1470495 / 7054049)   # 0.208
    assert w["311941"] == pytest.approx(5583554 / 7054049)   # 0.792
    assert sum(w.values()) == pytest.approx(1.0)


def test_bridge_drops_zero_links_and_uses_range_midpoints():
    # SIC 2077: the 311225 link exists in the concordance but has no activity.
    bridge = pd.DataFrame({"sic": ["2077"] * 4, "naics": ["311225", "311613", "311711", "311712"],
                           "shipments": ["0", "2,571,871", "8,223", "D (500-999)"]})
    out = weights_from_bridge(bridge)
    w = as_dict(out, "2077")
    assert "311225" not in w
    total = 2571871 + 8223 + 749.5
    assert w["311613"] == pytest.approx(2571871 / total)
    assert w["311712"] == pytest.approx(749.5 / total)
    assert set(out["quality"]) == {"range_mid"}


def test_bridge_falls_back_to_next_measure_when_suppressed_without_range():
    bridge = pd.DataFrame({"sic": ["2087"] * 2, "naics": ["311930", "311942"],
                           "shipments": ["6,590,816", "D"], "employees": ["6,243", "2,981"]})
    out = weights_from_bridge(bridge)
    assert set(out["source"]) == {"bridge_employees"}
    assert as_dict(out, "2087")["311930"] == pytest.approx(6243 / (6243 + 2981))


def test_bridge_sums_multiple_parts_of_same_pair():
    bridge = pd.DataFrame({"sic": ["1111"] * 3, "naics": ["111111", "111111", "222222"], "shipments": ["10", "30", "60"]})
    assert as_dict(weights_from_bridge(bridge), "1111") == pytest.approx({"111111": 0.4, "222222": 0.6})


BLS_1099 = pd.DataFrame({
    "sic_code": ["10-1099"] * 5,
    "naics_code": ["10-212200", "10-213000", "20-238910", "60-551114", "60-541370"],
    "ratio": [66.1, 24.3, 7.2, 1.3, 1.1]})
UNIVERSE = ["212221", "212222", "212234", "213114", "213115", "238910", "551114", "541370"]


def test_bls_expands_combined_series_and_rescales():
    out = weights_from_bls(BLS_1099, UNIVERSE)
    w = as_dict(out, "1099")
    assert sum(w.values()) == pytest.approx(1.0)
    # 212200 covers three 6-digit codes, 213000 covers two; each gets an equal part.
    assert w["212221"] == pytest.approx(66.1 / 3 / 100)
    assert w["213114"] == pytest.approx(24.3 / 2 / 100)
    assert set(out["quality"]) == {"exact"}


def test_bls_rescales_when_small_ratios_omitted():
    frame = pd.DataFrame({"sic_code": ["20-1542"] * 2, "naics_code": ["20-236220", "20-236210"], "ratio": [81.0, 18.1]})
    out = weights_from_bls(frame, ["236210", "236220"])
    assert as_dict(out, "1542")["236220"] == pytest.approx(81 / 99.1)
    assert set(out["quality"]) == {"rescaled"}


def test_read_bls_html(tmp_path):
    html = """<html><body><table>
    <tr><th>CES SIC Tabulating Code</th><th>SIC Industry</th><th>CES NAICS Tabulating Code</th>
        <th>NAICS Industry</th><th>SIC to NAICS Employment Ratio</th></tr>
    <tr><td>20-1542</td><td>Nonresidential building</td><td>20-236220</td><td>Commercial building</td><td>81.0</td></tr>
    <tr><td>20-1542</td><td>Nonresidential building</td><td>20-236210</td><td>Industrial building</td><td>18.1</td></tr>
    </table></body></html>"""
    path = tmp_path / "bls.html"
    path.write_text(html)
    frame = read_bls_ratios(path)
    assert frame["ratio"].tolist() == [81.0, 18.1]
    assert frame["sic_code"].iloc[0] == "20-1542"


def test_propagate_multiplies_and_conserves_mass():
    prior = pd.DataFrame({"sic": ["1099", "1099"], "naics": ["A", "B"], "weight": [0.7, 0.3]})
    step = pd.DataFrame({"src": ["A", "A", "B"], "dst": ["A1", "A2", "B1"]})
    out, lost = propagate(prior, step)
    assert as_dict(out, "1099") == pytest.approx({"A1": 0.35, "A2": 0.35, "B1": 0.3})
    assert lost["1099"] == pytest.approx(0.0)


def test_propagate_uses_explicit_shares_and_reports_lost_mass():
    prior = pd.DataFrame({"sic": ["1", "1"], "naics": ["A", "B"], "weight": [0.8, 0.2]})
    step = pd.DataFrame({"src": ["A", "A"], "dst": ["A1", "A2"], "share": [0.9, 0.1]})
    out, lost = propagate(prior, step)
    assert as_dict(out, "1") == pytest.approx({"A1": 0.9, "A2": 0.1})
    assert lost["1"] == pytest.approx(0.2)


def test_build_priors_precedence_and_restriction():
    links = pd.DataFrame({"sic": ["2035", "2035", "1099", "1099", "7372", "7372"],
                          "naics": ["311421", "311941", "212234", "213114", "511210", "541511"]})
    bridge = pd.DataFrame({"sic": ["2035"] * 2, "naics": ["311421", "311941"], "weight": [0.2, 0.8],
                           "source": "bridge_shipments", "quality": "exact"})
    step97 = pd.DataFrame({"src": ["311421", "311941"], "dst": ["311421", "311941"]})
    bls = weights_from_bls(pd.DataFrame({
        "sic_code": ["2035", "2035", "1099", "1099", "1099"],
        "naics_code": ["311421", "311941", "212200", "213114", "551114"],
        "ratio": [50, 50, 70, 28, 2]}), ["311421", "311941", "212234", "213114", "551114"])
    prior, audit = build_priors(links, bridge, step97, bls)
    assert as_dict(prior, "2035") == pytest.approx({"311421": 0.2, "311941": 0.8})       # bridge beats BLS
    w1099 = as_dict(prior, "1099")
    assert "551114" not in w1099                                                       # outside concordance
    assert w1099["212234"] == pytest.approx(70 / 98)
    assert as_dict(prior, "7372") == pytest.approx({"511210": 0.5, "541511": 0.5})       # equal fallback
    sources = prior.groupby("sic")["source"].first().to_dict()
    assert sources == {"2035": "bridge_shipments", "1099": "bls_employment", "7372": "equal"}
    assert len(audit) == 3


def test_build_priors_rejects_source_mostly_outside_concordance():
    links = pd.DataFrame({"sic": ["1099", "1099"], "naics": ["212234", "213114"]})
    bls = weights_from_bls(pd.DataFrame({"sic_code": ["1099", "1099"], "naics_code": ["212234", "551114"],
                                         "ratio": [20, 80]}), ["212234", "551114"])
    prior, audit = build_priors(links, bls=bls)
    assert set(prior["source"]) == {"equal"}
    assert "rejected" in set(audit["status"])


def test_bls_group_series_applies_to_members_without_own_rows():
    links = pd.DataFrame({"sic": ["1621", "1622", "1623", "1623"], "naics": ["237310", "237310", "237110", "237120"]})
    bls = weights_from_bls(pd.DataFrame({"sic_code": ["1620", "1620", "1623", "1623"],
                                         "naics_code": ["237110", "237120", "237110", "237120"],
                                         "ratio": [60, 40, 90, 10]}), ["237110", "237120", "237310"])
    prior, _ = build_priors(links, bls=bls, restrict_to_concordance=False)
    assert as_dict(prior, "1623") == pytest.approx({"237110": 0.9, "237120": 0.1})        # own row wins
    assert as_dict(prior, "1621") == pytest.approx({"237110": 0.6, "237120": 0.4})        # group series


def test_resolve_xwalk_keeps_weights_and_averages_group_codes():
    base = pd.DataFrame({"sic": ["7371", "7372", "7372"], "naics6": ["541511", "513210", "541511"],
                         "weight": [1.0, 0.75, 0.25], "source": ["equal", "bridge_shipments", "bridge_shipments"]})
    out = resolve_xwalk(base, {"7372", "7370"})
    w7372 = dict(zip(out[out.sic == "7372"].naics6, out[out.sic == "7372"].weight))
    assert w7372 == pytest.approx({"513210": 0.75, "541511": 0.25})
    w7370 = dict(zip(out[out.sic == "7370"].naics6, out[out.sic == "7370"].weight))
    assert w7370 == pytest.approx({"541511": 0.625, "513210": 0.375})                      # mean of 7371 and 7372
    assert set(out[out.sic == "7370"].match_level) == {"prefix3"}
    assert out.groupby("sic")["weight"].sum().tolist() == pytest.approx([1.0, 1.0])


def test_resolve_xwalk_without_weights_is_equal_split():
    base = pd.DataFrame({"sic": ["2035", "2035", "2035"], "naics6": ["311421", "311941", "311999"]})
    out = resolve_xwalk(base, {"2035"})
    assert out["weight"].tolist() == pytest.approx([1 / 3] * 3)
