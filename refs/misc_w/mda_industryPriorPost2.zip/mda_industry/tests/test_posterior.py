"""Unit tests for combining priors with text evidence."""
import numpy as np
import pytest
from posterior import (apply_temperature, constrained_posterior, fit_temperature, format_dist,
                       implied_prior, out_of_set_mass, parse_dist, similarity_posterior)

CLASSES = ["212", "213", "238", "541", "551"]
PRIOR_1099 = {"212": 0.661, "213": 0.243, "238": 0.072, "551": 0.013, "541": 0.011}
UNIFORM = np.full(5, 0.2)


def test_worked_example_text_overrides_national_majority():
    # MD&A reads like mining support services, so the minority 213 piece wins.
    p = np.array([[0.10, 0.70, 0.10, 0.05, 0.05]])
    post = constrained_posterior(p, UNIFORM, CLASSES, [PRIOR_1099], alpha=1.0, floor=0.0)[0]
    assert post["213"] == pytest.approx(0.695, abs=0.002)
    assert post["212"] == pytest.approx(0.270, abs=0.002)
    assert sum(post.values()) == pytest.approx(1.0)


def test_uninformative_text_returns_prior():
    # If the model just reproduces its training prior, the posterior must equal the economic prior.
    pi = np.array([0.4, 0.3, 0.1, 0.1, 0.1])
    post = constrained_posterior(pi[None, :], pi, CLASSES, [PRIOR_1099], floor=0.0)[0]
    total = sum(PRIOR_1099.values())
    assert post == pytest.approx({c: w / total for c, w in PRIOR_1099.items()})


def test_dividing_out_training_prior_avoids_double_counting():
    # The model favors 212 only because 212 was common in training; that must not add to the economic prior.
    pi = np.array([0.6, 0.1, 0.1, 0.1, 0.1])
    p = pi[None, :].copy()
    with_division = constrained_posterior(p, pi, CLASSES, [{"212": 0.5, "213": 0.5}])[0]
    without = constrained_posterior(p, UNIFORM, CLASSES, [{"212": 0.5, "213": 0.5}])[0]
    assert with_division["212"] == pytest.approx(0.5)
    assert without["212"] > 0.8


def test_alpha_zero_ignores_prior_and_alpha_scales_trust():
    p = np.array([[0.30, 0.50, 0.10, 0.05, 0.05]])
    prior = {"212": 0.9, "213": 0.1}
    post0 = constrained_posterior(p, UNIFORM, CLASSES, [prior], alpha=0.0)[0]
    assert post0["213"] == pytest.approx(0.5 / 0.8)
    posts = [constrained_posterior(p, UNIFORM, CLASSES, [prior], alpha=a)[0]["212"] for a in (0.0, 0.5, 1.0, 2.0)]
    assert posts == sorted(posts)


def test_floor_lets_strong_text_pick_a_zero_prior_link():
    p = np.array([[0.01, 0.97, 0.01, 0.005, 0.005]])
    prior = {"212": 1.0, "213": 0.0}
    assert constrained_posterior(p, UNIFORM, CLASSES, [prior], floor=0.0)[0]["213"] == 0.0
    assert constrained_posterior(p, UNIFORM, CLASSES, [prior], floor=0.05)[0]["213"] > 0.7


def test_unscored_candidate_gets_neutral_likelihood_and_empty_prior_returns_empty():
    p = np.array([[0.2, 0.2, 0.2, 0.2, 0.2], [0.2] * 5])
    out = constrained_posterior(p, UNIFORM, CLASSES, [{"999": 0.5, "212": 0.5}, {}])
    assert out[0] == pytest.approx({"999": 0.5, "212": 0.5})
    assert out[1] == {}


def test_out_of_set_mass_flags_suspect_sic():
    p = np.array([[0.05, 0.05, 0.10, 0.80, 0.00], [0.60, 0.30, 0.10, 0.0, 0.0]])
    mass = out_of_set_mass(p, CLASSES, [{"212", "213"}, {"212", "213"}])
    assert mass == pytest.approx([0.9, 0.1])
    assert out_of_set_mass(p, CLASSES, [set(), {"999"}]) == pytest.approx([1.0, 1.0])


def test_implied_prior_for_balanced_hierarchy():
    class Sub:
        classes_ = np.array(["212", "213"])
    pi = implied_prior(["21", "23", "54", "99"], {"21": Sub(), "23": "238", "54": "541", "99": None}, CLASSES)
    # Three active sectors, each 1/3; sector 21 split between two children.
    assert pi == pytest.approx([1 / 6, 1 / 6, 1 / 3, 1 / 3, 0.0])


def test_temperature_recovers_overconfidence():
    rng = np.random.default_rng(0)
    logits = rng.normal(0, 1.5, size=(4000, 5))
    true_p = np.exp(logits) / np.exp(logits).sum(1, keepdims=True)
    y = np.array([rng.choice(5, p=row) for row in true_p])
    overconfident = apply_temperature(true_p, 0.5)          # sharpened, as an uncalibrated model would be
    assert fit_temperature(overconfident, y) == pytest.approx(2.0, rel=0.15)
    assert fit_temperature(true_p, y) == pytest.approx(1.0, rel=0.15)


def test_similarity_posterior_text_beats_prior_when_clear_and_prior_wins_on_tie():
    a, b = np.array([1.0, 0.0]), np.array([0.0, 1.0])
    candidates = np.vstack([a, b])
    prior = np.array([0.8, 0.2])
    filing = np.array([0.3, 0.954])                           # clearly closer to b
    post, sim = similarity_posterior(filing / np.linalg.norm(filing), candidates, prior, tau=0.1)
    assert post[1] > 0.9 and sim[1] > sim[0]
    tie = np.array([1.0, 1.0]) / np.sqrt(2)
    post_tie, _ = similarity_posterior(tie, candidates, prior, tau=0.1)
    assert post_tie == pytest.approx([0.8, 0.2])
    post_soft, _ = similarity_posterior(filing / np.linalg.norm(filing), candidates, prior, tau=10.0)
    assert post_soft[0] > 0.7                                 # large tau: text barely counts


def test_dist_round_trip():
    dist = {"213": 0.695, "212": 0.27, "238": 0.035}
    assert parse_dist(format_dist(dist)) == pytest.approx(dist)
    assert parse_dist("") == {} and parse_dist(None) == {}
