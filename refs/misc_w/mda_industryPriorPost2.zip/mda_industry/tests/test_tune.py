"""Unit tests for 10_tune.py: company split, paired bootstrap, tie rule, and recovering a known best alpha."""
import importlib.util
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pandas as pd
import pytest

spec = importlib.util.spec_from_file_location("tune", Path(__file__).resolve().parents[1] / "10_tune.py")
tune = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tune)
ARGS = SimpleNamespace(min_rows=15, bootstrap=300, seed=0, current_tau=0.05)


def test_cik_split_is_deterministic_and_disjoint():
    ciks = [str(i) for i in range(100)] * 3
    a, b = tune.cik_split(ciks, 0.3, 1), tune.cik_split(ciks, 0.3, 1)
    assert a == b and len(a) == 30
    assert tune.cik_split(ciks, 0.3, 2) != a


def test_paired_bootstrap_shapes_and_extremes():
    correct = np.column_stack([np.ones(40), np.zeros(40)])
    boot = tune.paired_bootstrap(correct, np.ones(40), np.repeat(np.arange(10), 4), 50, 0)
    assert boot.shape == (50, 2)
    assert np.allclose(boot[:, 0], 1) and np.allclose(boot[:, 1], 0)


def test_choose_prefers_default_when_tied_and_best_when_clearly_better():
    grid = pd.DataFrame({"alpha": [0.0, 1.0], "accuracy": [0.80, 0.79]})
    rng = np.random.default_rng(0)
    tied = np.column_stack([rng.normal(0.80, 0.03, 500), rng.normal(0.79, 0.03, 500)])
    pick, _ = tune.choose(grid, tied, lambda r: abs(r["alpha"] - 1))
    assert grid.iloc[pick]["alpha"] == 1.0
    clear = np.column_stack([np.full(500, 0.95), np.full(500, 0.60)])
    grid2 = pd.DataFrame({"alpha": [0.0, 1.0], "accuracy": [0.95, 0.60]})
    pick2, _ = tune.choose(grid2, clear, lambda r: abs(r["alpha"] - 1))
    assert grid2.iloc[pick2]["alpha"] == 0.0


def make_case(n_firms, prior_major, text_strength, truth_major_share, seed):
    """Two candidate codes A/B for a split SIC. Prior favors A; text points to the true code with given strength."""
    rng = np.random.default_rng(seed)
    classes = np.array(["111", "222", "333"])
    acc, truth, P3 = [], [], []
    for i in range(n_firms):
        true = "111" if rng.random() < truth_major_share else "222"
        if text_strength is None:                                   # pure noise text
            p = rng.dirichlet([1, 1, 1])
        else:
            p = np.array([1 - text_strength, text_strength, 0.0]) if true == "222" else np.array([text_strength, 1 - text_strength, 0.0])
            p = 0.95 * p + 0.05 / 3
        acc.append(f"a{i}"); truth.append(true); P3.append(p)
    P3 = np.array(P3)
    oof = {"P3": P3, "PI": np.full_like(P3, 1 / 3), "classes": classes, "accession": np.array(acc), "temperature": 1.0}
    prior = f"111:{prior_major};222:{1 - prior_major:.3f}"
    filings = pd.DataFrame({"accession": acc, "cik": [f"c{i}" for i in range(n_firms)], "split_sic": True, "naics3_prior": prior})
    preds = pd.DataFrame({"accession": acc, "naics3_pred": classes[P3.argmax(1)], "sic_suspect": False})
    gold = pd.DataFrame({"accession": acc, "gold_naics3": truth, "gold_naics6": np.nan, "sampling_weight": 1.0})
    return gold, filings, oof, preds, set(filings["cik"])


def test_informative_text_with_misleading_prior_chooses_low_alpha():
    # Prior says 90/10 but firms are 50/50; text is 70/30 right. Only alpha <= 0.25 follows the text.
    gold, filings, oof, preds, ciks = make_case(200, 0.9, 0.7, 0.5, 0)
    grid, report, chosen = tune.tune_naics3(gold, filings, oof, preds, ciks, ARGS)
    assert chosen[0] <= 0.25
    assert report["tuning_split"]["chosen"] > report["tuning_split"]["prior_only"] + 0.3


def test_noise_text_with_accurate_prior_chooses_high_alpha():
    # Prior 85/15 matches reality and text is noise: following the prior is best.
    gold, filings, oof, preds, ciks = make_case(300, 0.85, None, 0.85, 1)
    grid, report, chosen = tune.tune_naics3(gold, filings, oof, preds, ciks, ARGS)
    assert chosen[0] >= 1.0
    assert report["tuning_split"]["chosen"] >= report["tuning_split"]["text_only_alpha0"] + 0.15


def test_too_few_rows_skips_tuning():
    gold, filings, oof, preds, ciks = make_case(10, 0.9, 0.7, 0.5, 2)
    _, report, chosen = tune.tune_naics3(gold, filings, oof, preds, ciks, ARGS)
    assert chosen is None and "skipped" in report


def test_tau_grid_recovers_text_when_similarity_is_informative():
    rng = np.random.default_rng(3)
    rows, gold = [], []
    for i in range(120):
        true = "311421" if i % 2 else "311941"
        sim = [0.30, 0.20] if true == "311421" else [0.20, 0.30]
        sim = np.array(sim) + rng.normal(0, 0.02, 2)
        rows.append((f"a{i}", "311", "sic_links", "311421;311941", "0.21;0.79", ";".join(map(str, sim))))
        gold.append((f"a{i}", "311", true, 1.0))
    cands = pd.DataFrame(rows, columns=["accession", "target_naics3", "basis", "codes", "prior", "similarity"])
    gold = pd.DataFrame(gold, columns=["accession", "gold_naics3", "gold_naics6", "sampling_weight"])
    filings = pd.DataFrame({"accession": cands["accession"], "cik": [f"c{i}" for i in range(120)]})
    grid, report, tau = tune.tune_naics6(gold, filings, cands, set(filings["cik"]), 1.0, 0.01, ARGS)
    assert report["tuning"]["chosen"] >= 0.9 > report["tuning"]["prior_only"]
    assert tau <= grid["tau"].max()
