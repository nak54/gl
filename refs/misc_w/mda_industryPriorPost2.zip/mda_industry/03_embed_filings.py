#!/usr/bin/env python
"""Embed kept chunks and length-weight average them into filing vectors."""
from __future__ import annotations
import json
import numpy as np
import pandas as pd
from common import base_parser, embed_texts


def main():
    parser = base_parser(__doc__)
    parser.add_argument("--backend", choices=["sentence-transformers", "hash"], default="sentence-transformers")
    parser.add_argument("--model", default="sentence-transformers/all-mpnet-base-v2")
    parser.add_argument("--batch-size", type=int, default=32)
    args = parser.parse_args()
    filings = pd.read_parquet(args.workdir / "filings.parquet")
    chunks = pd.read_parquet(args.workdir / "chunks.parquet")

    vectors = embed_texts(chunks["text"].tolist(), args.backend, args.model, args.batch_size)
    assert len(vectors) == len(chunks), "chunk-to-vector mapping must be 1:1"
    lengths = chunks["text"].str.split().str.len().to_numpy(dtype=np.float32)
    position = pd.Series(np.arange(len(filings)), index=filings["accession"])
    doc_index = chunks["accession"].map(position).to_numpy()
    assert not np.isnan(doc_index.astype(float)).any()

    pooled = np.zeros((len(filings), vectors.shape[1]), dtype=np.float32)
    np.add.at(pooled, doc_index, vectors * lengths[:, None])
    norms = np.linalg.norm(pooled, axis=1, keepdims=True)
    pooled = np.divide(pooled, norms, out=np.zeros_like(pooled), where=norms > 0)

    np.save(args.workdir / "chunk_vectors.npy", vectors)
    np.save(args.workdir / "filing_vectors.npy", pooled)
    (args.workdir / "embedding_meta.json").write_text(json.dumps({"backend": args.backend, "model": args.model, "dim": int(vectors.shape[1])}))
    print(f"chunk_vectors={vectors.shape} filing_vectors={pooled.shape} zero_vectors={(norms[:, 0] == 0).sum()}")


if __name__ == "__main__":
    main()
