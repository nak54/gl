#!/usr/bin/env python
"""Hierarchical NAICS2 -> NAICS3 classifier, combined with the economic prior as a posterior.

1. Train on prior-weighted soft labels with CIK-grouped out-of-fold (OOF) predictions.
2. Calibrate OOF probabilities with a temperature fitted on clear-cut filings.
3. Combine with the prior over each filing's SIC candidates (posterior.constrained_posterior).
4. Relabel: the posterior replaces the prior as each training filing's soft label; retrain (--em-iters).
5. Report the unconstrained prediction (naics3_pred), the constrained one (naics3_constrained),
   and sic_suspect when most text probability falls outside the SIC's candidates.

Writes predictions_oof.parquet, metrics.json, final_model.joblib, posterior_config.json.
"""
from __future__ import annotations
import json
from dataclasses import dataclass, field
import joblib
import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedGroupKFold
from common import base_parser, sector
from posterior import (apply_temperature, constrained_posterior, fit_temperature, format_dist,
                       implied_prior, out_of_set_mass, parse_dist)


@dataclass
class Model:
    tfidf: TfidfVectorizer
    sector_clf: LogisticRegression | None
    sector_classes: list
    subsector: dict = field(default_factory=dict)  # sector -> classifier or constant string
    n3_classes: list = field(default_factory=list)


def features(model_tfidf, texts, vectors, tfidf_weight=1.0, dense_weight=1.0):
    return sparse.hstack([model_tfidf.transform(texts) * tfidf_weight,
                          sparse.csr_matrix(vectors) * dense_weight], format="csr")


def expand(labels: pd.DataFrame, positions: dict, level: str, allowed=None):
    frame = labels[(labels["level"] == level) & labels["accession"].isin(positions)]
    if allowed is not None:
        frame = frame[frame["code"].isin(allowed)]
    rows = frame["accession"].map(positions).to_numpy()
    return rows, frame["code"].to_numpy(), frame["weight"].to_numpy()


def fit_lr(X, y, weights, c):
    return LogisticRegression(C=c, class_weight="balanced", max_iter=1000).fit(X, y, sample_weight=weights)


def supported_classes(labels, filings, level, min_ciks):
    frame = labels[labels["level"] == level].merge(filings[["accession", "cik"]], on="accession")
    counts = frame.groupby("code")["cik"].nunique()
    return set(counts[counts >= min_ciks].index)


def fit_model(filings, vectors, labels, train_pos, args) -> Model:
    train = filings.iloc[train_pos]
    tfidf = TfidfVectorizer(ngram_range=(1, 2), min_df=args.min_df, max_df=0.6, sublinear_tf=True,
                            stop_words="english", max_features=args.max_features)
    tfidf.fit(train["kept_text"])
    X = features(tfidf, train["kept_text"], vectors[train_pos])
    positions = dict(zip(train["accession"], range(len(train))))
    sectors_ok = supported_classes(labels[labels.accession.isin(positions)], train, "naics2", args.min_ciks)
    rows, y, w = expand(labels, positions, "naics2", sectors_ok)
    if len(set(y)) < 2:
        raise SystemExit("Need at least two supported NAICS2 classes")
    clf = fit_lr(X[rows], y, w, args.c)

    n3_ok = supported_classes(labels[labels.accession.isin(positions)], train, "naics3", args.min_ciks)
    rows3, y3, w3 = expand(labels, positions, "naics3", n3_ok)
    parents = np.array([sector(code) for code in y3])
    subsector = {}
    for sec in clf.classes_:
        mask = parents == sec
        classes = set(y3[mask])
        if len(classes) == 1:
            subsector[sec] = next(iter(classes))
        elif len(classes) >= 2:
            subsector[sec] = fit_lr(X[rows3[mask]], y3[mask], w3[mask], args.c)
    n3_classes = sorted(set(y3))
    return Model(tfidf, clf, list(clf.classes_), subsector, n3_classes)


def predict(model: Model, texts, vectors):
    X = features(model.tfidf, texts, vectors)
    p2 = model.sector_clf.predict_proba(X)
    p3 = np.zeros((X.shape[0], len(model.n3_classes)))
    idx3 = {c: i for i, c in enumerate(model.n3_classes)}
    for j, sec in enumerate(model.sector_classes):
        sub = model.subsector.get(sec)
        if sub is None:
            continue
        if isinstance(sub, str):
            p3[:, idx3[sub]] += p2[:, j]
        else:
            conditional = sub.predict_proba(X)
            for k, code in enumerate(sub.classes_):
                p3[:, idx3[code]] += p2[:, j] * conditional[:, k]
    p3 = p3 / np.maximum(p3.sum(axis=1, keepdims=True), 1e-12)
    return p2, p3


def top_k(probabilities, classes, k=3):
    order = np.argsort(-probabilities, axis=1)[:, :k]
    return [[(classes[j], float(row[j])) for j in idx] for row, idx in zip(probabilities, order)]


def assign_folds(filings, n_splits, seed):
    eligible = filings[filings["train_eligible"]]
    primary = eligible["naics3_xwalk_primary"].map(sector)
    sgkf = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    fold_of = {}
    for fold, (_, test) in enumerate(sgkf.split(eligible, primary, eligible["cik"])):
        fold_of.update({c: fold for c in eligible.iloc[test]["cik"]})
    rest = sorted(set(filings["cik"]) - set(fold_of))
    fold_of.update({c: i % n_splits for i, c in enumerate(rest)})
    return filings["cik"].map(fold_of).to_numpy()


def run_oof(filings, vectors, labels, folds, eligible, chunks, chunk_vectors, classes, args):
    """One full cross-fitting pass. Returns raw P3, implied priors PI (both n x K on global classes),
    sector predictions, and segment-based secondary codes."""
    n, index = len(filings), {c: k for k, c in enumerate(classes)}
    P3, PI = np.zeros((n, len(classes))), np.zeros((n, len(classes)))
    sectors = pd.DataFrame(index=filings.index, columns=["naics2_pred", "naics2_conf", "naics2_top3"], dtype=object)
    secondary = pd.Series("", index=filings.index, dtype=object)
    for fold in range(args.folds):
        test_pos = np.where(folds == fold)[0]
        train_pos = np.where((folds != fold) & eligible)[0]
        assert not set(filings.iloc[test_pos]["cik"]) & set(filings.iloc[train_pos]["cik"]), "CIK leakage"
        model = fit_model(filings, vectors, labels, train_pos, args)
        test = filings.iloc[test_pos]
        p2, p3 = predict(model, test["kept_text"], vectors[test_pos])
        cols = [index[c] for c in model.n3_classes]
        P3[np.ix_(test_pos, cols)] = p3
        PI[np.ix_(test_pos, cols)] = implied_prior(model.sector_classes, model.subsector, model.n3_classes)
        for pos, t2 in zip(test_pos, top_k(p2, model.sector_classes)):
            sectors.iloc[pos] = [t2[0][0], t2[0][1], ";".join(c for c, _ in t2)]
        seg_mask = chunks["section"].eq("segment") & chunks["accession"].isin(test["accession"])
        if seg_mask.any():
            seg = chunks[seg_mask]
            _, seg_p3 = predict(model, seg["text"], chunk_vectors[seg.index.to_numpy()])
            mean = pd.DataFrame(seg_p3, columns=model.n3_classes).groupby(seg["accession"].to_numpy()).mean()
            filing_probs = pd.DataFrame(p3, columns=model.n3_classes, index=test["accession"])
            positions = dict(zip(filings["accession"], range(n)))
            for accession, row in mean.iterrows():
                baseline = filing_probs.loc[accession]
                lift = row / baseline.clip(lower=1e-6)
                keep = (row >= args.secondary_min_prob) & (lift >= args.secondary_min_lift) & (row.index != baseline.idxmax())
                secondary.iloc[positions[accession]] = ";".join(row[keep].sort_values(ascending=False).index)
    return P3, PI, sectors, secondary


def calibrate(P3, filings, classes, mask):
    """Fit a temperature on filings whose SIC points clearly to one NAICS3 (weak but mostly right)."""
    index = {c: k for k, c in enumerate(classes)}
    target = filings["naics3_xwalk_primary"].map(index)
    use = mask & filings["prior_top_share"].ge(0.8).to_numpy() & target.notna().to_numpy()
    if use.sum() < 20:
        return 1.0
    return fit_temperature(P3[use], target[use].astype(int).to_numpy())


def posterior_labels(filings, priors, posteriors, suspect, eligible):
    """New soft labels: the posterior for eligible, non-suspect filings; the prior otherwise."""
    rows = []
    for i, accession in enumerate(filings["accession"]):
        dist = posteriors[i] if eligible[i] and not suspect[i] and posteriors[i] else priors[i]
        for code, weight in dist.items():
            rows.append((accession, "naics3", code, weight))
        by_sector = {}
        for code, weight in dist.items():
            by_sector[sector(code)] = by_sector.get(sector(code), 0) + weight
        rows += [(accession, "naics2", code, weight) for code, weight in by_sector.items()]
    return pd.DataFrame(rows, columns=["accession", "level", "code", "weight"])


def hit_rates(frame, candidates):
    top1_n3 = np.mean([p in c for p, c in zip(frame["naics3_pred"], candidates)])
    top3_n3 = np.mean([bool(set(t.split(";")) & c) for t, c in zip(frame["naics3_top3"], candidates)])
    top1_n2 = np.mean([p in {sector(x) for x in c} for p, c in zip(frame["naics2_pred"], candidates)])
    return float(top1_n2), float(top1_n3), float(top3_n3)


def score(frame):
    known = frame[frame["naics3_xwalk_primary"].notna()]
    candidates = [set(x.split(";")) for x in known["naics_xwalk"]]
    n2, n3, n3top3 = hit_rates(known, candidates)
    return {"n": int(len(known)), "naics2_top1_in_sic_candidates": n2, "naics3_top1_in_sic_candidates": n3,
            "naics3_top3_in_sic_candidates": n3top3,
            "naics2_macro_f1_vs_primary": float(f1_score(known["naics3_xwalk_primary"].map(sector), known["naics2_pred"], average="macro", zero_division=0)),
            "naics3_macro_f1_vs_primary": float(f1_score(known["naics3_xwalk_primary"], known["naics3_pred"], average="macro", zero_division=0))}


def main():
    parser = base_parser(__doc__)
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--c", type=float, default=4.0)
    parser.add_argument("--min-df", type=int, default=3)
    parser.add_argument("--max-features", type=int, default=150_000)
    parser.add_argument("--min-ciks", type=int, default=5, help="Minimum distinct companies required to train a class")
    parser.add_argument("--alpha", type=float, default=1.0, help="Trust in the economic prior: 0 ignores it")
    parser.add_argument("--floor", type=float, default=0.01, help="Minimum prior weight so strong text can pick a rare link")
    parser.add_argument("--em-iters", type=int, default=2, help="Relabeling passes (0 trains on the prior only)")
    parser.add_argument("--suspect-threshold", type=float, default=0.5, help="Text mass outside SIC candidates that flags sic_suspect")
    parser.add_argument("--suspect-min-conf", type=float, default=0.4, help="Top outside code must have at least this probability")
    parser.add_argument("--secondary-min-prob", type=float, default=0.12)
    parser.add_argument("--secondary-min-lift", type=float, default=2.0, help="Segment probability divided by filing-level probability")
    args = parser.parse_args()

    filings = pd.read_parquet(args.workdir / "filings.parquet")
    labels = pd.read_parquet(args.workdir / "labels.parquet")
    vectors = np.load(args.workdir / "filing_vectors.npy")
    chunks = pd.read_parquet(args.workdir / "chunks.parquet")
    chunk_vectors = np.load(args.workdir / "chunk_vectors.npy")
    assert len(vectors) == len(filings) and len(chunk_vectors) == len(chunks)

    folds = assign_folds(filings, args.folds, args.seed)
    eligible = filings["train_eligible"].to_numpy()
    classes = sorted(labels.loc[labels["level"] == "naics3", "code"].unique())
    priors = [parse_dist(x) for x in filings["naics3_prior"]]
    candidate_sets = [set(p) for p in priors]
    history = []
    for iteration in range(args.em_iters + 1):
        P3, PI, sectors, secondary = run_oof(filings, vectors, labels, folds, eligible, chunks, chunk_vectors, classes, args)
        temperature = calibrate(P3, filings, classes, eligible)
        P3c = apply_temperature(P3, temperature)
        posteriors = constrained_posterior(P3c, PI, classes, priors, alpha=args.alpha, floor=args.floor)
        outside = out_of_set_mass(P3c, classes, candidate_sets)
        top = P3c.argmax(axis=1)
        top_outside = np.array([classes[t] not in cands for t, cands in zip(top, candidate_sets)])
        # Suspect only when the text is confident about a code outside the SIC's candidates;
        # diffuse, uninformative text should fall back to the prior instead.
        suspect = (outside > args.suspect_threshold) & top_outside & (P3c.max(axis=1) >= args.suspect_min_conf)
        if iteration < args.em_iters:
            previous = labels
            labels = posterior_labels(filings, priors, posteriors, suspect, eligible)
            joined = previous[previous.level == "naics3"].merge(labels[labels.level == "naics3"], on=["accession", "code"], how="outer").fillna(0)
            change = float((joined["weight_x"] - joined["weight_y"]).abs().groupby(joined["accession"]).sum().mean() / 2)
            history.append({"iteration": iteration, "temperature": temperature, "mean_label_shift": change, "suspect_rate": float(suspect.mean())})
            print(f"relabel {iteration}: T={temperature:.2f} mean label shift={change:.4f} suspect={suspect.mean():.1%}")
    history.append({"iteration": args.em_iters, "temperature": temperature, "suspect_rate": float(suspect.mean())})
    labels.to_parquet(args.workdir / "labels_posterior.parquet", index=False)
    # Saved for 10_tune.py, which recomputes the posterior for other alpha/floor values without retraining.
    np.savez_compressed(args.workdir / "oof_probs.npz", P3=P3, PI=PI, classes=np.array(classes, dtype=str),
                        accession=filings["accession"].to_numpy(dtype=str), temperature=temperature)

    tops = top_k(P3c, classes)
    output = filings.drop(columns=["kept_text"]).copy()
    output[["naics2_pred", "naics2_conf", "naics2_top3"]] = sectors.to_numpy()
    output["naics2_conf"] = output["naics2_conf"].astype(float)
    output["naics3_pred"] = [t[0][0] for t in tops]
    output["pred_conf"] = [t[0][1] for t in tops]
    output["pred_margin"] = [t[0][1] - (t[1][1] if len(t) > 1 else 0.0) for t in tops]
    output["naics3_top3"] = [";".join(c for c, _ in t) for t in tops]
    output["naics3_top3_probs"] = [";".join(f"{p:.4f}" for _, p in t) for t in tops]
    output["naics3_secondary"] = secondary.fillna("").astype(str).to_numpy()
    best = [max(p, key=p.get) if p else None for p in posteriors]
    output["naics3_constrained"] = best
    output["constrained_conf"] = [p[b] if b else np.nan for p, b in zip(posteriors, best)]
    output["naics3_posterior"] = [format_dist(p) for p in posteriors]
    output["naics2_constrained"] = output["naics3_constrained"].map(lambda c: sector(c) if isinstance(c, str) else None)
    output["naics3_prior_top"] = output["naics3_xwalk_primary"]
    output["out_of_set_mass"] = outside
    output["sic_suspect"] = suspect & output["naics3_constrained"].notna().to_numpy()
    material = output["naics_xwalk_material"].map(lambda x: set(x.split(";")) if x else set())
    output["agrees_with_sic"] = [p in c for p, c in zip(output["naics3_pred"], material)]
    candidates = output["naics_xwalk"].map(lambda x: set(x.split(";")) if x else set())
    output["sector_agrees_with_sic"] = [p in {sector(x) for x in c} for p, c in zip(output["naics2_pred"], candidates)]
    output.to_parquet(args.workdir / "predictions_oof.parquet", index=False)

    metrics = {"weak_label_note": "SIC-derived labels are noisy. Use 09_validate.py against hand labels for true accuracy.",
               "oof_eligible": score(output[eligible]),
               "oof_by_year": {str(y): score(g) for y, g in output[eligible].groupby("year")},
               "temporal_holdout": {},
               "relabel_history": history,
               "split_sic_filings": int(output["split_sic"].sum()),
               "constrained_differs_from_prior_top": float((output["naics3_constrained"] != output["naics3_prior_top"])[output["split_sic"]].mean()) if output["split_sic"].any() else None,
               "sic_suspect_rate": float(output["sic_suspect"].mean())}
    # Drift check: test on one year using held-out companies, and train only on other years and other companies.
    held_out = np.isin(folds, [0, 1])
    for year in sorted(filings["year"].unique()):
        test_pos = np.where((filings["year"] == year) & eligible & held_out)[0]
        train_pos = np.where((filings["year"] != year) & eligible & ~held_out)[0]
        assert not set(filings.iloc[test_pos]["cik"]) & set(filings.iloc[train_pos]["cik"]), "CIK leakage"
        if len(train_pos) < 50 or len(test_pos) == 0:
            metrics["temporal_holdout"][str(year)] = {"skipped": f"train={len(train_pos)} test={len(test_pos)}"}
            continue
        model = fit_model(filings, vectors, labels, train_pos, args)
        test = filings.iloc[test_pos]
        p2, p3 = predict(model, test["kept_text"], vectors[test_pos])
        frame = output.iloc[test_pos].copy()
        frame["naics2_pred"] = [model.sector_classes[i] for i in p2.argmax(1)]
        frame["naics3_pred"] = [model.n3_classes[i] for i in p3.argmax(1)]
        frame["naics3_top3"] = [";".join(c for c, _ in t) for t in top_k(p3, model.n3_classes)]
        metrics["temporal_holdout"][str(year)] = {"train": int(len(train_pos)), **score(frame)}

    final = fit_model(filings, vectors, labels, np.where(eligible)[0], args)
    joblib.dump({**vars(final), "implied_prior": implied_prior(final.sector_classes, final.subsector, final.n3_classes)},
                args.workdir / "final_model.joblib")
    (args.workdir / "posterior_config.json").write_text(json.dumps(
        {"alpha": args.alpha, "floor": args.floor, "temperature": temperature, "suspect_threshold": args.suspect_threshold, "suspect_min_conf": args.suspect_min_conf,
         "em_iters": args.em_iters, "classes": classes}, indent=2))
    (args.workdir / "metrics.json").write_text(json.dumps(metrics, indent=2))
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
