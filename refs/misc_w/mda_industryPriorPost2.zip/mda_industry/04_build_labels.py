#!/usr/bin/env python
"""Turn filed SICs into prior-weighted NAICS2/NAICS3 candidate labels and per-filing prior columns."""
from __future__ import annotations
import pandas as pd
from common import EXCLUDED_SICS, base_parser, resolve_xwalk
from posterior import format_dist


def main():
    parser = base_parser(__doc__)
    parser.add_argument("--split-threshold", type=float, default=0.8, help="A SIC is split if its top NAICS3 share is below this")
    parser.add_argument("--material-share", type=float, default=0.10, help="Minimum prior share for a link to count as SIC agreement")
    args = parser.parse_args()
    filings = pd.read_parquet(args.workdir / "filings.parquet")
    base = pd.read_parquet(args.workdir / "ref/sic_naics6.parquet")
    sic_titles = pd.read_parquet(args.workdir / "ref/sic_titles.parquet")
    xwalk = resolve_xwalk(base, set(filings["sic"]) | set(sic_titles["sic"]))
    xwalk.to_parquet(args.workdir / "ref/sic_xwalk_resolved.parquet", index=False)

    match = xwalk.groupby("sic")["match_level"].first()
    filings["match_level"] = filings["sic"].map(match).fillna("none")
    filings["excluded_sic"] = filings["sic"].isin(EXCLUDED_SICS)
    filings["train_eligible"] = (~filings["excluded_sic"]) & filings["match_level"].isin(["exact", "prefix3"]) & (filings["kept_words"] > 0)

    n3 = xwalk.groupby(["sic", "naics3"], as_index=False)["weight"].sum()
    n2 = xwalk.groupby(["sic", "naics2"], as_index=False)["weight"].sum()
    rows = []
    for level, table, column in (("naics2", n2, "naics2"), ("naics3", n3, "naics3")):
        merged = filings[["accession", "sic"]].merge(table, on="sic")
        rows.append(merged.rename(columns={column: "code"}).assign(level=level)[["accession", "level", "code", "weight"]])
    pd.concat(rows).to_parquet(args.workdir / "labels.parquet", index=False)

    primary = n3.sort_values(["sic", "weight", "naics3"], ascending=[True, False, True]).groupby("sic").first()
    candidates = n3.groupby("sic")["naics3"].apply(lambda s: ";".join(sorted(s)))
    material = n3[n3["weight"] >= args.material_share].groupby("sic")["naics3"].apply(lambda s: ";".join(sorted(s)))
    dist = n3.groupby("sic").apply(lambda g: format_dist(dict(zip(g["naics3"], g["weight"]))), include_groups=False)
    source = xwalk.groupby("sic")["prior_source"].first()
    filings["naics3_xwalk_primary"] = filings["sic"].map(primary["naics3"])
    filings["prior_top_share"] = filings["sic"].map(primary["weight"])
    filings["naics_xwalk"] = filings["sic"].map(candidates).fillna("")
    filings["naics_xwalk_material"] = filings["sic"].map(material).fillna("")
    filings["naics3_prior"] = filings["sic"].map(dist).fillna("")
    filings["prior_source"] = filings["sic"].map(source).fillna("none")
    filings["split_sic"] = filings["prior_top_share"] < args.split_threshold
    filings.to_parquet(args.workdir / "filings.parquet", index=False)
    print(filings.groupby("match_level").size().to_dict(), f"excluded={filings.excluded_sic.sum()} eligible={filings.train_eligible.sum()}")
    print("prior source by filing:", filings["prior_source"].value_counts().to_dict(), f"split-SIC filings: {filings.split_sic.sum():,}")
    unmatched = sorted(filings.loc[(filings.match_level == "none") & ~filings.excluded_sic, "sic"].unique())
    if unmatched:
        print("WARNING no crosswalk for SIC:", unmatched[:30])


if __name__ == "__main__":
    main()
