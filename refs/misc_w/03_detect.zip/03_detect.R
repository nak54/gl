## ---------------------------------------------------------------------------
## 03_detect.R -- find where each candidate's resume starts inside the packet
## Port of initialize_dataframe.R / search.R / update_resume_df.R /
## collapse_resume_df.R / compare_text_OCR.R
## ---------------------------------------------------------------------------

NAMES_REQUIRED <- c("Applicant First Name", "Applicant Last Name",
                    "Applicant Email Address")

## Apply the same normalisation to a search term that clean_pdf_text() applies
## to the page text.
norm_needle <- function(x) {
  x <- tolower(as.character(x))
  x <- gsub("[,\n\t-]", " ", x)
  trimws(gsub("[[:blank:]]+", " ", x))
}

## Read the USAS names spreadsheet -----------------------------------------
load_names <- function(path) {
  ext <- tolower(tools::file_ext(path))
  tbl <- if (ext %in% c("xlsx", "xls")) {
    require_pkgs("readxl", "reading the names spreadsheet")
    as.data.frame(readxl::read_excel(path))
  } else {
    utils::read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
  }
  miss <- setdiff(NAMES_REQUIRED, names(tbl))
  if (length(miss)) {
    die("names file %s is missing required column(s): %s",
        basename(path), paste(miss, collapse = ", "))
  }
  if (!"Applicant Phone Number" %in% names(tbl)) {
    tbl[["Applicant Phone Number"]] <- NA_character_
  }

  n_dup <- sum(duplicated(tbl))
  if (n_dup > 0L) {
    acr_warn(paste0("the names sheet contains %d duplicated row(s). Remove duplicated ",
                    "applicants and run again -- applicants sharing a first/last name ",
                    "must be handled manually."), n_dup)
  }

  people <- data.frame(
    firstName = tolower(trimws(as.character(tbl[["Applicant First Name"]]))),
    lastName  = tolower(trimws(as.character(tbl[["Applicant Last Name"]]))),
    email     = tolower(trimws(as.character(tbl[["Applicant Email Address"]]))),
    phone     = gsub("[^0-9]", "", as.character(tbl[["Applicant Phone Number"]])),
    stringsAsFactors = FALSE
  )
  ## The page text has had commas and dashes turned into spaces, so the things
  ## we search for must be normalised the same way -- otherwise hyphenated
  ## names and e-mail addresses (Ha-Yoon, Ha-YoonBurton@...) never match.
  people$firstNameSearch <- norm_needle(people$firstName)
  people$lastNameSearch  <- norm_needle(people$lastName)
  people$emailSearch     <- norm_needle(people$email)
  people <- people[!is.na(people$firstName) & nzchar(people$firstName), , drop = FALSE]
  people <- unique(people)
  rownames(people) <- NULL

  n_missing_email <- sum(!nzchar(people$email) | is.na(people$email))
  if (n_missing_email > 0L) {
    acr_warn("%d applicant(s) have no e-mail address; they can only be matched by name",
             n_missing_email)
  }

  msg("names sheet: %d applicant(s), %d column(s)", nrow(people), ncol(tbl))
  list(table = tbl, people = people)
}

## Name search -------------------------------------------------------------
## For every page, look for an applicant whose first and last name both appear
## near the top of the page, in the right order and close together. The same
## heuristics as the Shiny app:
##   * first name starts within the first 400 characters of the page
##   * the page is not a USAJobs "references:" page
##   * the last name follows the first name, no more than 50 characters later
## Only the first applicant matched on a page is recorded.
search_names <- function(pages, people) {
  hits <- list()
  for (i in seq_along(pages)) {
    page <- pages[[i]]
    if (is.na(page) || !nzchar(page)) next
    if (grepl("references:", page, fixed = TRUE)) next
    for (x in seq_len(nrow(people))) {
      fn <- people$firstNameSearch[x]
      ln <- people$lastNameSearch[x]
      if (!nzchar(fn) || !nzchar(ln)) next
      f_at <- regexpr(rx_token(fn), page, perl = TRUE)[1L]
      if (f_at == -1L || f_at >= 400L) next
      l_at <- regexpr(rx_token(ln), page, perl = TRUE)[1L]
      if (l_at == -1L) next
      loc_diff <- l_at - f_at
      if (loc_diff <= 0L || loc_diff >= 50L) next
      hits[[length(hits) + 1L]] <- data.frame(
        pageNumber = i, charactersPerPage = nchar(page),
        firstName = people$firstName[x], lastName = people$lastName[x],
        email = people$email[x],
        firstNameLoc = f_at, lastNameLoc = l_at, nameLocDiff = loc_diff,
        method = "name", stringsAsFactors = FALSE
      )
      break                                     # first match on the page wins
    }
  }
  if (!length(hits)) return(empty_hits())
  do.call(rbind, hits)
}

empty_hits <- function() {
  data.frame(pageNumber = integer(), charactersPerPage = integer(),
             firstName = character(), lastName = character(), email = character(),
             firstNameLoc = integer(), lastNameLoc = integer(),
             nameLocDiff = integer(), method = character(),
             stringsAsFactors = FALSE)
}

## E-mail / phone search ---------------------------------------------------
## For applicants still unaccounted for, look for their e-mail address (in the
## cleaned text) or their phone number (in the digits-only text). The first
## page carrying the identifier is taken as the start of that resume.
search_field <- function(pages, todo, field = c("email", "phone")) {
  field <- match.arg(field)
  hits <- list()
  if (!nrow(todo)) return(empty_hits())
  needles <- if (field == "email") todo$emailSearch else todo$phone
  for (x in seq_len(nrow(todo))) {
    needle <- needles[x]
    if (is.na(needle) || !nzchar(needle)) next
    if (field == "phone" && nchar(needle) < 7L) next
    found <- NA_integer_
    for (i in seq_along(pages)) {
      page <- pages[[i]]
      if (is.na(page) || !nzchar(page)) next
      if (grepl(needle, page, fixed = TRUE)) { found <- i; break }
    }
    if (is.na(found)) next
    hits[[length(hits) + 1L]] <- data.frame(
      pageNumber = found, charactersPerPage = nchar(pages[[found]]),
      firstName = todo$firstName[x], lastName = todo$lastName[x],
      email = todo$email[x],
      firstNameLoc = NA_integer_, lastNameLoc = NA_integer_,
      nameLocDiff = NA_integer_, method = field, stringsAsFactors = FALSE
    )
  }
  if (!length(hits)) return(empty_hits())
  do.call(rbind, hits)
}

## One layer (embedded text or OCR): name search, then e-mail, then phone for
## whoever is left. Returns the page hits and the still-unmatched applicants.
detect_layer <- function(layer, people, label) {
  hits <- search_names(layer$text, people)
  todo <- people[!people$email %in% hits$email, , drop = FALSE]
  msg("%s layer: %d candidate(s) matched by name, %d left", label,
      length(unique(hits$email)), nrow(todo))

  by_email <- search_field(layer$flat, todo, "email")
  if (nrow(by_email)) {
    hits <- rbind(hits, by_email)
    todo <- todo[!todo$email %in% by_email$email, , drop = FALSE]
    msg("%s layer: %d more by e-mail, %d left", label, nrow(by_email), nrow(todo))
  }

  by_phone <- search_field(layer$numbers, todo, "phone")
  if (nrow(by_phone)) {
    hits <- rbind(hits, by_phone)
    todo <- todo[!todo$email %in% by_phone$email, , drop = FALSE]
    msg("%s layer: %d more by phone, %d left", label, nrow(by_phone), nrow(todo))
  }

  list(hits = hits, todo = todo)
}

## Collapse page hits to one start page per candidate.
collapse_hits <- function(hits) {
  if (!nrow(hits)) {
    return(data.frame(email = character(), firstName = character(),
                      lastName = character(), startPage = integer(),
                      method = character(), stringsAsFactors = FALSE))
  }
  hits <- hits[order(hits$pageNumber), , drop = FALSE]
  keep <- !duplicated(hits$email)
  out <- hits[keep, c("email", "firstName", "lastName", "pageNumber", "method")]
  names(out)[names(out) == "pageNumber"] <- "startPage"
  out[order(out$startPage), , drop = FALSE]
}

## Derive endPage/resumeLength from the ordered start pages. A candidate's
## resume runs until the page before the next candidate starts; the last one
## runs to the end of the packet. A start page supplied manually may carry its
## own endPage, which is honoured when it does not overlap the next candidate.
finalise_pages <- function(cand, n_pages) {
  if (!nrow(cand)) return(cand)
  cand$startPage <- suppressWarnings(as.integer(cand$startPage))
  cand <- cand[order(cand$startPage), , drop = FALSE]
  computed <- lead_vec(cand$startPage, default = n_pages + 1L) - 1L
  computed[length(computed)] <- n_pages
  ## two candidates detected on the same page: give each at least one page and
  ## say so, rather than producing a negative resume length
  overlap <- computed < cand$startPage
  if (any(overlap)) {
    acr_warn("%d candidate(s) start on a page already used by the previous candidate (%s); each keeps one page -- check candidates.csv",
             sum(overlap), paste(cand$email[overlap], collapse = ", "))
    computed[overlap] <- cand$startPage[overlap]
  }
  if (!"endPage" %in% names(cand)) cand$endPage <- NA_integer_
  given <- suppressWarnings(as.integer(cand$endPage))
  use <- ifelse(!is.na(given) & given >= cand$startPage & given <= computed,
                given, computed)
  cand$endPage <- as.integer(use)
  cand$resumeLength <- cand$endPage - cand$startPage + 1L
  rownames(cand) <- NULL
  cand
}

## Reconcile the two extraction layers. When both found a candidate, the
## earlier start page wins (the Shiny app's compare_text_OCR logic); a
## candidate found in only one layer is taken from that layer.
detect_candidates <- function(pages, people, n_pages) {
  text_layer <- clean_pdf_text(pages$text)
  res_text <- detect_layer(text_layer, people, "text")

  if (!is.null(pages$ocr)) {
    ocr_layer <- clean_pdf_text(pages$ocr)
    res_ocr <- detect_layer(ocr_layer, people, "ocr")
  } else {
    res_ocr <- list(hits = empty_hits(), todo = people)
  }

  a <- collapse_hits(res_text$hits)
  b <- collapse_hits(res_ocr$hits)
  both <- rbind(a, b)
  if (nrow(both)) {
    both <- both[order(both$email, both$startPage), , drop = FALSE]
    both <- both[!duplicated(both$email), , drop = FALSE]
  }
  matched <- finalise_pages(both, n_pages)

  unmatched_emails <- setdiff(people$email, matched$email)
  unmatched <- people[people$email %in% unmatched_emails, , drop = FALSE]
  unmatched <- data.frame(
    email = unmatched$email,
    missingFirstName = unmatched$firstName,
    missingLastName = unmatched$lastName,
    startPage = rep(NA_integer_, nrow(unmatched)),   # 0 rows when all matched
    endPage = rep(NA_integer_, nrow(unmatched)),
    stringsAsFactors = FALSE
  )
  rownames(unmatched) <- NULL

  msg("detected %d candidate(s) in %d page(s); %d not found",
      nrow(matched), n_pages, nrow(unmatched))
  list(matched = matched, unmatched = unmatched)
}

## Manual fixes ------------------------------------------------------------
## Read an edited unmatched_candidates.csv and fold the rows that now carry
## both page numbers into the candidate table.
merge_manual <- function(matched, manual_path, n_pages) {
  if (is.na(manual_path) || !file.exists(manual_path)) return(matched)
  man <- utils::read.csv(manual_path, stringsAsFactors = FALSE, check.names = FALSE)
  need <- c("startPage", "endPage")
  if (!all(need %in% names(man))) {
    acr_warn("%s has no startPage/endPage columns, ignoring it", manual_path)
    return(matched)
  }
  man$startPage <- suppressWarnings(as.integer(man$startPage))
  man$endPage <- suppressWarnings(as.integer(man$endPage))
  man <- man[!is.na(man$startPage) & !is.na(man$endPage), , drop = FALSE]
  if (!nrow(man)) {
    msg("%s contains no filled-in page numbers yet", manual_path)
    return(matched)
  }
  fn <- if ("missingFirstName" %in% names(man)) man$missingFirstName else man$firstName
  ln <- if ("missingLastName" %in% names(man)) man$missingLastName else man$lastName
  em <- if ("missingEmail" %in% names(man)) man$missingEmail else man$email
  add <- data.frame(email = tolower(trimws(em)),
                    firstName = tolower(trimws(fn)),
                    lastName = tolower(trimws(ln)),
                    startPage = man$startPage,
                    method = "manual",
                    endPage = man$endPage,
                    stringsAsFactors = FALSE)
  add <- add[!add$email %in% matched$email, , drop = FALSE]
  if (!nrow(add)) return(matched)

  cols <- union(names(matched), names(add))
  for (cl in setdiff(cols, names(matched))) matched[[cl]] <- NA
  for (cl in setdiff(cols, names(add))) add[[cl]] <- NA
  out <- rbind(matched[, cols, drop = FALSE], add[, cols, drop = FALSE])
  msg("merged %d manually located candidate(s) from %s", nrow(add), basename(manual_path))
  finalise_pages(out, n_pages)
}

## Ask for the missing page numbers on the console (-i/--interactive).
prompt_unmatched <- function(unmatched) {
  if (!nrow(unmatched) || !interactive_stdin()) return(unmatched)
  cat("\nEnter the start and end page for each candidate below (blank to skip).\n")
  for (i in seq_len(nrow(unmatched))) {
    cat(sprintf("\n%s %s <%s>\n", unmatched$missingFirstName[i],
                unmatched$missingLastName[i], unmatched$email[i]))
    s <- trimws(readline_stdin("  startPage: "))
    e <- trimws(readline_stdin("  endPage:   "))
    if (nzchar(s)) unmatched$startPage[i] <- suppressWarnings(as.integer(s))
    if (nzchar(e)) unmatched$endPage[i] <- suppressWarnings(as.integer(e))
  }
  unmatched
}

interactive_stdin <- function() {
  isTRUE(interactive()) || isatty(stdin())
}

readline_stdin <- function(prompt = "") {
  cat(prompt)
  utils::flush.console()
  line <- readLines(con = stdin(), n = 1L)
  if (!length(line)) "" else line
}
