## ---------------------------------------------------------------------------
## 07_report.R -- CSV, XLSX and PNG outputs
## The Shiny app's plotly charts and sf/GIS maps are deliberately not ported;
## the CLI ships static ggplot2 PNGs instead (see cliR4.6 instructions).
## ---------------------------------------------------------------------------

ACR_SERIES <- c("#2a78d6", "#eb6834", "#1baf7a", "#eda100",
                "#e87ba4", "#008300", "#4a3aa7", "#e34948")
ACR_SURFACE <- "#fcfcfb"
ACR_INK <- "#0b0b0b"
ACR_INK2 <- "#52514e"
ACR_GRID <- "#e4e4e0"

acr_theme <- function(base_size = 12) {
  ggplot2::theme_minimal(base_size = base_size) +
    ggplot2::theme(
      plot.background = ggplot2::element_rect(fill = ACR_SURFACE, colour = NA),
      panel.background = ggplot2::element_rect(fill = ACR_SURFACE, colour = NA),
      panel.grid.major.y = ggplot2::element_blank(),
      panel.grid.minor = ggplot2::element_blank(),
      panel.grid.major.x = ggplot2::element_line(colour = ACR_GRID, linewidth = 0.3),
      axis.ticks = ggplot2::element_blank(),
      axis.text = ggplot2::element_text(colour = ACR_INK2),
      axis.title = ggplot2::element_text(colour = ACR_INK2, size = base_size - 1),
      plot.title = ggplot2::element_text(colour = ACR_INK, face = "bold",
                                         size = base_size + 3),
      plot.subtitle = ggplot2::element_text(colour = ACR_INK2, size = base_size - 1),
      plot.caption = ggplot2::element_text(colour = ACR_INK2, size = base_size - 3),
      legend.position = "bottom",
      legend.title = ggplot2::element_blank(),
      legend.text = ggplot2::element_text(colour = ACR_INK2)
    )
}

candidate_labels <- function(df) {
  fn <- if ("Applicant First Name" %in% names(df)) df[["Applicant First Name"]] else ""
  ln <- if ("Applicant Last Name" %in% names(df)) df[["Applicant Last Name"]] else ""
  lab <- trimws(paste(fn, ln))
  blank <- !nzchar(lab) | grepl("^(NA ?)+$", lab)
  lab[blank] <- df$email[blank]
  dup <- lab %in% lab[duplicated(lab)]
  lab[dup] <- sprintf("%s (%s)", lab[dup], df$email[dup])
  lab
}

fold_for_chart <- function(df, cats) {
  if (length(cats) <= length(ACR_SERIES)) return(list(df = df, cats = cats))
  weight <- vapply(cats, function(c) sum(as.numeric(df[[c]]), na.rm = TRUE), numeric(1))
  keep <- cats[cats %in% names(sort(weight, decreasing = TRUE))[seq_len(length(ACR_SERIES) - 1L)]]
  rest <- setdiff(cats, keep)
  df[["Other"]] <- rowSums(as.data.frame(lapply(rest, function(c) as.numeric(df[[c]]))))
  list(df = df, cats = c(keep, "Other"))
}

chart_ranking <- function(scores, cats, path, title, subtitle, top_n) {
  if (!have_pkg("ggplot2")) return(invisible(NULL))
  df <- utils::head(scores[order(-scores[["Total Score"]]), , drop = FALSE], top_n)
  if (!nrow(df)) return(invisible(NULL))
  df$label <- candidate_labels(df)
  df$label <- factor(df$label, levels = rev(df$label))
  p <- ggplot2::ggplot(df, ggplot2::aes(x = .data[["Total Score"]], y = .data$label)) +
    ggplot2::geom_col(fill = ACR_SERIES[1L], width = 0.62) +
    ggplot2::geom_text(ggplot2::aes(label = .data[["Total Score"]]),
                       hjust = -0.35, colour = ACR_INK2, size = 3.2) +
    ggplot2::scale_x_continuous(expand = ggplot2::expansion(mult = c(0, 0.12))) +
    ggplot2::labs(title = title, subtitle = subtitle,
                  x = "Total score", y = NULL,
                  caption = "Scores are relative to this candidate pool (top resume in each category = 5).") +
    acr_theme()
  save_chart(p, path, n_rows = nrow(df))
}

chart_stacked <- function(scores, cats, path, title, subtitle, top_n) {
  if (!have_pkg("ggplot2")) return(invisible(NULL))
  df <- utils::head(scores[order(-scores[["Total Score"]]), , drop = FALSE], top_n)
  if (!nrow(df) || !length(cats)) return(invisible(NULL))
  df$label <- candidate_labels(df)
  folded <- fold_for_chart(df, cats)
  df <- folded$df
  cats <- folded$cats
  long <- do.call(rbind, lapply(cats, function(cat) data.frame(
    label = df$label, category = cat, score = as.numeric(df[[cat]]),
    total = df[["Total Score"]], stringsAsFactors = FALSE)))
  long$label <- factor(long$label, levels = rev(df$label))
  long$category <- factor(long$category, levels = cats)
  pal <- stats::setNames(ACR_SERIES[seq_along(cats)], cats)
  p <- ggplot2::ggplot(long, ggplot2::aes(x = .data$score, y = .data$label,
                                          fill = .data$category)) +
    ggplot2::geom_col(width = 0.62, colour = ACR_SURFACE, linewidth = 0.7) +
    ggplot2::scale_fill_manual(values = pal, drop = FALSE) +
    ggplot2::scale_x_continuous(expand = ggplot2::expansion(mult = c(0, 0.06))) +
    ggplot2::labs(title = title, subtitle = subtitle,
                  x = "Score by category (0-5 each)", y = NULL) +
    acr_theme() +
    ggplot2::guides(fill = ggplot2::guide_legend(nrow = 2, byrow = TRUE))
  save_chart(p, path, n_rows = nrow(df))
}

chart_heatmap <- function(scores, cats, path, title, subtitle, top_n) {
  if (!have_pkg("ggplot2")) return(invisible(NULL))
  df <- utils::head(scores[order(-scores[["Total Score"]]), , drop = FALSE], top_n)
  if (!nrow(df) || !length(cats)) return(invisible(NULL))
  df$label <- candidate_labels(df)
  long <- do.call(rbind, lapply(cats, function(cat) data.frame(
    label = df$label, category = cat, score = as.numeric(df[[cat]]),
    stringsAsFactors = FALSE)))
  long$label <- factor(long$label, levels = rev(df$label))
  long$category <- factor(long$category, levels = cats)
  p <- ggplot2::ggplot(long, ggplot2::aes(x = .data$category, y = .data$label,
                                          fill = .data$score)) +
    ggplot2::geom_tile(colour = ACR_SURFACE, linewidth = 1.2) +
    ggplot2::geom_text(ggplot2::aes(label = .data$score), size = 3.1,
                       colour = ifelse(long$score > 3, "#ffffff", ACR_INK)) +
    ggplot2::scale_fill_gradient(low = "#eaf1fa", high = "#14467f", limits = c(0, 5)) +
    ggplot2::labs(title = title, subtitle = subtitle, x = NULL, y = NULL) +
    acr_theme() +
    ggplot2::theme(panel.grid.major.x = ggplot2::element_blank(),
                   axis.text.x = ggplot2::element_text(angle = 20, hjust = 1),
                   legend.position = "right")
  save_chart(p, path, n_rows = nrow(df), width = 9 + 0.5 * length(cats))
}

save_chart <- function(p, path, n_rows, width = 10) {
  h <- max(3.5, 0.34 * n_rows + 2.2)
  ggplot2::ggsave(path, p, width = width, height = h, dpi = 150, bg = ACR_SURFACE)
  msg("chart: %s", path)
  invisible(path)
}

## ---------------------------------------------------------------------------
## XLSX writer, styled like the app's ResumeRank workbooks:
##   every sheet is an Excel table (TableStyleMedium17, banded rows, filter)
##   category score cells  -> #AEDEF5 + thin border
##   Total Score cells     -> #EAB139 + thin border
##   quartile cells        -> #A5BA73
## Only sheets carrying a "category_cols" attribute get the category fill, so
## Detailed Frequency and Proportion stay plain, as in the reference file.
## Empty sheets are still written (headers only) so every workbook has 3 sheets.
## ---------------------------------------------------------------------------
write_workbook <- function(path, sheets) {
  if (!have_pkg("openxlsx")) {
    acr_warn("openxlsx is not installed; skipping %s (CSVs were still written)", basename(path))
    return(invisible(NULL))
  }
  wb <- openxlsx::createWorkbook()
  head_fill <- openxlsx::createStyle(fgFill = "#AEDEF5", border = "TopBottomLeftRight",
                                     borderStyle = "thin")
  total_fill <- openxlsx::createStyle(fgFill = "#EAB139", border = "TopBottomLeftRight",
                                      borderStyle = "thin")
  quart_fill <- openxlsx::createStyle(fgFill = "#A5BA73")

  k <- 0L
  for (nm in names(sheets)) {
    df <- sheets[[nm]]
    if (is.null(df) || !ncol(df)) next
    k <- k + 1L
    cat_cols <- attr(df, "category_cols")
    df <- whole_numbers_as_integer(as.data.frame(df, stringsAsFactors = FALSE,
                                                 check.names = FALSE))
    sheet <- substr(nm, 1, 31)
    openxlsx::addWorksheet(wb, sheet)
    openxlsx::writeDataTable(wb, sheet = sheet, x = df, startRow = 1, startCol = 1,
                             tableStyle = "TableStyleMedium17",
                             withFilter = TRUE, bandedRows = TRUE)
    if (nrow(df)) {
      rows <- seq_len(nrow(df)) + 1L
      if (length(cat_cols)) {
        j <- match(cat_cols, names(df))
        j <- j[!is.na(j)]
        if (length(j)) openxlsx::addStyle(wb, sheet, head_fill, cols = j, rows = rows,
                                          gridExpand = TRUE)
      }
      if ("Total Score" %in% names(df)) {
        openxlsx::addStyle(wb, sheet, total_fill, cols = match("Total Score", names(df)),
                           rows = rows, gridExpand = TRUE)
      }
      if ("quartile" %in% names(df)) {
        openxlsx::addStyle(wb, sheet, quart_fill, cols = match("quartile", names(df)),
                           rows = rows, gridExpand = TRUE)
      }
    }
    openxlsx::setColWidths(wb, sheet, cols = seq_along(df), widths = "auto")
  }
  openxlsx::saveWorkbook(wb, path, overwrite = TRUE)
  msg("workbook: %s (%d sheet(s))", path, k)
  invisible(path)
}

## 3 instead of 3.0 in Excel: numeric columns holding only whole numbers -> integer
whole_numbers_as_integer <- function(df) {
  for (j in seq_along(df)) {
    x <- df[[j]]
    if (is.double(x) && all(is.na(x) | (is.finite(x) & x == round(x) & abs(x) < .Machine$integer.max)))
      df[[j]] <- as.integer(x)
  }
  df
}

## ---------------------------------------------------------------------------
## Score reports: one workbook per score type x weighting, three sheets:
##   Score Frequency | Detailed Frequency | Proportion
## ---------------------------------------------------------------------------
REPORT_CATEGORIES <- c(
  "data analysis & governance",
  "data visualization & reporting",
  "project & program management",
  "requirements & stakeholder management",
  "modernization & automation",
  "implementation & communication",
  "tax experience",
  "tax expertise & professional experience",
  "tax data, analytics & technology"
)
REPORT_NAME_COLS <- c("Applicant First Name", "Applicant Last Name", "email")
DETAILED_REPORT_COLS <- c(REPORT_NAME_COLS, "resumelength", "category", "keywords",
                          "Freq", "Freq_binary", "score_adjustment", "count", "wordcount")

## Report category label: lower case, single spaces. The keyword file may say
## "Data Analysis & Governance"; the report layout uses the lower-case form.
canon_category <- function(x) tolower(gsub("[[:space:]]+", " ", trimws(as.character(x))))

## Fixed category order. Categories in the keyword file but not in the layout
## are appended so the columns still add up to Total Score.
report_categories <- function(cats) {
  cats <- unique(canon_category(cats))
  missing <- setdiff(REPORT_CATEGORIES, cats)
  extra <- setdiff(cats, REPORT_CATEGORIES)
  if (length(missing)) acr_warn("keyword file has no terms for: %s (columns filled with 0)",
                                paste(missing, collapse = "; "))
  if (length(extra)) acr_warn("keyword categories not in the report layout, appended: %s",
                              paste(extra, collapse = "; "))
  c(REPORT_CATEGORIES, extra)
}

## Rename category columns (any case) to their report label.
canon_category_cols <- function(df, report_cats) {
  df <- as.data.frame(df, stringsAsFactors = FALSE, check.names = FALSE)
  hit <- canon_category(names(df)) %in% report_cats &
         !names(df) %in% c(REPORT_NAME_COLS, "resumelength", "Total Score", "quartile")
  names(df)[hit] <- canon_category(names(df)[hit])
  df
}

## Exactly `cols`, in order. Missing category columns -> 0, others -> "".
select_report_cols <- function(df, cols, cat_cols = character()) {
  df <- as.data.frame(df, stringsAsFactors = FALSE, check.names = FALSE)
  for (cl in setdiff(cols, names(df))) {
    df[[cl]] <- if (cl %in% cat_cols) rep(0, nrow(df)) else rep("", nrow(df))
  }
  out <- df[, cols, drop = FALSE]
  rownames(out) <- NULL
  out
}

score_report_sheet <- function(scores, report_cats) {
  cols <- c(REPORT_NAME_COLS, "resumelength", report_cats, "Total Score", "quartile")
  scores <- canon_category_cols(scores, report_cats)
  scores <- scores[order(-scores[["Total Score"]], scores$email), , drop = FALSE]
  out <- select_report_cols(scores, cols, report_cats)
  attr(out, "category_cols") <- report_cats     # blue fill on category cells
  out
}

## Raw per-category values (3 dp), rows in the same order as Score Frequency.
## No category fill, as in the reference workbook.
proportion_report_sheet <- function(prop, report_cats, order_email = NULL) {
  prop <- canon_category_cols(prop, report_cats)
  out <- select_report_cols(prop, c(REPORT_NAME_COLS, report_cats), report_cats)
  for (cl in report_cats) out[[cl]] <- round(as.numeric(out[[cl]]), 3)
  if (length(order_email)) {
    out <- out[order(match(out$email, order_email), out$email), , drop = FALSE]
    rownames(out) <- NULL
  }
  out
}

## count = number of distinct keywords in the category (the scoring denominator).
## To use Freq / wordcount instead, change the d$count line to: d$count <- d$ratio
detailed_report_sheet <- function(joined, keywords, name_table, order_email = NULL) {
  empty <- as.data.frame(
    stats::setNames(replicate(length(DETAILED_REPORT_COLS), character(0), simplify = FALSE),
                    DETAILED_REPORT_COLS),
    stringsAsFactors = FALSE, check.names = FALSE)
  if (!nrow(joined)) return(empty)
  d <- detailed_table(joined, name_table)
  if (!nrow(d)) return(empty)
  d$category <- canon_category(d$category)
  tpc <- tapply(keywords$keyword, canon_category(keywords$category),
                function(z) length(unique(z)))
  d$count <- as.integer(tpc[d$category])
  rank <- if (length(order_email)) match(d$email, order_email) else 0L
  d <- d[order(rank, d$email, d$category, d$keywords), , drop = FALSE]
  select_report_cols(d, DETAILED_REPORT_COLS)
}

write_score_report <- function(path, score_sheet, detailed_sheet, prop_sheet) {
  write_workbook(path, list("Score Frequency" = score_sheet,
                            "Detailed Frequency" = detailed_sheet,
                            "Proportion" = prop_sheet))
}
