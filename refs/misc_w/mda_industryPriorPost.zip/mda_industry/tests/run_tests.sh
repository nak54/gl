#!/usr/bin/env bash
# Unit tests, a synthetic end-to-end run with planted split SICs, ablations, and a shuffled-label negative control.
# Uses hashed vectors, so no model download.
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m pytest tests/test_priors.py tests/test_posterior.py -q
T="${1:-$(mktemp -d)}"; W="$T/work"; rm -rf "$W"
python3 tests/make_synthetic.py "$T"
python3 01_build_refs.py --workdir "$W" --refdir "$T/reference_files"
python3 02_filter_mda.py --workdir "$W" --input "$T/filings_in.parquet"
python3 03_embed_filings.py --workdir "$W" --backend hash
python3 04_build_labels.py --workdir "$W"
python3 05_train_classifier.py --workdir "$W" > "$T/train.log"
python3 06_rank_sic.py --workdir "$W"
python3 07_llm_review.py --workdir "$W" --mock
python3 08_build_output.py --workdir "$W"
python3 09_validate.py sample --workdir "$W" --n 80
python3 tests/check_results.py "$T"
python3 09_validate.py score --workdir "$W" --gold "$W/gold_simulated.csv" --bootstrap 100 > "$T/validation.json"
python3 - "$T/validation.json" <<'P'
import json, sys
r = json.load(open(sys.argv[1]))
print("validation naics3 accuracy:", {k: round(r[k]["naics3_accuracy"], 3) for k in ("sic_crosswalk_baseline", "model", "posterior", "final_with_llm")})
print("validation split-SIC filings:", {k: round(v, 3) for k, v in r["split_sic_filings"].items()})
print("validation naics6:", r.get("naics6"))
assert r["split_sic_filings"]["posterior"] > r["split_sic_filings"]["prior_top"]
P

# Ablations on the split SICs: no prior (alpha 0) and no relabeling (em-iters 0).
for cfg in "--alpha 0" "--em-iters 0"; do
  A="$T/ablate"; rm -rf "$A"; cp -r "$W" "$A"
  python3 05_train_classifier.py --workdir "$A" $cfg > /dev/null
  python3 - "$A" "$T" "$cfg" <<'P'
import sys, pandas as pd
a, t, cfg = sys.argv[1:]
d = pd.read_parquet(f"{a}/predictions_oof.parquet").merge(pd.read_parquet(f"{t}/truth.parquet"), on="accession")
s, wk = d[d.scenario == "split_naics3"], d[d.scenario == "split_weak_text"]
print(f"ablation {cfg}: split accuracy={(s.naics3_constrained == s.true_naics3).mean():.3f} weak-text follows prior={(wk.naics3_constrained == '212').mean():.3f}")
P
done

# Negative control: shuffled company SICs should collapse agreement to about chance.
N="$T/neg"; rm -rf "$N"; mkdir -p "$N"; cp -r "$W/ref" "$N/ref"
python3 - "$W" "$N" <<'P'
import sys, numpy as np, pandas as pd, shutil
w, n = sys.argv[1:]
f = pd.read_parquet(f"{w}/filings.parquet")
keep = ["accession", "cik", "year", "sic", "company", "kept_text", "filter_fallback", "sections_kept", "kept_words"]
f = f[keep]
m = f.drop_duplicates("cik")[["cik", "sic"]]
m["sic"] = np.random.default_rng(1).permutation(m["sic"].values)
f = f.drop(columns="sic").merge(m, on="cik").set_index("accession").loc[pd.read_parquet(f"{w}/filings.parquet")["accession"]].reset_index()
f.to_parquet(f"{n}/filings.parquet", index=False)
for x in ("chunks.parquet", "chunk_vectors.npy", "filing_vectors.npy", "embedding_meta.json"):
    shutil.copy(f"{w}/{x}", f"{n}/{x}")
P
python3 04_build_labels.py --workdir "$N" > /dev/null
python3 05_train_classifier.py --workdir "$N" > "$T/neg.log"
python3 -c "import json; m=json.load(open('$N/metrics.json')); v=m['oof_eligible']['naics3_top1_in_sic_candidates']; print('NEGATIVE CONTROL naics3 top1:', round(v,3)); assert v < 0.25"
echo ALL TESTS PASSED
