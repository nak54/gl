# MD&A industry classifier

Assigns SIC, NAICS2, and NAICS3 labels to 2019, 2024, and 2025 MD&A filings. The filed SIC serves as a noisy training label, not the answer.

## Setup

```bash
pip install -r requirements.txt
```

### Input Parquet

Required: `accession`, `cik`, `year`, `sic`, `mda_text`. Optional: `ticker`, `company`. Use `--text-col` if your text column has another name.

### Reference files

Put these in `reference_files/`. Excel files can be `.xls` or `.xlsx`.

| File | Source |
|---|---|
| `sic1987_to_naics2002` | Census: 1987 SIC to 2002 NAICS |
| `naics2002_to_naics2007` | Census: 2002 NAICS to 2007 NAICS |
| `naics2007_to_naics2012` | Census: 2007 NAICS to 2012 NAICS |
| `naics2012_to_naics2017` | Census: 2012 NAICS to 2017 NAICS |
| `naics2017_to_naics2022` | Census: 2017/2022 concordance in either direction |
| `naics2022_codes` | Census: 2022 NAICS 2-6 digit code list |
| `sec_sic_list.csv` | SEC SIC code list, saved with columns `SIC Code`, `Industry Title` |
| `census_bridge_sic_naics1997.csv` (optional) | Census 1997 Economic Census Bridge, Table 2, as a tidy CSV (see below) |
| `naics1997_to_naics2002` (required with the Bridge) | Census: 1997 NAICS to 2002 NAICS |
| `bls_sic_naics2002_ratios.html` or `.csv` (optional) | BLS CES "SIC 4-digit to NAICS 2002 ratios" page, saved as HTML |
| `naics2022_descriptions` (optional) | Census 2022 NAICS descriptions; improves 6-digit matching |

Census concordances: https://www.census.gov/naics/concordances/concordances.html
BLS ratios: https://www.bls.gov/ces/naics/sic-4-digit-to-naics-2002-ratios.htm
Census Bridge (archived): https://webarchive.library.unt.edu/web/20081109110906/http:/www.census.gov/epcd/ec97brdg/introbdg.htm

### Bridge CSV format

One row per SIC x NAICS 1997 piece. Leave out the SIC total rows and copy cells as published:

```
sic,naics,shipments,employees,payroll,establishments
2035,311421,"1,470,495","7,935","189,005",129
2035,311941,"5,583,554","12,681","412,045",225
2087,311999,D (1000-2499),D,D,32
```

Weights come from the piece values (1,470,495 / 7,054,049 = 20.8%). The printed "9% of 311421" is
the piece's share of the NAICS code, the reverse direction, and is not used. "D (low-high)"
cells use the range midpoint; a "D" with no range moves to the next measure.

SEC list: https://www.sec.gov/search-filings/standard-industrial-classification-sic-code-list

## Run

```bash
./run_all.sh path/to/filings.parquet work                 # LLM dry run
export ANTHROPIC_API_KEY=...
python 07_llm_review.py --workdir work --limit 25         # Inspect a small batch first
python 07_llm_review.py --workdir work                    # Resumes and finishes the queue
python 08_build_output.py --workdir work
python 09_validate.py sample --workdir work               # Fill in gold_naics3 from the 10-K
python 09_validate.py score --workdir work --gold work/validation_sheet.csv
```

Main result: `work/industry_labels.parquet` and `.csv`.

## Scripts

| Script | Purpose |
|---|---|
| `01_build_refs.py` | Builds the weighted SIC to NAICS 2022 crosswalk: Bridge, then BLS, then equal weights, carried through each vintage |
| `02_filter_mda.py` | Validates input, keeps business sections, and chunks at 220 words |
| `03_embed_filings.py` | Embeds chunks and builds filing vectors |
| `04_build_labels.py` | Builds weighted labels, with fallback for SEC group codes such as 7370 |
| `05_train_classifier.py` | Trains NAICS2 then NAICS3, calibrates, combines with the prior, and relabels |
| `06_rank_sic.py` | Ranks SICs and picks 6-digit NAICS from prior x embedding similarity |
| `07_llm_review.py` | Reviews flagged filings with constrained choices and verified quotes |
| `08_build_output.py` | Builds the final table |
| `09_validate.py` | Creates a blinded labeling sheet and scores it with sampling weights |

## How the prior and the MD&A text combine

For filing i with filed SIC s, over the NAICS3 codes linked to s:

    P(c | text, s) ∝ max(prior(c|s), floor)^alpha × P(c | text) / pi(c)

- `prior(c|s)`: economic weight from `priors.py`.
- `P(c | text)`: calibrated out-of-fold classifier probability.
- `pi(c)`: class prior implied by balanced training, divided out to avoid counting the prior twice.
- `alpha` (default 1): trust in the prior. `floor` (default 0.01): lets strong text pick a rare link.

Script 05 repeats training with the posterior as each filing's soft label (`--em-iters`, default 2).
`sic_suspect` is set when most text probability falls outside the SIC's candidates and the top
outside code has at least `--suspect-min-conf` probability. Diffuse text falls back to the prior.

Script 06 picks 6-digit NAICS among the SIC's links under the chosen NAICS3, with
likelihood exp(cosine(filing, NAICS title + description) / tau).

`naics3_final` precedence: verified LLM answer, then `naics3_pred` if `sic_suspect`, then `naics3_constrained`.

## Key columns

- `sic_sec`, `sic_title`: filed SIC and title
- `naics_xwalk`: all NAICS3 candidates for the filed SIC
- `naics2_pred`, `naics3_pred`, `pred_conf`: model output
- `naics3_secondary`: other industries suggested by segment text
- `prior_source`, `naics3_prior`, `prior_top_share`, `split_sic`: economic prior for the filed SIC
- `naics3_constrained`, `constrained_conf`, `naics3_posterior`: posterior over the SIC's candidates
- `out_of_set_mass`, `sic_suspect`: text evidence that the filed SIC is wrong
- `naics6_pred`, `naics6_conf`, `naics6_final`: 6-digit choice
- `agrees_with_sic`: predicted NAICS3 holds at least 10% of the SIC's prior
- `naics3_final`, `naics2_final`, `sic_final`, `final_source`: final labels and origin
- `needs_human_review`: flagged and not resolved by a verified LLM answer

## Tuning

Tune `--alpha`, `--floor` (script 05), and `--tau` (script 06) on hand labels. `09_validate.py score`
reports prior-only, text-only, and posterior accuracy, overall and for split-SIC filings.

Secondary-industry defaults (`--secondary-min-prob 0.12`, `--secondary-min-lift 2`) were set on synthetic data. Re-tune them on hand labels. Review thresholds are `--conf-threshold` and `--margin-threshold` in script 07.

`final_model.joblib` stores the fitted objects as a dictionary for later scoring.

## Test

```bash
bash tests/run_tests.sh
```

Runs 36 unit tests (Census and BLS figures for SIC 2035, 2077, 2087, 1099, 1542), a synthetic
end-to-end run with planted split SICs, ablations (no prior, no relabeling), and a shuffled-SIC
negative control. Synthetic scores test the mechanics, not real accuracy.
