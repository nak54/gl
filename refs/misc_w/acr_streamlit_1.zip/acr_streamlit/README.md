# Automated Candidate Review — Streamlit port

A Python/Streamlit rebuild of the R Shiny ACR app: take one PDF containing every
applicant's resume, find where each candidate's resume starts and ends, extract the
text, and rank candidates with a **bag-of-words** keyword model.

## Install & run

```bash
pip install -r requirements.txt
# optional but recommended — enables the OCR fallback:
#   Ubuntu/Debian: sudo apt install tesseract-ocr
#   macOS:         brew install tesseract
#   Windows:       https://github.com/UB-Mannheim/tesseract/wiki
streamlit run app.py
```

Headless (no browser), same pipeline — the keywords argument is optional and defaults
to the built-in dictionary:

```bash
python samples/make_samples.py          # writes sample_names.xlsx + sample_keywords.csv
python run_headless.py DS_demo_resumes.pdf samples/sample_names.xlsx --out acr_output
# or with your own set:
python run_headless.py DS_demo_resumes.pdf samples/sample_names.xlsx my_keywords.csv
```

## Input files

**Names Spreadsheet** (`.xlsx`/`.csv`) — required columns:

| column | used for |
|---|---|
| `Applicant First Name` | name matching, output tables |
| `Applicant Middle Name` | output tables |
| `Applicant Last Name` | name matching, output tables |
| `Applicant Email Address` | join key throughout; email matching |
| `Applicant Phone Number` | phone matching fallback |

Any other columns (`Application Locations`, `Vacancy Job Title`, …) ride along into
the scored output.

**Keywords file** (`.csv`/`.xlsx`) — `category`, `keyword`, `score_adjustment`.
`score_adjustment` is the weight used by the weighted score; it defaults to 1.

### Built-in keyword dictionary

`data/DS_demo_keywords.csv` ships with the app and is **loaded automatically** on the
Score Resumes step — you can rank a batch without uploading a keywords file at all.
242 keywords in 5 categories:

| category | keywords |
|---|---|
| Data Analysis | 67 |
| Data Modeling | 47 |
| Data Visualizations | 18 |
| Programming Languages and Tools | 76 |
| project management | 34 |

Every weight in it is `1`, so the weighted and unweighted rankings come out identical
until you edit some — the Score Resumes table is editable in place, and **Reset edits
to the built-in set** puts it back. Switch the **Keyword set** radio to *Upload my own*
for a different dictionary; to change the default permanently, replace
`data/DS_demo_keywords.csv`.

Five duplicate `(category, keyword)` rows in the shipped file are collapsed on load
(`linux` ×3, `python` ×2, `machine learning` ×2, `monte carlo` ×2). A keyword repeated
inside one category would be counted once but still inflate that category's divisor,
skewing its score down. The same keyword in two *different* categories (`plotlyjs`) is
legitimate and is kept in both.

## What each module ports

| Python | R original |
|---|---|
| `acr/parse.py` | `R/parse.R` — pdftools text + Tesseract OCR per page (threads instead of `doParallel`) |
| `acr/clean.py` | `R/clean.R` — `clean_pdf_text()`, `clean_ngrams()` |
| `acr/search.py` | `R/search.R`, `R/update_resume_df.R`, `R/collapse_resume_df.R`, `R/compare_text_OCR.R` |
| `acr/bow.py` | `R/optimize_extract.R`, `R/bow.R`, `R/corpus.R`, quanteda `tokenize()` |
| `acr/score.py` | `aggregate_normalize_score()` in `R/score.R` |
| `acr/export.py` | `R/output_score.R` + the Shiny download handlers |
| `acr/pipeline.py` | the `observeEvent` chains in `server.R` |
| `app.py` | `ui.R` + `server.R` rendering |

Not ported: the CONUS/HI/AK applicant-location maps (`R/map.R`,
`R/selection_events.R`), which depend on the `www/` shapefile and the GDI workstation
workbook.

## The pipeline

1. **Extract** — every page is read twice: embedded PDF text and (optionally)
   Tesseract OCR of a rendered page.
2. **Detect candidates** — for each applicant, find the first page carrying their
   first+last name close together; failing that their email; failing that their phone
   number, matched against a digits-only version of the page. Run over both extraction
   routes and reconcile: found by both → earlier start page wins; found by one → that
   one wins. Anyone found by neither goes into the editable "not found" table.
3. **Assign ranges** — resumes are contiguous, so `endPage` is the page before the next
   candidate starts; the last candidate runs to the end of the PDF.
4. **Split** — one `<email>_resume.pdf` per candidate.
5. **Pick the better extraction** — per page, keep whichever route matched more distinct
   keywords, then join that candidate's pages into one document.
6. **Score**:

   ```
   ratio           = keyword frequency / resume length
   Freq_normalized = 1 + (ratio - min) / (max - min) * 4          -> [1, 5]
   weighted only:  Freq_normalized *= score_adjustment
   per (category, resume): sum, then / number of keywords in that category
   per category column:    ceil(value * 5 / column max)           -> 1..5
   Total Score     = sum of the category scores
   quartile        = quartile of Total Score across the pool
   ```

7. **Rank & export** — sortable tables, a plain or category-stacked bar chart with the
   matched keywords in the hover, top-*N* / top-*x%* filters, a three-sheet styled
   workbook (Score Frequency / Detailed Frequency / Proportion) and a zip of the top
   candidates' resumes.

## Faithfulness notes

Two quirks of the R implementation are reproduced deliberately, because changing them
changes every score:

- **`wordcount` is a character count**, not a word count — `str_count()` was called
  without a pattern in `bow.R`, and the normalisation divides by it.
- **Min/max for the 1–5 rescale are global**, taken across every keyword × resume pair
  rather than per resume or per category, so scores are relative to the applicant pool.

Two behaviours differ:

- OCR runs in a **thread pool** (`concurrent.futures`) rather than a `makeCluster`
  fork, and defaults to 300 dpi instead of 600 — 600 dpi is available in the sidebar
  and is markedly slower for little gain on most resumes.
- Keyword matching uses regex with boundaries that tolerate `c++`, `c#` and `r&d`
  rather than quanteda's tokenizer, so symbol-bearing keywords match where quanteda
  would have dropped them.

- **Duplicate keyword rows are collapsed** (see above). The R version left them in,
  where they quietly deflated that category's score.

## Verified against

`DS_demo_resumes.pdf` (19 pages, 9 applicants): all 9 candidates detected — 8 by name,
1 by phone number — with page ranges 1, 2–5, 6–7, 8–10, 11, 12–13, 14–15, 16, 17–19,
and identical rankings with and without OCR enabled.

Ranked with the built-in dictionary:

| # | applicant | analysis | modeling | visualization | programming | proj. mgmt | total |
|---|---|---|---|---|---|---|---|
| 1 | Judie Goode | 5 | 4 | 5 | 5 | 2 | **21** |
| 2 | Bridgette Fortier | 4 | 2 | 4 | 2 | 5 | **17** |
| 3 | Séréna Giraud | 3 | 4 | 4 | 5 | 0 | **16** |
| 4 | Ha-Yoon Burton | 2 | 2 | 3 | 5 | 3 | **15** |
| 5 | Ségolène Moss | 3 | 5 | 1 | 2 | 1 | **12** |
| 6 | Raewyn Bateson | 3 | 5 | 0 | 2 | 1 | **11** |
| 7 | Mukhtaar Takenaka | 1 | 1 | 3 | 4 | 0 | **9** |
| 8 | Jonah Dickerson | 1 | 0 | 0 | 1 | 1 | **3** |
| 9 | Roslyn Beck | 0 | 0 | 0 | 1 | 1 | **2** |
