"""Headless end-to-end run — same pipeline the Streamlit app drives.

Usage:
    python run_headless.py resumes.pdf names.xlsx keywords.csv [--no-ocr] [--out DIR]
"""
from __future__ import annotations

import argparse
import os

import pandas as pd

from acr import export, pipeline, score, search

DEFAULT_KEYWORDS = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "data", "DS_demo_keywords.csv"
)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf")
    ap.add_argument("names")
    ap.add_argument(
        "keywords",
        nargs="?",
        default=DEFAULT_KEYWORDS,
        help="category/keyword/score_adjustment file "
        "(default: the built-in data science dictionary)",
    )
    ap.add_argument("--no-ocr", action="store_true")
    ap.add_argument("--out", default="acr_output")
    args = ap.parse_args()
    if not os.path.exists(args.keywords):
        ap.error(f"keywords file not found: {args.keywords}")

    os.makedirs(args.out, exist_ok=True)
    use_ocr = not args.no_ocr

    name_table = (
        pd.read_csv(args.names) if args.names.lower().endswith(".csv") else pd.read_excel(args.names)
    )
    kw = (
        pd.read_csv(args.keywords)
        if args.keywords.lower().endswith(".csv")
        else pd.read_excel(args.keywords)
    )
    keywords = score.prepare_keywords(kw)
    candidates = search.build_candidate_table(name_table)

    print(f"Parsing {args.pdf} (OCR: {use_ocr}) …")
    parsed = pipeline.parse_and_clean(
        args.pdf, use_ocr=use_ocr, progress=lambda f, m: print(f"  [{f:5.0%}] {m}")
    )

    processed, unmatched = search.detect_candidates(
        candidates,
        parsed.text_clean,
        parsed.text_numbers,
        parsed.ocr_clean,
        parsed.ocr_numbers,
        parsed.n_pages,
        use_ocr=use_ocr,
    )
    print(f"\nDetected {len(processed)} / {len(candidates)} candidates")
    print(processed[["firstName", "lastName", "startPage", "endPage", "matchedBy"]].to_string(index=False))
    if not unmatched.empty:
        print("\nNot found:")
        print(unmatched[["firstName", "lastName", "email"]].to_string(index=False))

    split_files = pipeline.split_resumes(args.pdf, processed, os.path.join(args.out, "resumes"))
    res = pipeline.score_resumes(parsed, processed, keywords, name_table, split_files, use_ocr=use_ocr)

    if res["final_df"].empty:
        print("\nNo keywords matched.")
        return 1

    categories = sorted(keywords["category"].unique())
    for label, key in (("unweighted", "scores"), ("weighted", "scores_weighted")):
        df = res[key]
        cols = ["Applicant First Name", "Applicant Last Name"] + categories + ["Total Score", "quartile"]
        cols = [c for c in cols if c in df.columns]
        print(f"\n=== Ranking ({label}) ===")
        print(df[cols].to_string(index=False))
        path = os.path.join(args.out, f"ACR_scores_{label}.xlsx")
        with open(path, "wb") as fh:
            fh.write(
                export.build_workbook(
                    df,
                    res["detailed"],
                    res["proportion_weighted"] if label == "weighted" else res["proportion"],
                    categories,
                )
            )
        print(f"wrote {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
