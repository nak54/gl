"""End-to-end orchestration, usable from Streamlit or a plain script."""
from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass
from typing import Callable, List, Optional, Sequence

import pandas as pd
import pymupdf

from . import bow as bow_mod
from . import clean as clean_mod
from . import parse as parse_mod
from . import score as score_mod
from . import search as search_mod


@dataclass
class ParsedPdf:
    extraction: parse_mod.Extraction
    text_clean: List[str]
    text_numbers: List[str]
    ocr_clean: List[str]
    ocr_numbers: List[str]
    n_pages: int


def parse_and_clean(
    pdf_path: str,
    use_ocr: bool = True,
    dpi: int = 300,
    progress: Optional[Callable[[float, str], None]] = None,
) -> ParsedPdf:
    ex = parse_mod.parse_pdf(pdf_path, use_ocr=use_ocr, dpi=dpi, progress=progress)
    t_clean, t_num, _ = clean_mod.clean_pdf_text(ex.pdf_text)
    o_clean, o_num, _ = clean_mod.clean_pdf_text(ex.ocr_text)
    return ParsedPdf(ex, t_clean, t_num, o_clean, o_num, ex.n_pages)


def split_resumes(pdf_path: str, processed_df: pd.DataFrame, out_dir: Optional[str] = None) -> List[str]:
    """Port of save_individual_resumes(): one PDF per candidate, named <email>_resume.pdf."""
    out_dir = out_dir or tempfile.mkdtemp(prefix="acr_resumes_")
    os.makedirs(out_dir, exist_ok=True)
    src = pymupdf.open(pdf_path)
    files = []
    try:
        for _, row in processed_df.iterrows():
            start, end = int(row["startPage"]), int(row["endPage"])
            safe = str(row["email"]).replace("/", "_").replace("\\", "_")
            path = os.path.join(out_dir, f"{safe}_resume.pdf")
            out = pymupdf.open()
            out.insert_pdf(src, from_page=start - 1, to_page=end - 1)
            out.save(path)
            out.close()
            files.append(path)
    finally:
        src.close()
    return files


def score_resumes(
    parsed: ParsedPdf,
    processed_df: pd.DataFrame,
    keywords_df: pd.DataFrame,
    name_table: pd.DataFrame,
    split_files: Sequence[str],
    use_ocr: bool = True,
):
    """Run the BoW scoring chain. Returns a dict of result frames."""
    keywords = score_mod.prepare_keywords(keywords_df)

    text_pages = clean_mod.clean_ngrams(parsed.extraction.pdf_text)
    ocr_pages = clean_mod.clean_ngrams(parsed.extraction.ocr_text)

    page_choice_texts, resume_texts, extraction_report = bow_mod.find_optimum_extraction(
        text_pages,
        ocr_pages,
        keywords["keyword"].tolist(),
        processed_df,
        use_ocr=use_ocr and parsed.extraction.ocr_used,
    )

    unlisted, count_df = bow_mod.build_bow_inputs(resume_texts)
    corpus = bow_mod.create_clean_corpus(unlisted)

    # resume length in pages, as the R app overwrites it after bow()
    count_df["resumelength"] = list(processed_df["resumeLength"].astype(int))

    final_df = bow_mod.tokenize(corpus, keywords, split_files)

    if final_df.empty:
        return {
            "keywords": keywords,
            "final_df": final_df,
            "extraction_report": extraction_report,
            "scores": pd.DataFrame(),
            "scores_weighted": pd.DataFrame(),
            "detailed": pd.DataFrame(),
            "proportion": pd.DataFrame(),
            "proportion_weighted": pd.DataFrame(),
            "matched_keywords": pd.DataFrame(),
        }

    scores, scores_w, detailed, prop, prop_w = score_mod.aggregate_normalize_score(
        keywords, final_df, count_df, list(split_files), name_table
    )

    return {
        "keywords": keywords,
        "final_df": final_df,
        "extraction_report": extraction_report,
        "scores": scores,
        "scores_weighted": scores_w,
        "detailed": detailed,
        "proportion": prop,
        "proportion_weighted": prop_w,
        "matched_keywords": score_mod.matched_keywords_by_category(detailed),
    }
