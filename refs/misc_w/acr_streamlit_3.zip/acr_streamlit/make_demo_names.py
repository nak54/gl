"""Regenerate the demo Names Spreadsheet in data/ for the bundled DS_demo_resumes.pdf."""
import os

import pandas as pd

HERE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

names = pd.DataFrame(
    [
        ("Séréna", "", "Giraud", "SérénaGiraud@aol.com", "137 951-1480", "Berkeley, CA"),
        ("Bridgette", "", "Fortier", "BridgetteFortier@yahoo.com", "576-023-8722", "Baton Rouge, LA"),
        ("Mukhtaar", "", "Takenaka", "MukhtaarTakenaka@hotmail.com", "267 417-4233", "Austin, TX"),
        ("Jonah", "", "Dickerson", "JonahDickerson@gmail.com", "(842) 849-6313", "Atlanta, GA"),
        ("Ha-Yoon", "", "Burton", "Ha-YoonBurton@gmail.com", "392-306-0608", "Seattle, WA"),
        ("Judie", "A.", "Goode", "JudieGoode@gmail.com", "622-304-7081", "Denton, TX"),
        ("Ségolène", "", "Moss", "SégolèneMoss@gmail.com", "339-012-8521", "Boston, MA"),
        ("Raewyn", "", "Bateson", "RewynBateson@yahoo.com", "882-703-0061", "St. Petersburg, FL"),
        ("Roslyn", "", "Beck", "RoslynBeck@aol.com", "555-100-2000", "Chicago, IL"),
    ],
    columns=[
        "Applicant First Name",
        "Applicant Middle Name",
        "Applicant Last Name",
        "Applicant Email Address",
        "Applicant Phone Number",
        "Application Locations",
    ],
)

if __name__ == "__main__":
    os.makedirs(HERE, exist_ok=True)
    out = os.path.join(HERE, "DS_demo_names.xlsx")
    names.to_excel(out, index=False)
    print(f"wrote {out}")
