"""Workbook / zip export — port of R/output_score.R and the download handlers."""
from __future__ import annotations

import io
import os
import zipfile
from typing import Sequence

import pandas as pd
from openpyxl.styles import Border, PatternFill, Side
from openpyxl.utils import get_column_letter

RANK_FILL = PatternFill("solid", fgColor="AEDEF5")
TOTAL_FILL = PatternFill("solid", fgColor="EAB139")
QUARTILE_FILL = PatternFill("solid", fgColor="A5BA73")
THIN = Border(*[Side(style="thin")] * 4)


def _clean(df: pd.DataFrame) -> pd.DataFrame:
    return df.copy() if df is not None else pd.DataFrame()


def build_workbook(
    scores: pd.DataFrame,
    detailed: pd.DataFrame,
    proportion: pd.DataFrame,
    categories: Sequence[str],
) -> bytes:
    """Three-sheet workbook with the same colour coding as output_score.R."""
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as xw:
        _clean(scores).to_excel(xw, sheet_name="Score Frequency", index=False)
        _clean(detailed).to_excel(xw, sheet_name="Detailed Frequency", index=False)
        _clean(proportion).to_excel(xw, sheet_name="Proportion", index=False)

        ws = xw.sheets["Score Frequency"]
        cols = list(scores.columns)
        n_rows = len(scores)
        cat_idx = [cols.index(c) + 1 for c in categories if c in cols]
        for ci in cat_idx:
            for r in range(2, n_rows + 2):
                cell = ws.cell(row=r, column=ci)
                cell.fill = RANK_FILL
                cell.border = THIN
        if "Total Score" in cols:
            ci = cols.index("Total Score") + 1
            for r in range(2, n_rows + 2):
                cell = ws.cell(row=r, column=ci)
                cell.fill = TOTAL_FILL
                cell.border = THIN
        if "quartile" in cols:
            ci = cols.index("quartile") + 1
            for r in range(2, n_rows + 2):
                ws.cell(row=r, column=ci).fill = QUARTILE_FILL

        for sheet in xw.sheets.values():
            for i, col in enumerate(sheet.iter_cols(min_row=1, max_row=1), start=1):
                header = col[0].value
                width = min(max(12, len(str(header)) + 4), 40)
                sheet.column_dimensions[get_column_letter(i)].width = width
            sheet.freeze_panes = "A2"
    return buf.getvalue()


def zip_files(paths: Sequence[str]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in paths:
            if os.path.exists(p):
                zf.write(p, arcname=os.path.basename(p))
    return buf.getvalue()
