"""Aggregate / normalise / score — port of aggregate_normalize_score() in R/score.R.

Scoring, verbatim from the R implementation:

  ratio            = keyword Freq / resume wordcount
  Freq_normalized  = 1 + (ratio - min) / (max - min) * 4      -> [1, 5], global min/max
  (weighted only)  Freq_normalized *= score_adjustment
  per (category, resume): sum Freq_normalized, divide by the number of keywords
                          defined in that category  -> adj_freq_normalized
  per category column:    ceiling(value * 5 / column max)     -> 1..5 category score
  Total Score      = row sum of the category scores
  quartile         = quartile of Total Score across the applicant pool
"""
from __future__ import annotations

import math
from typing import List, Sequence, Tuple

import numpy as np
import pandas as pd

NAME_EMAIL_COL = "Applicant Email Address"


def _email_from_path(path: str) -> str:
    base = str(path).replace("\\", "/").split("/")[-1]
    return base.split("_resume.pdf")[0]


def prepare_keywords(df: pd.DataFrame) -> pd.DataFrame:
    """Lowercase category/keyword, default score_adjustment to 1."""
    out = df.copy()
    out.columns = [str(c).strip() for c in out.columns]
    rename = {}
    for c in out.columns:
        lc = c.lower()
        if lc == "category":
            rename[c] = "category"
        elif lc == "keyword":
            rename[c] = "keyword"
        elif lc in ("score_adjustment", "weight", "score adjustment"):
            rename[c] = "score_adjustment"
    out = out.rename(columns=rename)
    for req in ("category", "keyword"):
        if req not in out.columns:
            raise ValueError(
                "Keywords file must have 'category' and 'keyword' columns "
                "(plus an optional 'score_adjustment' weight)."
            )
    if "score_adjustment" not in out.columns:
        out["score_adjustment"] = 1.0
    out["category"] = out["category"].astype(str).str.strip().str.lower()
    out["keyword"] = out["keyword"].astype(str).str.strip().str.lower()
    out["score_adjustment"] = pd.to_numeric(
        out["score_adjustment"], errors="coerce"
    ).fillna(1.0)
    out = out[(out["keyword"] != "") & (out["keyword"] != "nan")]
    out = out[["category", "keyword", "score_adjustment"]]

    # A keyword repeated inside one category would be counted once but inflate
    # that category's denominator, and would fan out the scoring join into
    # duplicate rows. Collapse them, keeping the strongest weight. The same
    # keyword in two DIFFERENT categories is legitimate and is kept.
    out = (
        out.sort_values("score_adjustment", ascending=False)
        .drop_duplicates(subset=["category", "keyword"], keep="first")
        .sort_index()
        .reset_index(drop=True)
    )
    return out


def count_duplicate_keywords(df: pd.DataFrame) -> int:
    """How many rows prepare_keywords() would collapse — for a UI note."""
    try:
        raw = df.copy()
        raw.columns = [str(c).strip().lower() for c in raw.columns]
        if "category" not in raw or "keyword" not in raw:
            return 0
        raw["category"] = raw["category"].astype(str).str.strip().str.lower()
        raw["keyword"] = raw["keyword"].astype(str).str.strip().str.lower()
        return int(len(raw) - len(raw.drop_duplicates(subset=["category", "keyword"])))
    except Exception:
        return 0


def _quartile(total: pd.Series) -> pd.Series:
    q1, q2, q3 = (total.quantile(p) for p in (0.25, 0.50, 0.75))
    return pd.Series(
        np.where(
            total > q3, 4, np.where(total > q2, 3, np.where(total > q1, 2, 1))
        ),
        index=total.index,
    )


def _create_scores_table(
    joined: pd.DataFrame,
    keywords: pd.DataFrame,
    resume_length: pd.DataFrame,
    split_files: Sequence[str],
    name_table: pd.DataFrame,
    categories: List[str],
    weighted: bool,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    j = joined.copy()

    ratio = j["Freq"] / j["wordcount"].replace(0, np.nan)
    lo, hi = ratio.min(), ratio.max()
    span = (hi - lo) if (hi - lo) else 1.0
    j["Freq_normalized"] = 1 + ((ratio - lo) / span) * 4
    j["Freq_normalized"] = j["Freq_normalized"].fillna(1.0)

    if weighted:
        j["Freq_normalized"] = j["Freq_normalized"] * j["score_adjustment"]

    clusters = (
        j.groupby(["category", "column_lab", "split_files"], as_index=False)
        .agg(Freq_normalized=("Freq_normalized", "sum"), count=("count", "mean"))
    )
    clusters["adj_freq_normalized"] = clusters["Freq_normalized"] / clusters["count"]

    wide = clusters.pivot_table(
        index="split_files",
        columns="category",
        values="adj_freq_normalized",
        aggfunc="sum",
        fill_value=0.0,
    ).reset_index()
    wide.columns.name = None

    proportion = wide.copy()
    proportion["email"] = proportion["split_files"].map(_email_from_path)

    scores = wide.copy()
    present = [c for c in scores.columns if c != "split_files"]
    for col in present:
        mx = scores[col].max()
        factor = (5.0 / mx) if mx else 0.0
        scores[col] = np.ceil(scores[col] * factor)

    for cat in categories:  # categories with zero matches anywhere
        if cat not in scores.columns:
            scores[cat] = 0.0
            proportion[cat] = 0.0

    scores["total"] = scores[categories].sum(axis=1)
    scores["email"] = scores["split_files"].map(_email_from_path)
    scores = scores.merge(resume_length, on="split_files", how="left")

    # resumes with no keyword hits at all -> all-zero rows
    missing = [f for f in split_files if f not in set(scores["split_files"])]
    if missing:
        extra = pd.DataFrame({"split_files": missing})
        for cat in categories:
            extra[cat] = 0.0
        extra["total"] = 0.0
        extra["email"] = extra["split_files"].map(_email_from_path)
        extra["resumelength"] = np.nan
        scores = pd.concat([scores, extra], ignore_index=True)
        proportion = pd.concat(
            [proportion, extra.drop(columns=["total", "resumelength"])],
            ignore_index=True,
        )

    scores["quartile"] = _quartile(scores["total"])
    scores = scores.sort_values("total", ascending=False).reset_index(drop=True)

    nt = name_table.copy()
    nt[NAME_EMAIL_COL] = nt[NAME_EMAIL_COL].astype(str).str.strip().str.lower()
    scores = scores.merge(nt, left_on="email", right_on=NAME_EMAIL_COL, how="left")

    scores = scores.drop(columns=[c for c in ("split_files", NAME_EMAIL_COL) if c in scores])
    scores = scores.rename(columns={"total": "Total Score"})

    lead = [
        c
        for c in (
            "Applicant First Name",
            "Applicant Middle Name",
            "Applicant Last Name",
            "email",
            "resumelength",
        )
        if c in scores.columns
    ]
    tail = [c for c in scores.columns if c not in lead + categories + ["Total Score", "quartile"]]
    scores = scores[lead + categories + ["Total Score", "quartile"] + tail]

    proportion = proportion.drop(columns=["split_files"], errors="ignore")
    return scores, proportion


def aggregate_normalize_score(
    keywords: pd.DataFrame,
    final_df: pd.DataFrame,
    count_df: pd.DataFrame,
    split_files: Sequence[str],
    name_table: pd.DataFrame,
):
    """Returns (scores, scores_weighted, detailed, proportion, proportion_weighted)."""
    if final_df.empty:
        empty = pd.DataFrame()
        return empty, empty, empty, empty, empty

    denom = keywords.groupby("category", as_index=False).agg(count=("keyword", "count"))

    joined = final_df.merge(
        keywords, left_on="keywords", right_on="keyword", how="left"
    ).drop(columns=["keyword"])
    joined = joined.merge(denom, on="category", how="left")
    joined = joined.merge(count_df, on="column_lab", how="left")
    joined = joined[joined["category"].notna()]

    resume_length = (
        joined.groupby("split_files", as_index=False)["resumelength"].mean()
    )

    categories = sorted(keywords["category"].dropna().unique().tolist())

    scores, proportion = _create_scores_table(
        joined, keywords, resume_length, split_files, name_table, categories, weighted=False
    )
    scores_w, proportion_w = _create_scores_table(
        joined, keywords, resume_length, split_files, name_table, categories, weighted=True
    )

    # detailed frequency table
    detailed = joined.copy()
    detailed["email"] = detailed["split_files"].map(_email_from_path)
    nt = name_table.copy()
    nt[NAME_EMAIL_COL] = nt[NAME_EMAIL_COL].astype(str).str.strip().str.lower()
    detailed = detailed.merge(
        nt[[NAME_EMAIL_COL, "Applicant First Name", "Applicant Last Name"]],
        left_on="email",
        right_on=NAME_EMAIL_COL,
        how="left",
    ).drop(columns=[NAME_EMAIL_COL, "split_files", "column_lab"], errors="ignore")
    front = ["Applicant First Name", "Applicant Last Name", "email", "resumelength"]
    front = [c for c in front if c in detailed.columns]
    detailed = detailed[front + [c for c in detailed.columns if c not in front]]

    names_df = nt[[NAME_EMAIL_COL, "Applicant First Name", "Applicant Last Name"]]

    def _finish_prop(prop: pd.DataFrame) -> pd.DataFrame:
        out = prop.merge(
            names_df, left_on="email", right_on=NAME_EMAIL_COL, how="left"
        ).drop(columns=[NAME_EMAIL_COL], errors="ignore")
        front = ["Applicant First Name", "Applicant Last Name", "email"]
        front = [c for c in front if c in out.columns]
        out = out[front + [c for c in out.columns if c not in front]]
        num = out.select_dtypes(include=[np.number]).columns
        out[num] = out[num].round(3)
        return out

    return scores, scores_w, detailed, _finish_prop(proportion), _finish_prop(proportion_w)


def matched_keywords_by_category(detailed: pd.DataFrame) -> pd.DataFrame:
    """Port of matched_keywords_df: '; '-joined keywords per email+category."""
    if detailed.empty:
        return pd.DataFrame(columns=["email", "category", "keywords_matched"])
    return (
        detailed.groupby(["email", "category"], as_index=False)["keywords"]
        .agg(lambda s: "; ".join(sorted(set(s))))
        .rename(columns={"keywords": "keywords_matched"})
    )
