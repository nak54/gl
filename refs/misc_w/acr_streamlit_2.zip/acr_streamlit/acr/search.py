"""Candidate detection and resume boundary logic.

Python port of R/search.R, R/update_resume_df.R, R/collapse_resume_df.R and
R/compare_text_OCR.R.

Strategy, unchanged from the Shiny app:

1. For every page, look for each candidate's first+last name appearing close
   together (a resume header). The first page a candidate appears on is the
   start of their resume.
2. Candidates still unmatched are searched for by email address.
3. Candidates still unmatched are searched for by phone number, against the
   digits-only version of the page.
4. Steps 1-3 are run twice — once over the embedded-text pages and once over
   the OCR pages — and the two candidate maps are reconciled: when both find a
   candidate the earlier start page wins; otherwise whichever found them wins.
5. Candidates found by neither route go to the "not found" table for manual
   page entry.

Resumes are assumed contiguous and non-overlapping, so a candidate's end page
is the page before the next candidate starts (last candidate runs to the end of
the PDF) — same as collapse_resume_df().
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple

import pandas as pd

NAME_PROXIMITY = 60  # max chars between first and last name to count as a header

NAME_COLUMNS = {
    "first": "Applicant First Name",
    "last": "Applicant Last Name",
    "email": "Applicant Email Address",
    "phone": "Applicant Phone Number",
}


def build_candidate_table(name_table: pd.DataFrame) -> pd.DataFrame:
    """Port of the usas_report_names() transmute in server.R."""
    missing = [c for c in NAME_COLUMNS.values() if c not in name_table.columns]
    if missing:
        raise ValueError(
            "Names spreadsheet is missing required column(s): " + ", ".join(missing)
        )
    out = pd.DataFrame(
        {
            "firstName": name_table[NAME_COLUMNS["first"]].astype(str).str.strip().str.lower(),
            "lastName": name_table[NAME_COLUMNS["last"]].astype(str).str.strip().str.lower(),
            "email": name_table[NAME_COLUMNS["email"]].astype(str).str.strip().str.lower(),
            "phone": name_table[NAME_COLUMNS["phone"]]
            .astype(str)
            .str.replace(r"[()+\-. ]", "", regex=True),
        }
    )
    out = out.drop_duplicates()
    out = out[out["firstName"].notna() & (out["firstName"] != "") & (out["firstName"] != "nan")]
    return out.reset_index(drop=True)


def _find_first_page(
    pages_text: List[str],
    pages_numbers: List[str],
    candidate: pd.Series,
) -> Tuple[Optional[int], Optional[str]]:
    """Return (1-based page number, match method) for one candidate."""
    first = str(candidate["firstName"]).strip()
    last = str(candidate["lastName"]).strip()
    email = str(candidate["email"]).strip()
    phone = re.sub(r"\D", "", str(candidate["phone"] or ""))

    # --- 1. name search (first and last name near each other) ---
    if first and last:
        f_re = re.compile(r"\b" + re.escape(first) + r"\b")
        l_re = re.compile(r"\b" + re.escape(last) + r"\b")
        for i, text in enumerate(pages_text):
            f_locs = [m.start() for m in f_re.finditer(text)]
            if not f_locs:
                continue
            l_locs = [m.start() for m in l_re.finditer(text)]
            if not l_locs:
                continue
            for fl in f_locs:
                if any(abs(ll - fl) <= NAME_PROXIMITY for ll in l_locs):
                    return i + 1, "name"

    # --- 2. email search ---
    if email and "@" in email:
        for i, text in enumerate(pages_text):
            if email in text:
                return i + 1, "email"
        squished = email.replace(" ", "")
        for i, text in enumerate(pages_numbers):
            if squished.replace("@", "") and squished.replace("@", "") in text:
                return i + 1, "email"

    # --- 3. phone search (digits-only page text) ---
    if phone and len(phone) >= 7:
        for i, text in enumerate(pages_numbers):
            if phone in text:
                return i + 1, "phone"
        tail = phone[-10:]
        if len(tail) == 10:
            for i, text in enumerate(pages_numbers):
                if tail in text:
                    return i + 1, "phone"

    return None, None


def search_candidates(
    candidates: pd.DataFrame,
    pages_text: List[str],
    pages_numbers: List[str],
    label: str,
) -> pd.DataFrame:
    """One pass of steps 1-3 over one extraction route."""
    rows = []
    for _, cand in candidates.iterrows():
        page, method = _find_first_page(pages_text, pages_numbers, cand)
        if page is not None:
            rows.append(
                {
                    "firstName": cand["firstName"],
                    "lastName": cand["lastName"],
                    "email": cand["email"],
                    "startPage": page,
                    "matchedBy": method,
                    "source": label,
                }
            )
    return pd.DataFrame(
        rows,
        columns=["firstName", "lastName", "email", "startPage", "matchedBy", "source"],
    )


def compare_text_ocr(
    from_text: pd.DataFrame, from_ocr: pd.DataFrame
) -> pd.DataFrame:
    """Port of compare_text_OCR(): reconcile the two extraction routes.

    Found by both -> keep the earlier start page (Final1/Final2 in the R code).
    Found by one  -> keep it (Final3/Final4).
    """
    merged = from_text.merge(from_ocr, on="email", how="outer", suffixes=("_txt", "_ocr"))
    rows = []
    for _, r in merged.iterrows():
        s_txt, s_ocr = r.get("startPage_txt"), r.get("startPage_ocr")
        use_txt = pd.notna(s_txt) and (pd.isna(s_ocr) or s_txt <= s_ocr)
        sfx = "_txt" if use_txt else "_ocr"
        if pd.isna(r.get(f"startPage{sfx}")):
            continue
        rows.append(
            {
                "firstName": r[f"firstName{sfx}"],
                "lastName": r[f"lastName{sfx}"],
                "email": r["email"],
                "startPage": int(r[f"startPage{sfx}"]),
                "matchedBy": r[f"matchedBy{sfx}"],
                "source": "pdf_text" if use_txt else "ocr",
            }
        )
    return pd.DataFrame(
        rows,
        columns=["firstName", "lastName", "email", "startPage", "matchedBy", "source"],
    )


def assign_page_ranges(df: pd.DataFrame, n_pages: int) -> pd.DataFrame:
    """Port of collapse_resume_df(): startPage -> endPage/resumeLength."""
    if df.empty:
        return df.assign(endPage=[], resumeLength=[])
    out = df.sort_values("startPage").reset_index(drop=True).copy()
    out["startPage"] = out["startPage"].astype(int)
    out["endPage"] = out["startPage"].shift(-1) - 1
    out.loc[out.index[-1], "endPage"] = n_pages
    out["endPage"] = out["endPage"].astype(int)
    out["resumeLength"] = out["endPage"] - out["startPage"] + 1
    return out


def detect_candidates(
    candidates: pd.DataFrame,
    text_pages: List[str],
    text_numbers: List[str],
    ocr_pages: List[str],
    ocr_numbers: List[str],
    n_pages: int,
    use_ocr: bool = True,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Full detection. Returns (processed_df, unmatched_df)."""
    from_text = search_candidates(candidates, text_pages, text_numbers, "pdf_text")
    if use_ocr and any(ocr_pages):
        from_ocr = search_candidates(candidates, ocr_pages, ocr_numbers, "ocr")
        combined = compare_text_ocr(from_text, from_ocr)
    else:
        combined = from_text

    # de-duplicate: one page can only start one resume; keep the first claimant
    combined = combined.sort_values(["startPage", "email"]).drop_duplicates(
        subset="startPage", keep="first"
    )
    processed = assign_page_ranges(combined, n_pages)

    found = set(processed["email"]) if not processed.empty else set()
    unmatched = candidates[~candidates["email"].isin(found)].copy()
    unmatched = unmatched[["firstName", "lastName", "email"]]
    unmatched["startPage"] = pd.NA
    unmatched["endPage"] = pd.NA
    return processed.reset_index(drop=True), unmatched.reset_index(drop=True)


def apply_manual_pages(
    processed: pd.DataFrame,
    edited_unmatched: pd.DataFrame,
    n_pages: int,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Port of the apply_unmatched_changes observer.

    Rows in the unmatched table that now carry both a start and end page are
    folded into the processed table and page ranges are recomputed.
    """
    e = edited_unmatched.copy()
    e["startPage"] = pd.to_numeric(e["startPage"], errors="coerce")
    e["endPage"] = pd.to_numeric(e["endPage"], errors="coerce")
    newly = e[e["startPage"].notna() & e["endPage"].notna()].copy()
    still = e[e["startPage"].isna() | e["endPage"].isna()].copy()

    if newly.empty:
        return processed, still

    newly["matchedBy"] = "manual"
    newly["source"] = "manual"
    cols = ["firstName", "lastName", "email", "startPage", "matchedBy", "source"]
    merged = pd.concat([processed[cols], newly[cols]], ignore_index=True)
    merged = merged.sort_values("startPage").drop_duplicates(subset="email", keep="last")
    out = assign_page_ranges(merged, n_pages)

    # honour explicitly entered end pages
    manual_ends: Dict[str, int] = dict(
        zip(newly["email"], newly["endPage"].astype(int))
    )
    for i, row in out.iterrows():
        if row["email"] in manual_ends:
            out.at[i, "endPage"] = manual_ends[row["email"]]
    out["resumeLength"] = out["endPage"] - out["startPage"] + 1
    return out.reset_index(drop=True), still.reset_index(drop=True)
