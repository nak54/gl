"""Bag-of-words machinery — port of R/optimize_extract.R, R/bow.R, R/corpus.R
and the quanteda tokenize() step.

Pipeline (same order as the Shiny app):

    find_optimum_extraction()  pick pdf_text vs OCR per page, join pages per resume
    build_bow_inputs()         collapse each resume to one string + count_df
    create_clean_corpus()      tm-style scrub of the collapsed text
    tokenize()                 keyword frequency per resume -> long final_df
"""
from __future__ import annotations

import re
import unicodedata
from typing import Iterable, List, Sequence, Tuple

import pandas as pd

# --------------------------------------------------------------------------
# keyword helpers
# --------------------------------------------------------------------------

_SPECIAL_CHARS = re.compile(r"[^0123456789a-zA-Z++#&/ ]")


def _scrub(text: str) -> str:
    """removeSpecialChars() + tolower() + stripWhitespace() from corpus.R."""
    if not text:
        return ""
    text = text.replace("\\n", " ").replace("\n", " ").replace("\r", " ")
    text = text.replace("\\t", " ").replace("\t", " ")
    text = text.replace("(", " ").replace("-", " ").replace("'", "")
    text = _SPECIAL_CHARS.sub("", text)
    return re.sub(r"\s+", " ", text.lower()).strip()


def create_clean_corpus(docs: Iterable[str]) -> List[str]:
    """Port of create_clean_corpus()."""
    return [_scrub(d) for d in docs]


def normalize_keyword(keyword: str) -> str:
    return _scrub(str(keyword))


def keyword_pattern(keyword: str) -> re.Pattern:
    """Regex for one keyword, tolerant of multi-word phrases and symbols.

    Word boundaries are only applied on alphanumeric edges so that keywords
    like ``c++``, ``c#`` and ``r&d`` still match (``\\b`` would not fire after
    a ``+``).
    """
    kw = normalize_keyword(keyword)
    if not kw:
        return re.compile(r"(?!x)x")  # never matches
    parts = [re.escape(p) for p in kw.split(" ") if p]
    body = r"\s+".join(parts)
    left = r"(?<![0-9a-z])" if kw[0].isalnum() else r"(?<!\S)"
    right = r"(?![0-9a-z])" if kw[-1].isalnum() else r"(?!\S)"
    return re.compile(left + body + right)


# --------------------------------------------------------------------------
# 1. pick the better extraction per page  (find_optimum_function)
# --------------------------------------------------------------------------


def _match_count(text: str, patterns: Sequence[re.Pattern]) -> int:
    """find_matches(): number of DISTINCT keywords present in the text."""
    return sum(1 for p in patterns if p.search(text))


def find_optimum_extraction(
    pdf_text_pages: Sequence[str],
    ocr_pages: Sequence[str],
    keywords: Sequence[str],
    processed_df: pd.DataFrame,
    use_ocr: bool = True,
) -> Tuple[List[str], List[str], pd.DataFrame]:
    """Choose, per page, whichever extraction matched more keywords.

    Returns (page_texts, resume_texts, per-page choice report).
    """
    patterns = [keyword_pattern(k) for k in keywords]
    n = len(pdf_text_pages)
    chosen: List[str] = []
    report = []
    for i in range(n):
        t = (pdf_text_pages[i] or "").lower()
        o = (ocr_pages[i] or "").lower() if use_ocr and i < len(ocr_pages) else ""
        ct = _match_count(t, patterns)
        co = _match_count(o, patterns) if o else -1
        # R uses which.max(), which ties to the pdf_text column
        pick_text = ct >= co
        chosen.append(t if pick_text else o)
        report.append(
            {
                "page": i + 1,
                "pdf_text_matches": ct,
                "ocr_matches": max(co, 0),
                "used": "pdf_text" if pick_text else "ocr",
            }
        )

    resume_texts = []
    for _, row in processed_df.iterrows():
        start, end = int(row["startPage"]), int(row["endPage"])
        pages = chosen[start - 1 : end]
        resume_texts.append(" ".join(pages))

    return chosen, resume_texts, pd.DataFrame(report)


# --------------------------------------------------------------------------
# 2. collapse resumes + count_df  (bow.R)
# --------------------------------------------------------------------------


def build_bow_inputs(resume_texts: Sequence[str]) -> Tuple[List[str], pd.DataFrame]:
    """Port of bow(): collapsed resume strings and the count_df.

    NOTE: as in the R original, ``wordcount`` is a CHARACTER count
    (str_count() with no pattern) — the scoring normalisation divides keyword
    frequency by it, so it is kept identical for score parity.
    """
    unlisted, rows = [], []
    for i, txt in enumerate(resume_texts, start=1):
        collapsed = txt or ""
        collapsed = collapsed.replace("�", "")
        collapsed = unicodedata.normalize("NFKD", collapsed)
        collapsed = collapsed.encode("ascii", "ignore").decode("ascii")
        unlisted.append(collapsed)
        rows.append(
            {
                "column_lab": f"content{i}",
                "wordcount": len(collapsed),
                "resumelength": 1,
            }
        )
    return unlisted, pd.DataFrame(rows)


# --------------------------------------------------------------------------
# 3. keyword frequencies  (tokenize)
# --------------------------------------------------------------------------


def tokenize(
    corpus: Sequence[str],
    keywords_df: pd.DataFrame,
    split_files: Sequence[str],
) -> pd.DataFrame:
    """Keyword frequency per resume -> long dataframe.

    Columns: column_lab, split_files, keywords, Freq, Freq_binary
    (only keywords actually present are kept, matching the R output).
    """
    kws = keywords_df["keyword"].astype(str).tolist()
    patterns = {k: keyword_pattern(k) for k in dict.fromkeys(kws)}
    rows = []
    for i, doc in enumerate(corpus):
        lab = f"content{i + 1}"
        sf = split_files[i] if i < len(split_files) else lab
        for kw, pat in patterns.items():
            freq = len(pat.findall(doc))
            if freq > 0:
                rows.append(
                    {
                        "column_lab": lab,
                        "split_files": sf,
                        "keywords": kw,
                        "Freq": freq,
                        "Freq_binary": 1,
                    }
                )
    return pd.DataFrame(
        rows, columns=["column_lab", "split_files", "keywords", "Freq", "Freq_binary"]
    )
