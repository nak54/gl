"""Text cleaning — Python port of R/clean.R.

clean_pdf_text()  <- clean_pdf_text()
clean_ngrams()    <- clean_ngrams()
"""
from __future__ import annotations

import re
from typing import Iterable, List, Tuple

_BLANK = r"[ \t ]"


def clean_page_text(text: str) -> Tuple[str, str, str]:
    """Return (clean_text, clean_numbers, collapsed_text) for one page.

    Mirrors R clean_pdf_text() which returns three parallel vectors:
      * clean_text     - lowercased, newlines/tabs/commas/hyphens -> space
      * clean_numbers  - all punctuation and blanks stripped (for phone matching)
      * resume_data    - clean_text with runs of blanks collapsed
    """
    if text is None:
        text = ""
    clean_text = text.lower()
    clean_text = clean_text.replace("\n", " ").replace("\t", " ")
    clean_text = re.sub(_BLANK + "+", " ", clean_text)
    clean_text = clean_text.replace(",", " ").replace("-", " ")

    # numbers: join digits split by a blank, drop punctuation, drop all blanks
    clean_numbers = re.sub(r"(?<=\d) (?=\d)", "", clean_text)
    clean_numbers = re.sub(r"[^\w\s]|_", "", clean_numbers)
    clean_numbers = re.sub(_BLANK, "", clean_numbers)

    collapsed = re.sub(_BLANK + "+", " ", clean_text)
    return clean_text, clean_numbers, collapsed


def clean_pdf_text(pages: Iterable[str]) -> Tuple[List[str], List[str], List[str]]:
    out = [clean_page_text(p) for p in pages]
    if not out:
        return [], [], []
    a, b, c = zip(*out)
    return list(a), list(b), list(c)


_SYMBOL_RE = re.compile(
    "[" "←-⇿" "⌀-⏿" "■-➿" "⬀-⯿"
    "�" "\U0001F000-\U0001FAFF" "]"
)


def clean_ngram(text: str) -> str:
    """Port of clean_ngrams() — scrub escapes/symbols out of extracted text."""
    if text is None:
        return ""
    t = text
    t = t.replace("\\n", " ").replace("\n", " ")
    t = t.replace('\\"', " ").replace('"', " ")
    t = t.replace("\\t", " ").replace("\t", " ")
    t = _SYMBOL_RE.sub(" ", t)
    t = t.replace(",", " ")
    t = t.replace("-", "")
    t = t.replace(".", " ")
    t = t.replace("/", " ")
    t = re.sub(r"[  ]+", " ", t)
    return t


def clean_ngrams(texts: Iterable[str]) -> List[str]:
    return [clean_ngram(t) for t in texts]
