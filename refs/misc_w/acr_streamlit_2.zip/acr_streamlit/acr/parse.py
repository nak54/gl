"""PDF text extraction — Python port of R/parse.R.

The R app extracts every page twice (pdftools::pdf_text and Tesseract OCR on a
600-dpi render) and later keeps, per page, whichever extraction matched more
keywords. This module does the same with PyMuPDF + pytesseract, in a thread
pool, and degrades gracefully to text-only when Tesseract is unavailable.
"""
from __future__ import annotations

import concurrent.futures as cf
import io
import os
import shutil
from dataclasses import dataclass, field
from typing import Callable, List, Optional

import pymupdf


def tesseract_available() -> bool:
    if shutil.which("tesseract") is None:
        return False
    try:
        import pytesseract  # noqa: F401
    except ImportError:
        return False
    return True


@dataclass
class Extraction:
    """Per-page text from both extraction routes (lowercased)."""

    pdf_text: List[str] = field(default_factory=list)
    ocr_text: List[str] = field(default_factory=list)
    ocr_used: bool = False
    n_pages: int = 0


def extract_pdf_text(pdf_path: str) -> List[str]:
    doc = pymupdf.open(pdf_path)
    try:
        return [(page.get_text() or "").lower() for page in doc]
    finally:
        doc.close()


def _ocr_page(pdf_path: str, page_no: int, dpi: int) -> str:
    import pytesseract
    from PIL import Image

    doc = pymupdf.open(pdf_path)
    try:
        pix = doc[page_no].get_pixmap(dpi=dpi)
        img = Image.open(io.BytesIO(pix.tobytes("png")))
        return (pytesseract.image_to_string(img) or "").lower()
    except Exception:
        return ""
    finally:
        doc.close()


def parse_pdf(
    pdf_path: str,
    use_ocr: bool = True,
    dpi: int = 300,
    max_workers: Optional[int] = None,
    progress: Optional[Callable[[float, str], None]] = None,
) -> Extraction:
    """Extract every page by direct text and (optionally) OCR.

    `progress(fraction, message)` is called as work completes so the Streamlit
    layer can drive a progress bar (the Shiny app used withProgress()).
    """
    text_pages = extract_pdf_text(pdf_path)
    n = len(text_pages)
    if progress:
        progress(0.35, f"Extracted embedded text from {n} pages")

    ocr_pages = [""] * n
    ocr_used = False
    if use_ocr and tesseract_available() and n:
        ocr_used = True
        workers = max_workers or min(8, (os.cpu_count() or 2))
        done = 0
        with cf.ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(_ocr_page, pdf_path, i, dpi): i for i in range(n)
            }
            for fut in cf.as_completed(futures):
                i = futures[fut]
                try:
                    ocr_pages[i] = fut.result()
                except Exception:
                    ocr_pages[i] = ""
                done += 1
                if progress:
                    progress(0.35 + 0.6 * done / n, f"OCR {done}/{n} pages")
    elif progress:
        progress(0.95, "OCR skipped")

    if progress:
        progress(1.0, "Text extraction complete")
    return Extraction(
        pdf_text=text_pages, ocr_text=ocr_pages, ocr_used=ocr_used, n_pages=n
    )
