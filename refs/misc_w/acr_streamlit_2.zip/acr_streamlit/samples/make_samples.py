"""Build the sample Names Spreadsheet + keywords file used in the README walkthrough."""
import os

import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))

names = pd.DataFrame(
    [
        ("Séréna", "", "Giraud", "SérénaGiraud@aol.com", "137 951-1480", "Berkeley, CA"),
        ("Bridgette", "", "Fortier", "BridgetteFortier@yahoo.com", "576-023-8722", "Baton Rouge, LA"),
        ("Mukhtaar", "", "Takenaka", "MukhtaarTakenaka@hotmail.com", "267 417-4233", "Austin, TX"),
        ("Jonah", "", "Dickerson", "JonahDickerson@gmail.com", "(842) 849-6313", "Atlanta, GA"),
        ("Ha-Yoon", "", "Burton", "Ha-YoonBurton@gmail.com", "392-306-0608", "Seattle, WA"),
        ("Judie", "A.", "Goode", "JudieGoode@gmail.com", "622-304-7081", "Denton, TX"),
        ("Ségolène", "", "Moss", "SégolèneMoss@gmail.com", "339-012-8521", "Boston, MA"),
        ("Raewyn", "", "Bateson", "RewynBateson@yahoo.com", "882-703-0061", "St. Petersburg, FL"),
        ("Roslyn", "", "Beck", "RoslynBeck@aol.com", "555-100-2000", "Chicago, IL"),
    ],
    columns=[
        "Applicant First Name",
        "Applicant Middle Name",
        "Applicant Last Name",
        "Applicant Email Address",
        "Applicant Phone Number",
        "Application Locations",
    ],
)

keywords = pd.DataFrame(
    [
        ("programming", "python", 1.5),
        ("programming", "r", 1.0),
        ("programming", "sql", 1.5),
        ("programming", "java", 1.0),
        ("programming", "git", 1.0),
        ("machine learning", "machine learning", 2.0),
        ("machine learning", "nlp", 1.5),
        ("machine learning", "neural network", 1.5),
        ("machine learning", "regression", 1.25),
        ("machine learning", "classification", 1.0),
        ("data engineering", "data pipeline", 1.5),
        ("data engineering", "etl", 1.5),
        ("data engineering", "aws", 1.0),
        ("data engineering", "database", 1.0),
        ("analytics", "power bi", 1.25),
        ("analytics", "tableau", 1.25),
        ("analytics", "dashboard", 1.0),
        ("analytics", "statistics", 1.25),
        ("communication", "presentation", 1.0),
        ("communication", "stakeholder", 1.0),
        ("communication", "training", 1.0),
    ],
    columns=["category", "keyword", "score_adjustment"],
)

if __name__ == "__main__":
    names.to_excel(os.path.join(HERE, "sample_names.xlsx"), index=False)
    keywords.to_csv(os.path.join(HERE, "sample_keywords.csv"), index=False)
    print("wrote sample_names.xlsx and sample_keywords.csv")
