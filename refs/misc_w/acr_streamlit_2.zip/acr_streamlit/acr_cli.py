#!/usr/bin/env python3
"""acr — rank candidates from a combined resume PDF, from the command line.

No Streamlit, no browser: this drives the same `acr` engine the app uses.

    python acr_cli.py resumes.pdf --names names.xlsx
    python acr_cli.py resumes.pdf --names names.xlsx --keywords my_kw.csv --top 10
    python acr_cli.py resumes.pdf --names names.xlsx --json - | jq '.[0]'

Exit codes:  0 ok · 1 bad input · 2 no keyword matches · 3 unmatched candidates
             (with --strict) · 130 interrupted
"""
from __future__ import annotations

import argparse
import json
import math
import os
import shutil
import sys
import textwrap
import time
from typing import List, Optional, Sequence

import pandas as pd

from acr import export, pipeline, score, search
from acr import parse as parse_mod

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_KEYWORDS = os.path.join(APP_DIR, "data", "DS_demo_keywords.csv")

USE_COLOR = sys.stderr.isatty() and os.environ.get("NO_COLOR") is None


def c(text: str, code: str) -> str:
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else text


def log(msg: str = "", quiet: bool = False) -> None:
    if not quiet:
        print(msg, file=sys.stderr)


def die(msg: str, code: int = 1) -> "None":
    print(c(f"error: {msg}", "31"), file=sys.stderr)
    raise SystemExit(code)


# --------------------------------------------------------------- io utils --
def read_table(path: str) -> pd.DataFrame:
    if not os.path.exists(path):
        die(f"file not found: {path}")
    ext = os.path.splitext(path)[1].lower()
    if ext in (".csv", ".txt"):
        return pd.read_csv(path)
    if ext in (".xlsx", ".xls", ".xlsm"):
        return pd.read_excel(path)
    die(f"unsupported file type '{ext}': {path}")


def write_table(df: pd.DataFrame, path: str) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    if path.lower().endswith((".xlsx", ".xls")):
        df.to_excel(path, index=False)
    else:
        df.to_csv(path, index=False)


# ------------------------------------------------------------ presentation -
def term_width(default: int = 120) -> int:
    try:
        return max(60, min(shutil.get_terminal_size(fallback=(default, 24)).columns - 4, 200))
    except Exception:
        return default


def abbreviate(categories: Sequence[str]) -> dict:
    """Short column codes for long category names, e.g. 'data analysis' -> 'DA'."""
    codes, seen = {}, set()
    for cat in categories:
        words = [w for w in str(cat).split() if w not in ("and", "of", "the", "&")]
        code = "".join(w[0] for w in words).upper() or str(cat)[:2].upper()
        base, n = code, 2
        while code in seen:
            code = f"{base}{n}"
            n += 1
        seen.add(code)
        codes[cat] = code
    return codes


def render_table(df: pd.DataFrame, max_width: Optional[int] = None) -> str:
    """Fixed-width table that survives a plain terminal."""
    if df.empty:
        return "(no rows)"
    max_width = max_width or term_width()
    disp = df.copy()
    for col in disp.columns:
        if pd.api.types.is_float_dtype(disp[col]):
            disp[col] = disp[col].map(lambda v: "" if pd.isna(v) else f"{v:g}")
        else:
            disp[col] = disp[col].astype(str).replace("nan", "")
    heads = [str(h) for h in disp.columns]
    widths = [
        max(len(h), *(len(v) for v in disp[col].tolist()) if len(disp) else len(h))
        for h, col in zip(heads, disp.columns)
    ]
    # shrink the widest text column(s) until the table fits
    while sum(widths) + 3 * (len(widths) - 1) > max_width and max(widths) > 8:
        i = widths.index(max(widths))
        widths[i] -= 1

    def row(cells: Sequence[str], bold: bool = False) -> str:
        out = []
        for cell, w in zip(cells, widths):
            cell = cell if len(cell) <= w else cell[: w - 1] + "…"
            out.append(cell.ljust(w))
        line = "   ".join(out).rstrip()
        return c(line, "1") if bold else line

    lines = [row(heads, bold=True), "   ".join("─" * w for w in widths)]
    for _, r in disp.iterrows():
        lines.append(row([str(r[col]) for col in disp.columns]))
    return "\n".join(lines)


def render_bars(df: pd.DataFrame, width: int = 28) -> str:
    """Ranked list with a score bar — the CLI stand-in for the app's bar chart."""
    if df.empty:
        return "(no candidates)"
    top = df["Total Score"].max() or 1
    name_w = max(
        len(f"{r.get('Applicant First Name','')} {r.get('Applicant Last Name','')}".strip())
        for _, r in df.iterrows()
    )
    name_w = min(max(name_w, 8), 32)
    lines = []
    for i, (_, r) in enumerate(df.iterrows(), start=1):
        name = f"{r.get('Applicant First Name','')} {r.get('Applicant Last Name','')}".strip()
        name = name if len(name) <= name_w else name[: name_w - 1] + "…"
        score_val = float(r["Total Score"])
        filled = int(round(score_val / top * width))
        bar = "█" * filled + "·" * (width - filled)
        lines.append(
            f"{i:>3}. {name.ljust(name_w)}  {c(bar, '36')}  "
            f"{c(f'{score_val:g}', '1')}  (Q{int(r['quartile'])})"
        )
    return "\n".join(lines)


# ------------------------------------------------------------------ main ---
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="acr",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description="Rank candidates in a combined resume PDF using a bag-of-words "
        "keyword model.",
        epilog=textwrap.dedent(
            """\
            examples:
              acr resumes.pdf --names names.xlsx
              acr resumes.pdf --names names.xlsx --keywords kw.csv --top-pct 25
              acr resumes.pdf --names names.xlsx --no-ocr --no-split-pdfs -q
              acr resumes.pdf --names names.xlsx --pages fixes.csv --strict
              acr resumes.pdf --names names.xlsx --json rankings.json
            """
        ),
    )
    p.add_argument("pdf", help="PDF containing every applicant's resume")
    p.add_argument(
        "-n", "--names", required=True, metavar="FILE",
        help="Names Spreadsheet (.xlsx/.csv) with the Applicant * columns",
    )
    p.add_argument(
        "-k", "--keywords", default=DEFAULT_KEYWORDS, metavar="FILE",
        help="category/keyword/score_adjustment file "
        "(default: the built-in data science dictionary)",
    )
    p.add_argument(
        "-o", "--out", default="acr_output", metavar="DIR",
        help="output directory (default: acr_output)",
    )

    g = p.add_argument_group("extraction")
    g.add_argument("--ocr", dest="ocr", action="store_true", default=None,
                   help="force the Tesseract OCR pass on")
    g.add_argument("--no-ocr", dest="ocr", action="store_false",
                   help="skip OCR (fast; scanned resumes will score 0)")
    g.add_argument("--dpi", type=int, default=300, metavar="N",
                   help="render DPI for OCR (default: 300)")
    g.add_argument("--workers", type=int, default=None, metavar="N",
                   help="OCR worker threads (default: CPU count, max 8)")

    g = p.add_argument_group("candidate detection")
    g.add_argument("--pages", metavar="FILE",
                   help="CSV of manual page fixes: email,startPage,endPage")
    g.add_argument("--strict", action="store_true",
                   help="exit 3 if any applicant could not be located in the PDF")
    g.add_argument("--no-split-pdfs", action="store_true",
                   help="score without writing one PDF per candidate (faster)")

    g = p.add_argument_group("ranking output")
    g.add_argument("-w", "--weighting", choices=["weighted", "unweighted", "both"],
                   default="both", help="which ranking(s) to produce (default: both)")
    g.add_argument("--top", type=int, metavar="N", help="keep only the top N applicants")
    g.add_argument("--top-pct", type=float, metavar="P",
                   help="keep only the top P%% of applicants")
    g.add_argument("--json", metavar="FILE",
                   help="also write the ranking as JSON ('-' for stdout)")
    g.add_argument("--no-xlsx", action="store_true", help="skip the styled workbook")
    g.add_argument("--csv", action="store_true",
                   help="also write rankings/detail/proportion as CSV")

    g = p.add_argument_group("verbosity")
    g.add_argument("-q", "--quiet", action="store_true", help="only errors on stderr")
    g.add_argument("--no-color", action="store_true", help="disable ANSI colour")
    return p


def main(argv: Optional[List[str]] = None) -> int:
    global USE_COLOR
    args = build_parser().parse_args(argv)
    if args.no_color:
        USE_COLOR = False
    quiet = args.quiet
    t0 = time.time()

    # ---------------------------------------------------------- validate --
    if not os.path.exists(args.pdf):
        die(f"PDF not found: {args.pdf}")
    if not os.path.exists(args.keywords):
        die(f"keywords file not found: {args.keywords}")
    if args.top is not None and args.top < 1:
        die("--top must be at least 1")
    if args.top_pct is not None and not (0 < args.top_pct <= 100):
        die("--top-pct must be between 0 and 100")

    os.makedirs(args.out, exist_ok=True)

    use_ocr = parse_mod.tesseract_available() if args.ocr is None else args.ocr
    if args.ocr and not parse_mod.tesseract_available():
        die("--ocr requested but Tesseract is not installed or not on PATH")
    if args.ocr is None and not use_ocr:
        log(c("note: Tesseract not found — running text extraction only", "33"), quiet)

    name_table = read_table(args.names)
    try:
        candidates = search.build_candidate_table(name_table)
    except ValueError as exc:
        die(str(exc))
    try:
        keywords = score.prepare_keywords(read_table(args.keywords))
    except ValueError as exc:
        die(str(exc))
    if keywords.empty:
        die(f"no usable keywords in {args.keywords}")

    log(c("Automated Candidate Review", "1"), quiet)
    log(
        f"  pdf       {args.pdf}\n"
        f"  names     {args.names}  ({len(candidates)} applicants)\n"
        f"  keywords  {args.keywords}  ({len(keywords)} keywords, "
        f"{keywords['category'].nunique()} categories)\n"
        f"  ocr       {'on' if use_ocr else 'off'}"
        + (f" @ {args.dpi} dpi" if use_ocr else ""),
        quiet,
    )

    # ------------------------------------------------------------- parse --
    log(c("\n▸ Extracting text", "1"), quiet)
    parsed = pipeline.parse_and_clean(
        args.pdf,
        use_ocr=use_ocr,
        dpi=args.dpi,
        max_workers=args.workers,
        progress=None if quiet else (lambda f, m: log(f"  [{f:5.0%}] {m}")),
    )

    # ------------------------------------------------------------ detect --
    log(c("\n▸ Detecting candidates", "1"), quiet)
    processed, unmatched = search.detect_candidates(
        candidates,
        parsed.text_clean,
        parsed.text_numbers,
        parsed.ocr_clean,
        parsed.ocr_numbers,
        parsed.n_pages,
        use_ocr=use_ocr,
    )

    if args.pages:
        fixes = read_table(args.pages)
        fixes.columns = [str(col).strip() for col in fixes.columns]
        need = {"email", "startPage", "endPage"}
        if not need.issubset(fixes.columns):
            die(f"--pages file must have columns: {', '.join(sorted(need))}")
        fixes["email"] = fixes["email"].astype(str).str.strip().str.lower()
        merged = unmatched.drop(columns=["startPage", "endPage"]).merge(
            fixes[["email", "startPage", "endPage"]], on="email", how="left"
        )
        processed, unmatched = search.apply_manual_pages(processed, merged, parsed.n_pages)
        log(f"  applied {len(fixes)} manual page fix(es)", quiet)

    if processed.empty:
        die("no candidates could be located in the PDF — check the names spreadsheet", 1)

    log(
        f"  {len(processed)}/{len(candidates)} located across {parsed.n_pages} pages",
        quiet,
    )
    if not quiet:
        by = processed["matchedBy"].value_counts().to_dict()
        log("  matched by: " + ", ".join(f"{k} {v}" for k, v in by.items()))
        log("\n" + textwrap.indent(
            render_table(processed[["firstName", "lastName", "startPage", "endPage",
                                    "resumeLength", "matchedBy"]]), "  "))

    write_table(processed, os.path.join(args.out, "candidates.csv"))
    if not unmatched.empty:
        write_table(unmatched, os.path.join(args.out, "unmatched.csv"))
        log(c(f"\n  ⚠ {len(unmatched)} applicant(s) NOT found in the PDF:", "33"), quiet)
        for _, r in unmatched.iterrows():
            log(f"      {r['firstName']} {r['lastName']}  <{r['email']}>", quiet)
        log(
            "    listed in unmatched.csv — add startPage/endPage there and re-run "
            "with --pages unmatched.csv",
            quiet,
        )
        if args.strict:
            return 3

    # -------------------------------------------------------------- split --
    if args.no_split_pdfs:
        split_files = [f"{e}_resume.pdf" for e in processed["email"]]
        log(c("\n▸ Skipping PDF split (--no-split-pdfs)", "1"), quiet)
    else:
        log(c("\n▸ Splitting resumes", "1"), quiet)
        split_dir = os.path.join(args.out, "resumes")
        split_files = pipeline.split_resumes(args.pdf, processed, split_dir)
        log(f"  wrote {len(split_files)} files to {split_dir}", quiet)

    # -------------------------------------------------------------- score --
    log(c("\n▸ Scoring", "1"), quiet)
    res = pipeline.score_resumes(
        parsed, processed, keywords, name_table, split_files, use_ocr=use_ocr
    )
    if res["final_df"].empty:
        die("no keywords were found in any resume — check the keywords file", 2)

    if not quiet and parsed.extraction.ocr_used:
        used = res["extraction_report"]["used"].value_counts().to_dict()
        log("  extraction used: " + ", ".join(f"{k} {v} pages" for k, v in used.items()))
    log(f"  {len(res['final_df'])} keyword hits across {len(processed)} resumes", quiet)

    categories = sorted(keywords["category"].unique())
    wanted = ["weighted", "unweighted"] if args.weighting == "both" else [args.weighting]

    json_payload = {}
    for label in wanted:
        df = (res["scores_weighted"] if label == "weighted" else res["scores"]).copy()
        df = df.sort_values("Total Score", ascending=False).reset_index(drop=True)

        n = len(df)
        if args.top_pct is not None:
            n = min(n, max(1, math.ceil(args.top_pct / 100 * len(df))))
        if args.top is not None:
            n = min(n, args.top)
        df = df.head(n)

        log(c(f"\n▸ Ranking — {label}", "1"), quiet)
        if not quiet:
            log("\n" + textwrap.indent(render_bars(df), "  ") + "\n")

            codes = abbreviate(categories)
            breakdown = pd.DataFrame(
                {
                    "#": range(1, len(df) + 1),
                    "applicant": [
                        f"{a} {b}".strip()
                        for a, b in zip(
                            df.get("Applicant First Name", pd.Series([""] * len(df))).fillna(""),
                            df.get("Applicant Last Name", pd.Series([""] * len(df))).fillna(""),
                        )
                    ],
                }
            )
            for cat in categories:
                if cat in df.columns:
                    breakdown[codes[cat]] = df[cat].values
            breakdown["TOTAL"] = df["Total Score"].values
            breakdown["Q"] = df["quartile"].values
            log(textwrap.indent(render_table(breakdown), "  "))
            log(
                textwrap.indent(
                    "legend: " + " · ".join(f"{v} = {k}" for k, v in codes.items()), "  "
                )
            )

        prop = res["proportion_weighted"] if label == "weighted" else res["proportion"]
        if not args.no_xlsx:
            path = os.path.join(args.out, f"ACR_scores_{label}.xlsx")
            with open(path, "wb") as fh:
                fh.write(export.build_workbook(df, res["detailed"], prop, categories))
            log(c(f"\n  wrote {path}", "32"), quiet)
        if args.csv:
            write_table(df, os.path.join(args.out, f"rankings_{label}.csv"))
            write_table(prop, os.path.join(args.out, f"proportion_{label}.csv"))
            log(c(f"  wrote {args.out}/rankings_{label}.csv", "32"), quiet)

        json_payload[label] = json.loads(df.to_json(orient="records"))

    if args.csv:
        write_table(res["detailed"], os.path.join(args.out, "detailed.csv"))
        write_table(res["matched_keywords"], os.path.join(args.out, "matched_keywords.csv"))

    if args.json:
        payload = json_payload if args.weighting == "both" else json_payload[wanted[0]]
        text = json.dumps(payload, indent=2, ensure_ascii=False)
        if args.json == "-":
            print(text)
        else:
            with open(args.json, "w", encoding="utf-8") as fh:
                fh.write(text)
            log(c(f"  wrote {args.json}", "32"), quiet)

    log(c(f"\nDone in {time.time() - t0:.1f}s → {args.out}/", "1"), quiet)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\ninterrupted", file=sys.stderr)
        raise SystemExit(130)
