"""Automated Candidate Review — Streamlit port of the R Shiny app.

Run with:  streamlit run app.py
"""
from __future__ import annotations

import math
import os
import tempfile

import pandas as pd
import plotly.express as px
import streamlit as st

from acr import export, pipeline
from acr import parse as parse_mod
from acr import score as score_mod
from acr import search as search_mod

st.set_page_config(page_title="Automated Candidate Review", page_icon="⭐", layout="wide")

PRIMARY = "#3c8dbc"

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_KEYWORDS_PATH = os.path.join(APP_DIR, "data", "DS_demo_keywords.csv")


@st.cache_data(show_spinner=False)
def load_default_keywords():
    """The keyword/weights dictionary bundled with the app."""
    if not os.path.exists(DEFAULT_KEYWORDS_PATH):
        return None
    return pd.read_csv(DEFAULT_KEYWORDS_PATH)


def _default_label() -> str:
    raw = load_default_keywords()
    if raw is None:
        return "data science dictionary (file missing)"
    prepped = score_mod.prepare_keywords(raw)
    return (
        f"data science dictionary ({len(prepped)} keywords, "
        f"{prepped['category'].nunique()} categories)"
    )


st.markdown(
    """
    <style>
      .block-container {padding-top: 2rem;}
      div[data-testid="stMetric"] {
        background: #f4f7fa; border: 1px solid #dfe6ec;
        border-radius: 8px; padding: 0.75rem 1rem;
      }
      h1, h2, h3 {color: #2b5d7d;}
    </style>
    """,
    unsafe_allow_html=True,
)

# ---------------------------------------------------------------- state ----
DEFAULTS = {
    "parsed": None,
    "pdf_path": None,
    "pdf_name": None,
    "name_table": None,
    "candidates": None,
    "processed_df": None,
    "unmatched_df": None,
    "split_files": None,
    "keywords_raw": None,
    "keywords_source": None,
    "results": None,
}
for k, v in DEFAULTS.items():
    st.session_state.setdefault(k, v)


def reset_downstream(*keys):
    for k in keys:
        st.session_state[k] = None


def save_upload(uploaded):
    path = os.path.join(tempfile.mkdtemp(prefix="acr_"), uploaded.name)
    with open(path, "wb") as fh:
        fh.write(uploaded.getbuffer())
    return path


def read_tabular(uploaded):
    if uploaded.name.lower().endswith(".csv"):
        return pd.read_csv(uploaded)
    return pd.read_excel(uploaded)


def drop_empty_cols(df: pd.DataFrame) -> pd.DataFrame:
    """Port of remove_na_columns()."""
    if df is None or df.empty:
        return df
    return df.loc[:, df.notna().any(axis=0)]


# ---------------------------------------------------------------- nav ------
with st.sidebar:
    st.title("⭐ ACR")
    st.caption("Automated Candidate Review")
    page = st.radio(
        "Steps",
        [
            "ℹ️  Instructions",
            "1️⃣  Upload Resumes",
            "2️⃣  Score Resumes",
            "3️⃣  Visualize & Rank",
            "❓  About",
        ],
        label_visibility="collapsed",
    )
    st.divider()
    use_ocr = st.toggle(
        "Use Tesseract OCR fallback",
        value=parse_mod.tesseract_available(),
        disabled=not parse_mod.tesseract_available(),
        help="Renders every page and OCRs it, then keeps whichever extraction "
        "matched more keywords — same as the Shiny app. Slower.",
    )
    if not parse_mod.tesseract_available():
        st.caption("⚠️ Tesseract not found — running text-extraction only.")
    ocr_dpi = st.select_slider("OCR DPI", [150, 200, 300, 400, 600], value=300, disabled=not use_ocr)

    if st.session_state.processed_df is not None:
        st.divider()
        st.metric("Candidates detected", len(st.session_state.processed_df))

# ======================================================== INSTRUCTIONS =====
if page.endswith("Instructions"):
    st.title("Automated Candidate Review")
    st.markdown(
        """
This app takes **one PDF containing every applicant's resume**, works out where each
candidate's resume begins and ends, extracts the text, then scores and ranks the
candidates with a **bag-of-words (BoW)** keyword model.

### Step 1 — Upload Resumes
Upload the combined resume PDF and the **Names Spreadsheet**. The app extracts text
from every page (embedded text plus, optionally, Tesseract OCR) and matches each
applicant to a start page by **name → email → phone number**. Anyone not found lands
in a table where you type their start/end page by hand. Then split the PDF into one
file per candidate.

**Names Spreadsheet must contain these columns:**
`Applicant First Name`, `Applicant Middle Name`, `Applicant Last Name`,
`Applicant Email Address`, `Applicant Phone Number` (and optionally
`Application Locations`, `Vacancy Job Title`, …).

### Step 2 — Score Resumes
A **data science keyword dictionary is built in** (`data/DS_demo_keywords.csv` — 242
keywords across *Data Analysis*,
*Data Modeling*, *Data Visualizations*, *Programming Languages and Tools* and
*project management*) and loads automatically — you can score without uploading
anything. Edit weights in place, or switch to **Upload my own** for a different
`category` / `keyword` / `score_adjustment` file. Every keyword's frequency is
normalised by resume length, summed within its category, scaled to 1–5, and totalled.

### Step 3 — Visualize & Rank
Rank applicants by total score, weighted or unweighted, filter to the top *N* or top
*x%*, and download the ranked workbook or the top candidates' resumes.
        """
    )
    st.info("Files stay in this session's temporary storage — nothing is uploaded anywhere else.")

# ======================================================== STEP 1 ===========
elif page.endswith("Upload Resumes"):
    st.title("Step 1 — Upload & Detect Candidates")

    c1, c2 = st.columns(2)
    with c1:
        pdf_up = st.file_uploader("PDF file containing all resumes", type=["pdf"])
    with c2:
        name_up = st.file_uploader("Names Spreadsheet", type=["xls", "xlsx", "csv"])

    if pdf_up is not None:
        if st.session_state.pdf_name != pdf_up.name:
            st.session_state.pdf_path = save_upload(pdf_up)
            st.session_state.pdf_name = pdf_up.name
            reset_downstream("parsed", "processed_df", "unmatched_df", "split_files", "results")
        import pymupdf

        doc = pymupdf.open(st.session_state.pdf_path)
        st.success(f"PDF uploaded — {len(doc)} pages.")
        doc.close()

    if name_up is not None:
        try:
            nt = read_tabular(name_up)
            st.session_state.name_table = nt
            dupes = len(nt) - len(nt.drop_duplicates())
            if dupes:
                st.error(
                    f"The names sheet contains {dupes} duplicate row(s). Remove duplicated "
                    "names and run again — applicants with identical first/last names must "
                    "be handled manually."
                )
            st.session_state.candidates = search_mod.build_candidate_table(nt)
            with st.expander(f"View uploaded Names Spreadsheet ({len(nt)} applicants)"):
                st.dataframe(drop_empty_cols(nt), width="stretch", height=300)
        except Exception as exc:
            st.error(f"Could not read the names spreadsheet: {exc}")

    st.divider()
    st.subheader("Detect candidates in the resume PDF")

    ready = st.session_state.pdf_path and st.session_state.candidates is not None
    if st.button("🔍  Detect Candidates in Resume PDF", type="primary", disabled=not ready):
        bar = st.progress(0.0, "Starting…")
        parsed = pipeline.parse_and_clean(
            st.session_state.pdf_path,
            use_ocr=use_ocr,
            dpi=ocr_dpi,
            progress=lambda f, m: bar.progress(min(f, 1.0), m),
        )
        st.session_state.parsed = parsed
        bar.progress(1.0, "Matching applicants to pages…")
        processed, unmatched = search_mod.detect_candidates(
            st.session_state.candidates,
            parsed.text_clean,
            parsed.text_numbers,
            parsed.ocr_clean,
            parsed.ocr_numbers,
            parsed.n_pages,
            use_ocr=use_ocr,
        )
        st.session_state.processed_df = processed
        st.session_state.unmatched_df = unmatched
        reset_downstream("split_files", "results")
        bar.empty()

    if st.session_state.processed_df is not None:
        processed = st.session_state.processed_df
        unmatched = st.session_state.unmatched_df
        parsed = st.session_state.parsed

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Total candidates", len(processed) + len(unmatched))
        m2.metric("Resume pages processed", parsed.n_pages)
        m3.metric("Found in PDF", len(processed))
        m4.metric("NOT found", len(unmatched))

        st.markdown("#### Candidates found in resumes PDF")
        st.dataframe(processed, width="stretch", height=280)

        st.markdown("#### Candidates not found — enter pages manually")
        if unmatched.empty:
            st.success("Every applicant was matched to a page range.")
        else:
            st.caption(
                "Type the correct `startPage` and `endPage` for each applicant, then apply."
            )
            edited = st.data_editor(
                unmatched,
                width="stretch",
                num_rows="fixed",
                disabled=["firstName", "lastName", "email"],
                column_config={
                    "startPage": st.column_config.NumberColumn(min_value=1, max_value=parsed.n_pages, step=1),
                    "endPage": st.column_config.NumberColumn(min_value=1, max_value=parsed.n_pages, step=1),
                },
                key="unmatched_editor",
            )
            if st.button("Apply Manual Changes"):
                p, u = search_mod.apply_manual_pages(processed, edited, parsed.n_pages)
                st.session_state.processed_df = p
                st.session_state.unmatched_df = u
                reset_downstream("split_files", "results")
                st.rerun()

        st.divider()
        st.subheader("Split resumes")
        if st.button("✂️  Split Individual Resumes", type="primary"):
            st.session_state.split_files = pipeline.split_resumes(
                st.session_state.pdf_path, st.session_state.processed_df
            )
            reset_downstream("results")

        if st.session_state.split_files:
            st.success(f"{len(st.session_state.split_files)} resumes split.")
            st.download_button(
                "⬇️  Download individual resumes (zip)",
                data=export.zip_files(st.session_state.split_files),
                file_name="individual_resumes.zip",
                mime="application/zip",
            )

# ======================================================== STEP 2 ===========
elif page.endswith("Score Resumes"):
    st.title("Step 2 — Keywords & Scoring")

    if st.session_state.split_files is None:
        st.warning("Complete Step 1 (detect and split resumes) first.")

    source = st.radio(
        "Keyword set",
        [f"Built-in — {_default_label()}", "Upload my own"],
        horizontal=True,
        help="The built-in data-science dictionary ships with the app and is loaded "
        "automatically. Either way you can edit weights below before scoring.",
    )
    use_builtin = source.startswith("Built-in")

    if use_builtin:
        if st.session_state.keywords_source != "builtin":
            raw = load_default_keywords()
            if raw is None:
                st.error(
                    f"Built-in keyword file not found at {DEFAULT_KEYWORDS_PATH} — "
                    "upload a keywords file instead."
                )
            else:
                st.session_state.keywords_raw = score_mod.prepare_keywords(raw)
                st.session_state.keywords_source = "builtin"
                st.session_state["_kw_dupes"] = score_mod.count_duplicate_keywords(raw)
                reset_downstream("results")
        c1, c2 = st.columns([3, 1])
        c1.caption(
            f"Loaded `{os.path.basename(DEFAULT_KEYWORDS_PATH)}` — the data-science "
            "dictionary bundled with the app."
        )
        raw_default = load_default_keywords()
        if raw_default is not None:
            c2.download_button(
                "⬇️  Download this set",
                data=raw_default.to_csv(index=False).encode(),
                file_name=os.path.basename(DEFAULT_KEYWORDS_PATH),
                mime="text/csv",
            )
        if raw_default is not None and st.button("↺  Reset edits to the built-in set"):
            st.session_state.keywords_raw = score_mod.prepare_keywords(raw_default)
            reset_downstream("results")
            st.rerun()
    else:
        template = pd.DataFrame(
            {
                "category": ["programming", "programming", "statistics", "communication"],
                "keyword": ["python", "sql", "regression", "presentation"],
                "score_adjustment": [1.5, 1.0, 1.25, 1.0],
            }
        )
        c1, c2 = st.columns([3, 1])
        with c1:
            kw_up = st.file_uploader(
                "CSV/XLSX file containing keywords and weights", type=["csv", "xlsx", "xls"]
            )
        with c2:
            st.write("")
            st.download_button(
                "⬇️ Keywords template",
                data=template.to_csv(index=False).encode(),
                file_name="keywords_template.csv",
                mime="text/csv",
            )

        if kw_up is not None:
            try:
                raw = read_tabular(kw_up)
                if st.session_state.keywords_source != kw_up.name:
                    st.session_state.keywords_raw = score_mod.prepare_keywords(raw)
                    st.session_state.keywords_source = kw_up.name
                    st.session_state["_kw_dupes"] = score_mod.count_duplicate_keywords(raw)
                    reset_downstream("results")
            except Exception as exc:
                st.error(f"Could not read the keywords file: {exc}")
        elif st.session_state.keywords_source == "builtin":
            st.session_state.keywords_raw = None
            st.session_state.keywords_source = None
            reset_downstream("results")

    if st.session_state.keywords_raw is not None:
        st.markdown("#### View / change / download keywords and weights")
        edited_kw = st.data_editor(
            st.session_state.keywords_raw,
            width="stretch",
            num_rows="dynamic",
            height=320,
            column_config={
                "score_adjustment": st.column_config.NumberColumn(
                    "score_adjustment", help="Weight applied in the weighted score", step=0.25
                )
            },
            key="kw_editor",
        )
        b1, b2, _ = st.columns([1, 1, 3])
        if b1.button("💾  Save changes to weights"):
            st.session_state.keywords_raw = score_mod.prepare_keywords(edited_kw)
            reset_downstream("results")
            st.success("Weights saved.")
        b2.download_button(
            "⬇️  Download edited keywords",
            data=edited_kw.to_csv(index=False).encode(),
            file_name="keywords_edited.csv",
            mime="text/csv",
        )

        kws = st.session_state.keywords_raw
        n_cat = kws["category"].nunique()
        st.caption(
            f"**{len(kws)} keywords across {n_cat} categories** — "
            + ", ".join(
                f"{c} ({n})" for c, n in kws.groupby("category").size().items()
            )
        )
        dupes = st.session_state.get("_kw_dupes", 0)
        if dupes:
            st.caption(
                f"ℹ️ {dupes} duplicate keyword row(s) were collapsed — a keyword "
                "repeated inside one category would inflate that category's divisor."
            )

        st.divider()
        st.subheader("Score resumes")
        can_score = st.session_state.split_files is not None
        if st.button("⭐  Score Resumes", type="primary", disabled=not can_score):
            with st.spinner("Scoring resumes…"):
                st.session_state.results = pipeline.score_resumes(
                    st.session_state.parsed,
                    st.session_state.processed_df,
                    st.session_state.keywords_raw,
                    st.session_state.name_table,
                    st.session_state.split_files,
                    use_ocr=use_ocr,
                )

    res = st.session_state.results
    if res is not None:
        if res["final_df"].empty:
            st.error(
                "No keywords were found in the resume PDF. Check that the correct "
                "keyword file was uploaded."
            )
        else:
            weighting = st.radio(
                "Keyword weighting", ["Weighted", "Unweighted"], horizontal=True, index=0
            )
            weighted = weighting == "Weighted"
            scores = res["scores_weighted"] if weighted else res["scores"]
            prop = res["proportion_weighted"] if weighted else res["proportion"]
            categories = sorted(res["keywords"]["category"].unique())

            t1, t2, t3, t4 = st.tabs(
                ["Score Frequency", "Detailed Frequency", "Proportion", "Extraction used"]
            )
            with t1:
                st.dataframe(drop_empty_cols(scores), width="stretch", height=420)
            with t2:
                st.dataframe(drop_empty_cols(res["detailed"]), width="stretch", height=420)
            with t3:
                st.dataframe(drop_empty_cols(prop), width="stretch", height=420)
            with t4:
                st.caption(
                    "Per page, whichever extraction matched more keywords was used — "
                    "the app's OCR-vs-text arbitration."
                )
                st.dataframe(res["extraction_report"], width="stretch", height=420)

            st.download_button(
                "⬇️  Download scored workbook (xlsx)",
                data=export.build_workbook(
                    drop_empty_cols(scores), res["detailed"], prop, categories
                ),
                file_name=f"ACR_scores_{'weighted' if weighted else 'unweighted'}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )

# ======================================================== STEP 3 ===========
elif page.endswith("Visualize & Rank"):
    st.title("Step 3 — Ranked Candidates")
    res = st.session_state.results

    if res is None or res["scores"].empty:
        st.warning("Score the resumes in Step 2 first.")
        st.stop()

    categories = sorted(res["keywords"]["category"].unique())

    ctrl1, ctrl2, ctrl3 = st.columns([2, 1, 1])
    with ctrl2:
        weighting = st.radio("Keyword weighting", ["Weighted", "Unweighted"], index=0)
        chart_type = st.radio("Bar chart type", ["Stacked by category", "Plain"], index=0)
    weighted = weighting == "Weighted"
    scores = (res["scores_weighted"] if weighted else res["scores"]).copy()
    scores = scores.sort_values("Total Score", ascending=False).reset_index(drop=True)
    total = len(scores)

    with ctrl3:
        pct = st.selectbox("Top applicants, %", [10, 25, 50, 100], index=1)
        pct_custom = st.number_input(
            "Custom percentage", min_value=1, max_value=100, value=int(pct), step=1
        )
    with ctrl1:
        default_n = max(1, math.ceil(pct_custom / 100 * total))
        n_applicants = st.slider(
            "Number of top applicants to display", 1, max(total, 1), min(default_n, total)
        )

    top = scores.head(n_applicants).copy()
    top["full_name"] = (
        top.get("Applicant First Name", pd.Series([""] * len(top))).fillna("").astype(str)
        + " "
        + top.get("Applicant Last Name", pd.Series([""] * len(top))).fillna("").astype(str)
        + "<br>"
        + top["email"].astype(str)
    )

    title = f"Top Applicants By Score ({'Weighted' if weighted else 'Unweighted'})"

    if chart_type == "Plain":
        fig = px.bar(top, x="full_name", y="Total Score", title=title)
        fig.update_traces(marker_color=PRIMARY)
    else:
        matched = res["matched_keywords"]
        melted = top.melt(
            id_vars=["full_name", "email"],
            value_vars=[c for c in categories if c in top.columns],
            var_name="category",
            value_name="score",
        ).merge(matched, on=["email", "category"], how="left")
        melted["keywords_matched"] = melted["keywords_matched"].fillna("—")
        fig = px.bar(
            melted,
            x="full_name",
            y="score",
            color="category",
            title=title,
            custom_data=["category", "keywords_matched"],
        )
        fig.update_traces(
            hovertemplate="<b>%{customdata[0]}</b><br>Score: %{y}<br><br>"
            "Keywords: %{customdata[1]}<extra></extra>"
        )

    fig.update_layout(
        xaxis_title="Applicant Name and Email",
        yaxis_title="Total Score",
        xaxis={"categoryorder": "total descending"},
        bargap=0.4,
        height=560,
        plot_bgcolor="#e5ecf6",
        legend_title_text="Category",
    )
    st.plotly_chart(fig, width="stretch")

    st.subheader(f"Displayed candidates ({len(top)} of {total})")
    display_cols = [
        c
        for c in top.columns
        if c not in ("full_name",) and not str(c).startswith("Unnamed")
    ]
    st.dataframe(drop_empty_cols(top[display_cols]), width="stretch", height=380)

    d1, d2 = st.columns(2)
    with d1:
        st.download_button(
            "⬇️  Download displayed candidates (csv)",
            data=top[display_cols].to_csv(index=False).encode(),
            file_name="top_candidates.csv",
            mime="text/csv",
        )
    with d2:
        if st.session_state.split_files:
            wanted = set(top["email"].astype(str))
            paths = [
                p
                for p in st.session_state.split_files
                if os.path.basename(p).split("_resume.pdf")[0] in wanted
            ]
            st.download_button(
                "⬇️  Download resumes of displayed candidates (zip)",
                data=export.zip_files(paths),
                file_name="top_candidate_resumes.zip",
                mime="application/zip",
            )

# ======================================================== ABOUT ============
else:
    st.title("About")
    a, b, c = st.columns(3)
    with a:
        st.markdown("### 📝 Pre-processing")
        st.write(
            "Text is pulled from the resume PDF directly and, optionally, via OCR. "
            "Some PDFs store text, others are scans — using both maximises the "
            "extractable content, and the app keeps whichever route found more keywords."
        )
    with b:
        st.markdown("### ✂️ Parsing")
        st.write(
            "The Names Spreadsheet drives parsing: each applicant is located by name, "
            "then email, then phone number. Whoever can't be matched automatically is "
            "listed for manual start/end page entry."
        )
    with c:
        st.markdown("### ⭐ Scoring")
        st.write(
            "Keyword frequency is normalised by resume length, min-max scaled to 1–5, "
            "optionally multiplied by the keyword's weight, summed within each category "
            "and divided by that category's keyword count, then rescaled to 1–5 and "
            "totalled across categories."
        )
    st.divider()
    st.caption(
        "Python/Streamlit port of the Automated Candidate Review Shiny app. "
        "The GIS applicant-location maps from the Shiny version are not included."
    )
