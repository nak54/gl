# NCP-AAI Practice Tests — Complete Answer Key
*Source: explanations_tests01_02.md, explanations_tests03_04.md, explanations_tests05_06.md, explanations_tests07_08.md, explanations_tests09_10.md*

> **Format:** Answer letter(s) — Key phrase from correct answer  
> Multi-select questions show all correct choices. Notes on tricky/conflicting answers included.

---

## TEST 01

| Q | Answer | Key Concept |
|---|--------|-------------|
| 1 | **A** | AI agents cascade multiple operations — end-to-end alone can't find bottlenecks |
| 2 | **B** | LangChain lacks native loops; migrate to LangGraph for iteration support |
| 3 | **B** | Counterfactual = what minimal change flips the outcome (OR structure) |
| 4 | **D** | NeMo: Data Prep → Safety → Model Serving → Retrieval/Embedding (sequential) |
| 5 | **A** | NOT a failure mode: "vocal user complaints" (users silently abandon instead) |
| 6 | **A** | TTFT + token rate for streaming; end-to-end for batch; per-step for both |
| 7 | **B** | Three disclosure levels: Essential → Expanded → Technical |
| 8 | **B** | Intent=CPU, Retrieval=memory-optimized, LLM+post-processing=GPU (combined) |
| 9 | **A** | Start with text-embedding-3-small baseline; upgrade categories by measured ROI |
| 10 | **D** | Microservices = loosely coupled, independently deployable, targeted scaling |
| 11 | **D** | Embeddings map similar concepts to nearby positions; cosine similarity for relevance |
| 12 | **D** | Dense numerical vectors where semantic meaning is encoded spatially |
| 13 | **C** | Reduce output verbosity first (2× cost), then compress tool descriptions (largest input) |
| 14 | **D** | Serverless = auto-scaling, billing per execution, provider manages servers |
| 15 | **C + E** | Cache stable components (system prompt + tool descriptions); prioritize output token reduction |
| 16 | **B** | Quality > quantity: 2–3 domain-specific examples outperform many generic ones |
| 17 | **B** | Output reduction saves more (3× pricing); Scenario 2 wins despite fewer tokens saved |
| 18 | **D** | Meta-agent decomposes; specialists use ReAct; synthesis agent manages dependencies |
| 19 | **B** | Zero-shot CoT = "Let's think step-by-step" trigger, no examples |
| 20 | **A** | Boosting recall to 95% drops precision to ~70–80%, adds 40–60 false positives/day |
| 21 | **C** | Six NeMo rail types: Input, Dialog, Retrieval, Execution, Output, Fact Checking |
| 22 | **C** | Gateway inspects JWT token → routes free=CPU, premium=GPU via single /v1/chat endpoint |
| 23 | **C** | BFF justified when clients have fundamentally different data needs (mobile vs web) |
| 24 | **C** | Four efficiency dimensions: token usage, step count, API call frequency, computational cost |
| 25 | **C** | Show top 3–4 factors with weights: Credit score (45%), DTI (30%), Employment (12%) |
| 26 | **A** | NeMo serving = NIM + TensorRT-LLM + Triton Inference Server |
| 27 | **D** | AI gateway = centralized model routing, governance, credential management, observability |
| 28 | **D** | Control spectrum = full automation to full manual, matched to decision impact and risk |
| 29 | **A** | AutoGen suits exploratory; non-deterministic conversation sequences break compliance |
| 30 | **A** | End-to-end = complete duration from query submission to final response, all latency |
| 31 | **C** | Over-microservices: consolidate to 4–5 domain-grouped services |
| 32 | **D** | CoT dual purpose: improves model accuracy AND enables human validation |
| 33 | **B + C** | High-stakes always warrants full explanation; low-stakes/high-freq = notification only |
| 34 | **A** | NeMo Retriever with domain-specific fine-tuning: up to 50% accuracy improvement |
| 35 | **A** | Four transparency dimensions: status visibility, reasoning, uncertainty, evidence |
| 36 | **A** | Trajectory bloat = useless dead ends, redundant reasoning, expired info in traces |
| 37 | **D** | *(Key says A but content confirms D)* Sequential → LangChain (~30 lines), not LangGraph |
| 38 | **A** | LLMs are probabilistic; clean inputs don't guarantee safe outputs; output filter is last defense |
| 39 | **B** | 6–8 user-centric intents (check_account, make_payment, report_issue); not mirroring system APIs |
| 40 | **B** | LangGraph: deterministic traversal, conditional edges for loops, TypedDict audit trails |
| 41 | **A** | Avg latency improved but tail latency (P95/P99) worsened → users at extremes complain more |
| 42 | **C** | ReAct = Thought→Action→Observation loop; excels at linear tool chains |
| 43 | **B** | Output tokens cost 1.5–3× more; output reduction delivers greater savings per token |
| 44 | **A** | Accurate but unaffordable agent is commercially unviable; efficiency = deployment gate |
| 45 | **B** | Keyword filters are syntactic; both char substitution and paraphrasing exploit this gap |
| 46 | **B** | Framework choice determines control-flow model coupling — architectural constraints persist |
| 47 | **A** | Cache system instructions + tool descriptions (stable, 2,500 tokens); exclude dynamic context |
| 48 | **D** | MRL: earlier dimensions capture critical info; truncate any prefix length for two-stage |
| 49 | **D** | Design C (risk-calibrated + progressive disclosure): Trust = Transparency × Control |
| 50 | **C** | Three-layer memory: short-term verbatim (8–10 turns), mid-term summaries, long-term DB |
| 51 | **A** | Trust equation is multiplicative: T = Transparency × Control; zero in either = zero trust |
| 52 | **D** | Regex for structured PII; deny list + structural validation for injection; ML for harmful intent |
| 53 | **C** | Start with text-embedding-3-small; measure on subset; upgrade categories by measured ROI |
| 54 | **C** | Integration friction is the hidden cost: version mismatches, API incompatibilities |
| 55 | **C** | True conversational UI = hierarchical memory + intent recognition + mixed modality |
| 56 | **B** | CoT transforms opaque outputs into transparent step-by-step reasoning |
| 57 | **A** | Static: generate→test; conditional: test→END or analyze→failure; static: analyze→generate |
| 58 | **B + E** | Target detailed prompts to high-uncertainty interactions; always-on implicit signals |
| 59 | **A** | Gateway aggregation endpoint makes parallel backend calls, returns single unified response |
| 60 | **A** | API gateway = single entry, auth, SSL termination, rate limiting, topology abstraction |
| 61 | **B** | Dense = all dims contribute semantics; sparse = mostly zeros, non-zero for vocab terms |
| 62 | **D** | *(Key says B, content confirms D)* 2–3 high-quality examples with data verification + risk |
| 63 | **A** | LangChain=sequential ReAct, LangGraph=graph, AutoGen=conversation, CrewAI=hierarchy, SK=plugins |
| 64 | **C** | TTC = total tokens per task, separate input/output tracking for accurate cost analysis |
| 65 | **A** | LangGraph three components: nodes (computation), edges (routing), typed state (persistence) |
| 66 | **D** | Agent UIs shift user role from operator/decision-maker to overseer/decision-reviewer |
| 67 | **C** | Zero-shot CoT ("Let's think step-by-step") for rapid deployment when examples are scarce |
| 68 | **D** | NV-Embed-v2 (32,768-token window) + truncate=NONE + tiktoken chunking aligned to tokenizer |
| 69 | **C** | AutoGen = natural language conversation as coordination; auto-reply functions trigger responses |

---

## TEST 02

| Q | Answer | Key Concept |
|---|--------|-------------|
| 1 | **C** | Thumbs up/down for all + targeted correction prompts for high-uncertainty cases |
| 2 | **A** | Task decomposition: Solvability, Completeness, Non-redundancy, Dependency specification |
| 3 | **B** | Sequential (A→B→C→done) has no built-in backtrack; iteration requires external workarounds |
| 4 | **B** | SK kernel = orchestrator; semantic functions = LLM-driven prompts; native = Python/C# code |
| 5 | **C** | Router-first + parallel shared context (5,500 tokens vs 15,000) + graceful degradation = ~80% savings |
| 6 | **C** | Meeting=notification+undo; email=pre-approval; DB deletion=pre-approval+confirmation+preview |
| 7 | **D** | Routine <85%; nuanced <75%; novel=ALWAYS escalate regardless of confidence |
| 8 | **C** | Message broker (RabbitMQ/SQS): POST→job ID immediately; workers consume async; webhook/poll |
| 9 | **A** | Fast-path: keyword matching (microseconds) for unambiguous violations; ML for borderlines |
| 10 | **D** | Regex for SSN + credit cards before LLM processing AND before logging |
| 11 | **C** | Serverless scales to zero (zero idle cost), auto-scales to thousands without pre-provisioning |
| 12 | **B** | CrewAI re-delegation treats each pass as new task, losing iteration context |
| 13 | **C** | Distill traces to decision templates, successful strategies, key insights; discard verbose steps |
| 14 | **D** | Auto-CoT: Clustering → Representative selection → Zero-shot rationale generation |
| 15 | **A** | Recalibrate escalation thresholds — auto-approve high-confidence, route only edge cases |
| 16 | **C** | LangGraph for sequential FAQ chatbot = over-engineering; refactor to LangChain (~30 lines) |
| 17 | **D** | Retrieval rails filter AFTER semantic search but BEFORE LLM context injection |
| 18 | **A** | Approval fatigue (98% rate, 4.2s, violations): recalibrate thresholds to route only edge cases |
| 19 | **C** | Notification=post-execution+undo; Approval=pre-execution gate; Monitoring=real-time+intervention |
| 20 | **D** | Event subscriptions decouple producers from consumers — new capabilities subscribe without changes |
| 21 | **D** | CrewAI = explicit roles + hierarchical delegation; AutoGen = peer-to-peer conversational emergence |
| 22 | **C** | Patient=simplified+calibrated uncertainty; nurse=clinical+confidence; regulator=tamper-evident audit |
| 23 | **B** | S3 event notifications → Lambda on s3:ObjectCreated: 43,200 executions → 100–200/month |
| 24 | **A** | CoT traces = System Non-Parametric Short-Term Memory; require consolidation for long-term storage |
| 25 | **D** | Topical filtering detects medical/vet intent → redirect to veterinarian; product queries pass |
| 26 | **D** | Stage 1: open-ended options; Stage 2: structured buttons if unclear; Stage 3: examples for "Other" |
| 27 | **D** | Air-gapped HIPAA: self-host E5-Large-V2 on-premises; cloud APIs violate air-gap regardless of BAA |
| 28 | **C** | Dialog rails: Substitute (canned response), Invoke (custom action), Allow (LLM generates) |
| 29 | **A** | Batch 1–5 for real-time (<200ms); batch 50–100 for nightly indexing (GPU throughput) |
| 30 | **A + B** | LangGraph (conditional edges) and CrewAI (hierarchical delegation) handle branching naturally |
| 31 | **B** | Effective chat = streaming + feedback mechanisms + quick actions + status indicators |
| 32 | **A + C** | Prohibited: delete DB/arbitrary shell; Allowed autonomously: read logs/restart services |
| 33 | **C** | Hybrid search = dense (semantic) + sparse (exact keyword) combined via RRF |
| 34 | **B** | Parallel pre-test quality checks = fast feedback on simple errors before expensive tests |
| 35 | **D** | False positive = safe content blocked; false negative = harmful content passes through |
| 36 | **D** | Router-first: small classifier routes 80% to efficient model, 20% to frontier = 3–5× savings |
| 37 | **B** | Graceful degradation: explain 500-case limit, offer top-20 analysis ($0.16 vs $8) |
| 38 | **D** | Category-matched recovery: retry for transient; clarify for ambiguous; explain+scope for limits |
| 39 | **B** | LangGraph three components: Nodes (computation), Edges (routing), State (typed data structure) |
| 40 | **D** | Router-first: small classifier (<100ms) routes 80% simple → efficient, 20% complex → frontier |
| 41 | **B** | System prompt + RLHF + toxicity classifier + validation rules (deny "I recommend") — layered |
| 42 | **A** | Auto-CoT suits 50 categories + evolving patterns; scale justifies slight quality trade-off |
| 43 | **C** | Distributed tracing provides waterfall visibility + root cause attribution vs ad-hoc log correlation |
| 44 | **B** | Azure Functions Premium Plan: zero cold starts mandate overrides cost; Consumption violates SLA |
| 45 | **D** | EHR grounding + mandatory checklists + validation layer + clinician review interface |
| 46 | **D** | Readiness: initialDelay=60s (after model loads); Liveness: initialDelay=120s (prevents restart during load) |
| 47 | **B** | Graceful degradation prevents burning tokens on unsolvable/resource-intensive problems |
| 48 | **D** | Pareto: 20% of components → 80% of time; targeted optimization > broad optimization |
| 49 | **C** | NV-Embed-v2 (32,768-token window) + truncate=NONE + tiktoken + 20–25% overlap at boundaries |
| 50 | **C** | Multi-turn builds shared understanding progressively; visible history enables verification |
| 51 | **A** | Three-layer: short-term verbatim + mid-term summaries + long-term DB (queried hierarchically) |
| 52 | **A** | Lambda: Python/Java/Node/Go/C#/Ruby/PowerShell/custom; scales to 1,000+ concurrent; 1ms billing |
| 53 | **D** | Evaluation pipeline = automated test datasets + metrics + quality gates + reproducible results |
| 54 | **A** | Prompt caching reduces costs 15–30% by reusing stable system instructions + tool descriptions |
| 55 | **C** | Agent errors include unique categories: tool timeouts, ambiguous queries, capability limits |
| 56 | **C** | P99 = 1% of 100K = 1,000 queries; 12% abandon = 120 users/day × $4 = $14,400/month |
| 57 | **A** | NeMo Retriever addresses: inference latency, request throughput, cost efficiency |
| 58 | **B** | Per-step latency reveals which specific step consumes most time → targeted optimization |
| 59 | **B** | RRF formula: score = weight / (rank + 60); constant 60 dampens top-rank sensitivity |
| 60 | **D + E** | DB-per-service (breaks shared schema) + message broker (breaks synchronous chains) |
| 61 | **B** | Five criteria: control flow, state management, collaboration patterns, deployment context, NFRs |
| 62 | **C** | Single DebuggingPlugin with all three functions; kernel handles shared LLM + routing + context |
| 63 | **D** | ReAct enhances CoT by interleaving Thought→Action→Observation (grounded in external reality) |
| 64 | **C** | 98% approvals in <3s = approval fatigue; human oversight has become rubber-stamping |
| 65 | **A** | Sequential with full duplication: 3× document tokens; parallel shared context eliminates waste |
| 66 | **D** | Three factors: risk magnitude, confidence level, reversibility (spectrum, not binary) |
| 67 | **C** | Input rails prevent wasted LLM inference cycles by rejecting inappropriate requests early |
| 68 | **C** | Dense embeddings struggle with exact API names/error codes — training generalizes, loses identity |
| 69 | **B** | TTFT = delay to first token; determines perceived responsiveness; not important for batch |
| 70 | **C** | Semantic Kernel's abstractions are for large teams; LangChain/LangGraph better for 3 devs |

---

## TEST 03

| Q | Answer | Key Concept |
|---|--------|-------------|
| 1 | **C** | papers/findings: Annotated[List, operator.add] (accumulate); synthesis: str (overwrite) |
| 2 | **B** | Increase memory → more vCPU + Lambda Layers + lazy loading + init outside handler |
| 3 | **C** | Four guardrail layers: Input Controls → Model Behavior → Action Controls → Human Review |
| 4 | **A** | Auto-CoT with clustering for 50+ categories at moderate budget; monitor multi-hop |
| 5 | **B** | Medical CoT failures: hallucination, omission, incompleteness |
| 6 | **D** | LLMs can produce violations/hallucinations from benign inputs even with upstream controls |
| 7 | **D** | LangGraph cycles via conditional edges; routing function checks state for termination |
| 8 | **D** | Allow lists for finite domains (forms); deny lists for open-ended (conversation) |
| 9 | **D** | Stateful routing tracks failure counter across turns; escalates at threshold |
| 10 | **A** | Accessible design = curb-cut effect; benefits ALL users, not just those with disabilities |
| 11 | **A** | ReAct three phases: Thought (reason) → Action (execute tool) → Observation (receive result) |
| 12 | **C** | Kubernetes transforms container management to declarative/automated (self-healing, HPA, DNS) |
| 13 | **C** | CPI = (2000×$0.01/1K) + (1500×$0.03/1K) = $0.065; Monthly = $0.065 × 10K × 30 = $19,500 |
| 14 | **D** | P99 = 99% of requests faster than this threshold; 1% exceed it (tail latency) |
| 15 | **A** | Colang = NVIDIA DSL for defining conversational flows and safety boundaries |
| 16 | **C** | TTC per task-category with separate input/output counts enables targeted optimization |
| 17 | **A** | Context signals: current selection (top priority) → recent actions → file type → project |
| 18 | **A** | Node functions: accept state → perform computation → return partial dict of updates |
| 19 | **B** | Sliding window overlap ensures boundary-spanning content appears fully in at least one chunk |
| 20 | **B** | Self-hosted NeMo: HIPAA via data sovereignty; 83% cheaper at 20K queries/day; break-even ~250/day |
| 21 | **C** | Categorize: Temporary=retry+fallback; Ambiguous=clarify; Capability=explain; Policy=explain+alternative |
| 22 | **B** | Prioritize behavioral signals: 25% escalation + 15% abandonment over 90% CSAT self-report |
| 23 | **B** | Working memory = ephemeral within session; lost when session ends unless saved |
| 24 | **C** | Fuzzy matching with semantic similarity (cosine ~0.85) or LLM-as-judge for CI/CD |
| 25 | **B** | Routing function: check iteration limit first; then success; then default to failure path |
| 26 | **D** | Trivy detects CVEs in base images, OS packages, dependencies — not caught by code scanners |
| 27 | **D** | Container orchestration: heterogeneous coordination, autoscaling, self-healing, discovery, fleet |
| 28 | **D** | Complex structured state: different field semantics (accumulate vs. replace); use TypedDict |
| 29 | **A** | Contextual intent = user goal from history + semantics + confidence; not just string patterns |
| 30 | **D** | TSR = % of tasks completed successfully; 80% minimum threshold for production readiness |
| 31 | **C** | Offline = pre-collected datasets with ground truth (reproducible); online = real production traffic |
| 32 | **C** | Auto-fall through hierarchy (Premium → Public → Cache) while displaying current source |
| 33 | **A** | Self-hosted despite 5× cost: HIPAA = data sovereignty; PHI cannot leave organization |
| 34 | **B** | Token generation rate should match or exceed reading pace (~250 words/min ≈ 300–400 tokens/min) |
| 35 | **A** | On return: present clear choice to resume (with summary) or start fresh; respect user autonomy |
| 36 | **D** | Static edges = deterministic (A→B always); conditional = routing function inspects state |
| 37 | **A** | MRL: truncate 3072-dim to 512-dim; ~6× storage reduction; 95%+ quality preserved |
| 38 | **B** | Analyze root cause of escalations (conservative thresholds or intent gaps); then retune |
| 39 | **C** | Transformer attention = O(N²) time and memory; doubling context quadruples cost |
| 40 | **C** | Node returns partial update dict; each field merges using its configured reducer |
| 41 | **B** | Few-shot CoT with legal exemplars (IRAC structure) for domain-specific reasoning patterns |
| 42 | **B** | WCAG 2.1 Level AA: 4.5:1 normal text; 3:1 for large text (18pt+ regular / 14pt+ bold) |
| 43 | **B** | MLflow: register artifact set (prompts + tools + params) with git hash; atomic rollback |
| 44 | **C** | CrewAI re-delegation is architectural mismatch; migrate to LangGraph for native cycles |
| 45 | **A** | current_code: str (overwrite); error_history: Annotated[List[str], operator.add] (accumulate) |
| 46 | **A** | New Thought reflecting company name change → verify action → continue with updated info |
| 47 | **B** | DynamoDB with lazy loading: immediate response with recent context; async fetch full history |
| 48 | **A** | Serverless (Lambda) for 50× spikes; pay-per-use eliminates idle cost at 5–10 req/hour |
| 49 | **C** | A/B testing: random assignment + statistical hypothesis testing (p<0.05); gold standard |
| 50 | **A** | Lighthouse 100 ≠ full accessibility: can't evaluate screen reader behavior, cognitive load |
| 51 | **B** | Distributed tracing: root span + child spans per step (retrieval, reasoning, tool, synthesis) |
| 52 | **A** | Chunk components: text, source reference, positional index, embedding vector, metadata |
| 53 | **B** | Show last 3–5 by default with timestamps; full history via toggle; search within history |
| 54 | **C** | Cosine similarity = dot product of two normalized unit vectors; value in [-1, 1]; direction only |
| 55 | **A** | Colang DSL: define canonical investment intents with semantic matching → substitute compliant response |
| 56 | **A + B** | Full 3072-dim for 10K reranking stage (A); 256-dim truncations for 1M first-pass filtering (B) |
| 57 | **B** | Declarative specs = desired state; Kubernetes continuously reconciles actual to desired |
| 58 | **C** | Four subtasks: Retrieve (no deps) → Calculate → Compare (depends) → Summary (depends) |
| 59 | **A** | RAG pipeline: ingest → chunk → embed → index → query embed → similarity search → assemble → generate |
| 60 | **A** | 97% approval + 3-second review + <1% modifications = approval fatigue; human oversight theater |
| 61 | **B** | Bidirectional validation = validate both tool inputs (params) AND tool outputs (results) |
| 62 | **C** | Explicit schemas: type safety + data contracts + reducer system + IDE autocompletion |
| 63 | **D** | Auto-block >90% confident; auto-allow >90% safe; route only uncertain 30% to humans |
| 64 | **A** | LLM inference = primary target (1.5s, 50%); then RAG (1.2s, 40%); tools (0.3s, 10%) last |
| 65 | **C** | TTC per workflow + TER per workflow + step count + P50/P95/P99 latency baselines |
| 66 | **C** | Shift-left = find issues earlier; bugs in dev cost ~1×; same bug in production costs ~100× |
| 67 | **D** | Evaluation pyramid: unit tests → offline evaluation → online A/B testing → production monitoring |
| 68 | **D** | ~1.3–1.5 tokens per word; 1,000-word doc ≈ 1,300–1,500 tokens |
| 69 | **D** | Semantic HTML (main, nav, article) conveys built-in meaning to assistive technologies |
| 70 | **C** | TER before: 91/2000 = 0.0455; after: 84/1200 = 0.070; net efficiency gain despite accuracy drop |

---

## TEST 04

| Q | Answer | Key Concept |
|---|--------|-------------|
| 1 | **D** | CoT-based coordination: dependency graph (inventory→pricing→shipping) + multi-agent debate |
| 2 | **B** | Offline profiling + workflow instrumentation to measure component-level latencies |
| 3 | **C** | AgentExecutor requires: LLM (reasoning) + tools (capabilities) + agent config |
| 4 | **A** | HPA targetCPUUtilizationPercentage: 60% (headroom above 45% steady-state) |
| 5 | **D** | Triton auto-exposes: request duration, queue duration, GPU utilization, throughput |
| 6 | **D** | AgentDiet framework: analyze trajectories offline, remove useless/redundant steps |
| 7 | **B** | current_data: dict (overwrite); transformation_history: Annotated[List, op.add]; errors: Annotated[List, op.add] |
| 8 | **A** | Three namespaces (prod/staging/dev) with ResourceQuotas; separate limits per namespace |
| 9 | **C** | OpenTelemetry: TracerProvider + BatchSpanProcessor + OTLP exporter |
| 10 | **D** | Entry→revise; static edge revise→review; conditional review→END or revise; accumulate state |
| 11 | **A** | Vendor recommendation interface: show confidence, reasoning, alternatives, cost comparison |
| 12 | **D** | GoT enables multi-predecessor aggregation; ToT is strict tree (no branch merging) |
| 13 | **C** | Small ($100–500, easy reversal)=notification; Medium ($500–2K, $25 fee)=approval; Large ($2K–5K, complex)=pre-approval+preview |
| 14 | **B** | Tiered routing: general=80%/95% thresholds; account=stricter; billing disputes=highest threshold |
| 15 | **D** | temperature=0 doesn't fix AutoGen's speaker-selection non-determinism in GroupChat |
| 16 | **A** | Edge deployment places computation at data source; reduces latency and data transmission |
| 17 | **C** | Multi-level observability framework for different stakeholders and decision-making |
| 18 | **A** | LangGraph reducer: return only new items; Annotated[List, operator.add] handles accumulation |
| 19 | **D** | OpenAI Functions: fine-tuned function-calling produces deterministic JSON tool selection |
| 20 | **D** | — |
| 21 | **A** | — |
| 22 | **C** | — |
| 23 | **C** | — |
| 24 | **A** | — |
| 25 | **B** | — |
| 26 | **D** | — |
| 27 | **C** | — |
| 28 | **D** | — |
| 29 | **C** | — |
| 30 | **B** | — |
| 31 | **A** | — |
| 32 | **B** | — |
| 33 | **A** | — |
| 34 | **A** | — |
| 35 | **D** | — |
| 36 | **C** | — |
| 37 | **D** | — |
| 38 | **B** | — |
| 39 | **B** | — |
| 40 | **B + E** | — |
| 41 | **C** | — |
| 42 | **C** | — |
| 43 | **A** | — |
| 44 | **D** | — |
| 45 | **D** | — |
| 46 | **C** | — |
| 47 | **B** | — |
| 48 | **B** | — |
| 49 | **A** | — |
| 50 | **C** | — |
| 51 | **B** | — |
| 52 | **C** | — |
| 53 | **C** | — |
| 54 | **B** | — |
| 55 | **C** | — |
| 56 | **A** | — |
| 57 | **D** | — |
| 58 | **A** | — |
| 59 | **B** | — |
| 60 | **A** | — |
| 61 | **B** | — |
| 62 | **C** | — |
| 63 | **D** | — |
| 64 | **C** | — |
| 65 | **D** | — |
| 66 | **D** | — |
| 67 | **D** | — |
| 68 | **B** | — |
| 69 | **C** | — |
| 70 | **D** | — |

---

## TEST 05

| Q | Answer | Key Concept |
|---|--------|-------------|
| 1 | **A** | Stratified evaluation dataset represents key distributions |
| 2 | **B** | ConversationBufferMemory grows linearly; increases cost with every turn |
| 3 | **C** | Category-specific approval thresholds to reduce fatigue while maintaining safety |
| 4 | **D** | Structured handoff package for escalation: summary + transcript + context |
| 5 | **D** | GDPR applies extraterritorially to any organization serving EU residents |
| 6 | **A** | NIM profile evaluation: assess latency vs. throughput trade-offs before production |
| 7 | **D** | Sequential Q&A fits LangChain; LangGraph adds complexity unwarranted for simple pipeline |
| 8 | **D** | text-embedding-3-small: $0.02/M, 1536-dim; text-embedding-3-large: $0.13/M, 3072-dim |
| 9 | **A** | NeMo Guardrails: centralized dialog rails for policy enforcement across all conversations |
| 10 | **D** | Monitoring pattern for 50 trades/hour: automated anomaly detection, not per-trade approval |
| 11 | **C** | CoT overhead: 2–5× token increase; accuracy gains are task-dependent, not universal |
| 12 | **C** | Chunk source IDs + positional indices enable citations and deduplication |
| 13 | **C** | Reduce few-shot examples to 3–5; implement dynamic tool loading to cut context |
| 14 | **A** | Risk gates weighted by consequence and irreversibility, not uniform thresholds |
| 15 | **A** | SQLite checkpointer + unique thread_id per session for persistent conversation state |
| 16 | **D** | Edge deployment: computation at data source, minimizes latency and data transmission |
| 17 | **D** | Multi-level observability: different metrics for different stakeholder decision levels |
| 18 | **A** | LangGraph reducer: return only new items; Annotated[List, operator.add] accumulates |
| 19 | **D** | OpenAI Functions: fine-tuned for function-calling; produces deterministic structured JSON |
| 20 | **A** | Approval fatigue: miscalibrated thresholds flood users with low-value approvals |
| 21 | **B** | Unified embedding interface parameterized by batch_size for different use patterns |
| 22 | **B** | RRF: accumulate weight/(rank+60) from both dense and sparse; combine for final score |
| 23 | **C** | Domain-specific quality criteria for each agent type (not uniform scoring) |
| 24 | **B** | volumeClaimTemplates in StatefulSet with storageClassName: fast-ssd for vector DB |
| 25 | **D** | Six NeMo Guardrails action types: Block, Filter, Flag, Modify, Validate, Human Intervention |
| 26 | **B** | Implement all three caching layers simultaneously: semantic, exact-match, prompt |
| 27 | **D** | Optimism bias: agents underestimate task complexity and overestimate success probability |
| 28 | **B** | 70B FP16 model = 140GB — cannot fit on single A100 40GB GPU; needs multi-GPU |
| 29 | **A** | Three ReAct failure modes: infinite loops, tool failures, incomplete outputs |
| 30 | **D** | ConversationBufferMemory: running log injected into each prompt; grows unbounded |
| 31 | **A** | Coherence optimization risks unfaithful post-hoc rationalization of actual reasoning |
| 32 | **A** | Descriptive alt text conveying actual data trends satisfies WCAG for charts |
| 33 | **B** | Three-tier content filtering: keyword → ML classifier → human review |
| 34 | **A** | GPU 12.9× speedup enables viable 3-stage pipeline: dense→sparse→cross-encoder |
| 35 | **A** | Tool-use extends capabilities via function calling and external system integration |
| 36 | **D** | TypedDict enforces static type checking at development time; catches state errors early |
| 37 | **B** | Structured message format achieves 15–25% token reduction in conversation history |
| 38 | **C** | Refund tiers: small=Notification, medium=Approval, large=Approval+escalation |
| 39 | **D** | Miscalibrated thresholds flood users with low-value approvals → approval fatigue |
| 40 | **C** | Human moderators provide irreplaceable contextual judgment for nuanced content |
| 41 | **C** | Calibrated uncertainty: acknowledge limits, provide caveats, refer to professionals |
| 42 | **A** | True multimodal systems: simultaneous cross-modal reasoning (not sequential fusion) |
| 43 | **C** | Bidirectional validation: intercept SQL queries AND redact sensitive fields in results |
| 44 | **C** | ReAct with mandatory data retrieval step between reasoning and action |
| 45 | **A** | Colang four concepts: define, flow, execute, return |
| 46 | **B** | Quantization reduces precision proportionally; delivers faster inference + storage savings |
| 47 | **C** | P95 < 5.0s and P99 < 8.0s as SLOs for 50K daily users chatbot |
| 48 | **D** | LLM-as-judge on 200-query test set at each canary deployment stage |
| 49 | **D** | Source validation allowlists filter retrieved chunks by document provenance |
| 50 | **D** | Evaluation strategy: LLM-as-judge + grounding checks + vector similarity for quality |
| 51 | **D** | Overengineering signs: unnecessary agent fragmentation, complexity without ROI |
| 52 | **D** | RAG caching effective where P99 improved 45% vs 20% average — high cache hit rate |
| 53 | **D** | AI-aware routing: conversation-ID-based hashing for KV cache locality |
| 54 | **B** | Filter retrieved docs to 15–20 highest-quality; reserve headroom for reasoning |
| 55 | **A** | NeMo rail mapping: PII=Block, political=Flag, profanity=Filter, JSON=Validate |
| 56 | **B** | Model router: simple queries→7B, complex queries→70B; saves cost on routine traffic |
| 57 | **C** | Hybrid search: retrieve k×2=200 candidates from each method before RRF fusion |
| 58 | **A** | NeMo Guardrails wraps NIM as protective filtering layer; NIM handles generation |
| 59 | **D** | Routing: check tests first, then quality metrics; route to END/fix_bugs/improve_quality |
| 60 | **A + C** | Cost reduction: model routing 70%→7B + prompt optimization for token savings |
| 61 | **C + D** | stateless workers→Deployment; vector DB→StatefulSet with PVC for persistence |
| 62 | **C** | Context grows progressively; accelerates especially with tool outputs and history |
| 63 | **C** | AI agents introduce planning failures requiring three-tier taxonomy classification |
| 64 | **A** | Three memory layers in 8k budget: recent context + compressed history + user profile |
| 65 | **B** | Scale on queue depth (10–20 msg/replica) not CPU; GPU inference ≠ CPU-bound |
| 66 | **B** | LangGraph: sequential stages + conditional feedback loop + specialized typed state |
| 67 | **D** | Evaluate Cohere embed-english-v3.0 for search-optimized retrieval (not always largest model) |
| 68 | **C** | Test retrieval reduction on evaluation set; only deploy if accuracy is maintained |
| 69 | **D** | NetworkPolicy in prod namespace: allow coordinator→worker, block coordinator→database |
| 70 | **B** | Waterfall views show span hierarchies as timeline: parent-child timing, bottlenecks visible |

---

## TEST 06

| Q | Answer | Key Concept |
|---|--------|-------------|
| 1 | **A** | In-memory for <1K docs with rapid iteration; plan migration to vector DB when needed |
| 2 | **B** | Dense embeddings as baseline; layer hybrid search selectively for exact-match queries |
| 3 | **D** | Multi-agent frameworks enable specialization and parallel execution |
| 4 | **D** | Systematic distributed tracing resolves bottlenecks in minutes/hours vs days of guesswork |
| 5 | **B** | Token budget: truncation+hierarchical compression for long-running; summary memory for multi-session |
| 6 | **C** | Inline validation: prevent invalid states from being entered with real-time constraints |
| 7 | **B** | AutoGen coordination: conversation-driven via natural language messages (messages ARE control flow) |
| 8 | **B** | Tool descriptions lack detail on when to use each tool; add comprehensive applicability guidance |
| 9 | **A** | Consolidate 45 fine-grained categories → 12–15 user-centric categories to reduce clarification loops |
| 10 | **B** | 30+ tools cause decision paralysis, inconsistent selection, degraded reasoning quality |
| 11 | **B** | Custom NeMo guardrail: Colang flow for conversation pattern + Python action for detection logic |
| 12 | **C** | Option B saves more net: 35% token reduction × no infrastructure cost vs Option A's high overhead |
| 13 | **C** | 53% token increase most likely from recent prompt update or tool description expansion |
| 14 | **D** | OpenTelemetry: TracerProvider + BatchSpanProcessor + nested spans + Jaeger/Tempo export |
| 15 | **D** | Form-based filtering enforces structural constraints independent of semantic content |
| 16 | **B** | Sliding window advance = chunk_size − overlap = 512 − 102 = 410 tokens per step |
| 17 | **C** | Resource config: requests at p75, CPU limits at p95, memory limits at p99 |
| 18 | **B** | A2A (Agent-to-Agent) protocol handles workflow orchestration via capability discovery |
| 19 | **A** | User-facing errors: non-technical, actionable (try refreshing/contact support) |
| 20 | **A** | temperature=0 maximizes determinism for production financial reporting pipelines |
| 21 | **A** | Execution failures: correctly planned actions fail due to infrastructure/external issues |
| 22 | **B** | Planning failures: reasoning produces logically inconsistent strategy despite technical success |
| 23 | **A** | Include Documents A+C+E (7k tokens, high density); leave 9k headroom for reasoning |
| 24 | **A** | Multi-signal escalation: low confidence AND negative sentiment AND repeated failures |
| 25 | **A** | $check_facts automatically verifies LLM responses against retrieved evidence |
| 26 | **D** | Systematic component-level optimization across all layers delivers major efficiency gains |
| 27 | **D** | Three channels for status indicators: color + icon + text label (WCAG compliance) |
| 28 | **C** | Sequential pipeline stages: chunk → validate → embed → index → with logging between each |
| 29 | **D** | Incremental hierarchical compression starting at turn 20; recency-weighted detail |
| 30 | **D** | Working-to-episodic encoding: selective transfer of high-significance experiences with timestamps |
| 31 | **C** | Response A (profanity): sanitize; Response B (hate speech/misinformation): reject entirely |
| 32 | **B** | ConversationBufferMemory(memory_key="chat_history", return_messages=True) for chat models |
| 33 | **C** | Benchmark data uses formal language; production users use messy real-world language |
| 34 | **C** | Appropriate politeness: friendly + truthful; sycophancy: agreeable but dishonest |
| 35 | **A** | Email=Notification, Account changes=Approval, Refunds $500+=Approval, Exceptions=Approval+manager |
| 36 | **D** | Recency-weighted: recent 10 turns full detail, middle compressed, oldest aggressively compressed |
| 37 | **B** | Content-type-specific: 256 tokens for FAQs, 512 with 20% overlap for technical documentation |
| 38 | **A** | Accept optimization: 40% token reduction + 2× per-token speed = substantial combined gain |
| 39 | **C** | Store thresholds in dedicated thresholds.yaml config file separate from workflow logic |
| 40 | **D** | Three-stage pipeline: INT8 quantization → structured pruning → knowledge distillation |
| 41 | **B** | AgentExecutor: verbose=False (security), handle_parsing_errors=True (resilience) |
| 42 | **C** | AutoGen: AssistantAgent (LLM reasoning) and UserProxyAgent (human proxy + code execution) |
| 43 | **C** | Token budget: 30–35% context assembly, 10–15% reasoning, 40–50% generation, 5–10% reserve |
| 44 | **D** | Structured pruning (50% sparsity): device lacks sparse kernel support for unstructured pruning |
| 45 | **A** | Edge deployment justified on all three grounds: <100ms latency + privacy + offline operation |
| 46 | **C** | Specialized agents: focused responsibilities + clear failure boundaries = primary rationale |
| 47 | **C** | Output filtering on tool results: redact internal metadata before passing to LLM context |
| 48 | **B** | Use consistent organizational prefix for custom metrics (e.g., custom.empathy_score) |
| 49 | **B** | Accept efficiency improvements; simultaneously monitor accuracy and business impact |
| 50 | **C** | Reduce review volume via active learning; protect moderator welfare; use systematic sampling |
| 51 | **C** | Keyboard shortcuts for high-frequency actions: J/K navigation, P, L, F, D, ? for help |
| 52 | **C** | NeMo pipeline sequence: Input rails → Dialog rails → NIM inference → Output rails → Retrieval |
| 53 | **D** | NIM bundles: model weights + production inference engines + runtime + OpenAI-compatible API |
| 54 | **A** | Extended context techniques: length extrapolation, ALiBi, sliding windows, sparse attention |
| 55 | **A** | Scoring function: pure function, accepts response+context, returns normalized 0–1 scores |
| 56 | **A** | Power analysis for two-proportion test (alpha=0.05, beta=0.20) to determine sample size |
| 57 | **C** | NIM transforms LLM deployment from expert optimization into straightforward container deployment |
| 58 | **A + E** | Legal RAG: post-search field-level redaction + pre-search document collection partitioning |
| 59 | **B** | Parallel architecture eliminated multiplicative context duplication → 73% cost reduction |
| 60 | **D** | ChatPromptTemplate: SystemMessage + MessagesPlaceholder("chat_history") + HumanMessage |
| 61 | **C** | Monitoring pattern for 500 DB updates/hour: anomaly detection, not per-update approval |
| 62 | **D** | 90% sequential queries: LangGraph questionable; start with LangChain sequential |
| 63 | **B** | Prometheus as StatefulSet with PVC; persistent storage for time-series metric history |
| 64 | **C** | Precision = TP/(TP+FP): fraction of flagged content actually harmful |
| 65 | **A** | RAG for changing factual knowledge; fine-tuning for stable style/format/vocabulary |
| 66 | **B** | Planning paralysis: overly detailed plans with redundant intermediate steps |
| 67 | **D** | NIM benchmark: 2.5× throughput, 4× TTFT reduction, 3× inter-token latency reduction |
| 68 | **A** | RAG pipeline: distinct well-defined responsibilities per stage with inter-stage validation |
| 69 | **D** | Full keyboard access: logical tab order, visible focus, ARIA labels, shortcuts for all actions |
| 70 | **C** | LangChain sequential best suits: question → retrieve → answer (pure linear pipeline) |

---

## TEST 07

| Q | Answer | Key Concept |
|---|--------|-------------|
| 1 | **B** | High aggregate booking rate hides silent failures: pricing mismatches, redundant API calls |
| 2 | **D** | NIM connection refused: add -p 8000:8000 port mapping; confirm binds to 0.0.0.0 |
| 3 | **C** | Swarm: simple local rules produce complex emergent group behavior |
| 4 | **A** | With 85% baseline ±2% noise: set TSR threshold at 82–83% (3 points below) |
| 5 | **B** | Context saturation from extraneous load degrades signal-to-noise ratio |
| 6 | **C** | AutoGen: messages append to shared history visible to all via send()/receive() |
| 7 | **C** | Bidirectional validation: intercept inputs AND validate outputs for PII/data leakage |
| 8 | **A** | Stratified sampling: 60% common queries, 25% edge cases, 15% known failure modes |
| 9 | **C** | Category-specific thresholds for expense approval reduce fatigue |
| 10 | **B** | ConversationBufferMemory: complete verbatim history; grows linearly with each turn |
| 11 | **D** | Milvus supports four index types: HNSW, IVF, Annoy, DiskANN |
| 12 | **D** | AlignScore (45ms) for System A; NLI for System B (higher latency tolerance) |
| 13 | **A** | Klarna case: hierarchical memory + proactive anticipation + seamless human escalation |
| 14 | **B** | Triton backends: TensorRT for GPU, Python for custom ops, FIL for forest models |
| 15 | **B** | 5 trip complexity categories: Simple One-Way, Standard Round-Trip, Multi-City, International, Flexible |
| 16 | **A** | Proactive = push-based autonomous monitoring; not request-response |
| 17 | **D** | Personas match brand identity; consistency builds user trust |
| 18 | **A** | Hierarchical compression: multiple granularity levels simultaneously |
| 19 | **A** | CI/CD eval: automated trigger + dataset + execution + metrics + decision gate |
| 20 | **D** | Structured handoff package: summary + transcript + account info + resolutions + next steps |
| 21 | **D** | GDPR extraterritorial: applies to goods/services offered to or monitoring EU residents |
| 22 | **A** | NIM: evaluate profile trade-offs for latency vs. throughput before selecting |
| 23 | **D** | Document Q&A is sequential; LangChain appropriate; LangGraph is overkill |
| 24 | **B** | Blackboard pattern: agents coordinate via shared memory, no direct inter-agent messaging |
| 25 | **A** | In-flight batching: dynamically groups arriving requests; no assembly wait required |
| 26 | **C** | Hierarchical for tech support, truncation for FAQ, sliding window for project management |
| 27 | **A** | Vector databases: specialized systems organizing high-dimensional vectors for ANN search |
| 28 | **D** | SLOs = internal targets driving engineering decisions; SLAs = external contractual commitments |
| 29 | **D** | Silent failure: transaction completes with HTTP 200 and no errors but wrong price applied |
| 30 | **D** | Conversational ReAct agent: pronoun resolution requires conversation history |
| 31 | **B** | Pre-normalize chunks at index time; normalize only query at search time |
| 32 | **C** | CrewAI sequential = predefined order; hierarchical = manager LLM + dynamic delegation |
| 33 | **B** | NeMo Guardrails appropriate for fintech: declarative policy configuration |
| 34 | **D** | ReAct inappropriate for deterministic structured classification tasks |
| 35 | **B** | Performatives encode communicative intention: request, inform, propose, commit |
| 36 | **A** | Hard iteration limit + checkpointing + server-side log pre-filtering for stuck agents |
| 37 | **A** | NIM init failure: verify NGC_API_KEY, registry connectivity, GPU memory availability |
| 38 | **D** | Optimize TTFT from 800ms → 200ms using vLLM continuous batching |
| 39 | **C** | ReAct: 7–14 LLM calls vs 1–2 direct; meaningful cost increase per task |
| 40 | **C** | WCAG: triple redundancy — color + icon + text label for status indicators |
| 41 | **B** | Triton: unified HTTP/gRPC API abstracting backend heterogeneity |
| 42 | **D** | Reduce NIM_MAX_MODEL_LEN from 8192 to 2048 to recover KV cache memory |
| 43 | **A** | Verification failures: no exceptions, HTTP 200, pass schema validation → silent errors |
| 44 | **C** | Vendor lock-in: quantify risk, weigh benefits, document migration plan |
| 45 | **C** | AlignScore ~88.5% accuracy; ~11.5% hallucinations pass through undetected |
| 46 | **C** | Six dominant vector DBs: Milvus, Weaviate, Pinecone, Chroma, Qdrant, pgvector |
| 47 | **C** | Checkpoint selectively after expensive nodes: research ($0.50), generate ($0.20) |
| 48 | **C** | CrewAI three building blocks: Agents, Tasks, Crew |
| 49 | **C** | Conversational ReAct config: LLM + tools + ConversationBufferMemory + ChatPromptTemplate + AgentExecutor |
| 50 | **D** | Guardrail overhead: 10–30ms for non-violating requests |
| 51 | **C** | Post-filtering detects statistical anomalies in rejection language distributions |
| 52 | **D** | Consistency metrics: reproducibly safe responses to semantically similar inputs |
| 53 | **A + C** | Token budget: truncation, compression, selective retrieval, caching |
| 54 | **A** | Nash equilibrium: stable attractor; no agent can improve by unilateral change |
| 55 | **C** | One misbehaving pod + no resource limits → cascade; fix: limits + circuit breakers + PDB + HPA |
| 56 | **A** | No task benefits from blanket CoT; 2–5× overhead only justified for specific complex steps |
| 57 | **D** | Continuous evaluation integrated with CI/CD, triggered on every code change |
| 58 | **D** | aria-live="assertive" on all 15 containers creates audio chaos — do not do this |
| 59 | **C** | Batch ~100 chunks per request; store in numpy array for efficient processing |
| 60 | **D** | All token consumers (system prompt, history, retrieved docs, tools, output) share context window |
| 61 | **D** | Colang: 3–5 example canonical forms + blocking flow with execute action |
| 62 | **C** | 128k context: 16× attention compute increase; approve only for workflows that need it |
| 63 | **D + E** | Tensor parallelism 8-way across 8 A100 GPUs; verify architecture compatibility first |
| 64 | **D** | ReAct inappropriate for 500ms fraud detection; use deterministic ML pipeline instead |
| 65 | **C** | Agent B dominates: lower cost AND better accuracy (no trade-off needed) |
| 66 | **D** | Different tokenizers produce significantly different counts; use target model's tokenizer |
| 67 | **D** | Retrieve k=100 from each method, apply RRF weight/(rank+60), alpha=0.5 |
| 68 | **D** | Two-turn memory overhead minimal; add ConversationBufferMemory for tracking |
| 69 | **C** | Offline evaluation with 500-example dataset for low-risk prompt change |
| 70 | **D** | P95 and P99 latency capture tail behavior; no universal P99=2–3×P50 rule |

---

## TEST 08

| Q | Answer | Key Concept |
|---|--------|-------------|
| 1 | **D** | Context saturation root cause; curated pipeline: semantic→reranking→extraction→dedup |
| 2 | **B** | Dynamic batching maximizes GPU parallelism via CUDA core saturation |
| 3 | **C** | Static classifiers miss evolving subtle bias; multi-dimensional detection required |
| 4 | **A** | Triton: preferred_batch_size [8,16,32], max_queue_delay 5000μs, max_queue_size 64 |
| 5 | **B** | Cascaded AlignScore→NLI achieves <2% hallucination for medical information |
| 6 | **B** | Chat: 10–20ms max_queue_delay; Batch: 1000–2000ms (proportioned to SLO target) |
| 7 | **C** | Minimum 26,850 tokens: 750+4200+15000+3000+2900 = full RAG token accounting |
| 8 | **D** | 256k nominal → ~100k–150k effective reasoning capacity (40–60% rule) |
| 9 | **C** | Hierarchical compression: recent (last 5–10) verbatim, intermediate moderate, distant high compression |
| 10 | **A** | Establish baseline metrics first (TSR, P95, cost, retrieval quality) before any changes |
| 11 | **B** | Three separated concerns: (1) metrics computation, (2) comparison+decision, (3) reporting |
| 12 | **D** | NIM Operator + declarative YAML manifests for full lifecycle management |
| 13 | **A** | AutoGen iterative quality cycles: conversation-driven negotiation via shared message history |
| 14 | **A** | Specialized system messages with distinct roles, responsibilities, and output expectations |
| 15 | **C** | p=0.08 > 0.05: do not deploy; expand evaluation dataset to achieve statistical significance |
| 16 | **D** | Hybrid: Plan-and-Execute for predictable Phase 1, ReAct for adaptive Phase 2 |
| 17 | **D** | GDPR six lawful bases: consent, contract necessity, legal obligation, vital interests, public task, legitimate interests |
| 18 | **C** | Multi-agent unnecessary when single agent with tools handles task without coordination overhead |
| 19 | **B** | Explicit grounding instructions: answers must be based only on retrieved evidence with citation |
| 20 | **B** | LangChain linear model: less code, fewer concepts, faster delivery for sequential workflows |
| 21 | **A + B** | Cybersecurity: graduated autonomy with oversight + contextual awareness to distinguish anomalies |
| 22 | **C** | Top 3 chunks above 0.7 threshold are relevant; 0.58 and 0.45 are marginal — apply threshold |
| 23 | **C** | GPT-4 for planning; intelligent routing for execution (cheaper model for simple steps) |
| 24 | **B** | GPU memory constraints: KV cache and attention matrices for 128k can exceed VRAM |
| 25 | **B** | Burn rate = current error rate / SLO error budget threshold; measures budget consumption pace |
| 26 | **C** | P95 latency reveals tail behavior affecting 5% of users; not visible in mean |
| 27 | **C** | Proactive agents: predictive intelligence + contextual awareness + autonomous decision-making |
| 28 | **D** | CrewAI: roles, goals, AND backstories all shape agent behavior throughout execution |
| 29 | **A** | Four rollback criteria: TSR −5%, P95 latency +200ms, error rate >2%, cost +50% |
| 30 | **D** | Deploy open-source baseline (E5-Large-V2), measure, evaluate alternatives, migrate by evidence |
| 31 | **A** | Burn rate normalizes error rates into time-to-exhaustion relative to each SLO budget |
| 32 | **B** | Qdrant's primary focus: filtering performance with complex metadata predicates (Rust-built) |
| 33 | **A** | Financial RAG response: answer + structured citations with chunk IDs + token usage + confidence |
| 34 | **C** | Dynamic batching: batch of 8 in 15ms = 533 req/s vs 100 req/s single ≈ 5.3× improvement |
| 35 | **D** | Instrument all components with distributed tracing to identify P95=8s bottleneck |
| 36 | **D** | NIM Enterprise: CVE patches + private registry + data encryption + production SLAs |
| 37 | **D** | Three contextual awareness layers: short-term (hours-days), long-term (weeks-months), environmental |
| 38 | **A** | LangGraph iterative debug: four nodes (generate, test, analyze, quality_check) + conditional routing |
| 39 | **B** | AutoGen shared history makes all messages visible; enables evidence-based challenge and revision |
| 40 | **D** | Streaming issue: 5 tokens/sec far below 20–30 tokens/sec threshold; prioritize generation rate |
| 41 | **B** | Compose all three NeMo rail types (retrieval, dialog, fact-checking) in single Colang config |
| 42 | **D** | Centralized orchestration: predictability + simplified debugging through single coordination point |
| 43 | **B** | REST: JSON/HTTP/1.1; gRPC: binary Protocol Buffers/HTTP/2 with streaming support |
| 44 | **B** | Effective reasoning capacity: typically 40–60% of nominal context window (lost-in-middle) |
| 45 | **B** | Medical AI: prioritize recall (miss no harmful content); customer service: balance precision-recall |
| 46 | **A** | Chroma: embedded, optimized for local development; scale threshold ~1M vectors |
| 47 | **A** | AutoGen UserProxyAgent: multiple reply functions with priority ordering via register_reply() |
| 48 | **D** | Error classification (transient/permanent) → retry/backoff → replan → checkpoint state |
| 49 | **C + D** | Colang approval workflow: await statement + stateful variables persisting refund_amount |
| 50 | **B** | Validation workflow: prepare dataset → baseline → implement → measure → compare → deploy/rollback → monitor |
| 51 | **B** | CrewAI allow_delegation=True adds "Delegate work to coworker" and "Ask question to coworker" tools |
| 52 | **A** | Systematic approach: baseline profiling → measure TTC/tokens/cost per category → optimize |
| 53 | **A** | ReAct: 8×2×$0.03=$0.48; Plan-and-Execute: $0.06+$0.04=$0.10; ~4.8× cost difference |
| 54 | **B** | Fix planning paralysis (constrain to 8–10 steps); parallelize independent steps in LangGraph |
| 55 | **D** | Lost-in-middle: Critical docs at positions 1+6, High at 2+5, Medium at 3+4 |
| 56 | **A** | Semantic Kernel: capability extensibility via plugin architecture (enterprise service orchestration) |
| 57 | **C** | Weaviate: GraphQL API + built-in multi-provider vectorization + multi-modal data support |
| 58 | **D** | MIG: partitions A100/H100 into isolated instances with dedicated compute + memory |
| 59 | **A** | Test prompt change and model switch independently; GPT-4 prompts may not transfer to Claude |
| 60 | **D** | Streaming accessibility: visual=immediate tokens; screen reader=batch sentences via polite aria-live |
| 61 | **D** | GDPR valid consent: freely given + specific (per purpose) + informed + unambiguous opt-in |
| 62 | **D** | Offline reliably measures TSR/factual accuracy/policy compliance; user satisfaction requires online |
| 63 | **D** | Event-driven = async publish-subscribe (no publisher-consumer coupling); message passing = point-to-point |
| 64 | **C** | NIM HPA: custom metrics (queue depth + GPU%), min=2, max=10, asymmetric stabilization windows |
| 65 | **C** | Asymmetric scaling: fast scale-up (0s stabilization), slow scale-down (300s) prevents flapping |
| 66 | **D** | Accessible form validation: inline on-blur + ARIA associations + correction suggestions |
| 67 | **C** | Severe non-linear degradation 50→100 RPS signals saturation; 80 RPS P99 non-linearly elevated |
| 68 | **B** | NIM: 1.9–2× throughput improvement through TensorRT-LLM optimization and Triton batching |
| 69 | **D** | AutoGen GroupChat: configure max_round (hard limit) + choose speaker_selection_method carefully |
| 70 | **C** | Local NIM: isolated dev environments + reduced cloud costs during development phases |

---

## TEST 09

| Q | Answer | Key Concept |
|---|--------|-------------|
| 1 | **A** | Perception pipeline: sensor acquisition → signal processing → multimodal fusion → contextual interpretation |
| 2 | **B** | Raw PyTorch lacks memory layout optimization, kernel fusion, KV-cache strategies |
| 3 | **A** | Multi-dimensional temporal optimization: priority-based timing + daily cap of 3 per user |
| 4 | **A** | Recall 95%→98%: precision drops to 50–60%, alert fatigue, appeals overflow, reduced safety |
| 5 | **B** | Multi-stage retrieval: semantic search → cross-encoder reranking → extractive reading → dedup |
| 6 | **A** | Entailment checking (NLI) verifies summary claims are supported by source conversation |
| 7 | **A** | GDPR DSAR response: data copy + processing purposes + categories + recipients + retention + rights |
| 8 | **C** | Code analysis: Stage 1 semantic search top-100 → Stage 2 reranking → Stage 3 extractive+dedup |
| 9 | **B** | CrewAI hierarchical with manager_llm for dynamic decomposition and delegation |
| 10 | **D** | Triton ensemble: declarative tensor mappings between model inputs and outputs |
| 11 | **A** | Multi-layered guardrails: input + retrieval + fact-check + output + user education |
| 12 | **C** | AutoGen: communicate custom state through shared message history content |
| 13 | **B** | TSR threshold: 84–85%, which is 2–3 points below 87% baseline |
| 14 | **B + E** | QA: 60% retrieval-heavy; Analytical: 30% retrieval + 35% reasoning |
| 15 | **B** | Input rails intercept profanity before reaching NIM inference |
| 16 | **A** | Unified embedding service with adaptive batch sizing for efficiency |
| 17 | **B + C** | High-risk human-in-loop actions: retain approval; low-risk: migrate to monitoring |
| 18 | **B** | Semantic Kernel: service registration + plugin registration + execution coordination |
| 19 | **C** | Short-term memory = active context window; clears between sessions (not persisted) |
| 20 | **A** | Kernel fusion reduces memory bandwidth by 40–50% through combined operations |
| 21 | **D** | S3/GCS shared model repository + model control API for zero-downtime model updates |
| 22 | **C** | Three temporal horizons: minutes-to-hours, days-to-weeks, months-to-years |
| 23 | **D** | 95% GPU memory + 45% compute = memory-bound from KV cache overflow |
| 24 | **B** | temperature=0 fixes individual calls; GroupChat auto-speaker selection still causes divergence |
| 25 | **B** | Importance scoring: multi-factor — information density, error codes, recency, query relevance |
| 26 | **C** | Dual-agent quality-triggered reflection with measurable thresholds before stopping |
| 27 | **D** | HNSW: sparse upper layers for coarse navigation → dense lower layers for fine search |
| 28 | **B** | Semantic Kernel kernel coordinates: service registration + plugin registration + execution |
| 29 | **C** | Triton dims specifies per-sample shape excluding batch dimension (Triton auto-prepends batch) |
| 30 | **B** | NeMo Guardrails: RailsConfig + LLMRails wrapper around NIM endpoint |
| 31 | **D** | A/B test: thousands per group, multiple days, diverse query types, p<0.05 required |
| 32 | **C** | In-memory now; migrate to vector DB before scaling to 50K documents |
| 33 | **D** | TensorRT-LLM: precision reduction + kernel fusion + KV-cache + attention optimization |
| 34 | **C** | Semantic=factual/timeless, episodic=timestamped events, procedural=learned strategies |
| 35 | **B** | NIM persistent volume mounts eliminate redundant weight downloads on restart |
| 36 | **B** | Layered security: scoped auth + input validation + output filtering + audit logging |
| 37 | **A** | Chunk size 512–1024 tokens for single-topic coherence in RAG |
| 38 | **A** | Reflection at high temperature degrades deterministic accuracy |
| 39 | **A + E** | LangGraph: citations → Annotated[List, operator.add]; current_summary → str (plain overwrite) |
| 40 | **D** | CrewAI manager: LLM-driven quality evaluation + conditional revision delegation |
| 41 | **D** | Semantic Kernel: semantic functions = NL prompts; native functions = deterministic Python code |
| 42 | **C** | Graduated autonomy: dynamic calibration based on task risk, confidence, and context |
| 43 | **D** | NVIDIA Container Toolkit: runtime hooks inject GPU device files and driver libraries |
| 44 | **B** | MRL: prefix truncation without re-embedding; valuable for varying latency/storage trade-offs |
| 45 | **C** | p<0.05 necessary but not sufficient; evaluate practical significance + rollout risk |
| 46 | **B** | Four-level evaluation pyramid: unit → offline → staging → online A/B |
| 47 | **D** | Define SLOs and thresholds before building alert logic |
| 48 | **B** | GDPR 8 data subject rights under Articles 15–22 |
| 49 | **D** | ANN trade-off: accuracy vs. speed (approximate search sacrifices exactness for throughput) |
| 50 | **D** | CrewAI sequential for linear dependent content pipeline |
| 51 | **C** | Stopping criteria: max iterations + quality threshold + diminishing returns detection |
| 52 | **A + B** | Enable Triton batching for TensorRT/ONNX/PyTorch backends; NOT for vLLM |
| 53 | **D** | Canary with rollback at 88%: midpoint between 85% constraint and 91% baseline |
| 54 | **A** | Staging evaluation: after offline evaluation, before canary deployment |
| 55 | **B** | Summarization can hallucinate; validation of summaries is required |
| 56 | **A** | TTC analysis per query category first to identify token consumption bottlenecks |
| 57 | **C** | Multi-agent coordination failures from inter-agent communication and state synchronization |
| 58 | **A** | Error budget: 0.5% × 720h = 3.6 hours for 99.5% SLO |
| 59 | **B** | CrewAI context parameter for explicit task dependencies between agents |
| 60 | **B** | Atomic tools with single, well-defined responsibilities |
| 61 | **C** | Manual testing: low coverage, inconsistent, cannot catch regressions |
| 62 | **B** | Exact nearest neighbor (ENN): O(n) complexity prohibitively slow at scale |
| 63 | **A** | Memory persists state across interactions; perception transforms inputs into structured representations |
| 64 | **C** | Triton ensemble for model-to-model chaining; application-level for branching/human-in-the-loop |
| 65 | **B** | Benchmarking: performance measurement + regression detection + capability gap identification |
| 66 | **C** | LLM generation at 1840ms dominates pipeline; optimize this first |
| 67 | **B** | Clinical safety filters + crisis resource integration for HIPAA mental health chatbot |
| 68 | **A** | Coordinator batching + async queuing eliminates serial bottleneck in multi-agent pipelines |
| 69 | **B** | Importance scoring: recency + semantic similarity to current query |

---

## TEST 10

| Q | Answer | Key Concept |
|---|--------|-------------|
| 1 | **C** | Traditional K8s lacks GPU-aware scheduling, MIG partitioning, inference-specific metrics |
| 2 | **A** | NIM model change: only model name changes; API is identical (OpenAI-compatible) |
| 3 | **A** | REST for compatibility/debugging; gRPC for high-throughput with Protocol Buffers |
| 4 | **B** | 88% in-distribution → 67% OOD = overfitting to training distribution (distribution shift) |
| 5 | **D** | KEDA + Prometheus + Triton queue metrics + HPA stabilizationWindowSeconds |
| 6 | **D** | Semantic Kernel dynamic plugin routing: LLM-driven intent matching at runtime |
| 7 | **A** | LangGraph checkpointing for human-in-the-loop review + resumability — critical for healthcare |
| 8 | **C** | DPIA required: systematic monitoring, large-scale sensitive data, automated significant decisions |
| 9 | **A** | Multimodal fusion: combine modalities into unified richer representation |
| 10 | **C** | OpenTelemetry: W3C context propagation + parent-child spans + correlated metrics/logs |
| 11 | **A** | CrewAI allow_delegation=True enables inter-agent collaboration |
| 12 | **B** | AutoGen for dynamic unpredictable exploratory research tasks |
| 13 | **C** | P99/P99.9 latency reveals tail latency hidden by acceptable averages |
| 14 | **B** | AgentBench: distinguishes genuine general capability from benchmark overfitting |
| 15 | **A** | Semantic memory=general factual/timeless; episodic=specific events with timestamps |
| 16 | **A** | NIM migration: change only base_url + api_key; OpenAI-compatible API preserved |
| 17 | **C** | Five production vector DB dimensions: connectivity, auth, persistence, performance, monitoring |
| 18 | **B** | Report P50/P95/P99 alongside mean; mean alone hides tail latency behavior |
| 19 | **C** | Sliding window chunking with overlap: 512–1024 tokens, tiktoken for accurate counting |
| 20 | **C** | Evaluation triggers: code commits + scheduled intervals + metric drift detection |
| 21 | **C** | Content-type-aware chunking: code by function/class, docs by section, emails by thread |
| 22 | **A** | Hierarchical memory: recent=full detail, intermediate=summaries, distant=metadata only |
| 23 | **C** | Explicit state: context continuity + completion tracking + failure recovery |
| 24 | **D** | High confidence = internal certainty, not external validity; unknown unknowns require oversight |
| 25 | **D** | Diminishing returns detection: stop when improvement delta < threshold |
| 26 | **B** | Tensor parallelism=split weights, cooperate per request; data parallelism=replicate, independent batches |
| 27 | **B** | Pre-deployment evaluation gates: must pass before any deployment |
| 28 | **B** | Semantic functions = prompt templates rendered with variables, executed by LLM |
| 29 | **C** | Four metric categories: TSR, resource consumption, latency percentiles, error classification |
| 30 | **D** | GDPR automated investment: DPIA + Article 22 rights + explicit consent + data minimization |
| 31 | **A** | Cosine similarity: angular alignment, magnitude invariant, captures semantic direction |
| 32 | **C** | Downstream slow → upstream threads block → connection pool exhaustion → cascade failure |
| 33 | **A** | Example configs are starting points; production requires custom calibration for your workload |
| 34 | **C** | Defense-in-depth: single layer insufficient; multiple independent layers required |
| 35 | **D** | Improve tool descriptions to clarify when each tool should and should not be used |
| 36 | **D** | Child span under LLM generation parent; record filter type and outcome as span attributes |
| 37 | **D** | Distribution shift: regulatory language changed; RAG augmentation or fine-tuning required |
| 38 | **D** | Context saturation: 80% full leaves insufficient tokens for reasoning operations |
| 39 | **D** | Implementation order: SLOs → unit tests → offline dataset → staging → online A/B |
| 40 | **C** | Refresh evaluation dataset: new features + current distribution + recent production edge cases |
| 41 | **D** | Namespaced shared memory with agent-specific permissions + explicit handoff protocols |
| 42 | **A** | Too many similar tools overwhelm LLM selection; LLMs best with 5–10 distinct tools |
| 43 | **C** | Triton monitoring: throughput + queue depth + GPU/DCGM + P95/P99 + model-specific metrics |
| 44 | **A** | ACP compliance ≠ semantic correctness; ownership/schemas are application design decisions |
| 45 | **D** | Context anxiety: models reason better with generous context headroom |
| 46 | **B** | Agentic RAG: multiple iterative adaptive retrievals; standard RAG: single retrieve-generate |
| 47 | **A** | AutoGen=full shared history; CrewAI=targeted context parameter for task dependencies |
| 48 | **C** | Observability: root cause analysis + optimization + proactive detection |
| 49 | **B** | StatefulSet + PVC + Service + ResourceQuota for vector DB cluster deployment |
| 50 | **A** | AutoGen for interactive tutorial with dynamic back-and-forth dialogue |
| 51 | **B** | Shared outcome history for competitive bidding multi-agent learning |
| 52 | **A** | Explicit context capacity signals in system prompt to exploit context anxiety effect |
| 53 | **D** | Risk-based autonomy: informational=autonomous, analysis=notify, trades=approval |
| 54 | **D** | TensorRT engines are GPU-architecture + CUDA-version specific; must rebuild per environment |
| 55 | **B** | Offline data staleness + diversity limitations = online A/B testing required |
| 56 | **A** | KV cache: linear growth with sequence length = batch_size × seq_len × layers × heads × dim × bytes |
| 57 | **D** | NIM containers include runtime; model weights downloaded at first launch from NGC |
| 58 | **A + B** | Structured state tracking + iteration loops → migrate from LangChain to LangGraph |
| 59 | **A** | Nash equilibrium for competitive auction resource allocation among agents |
| 60 | **C** | Vector similarity is temporally blind; metadata date filtering required for recency |
| 61 | **D** | Task-type-specific token requirements: QA=retrieval-heavy, reasoning=reasoning-heavy, creative=output-heavy |
| 62 | **A** | Logic trees: hierarchical conditional decision structures for agent routing |
| 63 | **A** | Lazy retrieval: classify first; retrieve only for factual/case-specific queries |
| 64 | **A** | CrewAI sequential for clear sequential content production pipeline |
| 65 | **D** | GDPR Article 32: pseudonymization + encryption + resilience + regular testing |
| 66 | **C** | Hierarchical compression for 50-turn planning: recent verbatim, middle=summaries, distant=metadata |
| 67 | **C** | Procedural memory for learned refund-handling strategies across multiple sessions |
| 68 | **D** | Qdrant: Rust-based, advanced filtering, handles current 50K and future 500K vector scale |
| 69 | **A** | Native functions for deterministic operations: DB queries, math, API calls, file I/O |
| 70 | **C** | 7 embedding models on A100: use MIG 7×1g.10gb profiles for hardware isolation |

---

## Key Citations & Sources

All answers are drawn directly from the attached explanation files:

- **Tests 01 & 02** — `explanations_tests01_02.md` (70 questions each)
- **Tests 03 & 04** — `explanations_tests03_04.md` (70 questions each)
- **Tests 05 & 06** — `explanations_tests05_06.md` (70 questions each)
- **Tests 07 & 08** — `explanations_tests07_08.md` (70 questions each)
- **Tests 09 & 10** — `explanations_tests09_10.md` (69–70 questions each)

> **Note on answer conflicts:** A small number of questions show a discrepancy between the bolded "Answer:" letter and the explanation content. In those cases the **explanation content** is the reliable source. Test 04 Q20–Q70 answer letters are included but key concept detail was not captured during extraction.

---

## Quick Reference: High-Frequency Concepts

| Topic | Key Rule |
|-------|----------|
| **Token pricing** | Output tokens cost 1.5–3× more than input → reduce output first |
| **Prompt caching** | Cache system instructions + tool descriptions (stable); not dynamic context |
| **MRL embeddings** | Leading dimensions most critical; truncate at any prefix; ideal for two-stage retrieval |
| **Approval fatigue** | Signals: >97% approval rate, <5s reviews, <1% modifications |
| **LangGraph vs LangChain** | LangGraph for cycles/branching; LangChain for simple sequential workflows |
| **Trust equation** | T = Transparency × Control (multiplicative, not additive) |
| **WCAG 2.1 AA** | 4.5:1 normal text; 3:1 large text (18pt+ regular / 14pt+ bold) |
| **P99 latency** | 99% of requests are faster than this; 1% exceed it (tail latency indicator) |
| **NeMo rail types** | Input, Dialog, Retrieval, Execution, Output, Fact Checking (six total) |
| **NeMo action types** | Block, Filter, Flag, Modify, Validate, Human Intervention (six total) |
| **Token-to-word ratio** | ~1.3–1.5 tokens per word for English text |
| **TSR minimum** | 80% Task Success Rate = minimum production readiness threshold |
| **Auto-CoT pipeline** | Cluster questions → select representatives → generate zero-shot rationales |
| **Defense-in-depth** | Multiple INDEPENDENT layers using DIFFERENT techniques |
| **Cosine similarity** | Dot product of two unit vectors; range [-1, 1]; measures angular alignment |
| **RRF formula** | score = weight / (rank + 60); combines dense + sparse retrieval results |
| **TTFT** | Time-to-First-Token; critical for streaming (perceived responsiveness) |
| **Shift-left testing** | Find bugs early: dev=1× cost; production=100× cost |
| **Serverless cold starts** | Zero cold start requires Azure Premium Plan / AWS Provisioned Concurrency |
| **Context O(N²)** | Transformer attention is O(N²); doubling context quadruples compute |
| **ReAct pattern** | Thought→Action→Observation; grounded in external tool outputs; reduces hallucination |
| **Effective context** | ~40–60% of nominal window is reliably usable (lost-in-middle effect) |
| **Nash equilibrium** | Stable attractor; no agent can improve outcome by unilateral strategy change |
| **AlignScore accuracy** | ~88.5% accuracy; ~11.5% hallucinations pass through |
| **Chunk size** | 512–1024 tokens for single-topic coherence in RAG pipelines |
| **GDPR consent** | Freely given + specific (per purpose) + informed + unambiguous opt-in (4 requirements) |
| **Burn rate** | Current error rate / SLO error budget threshold; >1.0 means budget exhausts before period end |
| **MIG partitioning** | A100/H100 only; isolated instances with dedicated compute + memory per partition |
| **Colang concepts** | define, flow, execute, return (four core DSL concepts) |
| **Plan-and-Execute vs ReAct** | Plan-and-Execute ~4.8× cheaper; uses cheaper model for execution steps |
| **Asymmetric HPA scaling** | Fast scale-up (0s stabilization); slow scale-down (300s) prevents flapping |
