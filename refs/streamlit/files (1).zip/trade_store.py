*** Begin Patch
*** Update File: trade_store.py
@@
-"""
-SQLite utility functions for the Educational Stock Trading Simulator.
-
-The trade ledger is the durable source of truth. The Streamlit app rebuilds
-cash, holdings, and the trade-history dashboard by replaying the rows stored
-in this database.
-"""
+"""
+SQLite utility functions for the Educational Stock Trading Simulator.
+
+The trade ledger is the durable source of truth. The Streamlit app rebuilds
+cash, holdings, and the trade-history dashboard by replaying the rows stored
+in this database.
+"""
@@
-from __future__ import annotations
-
-import sqlite3
-from pathlib import Path
-from typing import Any, Iterable
+from __future__ import annotations
+
+import json
+import logging
+import sqlite3
+from decimal import Decimal, ROUND_HALF_UP
+from pathlib import Path
+from typing import Any, Iterable
+
+
+logger = logging.getLogger(__name__)
+
+DB_SCHEMA_VERSION = 2
+MONEY_QUANT = Decimal("0.01")
@@
 TRADE_COLUMNS = (
     "id",
     "executed_at",
     "side",
     "ticker",
@@
     "cash_before",
     "cash_after",
     "reflection",
+    "idempotency_key",
 )
+
+
+def _to_decimal(value) -> Decimal:
+    if isinstance(value, Decimal):
+        return value
+    return Decimal(str(value))
+
+
+def _q_money(value) -> Decimal:
+    return _to_decimal(value).quantize(MONEY_QUANT, rounding=ROUND_HALF_UP)
@@
 def _connect(db_path: str | Path) -> sqlite3.Connection:
@@
     conn.row_factory = sqlite3.Row
     return conn
+
+
+def _get_user_version(conn: sqlite3.Connection) -> int:
+    return int(conn.execute("PRAGMA user_version").fetchone()[0])
+
+
+def _set_user_version(conn: sqlite3.Connection, version: int) -> None:
+    conn.execute(f"PRAGMA user_version = {int(version)}")
+
+
+def _create_schema_v1(conn: sqlite3.Connection) -> None:
+    conn.execute(
+        """
+        CREATE TABLE IF NOT EXISTS trades (
+            id INTEGER PRIMARY KEY AUTOINCREMENT,
+            executed_at TEXT NOT NULL,
+            side TEXT NOT NULL CHECK (side IN ('Buy', 'Sell')),
+            ticker TEXT NOT NULL,
+            qty INTEGER NOT NULL CHECK (qty > 0),
+            price REAL NOT NULL CHECK (price >= 0),
+            value REAL NOT NULL CHECK (value >= 0),
+            shares_before INTEGER NOT NULL CHECK (shares_before >= 0),
+            shares_after INTEGER NOT NULL CHECK (shares_after >= 0),
+            cash_before REAL NOT NULL,
+            cash_after REAL NOT NULL,
+            reflection TEXT NOT NULL
+        )
+        """
+    )
+    conn.execute(
+        """
+        CREATE INDEX IF NOT EXISTS idx_trades_executed_at
+        ON trades (executed_at, id)
+        """
+    )
+
+
+def _migrate_v1_to_v2(conn: sqlite3.Connection) -> None:
+    # Add idempotency key column for duplicate-submit protection.
+    # NULL allowed for legacy rows.
+    conn.execute("ALTER TABLE trades ADD COLUMN idempotency_key TEXT")
+    conn.execute(
+        """
+        CREATE UNIQUE INDEX IF NOT EXISTS ux_trades_idempotency_key
+        ON trades (idempotency_key)
+        WHERE idempotency_key IS NOT NULL
+        """
+    )
+
+
+def _apply_migrations(conn: sqlite3.Connection) -> None:
+    current = _get_user_version(conn)
+
+    if current == 0:
+        _create_schema_v1(conn)
+        _set_user_version(conn, 1)
+        current = 1
+        logger.info("db_migration_applied", extra={"from_version": 0, "to_version": 1})
+
+    if current < 2:
+        _migrate_v1_to_v2(conn)
+        _set_user_version(conn, 2)
+        current = 2
+        logger.info("db_migration_applied", extra={"from_version": 1, "to_version": 2})
+
+    # Safety: ensure latest base index always exists.
+    conn.execute(
+        """
+        CREATE INDEX IF NOT EXISTS idx_trades_executed_at
+        ON trades (executed_at, id)
+        """
+    )
@@
 def init_db(db_path: str | Path) -> None:
-    """Create the trade ledger table if it does not already exist."""
+    """Create / migrate trade ledger schema."""
     with _connect(db_path) as conn:
-        conn.execute(
-            """
-            CREATE TABLE IF NOT EXISTS trades (
-                id INTEGER PRIMARY KEY AUTOINCREMENT,
-                executed_at TEXT NOT NULL,
-                side TEXT NOT NULL CHECK (side IN ('Buy', 'Sell')),
-                ticker TEXT NOT NULL,
-                qty INTEGER NOT NULL CHECK (qty > 0),
-                price REAL NOT NULL CHECK (price >= 0),
-                value REAL NOT NULL CHECK (value >= 0),
-                shares_before INTEGER NOT NULL CHECK (shares_before >= 0),
-                shares_after INTEGER NOT NULL CHECK (shares_after >= 0),
-                cash_before REAL NOT NULL,
-                cash_after REAL NOT NULL,
-                reflection TEXT NOT NULL
-            )
-            """
-        )
-        conn.execute(
-            """
-            CREATE INDEX IF NOT EXISTS idx_trades_executed_at
-            ON trades (executed_at, id)
-            """
-        )
+        _apply_migrations(conn)
@@
 def _row_to_trade(row: sqlite3.Row) -> dict[str, Any]:
@@
         "shares_after": int(row["shares_after"]),
         "cash_before": float(row["cash_before"]),
         "cash_after": float(row["cash_after"]),
         "reflection": row["reflection"],
+        "idempotency_key": row["idempotency_key"] if "idempotency_key" in row.keys() else None,
     }
@@
 def load_trades(db_path: str | Path) -> list[dict[str, Any]]:
@@
         rows = conn.execute(
             """
             SELECT id, executed_at, side, ticker, qty, price, value,
-                   shares_before, shares_after, cash_before, cash_after, reflection
+                   shares_before, shares_after, cash_before, cash_after, reflection, idempotency_key
             FROM trades
             ORDER BY id
             """
         ).fetchall()
@@
 def record_trade(db_path: str | Path, trade: dict[str, Any]) -> int:
-    """Persist one committed buy/sell transaction and return its row id."""
+    """Persist one committed buy/sell transaction and return its row id.
+
+    Raises:
+        sqlite3.IntegrityError: e.g., duplicate idempotency_key
+    """
     init_db(db_path)
     with _connect(db_path) as conn:
-        cursor = conn.execute(
-            """
-            INSERT INTO trades (
-                executed_at, side, ticker, qty, price, value,
-                shares_before, shares_after, cash_before, cash_after, reflection
-            )
-            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
-            """,
-            (
-                trade["time"],
-                trade["side"],
-                trade["ticker"],
-                int(trade["qty"]),
-                float(trade["price"]),
-                float(trade["value"]),
-                int(trade["shares_before"]),
-                int(trade["shares_after"]),
-                float(trade["cash_before"]),
-                float(trade["cash_after"]),
-                trade.get("reflection", ""),
-            ),
-        )
-        return int(cursor.lastrowid)
+        try:
+            cursor = conn.execute(
+                """
+                INSERT INTO trades (
+                    executed_at, side, ticker, qty, price, value,
+                    shares_before, shares_after, cash_before, cash_after, reflection, idempotency_key
+                )
+                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
+                """,
+                (
+                    trade["time"],
+                    trade["side"],
+                    trade["ticker"],
+                    int(trade["qty"]),
+                    float(_q_money(trade["price"])),
+                    float(_q_money(trade["value"])),
+                    int(trade["shares_before"]),
+                    int(trade["shares_after"]),
+                    float(_q_money(trade["cash_before"])),
+                    float(_q_money(trade["cash_after"])),
+                    trade.get("reflection", ""),
+                    trade.get("idempotency_key"),
+                ),
+            )
+        except sqlite3.IntegrityError:
+            logger.warning(
+                "trade_insert_integrity_error",
+                extra={"event": "duplicate_or_constraint", "trade": json.dumps({k: str(v) for k, v in trade.items()})},
+            )
+            raise
+
+        row_id = int(cursor.lastrowid)
+        logger.info(
+            "trade_recorded",
+            extra={"trade_id": row_id, "side": trade["side"], "ticker": trade["ticker"], "qty": int(trade["qty"])},
+        )
+        return row_id
@@
 def clear_trades(db_path: str | Path) -> None:
@@
     init_db(db_path)
     with _connect(db_path) as conn:
         conn.execute("DELETE FROM trades")
+    logger.info("trades_cleared")
@@
 def rebuild_portfolio(
@@
-    cash = float(starting_cash)
+    cash = _q_money(starting_cash)
     holdings: dict[str, int] = {}
@@
-        value = float(trade["value"])
+        value = _q_money(trade["value"])
@@
         if trade["side"] == "Buy":
-            cash -= value
+            cash = _q_money(cash - value)
             holdings[ticker] = holdings.get(ticker, 0) + qty
         elif trade["side"] == "Sell":
-            cash += value
+            cash = _q_money(cash + value)
             holdings[ticker] = holdings.get(ticker, 0) - qty
@@
-    return cash, holdings
+    return float(cash), holdings
*** End Patch