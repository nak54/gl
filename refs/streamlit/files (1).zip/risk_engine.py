*** Begin Patch
*** Update File: risk_engine.py
@@
-from dataclasses import dataclass, field
-from typing import Optional, Union
+from dataclasses import dataclass
+from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
+from typing import Optional
@@
 STATE_META = {
@@
 }
+
+
+# ----------------------------
+# Decimal helpers
+# ----------------------------
+
+MONEY_QUANT = Decimal("0.01")
+
+
+def to_decimal(value) -> Decimal:
+    """Convert int/float/str/Decimal to Decimal safely via string conversion."""
+    if isinstance(value, Decimal):
+        return value
+    try:
+        return Decimal(str(value))
+    except (InvalidOperation, ValueError, TypeError):
+        raise ValueError(f"Cannot convert value={value!r} to Decimal")
+
+
+def quantize_money(amount: Decimal) -> Decimal:
+    return amount.quantize(MONEY_QUANT, rounding=ROUND_HALF_UP)
@@
 def format_value(value: Optional[float], unit: str) -> str:
@@
     if value is None:
         return "—"
     if unit == "currency":
-        return f"${value:,.2f}"
+        d = quantize_money(to_decimal(value))
+        return f"${d:,.2f}"
     if unit == "percent":
-        return f"{value:.1f}%"
+        return f"{float(value):.1f}%"
     # ratio (P/E, D/E, current ratio, beta, ATR handled as percent above)
-    return f"{value:.2f}"
+    return f"{float(value):.2f}"
@@
 @dataclass
 class Flag:
     severity: str      # "risky" | "missing" | "watch"
-    source: str         # "kpi" | "trade"
+    source: str        # "kpi" | "trade"
     key: str
     label: str
     detail: str
@@
 def buy_trade_flags(
@@
 ) -> list:
     """All flags for a BUY order, per spec section 5. Returns list[Flag]."""
     flags: list[Flag] = []
-    price = stock["price"]
+    price = to_decimal(stock["price"])
+    resulting_value = to_decimal(existing_shares + order_qty) * price
+    portfolio_value_d = to_decimal(portfolio_value)
 
-    # --- Position size cap: resulting TOTAL position vs portfolio value ---
-    resulting_value = (existing_shares + order_qty) * price
-    cap_value = (position_cap_pct / 100.0) * portfolio_value if portfolio_value else 0
-    if portfolio_value and resulting_value > cap_value:
-        pct_of_portfolio = (resulting_value / portfolio_value) * 100 if portfolio_value else 0
+    cap_value = (to_decimal(position_cap_pct) / Decimal("100")) * portfolio_value_d if portfolio_value_d > 0 else Decimal("0")
+    if portfolio_value_d > 0 and resulting_value > cap_value:
+        pct_of_portfolio = (resulting_value / portfolio_value_d) * Decimal("100")
         flags.append(Flag(
             severity=STATE_RISKY,
             source="trade",
@@
                 f"After this order you would hold {existing_shares + order_qty} shares "
-                f"({format_value(resulting_value, 'currency')}), which is "
-                f"{pct_of_portfolio:.1f}% of total portfolio value "
-                f"({format_value(portfolio_value, 'currency')}). The cap is "
+                f"({format_value(float(resulting_value), 'currency')}), which is "
+                f"{float(pct_of_portfolio):.1f}% of total portfolio value "
+                f"({format_value(float(portfolio_value_d), 'currency')}). The cap is "
                 f"{position_cap_pct:.0f}% of total resulting position, including any shares you "
                 f"already hold."
             ),
@@
     already_flagged_keys = {f.key for f in flags}
     if vol_row and vol_res is not None and vol_res["value"] is not None and vol_res["value"] < vol_row["watch"]:
-        # covered by the explicit avg-volume trade rule above; don't duplicate as a generic KPI flag
         already_flagged_keys.add("avg_dollar_volume")
+
     for key, res in kpi_results.items():
         if key in already_flagged_keys:
             continue
*** End Patch