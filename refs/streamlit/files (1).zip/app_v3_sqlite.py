*** Begin Patch
*** Update File: app_v3_sqlite.py
@@
-# ... keep existing imports ...
 import copy
+import logging
+import uuid
+from decimal import Decimal, ROUND_HALF_UP
 from datetime import datetime
 from pathlib import Path
 
 import streamlit as st
@@
 from data import DEFAULT_THRESHOLDS, DEFAULT_KEY_KPIS, SAMPLE_STOCKS
 import risk_engine as re_
 from trade_store import clear_trades, init_db, load_trades, rebuild_portfolio, record_trade
+
+# --- add logging setup near top ---
+logging.basicConfig(
+    level=logging.INFO,
+    format="%(asctime)s %(levelname)s %(name)s %(message)s",
+)
+logger = logging.getLogger(__name__)
@@
 POSITION_CAP_PCT = 15.0
+
+MONEY_QUANT = Decimal("0.01")
+
+
+def _to_decimal(v) -> Decimal:
+    return Decimal(str(v))
+
+
+def _q_money(v) -> Decimal:
+    return _to_decimal(v).quantize(MONEY_QUANT, rounding=ROUND_HALF_UP)
@@
 def init_state():
@@
     ss.nav = "Dashboard"
     ss.nav_radio = "Dashboard"
     ss.pending_nav = None
+    ss.pending_trade_idempotency_key = None  # NEW
@@
     if st.button("Continue to Pre-Trade Risk Summary", type="primary", disabled=bool(errors)):
         ss.trade_stage = "risk_gate"
         ss.reflection_text = ""
+        ss.pending_trade_idempotency_key = str(uuid.uuid4())  # NEW: one key per staged order
         st.rerun()
@@
 def _execute_trade(stock, side, qty):
@@
     ss = st.session_state
     ticker = stock["ticker"]
-    price = stock["price"]
+    price = _q_money(stock["price"])
@@
     if side not in {"Buy", "Sell"}:
         st.error("Order type must be Buy or Sell.")
         return False
 
+    if not ss.get("pending_trade_idempotency_key"):
+        # Defensive fallback for direct/racy submits
+        ss.pending_trade_idempotency_key = str(uuid.uuid4())
+
     # Re-read the durable ledger immediately before commit so validation uses
     # the latest persisted cash and holdings.
     refresh_portfolio_from_db()
 
-    value = qty * price
-    cash_before = float(ss.cash)
+    value = _q_money(Decimal(qty) * price)
+    cash_before = _q_money(ss.cash)
     current_shares = int(ss.holdings.get(ticker, 0))
@@
     if side == "Buy":
-        cash_after = cash_before - value
+        cash_after = _q_money(cash_before - value)
         shares_after = current_shares + qty
     else:
-        cash_after = cash_before + value
+        cash_after = _q_money(cash_before + value)
         shares_after = current_shares - qty
@@
         "ticker": ticker,
         "qty": qty,
-        "price": price,
-        "value": value,
+        "price": float(price),
+        "value": float(value),
         "shares_before": current_shares,
         "shares_after": shares_after,
-        "cash_before": cash_before,
-        "cash_after": cash_after,
+        "cash_before": float(cash_before),
+        "cash_after": float(cash_after),
         "reflection": ss.reflection_text.strip(),
+        "idempotency_key": ss.pending_trade_idempotency_key,  # NEW
     }
 
     try:
         transaction["id"] = record_trade(ss.db_path, transaction)
     except Exception as exc:
+        # Duplicate idempotency key => likely double-submit on rerun edge.
+        if "UNIQUE constraint failed: trades.idempotency_key" in str(exc):
+            st.warning("This trade was already submitted once. Duplicate submission was ignored.")
+            logger.warning("duplicate_trade_blocked", extra={"ticker": ticker, "side": side, "qty": qty})
+            # Treat as success path from UX perspective
+            refresh_portfolio_from_db()
+            ss.trade_stage = "ticket"
+            ss.trade_qty = 1
+            ss.reflection_text = ""
+            ss.trade_form_id += 1
+            ss.pending_trade_idempotency_key = None
+            queue_navigation("Dashboard")
+            return True
+
         st.error(f"Trade was not recorded because SQLite returned an error: {exc}")
+        logger.exception("trade_record_failed")
         return False
@@
     refresh_portfolio_from_db()
     ss.last_transaction = transaction
+
+    logger.info(
+        "trade_committed",
+        extra={"trade_id": transaction["id"], "side": side, "ticker": ticker, "qty": qty},
+    )
@@
     ss.trade_qty = 1
     ss.reflection_text = ""
     ss.trade_form_id += 1
+    ss.pending_trade_idempotency_key = None  # NEW: retire key after success
 
     queue_navigation("Dashboard")
     return True
*** End Patch